%% Author: Kieran Lynch
% Date: 13/06/23
% Contact: kieran.lynch@manchester.ac.uk

function UserPWD = SetPWD

UserPWD = '';

%e.g., UserPWD  = 'C:/Documents...';

end