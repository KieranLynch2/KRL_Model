%% User Inputs
OutputFileName = 'Zirc4QuenchTest.mat'; %Zirc2TestNo, Zirc4TestNo, Zirc4Test
Stage = 1;
GraphTitle = '';
xmax = 200; % set xscale limit

%% Code - don't change. Copy to new script to change.

load (['..\..\Outputs\' OutputFileName])
VoluFrac = sum(Outputs(Stage).VolFrac,2);
Time_secs = Outputs(Stage).Time';
semilogx(Time_secs,VoluFrac.*100,'LineWidth',2)
xlabel('Time / s')
ylabel('Volume Fraction')
title([GraphTitle])
