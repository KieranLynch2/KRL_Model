%% User Inputs
OutputFileName = 'TestRunWQ_2000Kps.mat'; %Zirc2TestNo, Zirc4TestNo, Zirc4Test
Stage = 1;
GraphTitle = '';
xmax = 200; % set xscale limit

%% Code - don't change. Copy to new script to change.

load (['../../Outputs/' OutputFileName])

nsum = sum(Outputs(Stage).NumDen);

n = (Outputs(Stage).NumDen_ln);

nsum = sum(n);

rad =  Outputs(Stage).Radius(1,:)'.*1e9;
plot(rad.*2,nsum,'-','LineWidth',2,'Color',[0.8500 0.3250 0.0980])
xlim([0 500])
meanrad = (sum(r(1,:).*nsum))/sum(nsum);

a=5;
%Below isn't accurate as it shows evolution of mean radius in each segement
%without considering how the number density/contribution of each segemnt to
%mean radius.
% MeanRadius_nm = sum(Outputs(Stage).MeanRad,2);
% Time_secs = Outputs(Stage).Time';
% semilogx(Time_secs,MeanRadius_nm,'LineWidth',2)
% xlabel('Time / s')
% ylabel('Mean radius / nm')
% title([GraphTitle])
