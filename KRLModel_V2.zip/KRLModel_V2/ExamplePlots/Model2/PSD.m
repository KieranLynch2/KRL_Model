%% User Inputs
OutputFileName = 'TestRunAQ_6Kps.mat'; %Zirc2TestNo, Zirc4TestNo, Zirc4Test
Stage = 1;
GraphTitle = '';
xmax = 1000; % set xscale limit

%% Code - don't change. Copy to new script to change.
% load (['../../Outputs/' OutputFileName])
% 
% rad =  Outputs(Stage).Radius(1,:)'.*1e9;
% nd = sum(Outputs(Stage).NumDen)'.*1e-18;
% plot(rad.*2,nd,'-','LineWidth',2,'Color',[0 0.4470 0.7410])
% hold on
% rad_sog = Outputs(Stage).Radius_ln(1,:)'.*1e9;
% nd_sog = sum(Outputs(Stage).NumDen_ln)'.*1e-18;
% plot(rad_sog.*2,nd_sog,'-','LineWidth',2,'Color',[0.8500 0.3250 0.0980])
% xlabel('SPP diameter / nm')
% ylabel('Number density / \mum^{-3}')
% title([GraphTitle])
% xlim([0 xmax])
% legend('KWN original output','SOG adjusted')


%% Code to seperate GB and GI SPPs

load (['../../Outputs/' OutputFileName])

rad =  Outputs(Stage).Radius(1,:)'.*1e9;
ndGB = (Outputs(Stage).NumDen(NSegs,:))'.*1e-18;
ndGI = sum(Outputs(Stage).NumDen(1:NSegs-1,:))'.*1e-18;

plot(rad.*2,ndGB,'-','LineWidth',2,'Color',[0 0.4470 0.7410])
hold on
plot(rad.*2,ndGI,'-','LineWidth',2,'Color',[0.8500 0.3250 0.0980])

xlabel('SPP diameter / nm')
ylabel('Number density / \mum^{-3}')
title([GraphTitle])
xlim([0 xmax])
legend('Grain boundary','Grain Interior')
