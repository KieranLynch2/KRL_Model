%% User Inputs
OutputFileName = 'Zirc4QuenchTest.mat'; %Zirc2TestNo, Zirc4TestNo, Zirc4Test
Stage = 1;
GraphTitle = '';
xmax = 200; % set xscale limit

%% Code - don't change. Copy to new script to change.
load (['..\..\Outputs\' OutputFileName])
NumDen = sum(Outputs(Stage).NumDenwTime,2);
Time_secs = Outputs(Stage).Time';
loglog(Time_secs,NumDen,'LineWidth',2)
xlabel('Time / s')
ylabel('Number Density / SPPs \mum^{-3}')
title([GraphTitle])

% if Alloy == 4 && Irradiation == 0
%     NumDen =  Outputs(Stage).NumDenwTime';
%     Time_secs = Outputs(Stage).Time'; 
%     semilogx(Time_secs,NumDen,'LineWidth',2)
%     xlabel('Time / s')
%     ylabel('Number Density / SPPs \mum^{-3}')
%     title([GraphTitle])
% elseif Alloy == 2 && Irradiation == 0
%     NumDen = Outputs(Stage).MeanRad';
%     Time_secs = Outputs(Stage).Time';
%     NumDenFeNi =  Outputs(Stage).NumDenwTimeFeNi';
%     semilogx(Time_secs,NumDen,'LineWidth',2) 
%     hold on
%     semilogx(Time_secs,NumDenFeNi,'LineWidth',2)
%     xlabel('Time / s')
%     ylabel('Number Density / SPPs \mum^{-3}')
%     title([GraphTitle])
%     legend('Fe-Cr','Fe-Ni')
% elseif Alloy == 4 && Irradiation == 1
%     warning('At high fluences this metric can be misleading due to the modelling technique used to re-bin SPPs based on dissolution rates.')
%     NumDen = Outputs(Stage).Npart;
%     Time_secs = Outputs(Stage).Time';
%     plot(Time_secs,NumDen,'LineWidth',2)
%     xlabel('Time / s')
%     ylabel('Number Density / SPPs \mum^{-3}')
%     title([GraphTitle])
% end