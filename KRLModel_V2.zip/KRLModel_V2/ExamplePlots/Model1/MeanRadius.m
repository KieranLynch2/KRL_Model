%% User Inputs
OutputFileName = 'Zirc2TestNo.mat'; %Zirc2TestNo, Zirc4TestNo, Zirc4Test
Alloy = 2; % 2 or 4
Stage = 1;
Irradiation = 0; %1 = irradiation, 0 = no irradiation
GraphTitle = '';
xmax = 200; % set xscale limit

load (['..\..\Outputs\' OutputFileName])
if Alloy == 4 && Irradiation == 0
    MeanRadius_nm = Outputs(Stage).MeanRad';
    Time_secs = Outputs(Stage).Time';
    semilogx(Time_secs,MeanRadius_nm,'LineWidth',2)
    xlabel('Time / s')
    ylabel('Mean radius / nm')
    title([GraphTitle])
elseif Alloy == 2 && Irradiation == 0
    MeanRadius_nm = Outputs(Stage).MeanRad';
    Time_secs = Outputs(Stage).Time';
    MeanRadius_FeNi_nm = Outputs(Stage).MeanRadFeNi';
    semilogx(Time_secs,MeanRadius_nm,'LineWidth',2)
    hold on
    semilogx(Time_secs,MeanRadius_FeNi_nm,'LineWidth',2)
    xlabel('Time / s')
    ylabel('Mean radius / nm')
    title([GraphTitle])
    legend('Fe-Cr','Fe-Ni')
elseif Alloy == 4 && Irradiation == 1
    warning('At high fluences this metric can be misleading due to the modelling technique used to re-bin SPPs based on dissolution rates.')
        MeanRadius_nm = Outputs(Stage).MeanRad';
    Time_secs = Outputs(Stage).Time';
    plot(Time_secs,MeanRadius_nm,'LineWidth',2)
    xlabel('Time / s')
    ylabel('Mean radius / nm')
    title([GraphTitle])
end