%% User Inputs
OutputFileName = 'Zirc4Test.mat'; %Zirc2TestNo, Zirc4TestNo, Zirc4Test
Alloy = 4; % 2 or 4
Stage = 1;
Irradiation = 1; %1 = irradiation, 0 = no irradiation
GraphTitle = '';
xmax = 200; % set xscale limit

load (['..\..\Outputs\' OutputFileName])
if Alloy == 4 && Irradiation == 0
    VoluFrac = Outputs(Stage).VolFrac';
    Time_secs = Outputs(Stage).Time';
    semilogx(Time_secs,VoluFrac.*100,'LineWidth',2)
    xlabel('Time / s')
    ylabel('Volume Fraction')
    title([GraphTitle])
elseif Alloy == 2 && Irradiation == 0
    VoluFrac = Outputs(Stage).VolFrac';
    VolFracFeNi = Outputs(Stage).VolFracFeNi';
    Time_secs = Outputs(Stage).Time';
    NumDenFeNi =  Outputs(Stage).NumDenwTimeFeNi';
    semilogx(Time_secs,VoluFrac.*100,'LineWidth',2)
    hold on
    semilogx(Time_secs,VolFracFeNi.*100,'LineWidth',2)
    xlabel('Time / s')
    ylabel('Volume Fraction')
    title([GraphTitle])
    legend('Fe-Cr','Fe-Ni')
elseif Alloy == 4 && Irradiation == 1
    error('N/A')
%NA
end