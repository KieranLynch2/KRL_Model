%% User Inputs
OutputFileName = 'Zirc2TestNo.mat'; %Zirc2TestNo, Zirc4TestNo, Zirc4Test
Alloy = 2; % 2 or 4
Stage = 1;
Irradiation = 0; %1 = irradiation, 0 = no irradiation
GraphTitle = '';
xmax = 200; % set xscale limit

load (['..\..\Outputs\' OutputFileName])
if Alloy == 4 && Irradiation == 0
    NumDen =  Outputs(Stage).NumDenwTime';
    Time_secs = Outputs(Stage).Time'; 
    semilogx(Time_secs,NumDen,'LineWidth',2)
    xlabel('Time / s')
    ylabel('Number Density / SPPs \mum^{-3}')
    title([GraphTitle])
elseif Alloy == 2 && Irradiation == 0
    NumDen = Outputs(Stage).MeanRad';
    Time_secs = Outputs(Stage).Time';
    NumDenFeNi =  Outputs(Stage).NumDenwTimeFeNi';
    semilogx(Time_secs,NumDen,'LineWidth',2) 
    hold on
    semilogx(Time_secs,NumDenFeNi,'LineWidth',2)
    xlabel('Time / s')
    ylabel('Number Density / SPPs \mum^{-3}')
    title([GraphTitle])
    legend('Fe-Cr','Fe-Ni')
elseif Alloy == 4 && Irradiation == 1
    warning('At high fluences this metric can be misleading due to the modelling technique used to re-bin SPPs based on dissolution rates.')
    NumDen = Outputs(Stage).Npart;
    Time_secs = Outputs(Stage).Time';
    plot(Time_secs,NumDen,'LineWidth',2)
    xlabel('Time / s')
    ylabel('Number Density / SPPs \mum^{-3}')
    title([GraphTitle])
end