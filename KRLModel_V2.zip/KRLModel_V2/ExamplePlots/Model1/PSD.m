%% User Inputs
OutputFileName = 'Zirc4Test.mat'; %Zirc2TestNo, Zirc4TestNo, Zirc4Test
Alloy = 4; % 2 or 4
Stage = 1; 
Irradiation = 0; %1 = irradiation, 0 = no irradiation
GraphTitle = '';
xmax = 200; % set xscale limit

%% Code - don't change. Copy to new script to change.
load (['..\..\Outputs\' OutputFileName])
if Alloy == 4 && radflag == 0
        rad = Outputs(Stage).Radius'.*1e9;
        nd =  Outputs(Stage).NumDen'.*1e-18;
        rad_sog = Outputs(Stage).Radius_ln'.*1e9;
        nd_sog = Outputs(Stage).NumDen_ln'.*1e-18;
        plot(rad.*2,nd,'-','LineWidth',2,'Color',[0 0.4470 0.7410])
        hold on
        plot(rad_sog.*2,nd_sog,'-','LineWidth',2,'Color',[0.8500 0.3250 0.0980])
        xlabel('SPP diameter / nm')
        ylabel('Number density / \mum^{-3}')
        title([GraphTitle])
        xlim([0 xmax])
        legend('KWN original output','SOG adjusted')
elseif Alloy == 2 && radflag == 0
        rad = Outputs(Stage).Radius'.*1e9;
        nd =  Outputs(Stage).NumDen'.*1e-18;
        rad_FeNi = Outputs(Stage).RadiusFeNi'.*1e9;
        nd_FeNi = Outputs(Stage).NumDenFeNi'.*1e-18;
        rad_sog = Outputs(Stage).Radius_ln'.*1e9;
        nd_sog = Outputs(Stage).NumDen_ln'.*1e-18;
        rad_sog_FeNi = Outputs(Stage).Radius_lnFeNi'.*1e9;
        nd_sog_FeNi = Outputs(Stage).NumDen_lnFeNi'.*1e-18;
        plot(rad.*2,nd,'--','LineWidth',2,'Color',[0 0.4470 0.7410])
        hold on
        plot(rad_sog.*2,nd_sog,'-','LineWidth',2,'Color',[0 0.4470 0.7410])
        plot(rad_FeNi.*2,nd_FeNi,'--','LineWidth',2,'Color',[0.8500 0.3250 0.0980])
        plot(rad_sog_FeNi.*2,nd_sog_FeNi,'-','LineWidth',2,'Color',[0.8500 0.3250 0.0980])
        xlabel('SPP diameter / nm')
        ylabel('Number density / \mum^{-3}')
        title([GraphTitle])
        xlim([0 xmax])
        legend('KWN original output - FeCr','SOG adjusted - FeCr','KWN original output - FeNi','SOG adjusted - FeNi')
elseif Alloy == 4 && radflag == 1
        plot((r_init.*2).*(10^9),n_init.*(10^-18),'-','LineWidth',2)
        hold on
        r_cryst(1) = 0;
        r_cryst_zero = find(r_cryst <= 0);
        n_cryst(r_cryst_zero) = 0;
        r_cryst_nonzero = find(r_cryst > 0);
        r_cryst_plot = r_cryst(r_cryst_nonzero);
        n_cryst_plot = n_cryst(r_cryst_nonzero);
        plot((r_cryst_plot.*2).*(10^9),n_cryst_plot.*(10^-18),'-','LineWidth',2)
        plot((Outputs(Stage).Radius.*2).*(10^9),Outputs(Stage).NumDen.*(10^-18),'-','LineWidth',2)
        legend('Initial SPP size distribution','Crystalline cores','Final SPP size distribution');
        xlabel('SPP diameter / nm')
        ylabel('Number density / \mum^{-3}')
        title([GraphTitle])
        xlim([0 xmax])
end
