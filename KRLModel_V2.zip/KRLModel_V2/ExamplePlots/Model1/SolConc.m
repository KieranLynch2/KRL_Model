%% User Inputs
OutputFileName = 'Zirc4TestNo.mat'; %Zirc2TestNo, Zirc4TestNo, Zirc4Test
Alloy = 4; % 2 or 4
Stage = 1;
Irradiation = 0; %1 = irradiation, 0 = no irradiation
GraphTitle = '';
xmax = 200; % set xscale limit

load (['..\..\Outputs\' OutputFileName])
if Alloy == 4 && Irradiation == 0
    SoluConc = Outputs(Stage).SolConc';
    Time_secs = Outputs(Stage).Time';
    semilogx(Time_secs,SoluConc.*100,'LineWidth',2)
    xlabel('Time / s')
    ylabel('Matrix solute concetration / at. %')
    title([GraphTitle])
elseif Alloy == 2 && Irradiation == 0
    SoluConc = Outputs(Stage).SolConc';
    SoluConcFeNi = Outputs(Stage).SolConcFeNi';
    Time_secs = Outputs(Stage).Time';
    NumDenFeNi =  Outputs(Stage).NumDenwTimeFeNi';
    semilogx(Time_secs,SoluConc.*100,'LineWidth',2)
    hold on
    semilogx(Time_secs,SoluConcFeNi.*100,'LineWidth',2)
    xlabel('Time / s')
    ylabel('Matrix solute concetration / at. %')
    title([GraphTitle])
    legend('Fe-Cr','Fe-Ni')
elseif Alloy == 4 && Irradiation == 1
    FeReleaseOnAmorph_atfrac = Outputs(Stage).FeAmorph';
    FeReleaseTotal_atfrac = Outputs(Stage).FeTotal';
    CrReleaseTotal_atfrac = Outputs(Stage).Cr';
    Time_secs = Outputs(Stage).Time';
    plot(Time_secs,FeReleaseOnAmorph_atfrac.*100,'LineWidth',2)
    hold on
    plot(Time_secs,FeReleaseTotal_atfrac.*100,'LineWidth',2)
    plot(Time_secs,CrReleaseTotal_atfrac.*100,'LineWidth',2)
    xlabel('Time / s')
    ylabel('Matrix solute concetration / at. %')
    title([GraphTitle])
    legend('Fe released on amorphization','Total Fe release','Cr release')
end