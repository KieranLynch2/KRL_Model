%% Author: Kieran Lynch
% Date: 07/04/25
% Contact: kieran.lynch@manchester.ac.uk

function UserPWD = SetPWD

UserPWD =   '';

%e.g.:
% UserPWD = 'C:/user/documents/KRLModel_V2

end