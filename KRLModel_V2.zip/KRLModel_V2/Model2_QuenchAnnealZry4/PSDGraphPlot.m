function PSDGraphPlot(PSDStage,Outputs,IterCount)


%Determine how many subplots to show
if length(PSDStage) <= 3; m = 1; n = 3; end
if length(PSDStage) > 3 && length(PSDStage) <= 6; m = 2; n = 3; end
if length(PSDStage) > 6 && length(PSDStage) <= 9; m = 3; n = 3; end

if ismember(IterCount,PSDStage) == 1
        SubplotNo = find(PSDStage==IterCount);
        subplot(m,n,SubplotNo); hold on;
        rad = Outputs(IterCount).Radius(1,:)'.*1e9;
        nd =  sum(Outputs(IterCount).NumDen)'.*1e-18;
        rad_sog = Outputs(IterCount).Radius_ln(1,:)'.*1e9;
        nd_sog = sum(Outputs(IterCount).NumDen_ln)'.*1e-18;
        plot(rad.*2,nd,'-','LineWidth',2,'Color',[0 0.4470 0.7410])
        plot(rad_sog.*2,nd_sog,'-','LineWidth',2,'Color',[0.8500 0.3250 0.0980])
        xlabel('SPP diameter / nm')
        ylabel('Number density / \mum^{-3}')
        title(['Zircaloy-4 Stage ' num2str(IterCount)])
        CurModalDiameter = ModalDiameterDetermine(rad,nd);
        xmax = CurModalDiameter*3;
        xlim([0 xmax])
        legend('KWN original output','SOG adjusted')

        drawnow()
        pause(3)
end


end
