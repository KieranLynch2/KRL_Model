%% This is the master run file for quench and quench/annealing
function OutputStatement = ScriptToRun_Model2_QA(tcprof,Mode_QuenchAnneal,FeConc,CrConc,radflag,OFN,PSDSnap,PSDStage,sfen,sfengb,GBen,w0,PostQAnnealOnly,DiffFlag,RangeValue)


%Nstages
NSteps = size(tcprof,1);

Outputs = struct;


if PostQAnnealOnly == 0
    r_in = []; n_in = []; rb_in = []; 
    if Mode_QuenchAnneal == 1 && NSteps == 1
        error('No annealing steps. Change mode to Quench only.')
    end
end

IterCount = 1;

NSegs = 2; %%KRL version 3 only two segments being modelled (GB and average comp over GI) 16/12/24


%Changing diffusivity of Cr in matrix based on the initial quenching
%condition to produce error ranges - 03/04/2025

% if strcmp(RangeValue,'Low')
%     DiffFlag = 1; %Lowest diffusivity of Cr in matrix
% elseif strcmp(RangeValue,'Av')
%     DiffFlag = 2;
% elseif strcmp(RangeValue,'High')
%     DiffFlag = 3;
% end

while IterCount <= NSteps
    tcprof_in = tcprof(IterCount,:);
    if IterCount == 1
        if PostQAnnealOnly == 0
            cd Quench/
            [r,n,rb,r_ln,n_ln,rbarout,vfout,tkout,tout,xbout,npartout,SolSplitout,xbchangeFickout,QR,NSegs,FeConc,CrConc,sfen,sfengb,GBen,w0] = ScriptToRun_Quench(tcprof_in,FeConc,CrConc,radflag,OFN,NSegs,sfen,sfengb,GBen,w0);
            TotModeOutDia = [];
            cd ../
        elseif PostQAnnealOnly == 1
           tcprofAnneal = tcprof;
           OFN_new = OFN;
            cd ../
            load(CurFile)
            cd Model2_QuenchAnnealZry4_v1.1/
            cd PostQAnneal/
           tcprof_in = tcprofAnneal;
           OFN = OFN_new;
            [r,n,rb,r_ln,n_ln,rbarout,vfout,tkout,tout,xbout,npartout,xbchangeFickout,TotModeOutDia] = ScriptToRun_PostQuenchAnneal(tcprof_in,r_in,rb_in,n_in,xbout,SolSplitout,xbchangeFickout,TimeTotal,QR,NSegs,FeConc,CrConc,DiffFlag,PostQAnnealOnly);
            cd ../
        end
    else
        % Only run subsequent annealing if quench and anneal mode is selected
        if Mode_QuenchAnneal == 1
            cd PostQAnneal/
            [r,n,rb,r_ln,n_ln,rbarout,vfout,tkout,tout,xbout,npartout,xbchangeFickout,TotModeOut] = ScriptToRun_PostQuenchAnneal(tcprof_in,r_in,rb_in,n_in,xbout,SolSplitout,xbchangeFickout,TimeTotal,QR,NSegs,FeConc,CrConc,DiffFlag,PostQAnnealOnly);
            cd ../
        elseif PostQAnnealOnly == 1
            cd PostQAnneal/
            [r,n,rb,r_ln,n_ln,rbarout,vfout,tkout,tout,xbout,npartout,xbchangeFickout,TotModeOut] = ScriptToRun_PostQuenchAnneal(tcprof_in,r_in,rb_in,n_in,xbout,SolSplitout,xbchangeFickout,TimeTotal,QR,NSegs,FeConc,CrConc,DiffFlag,PostQAnnealOnly);
            cd ../
        end
    end

    r_in = r; n_in = n; rb_in = rb; 
    
    %Outputs Struct
             TimeTotal = tout(end); %Carry the time through the loops
             Outputs(IterCount).Time = tout;
             Outputs(IterCount).SolConc = xbout;
             Outputs(IterCount).NumDenwTime = npartout;
             Outputs(IterCount).MeanRad = rbarout;
             Outputs(IterCount).VolFrac = vfout;
            Outputs(IterCount).Radius = r;
            Outputs(IterCount).NumDen = n;
            Outputs(IterCount).Radius_ln = r_ln;
            Outputs(IterCount).NumDen_ln = n_ln;
            Outputs(IterCount).ModalDia = TotModeOutDia;

        if PSDSnap == 1
           PSDGraphPlot(PSDStage,Outputs,IterCount)
        end

    IterCount = IterCount + 1;
end

%Write output files
Alloy = 4;
FeCrRatio = FeConc/CrConc;
WriteFileZry4QA(Outputs,r,n,r_ln,n_ln,Alloy,FeConc,CrConc,FeCrRatio,tcprof,OFN,NSegs);

% Save r and n now as one PSD so it can be used as an irradiation input.
rSegments = r;
nSegments = n;
r = r(1,:);
n = sum(n);

OFN_matlab = (['../Outputs/' OFN '.mat']); % Choose an output filename 
save([OFN_matlab])

OutputStatement = (['Simulation complete. Please check Outputs folder.']);


end