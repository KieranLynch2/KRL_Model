function [rc] = critrad_amorph(sfen,xa,xb,xc,vf,tk,vmol)
% function[rc] = critrad(sfen,xa,xbinst,tk)
% Calculates critical radius for growth/nucleation
%
% Inputs
% sfen      Interfacial energy of nuclei (J/m^2)
% xa        Equilibrium concentration of Zr in matrix at interface
% xb        Zr concentration in matrix (far field)
% xc        Zr concentration in dispersoids
% vf        Volume fraction of dispersoids
% tk        Temperature (K)
% Outputs
% rc        Critical radius (m)
%
%
% update mean matrix concentration
%
% RC = 1 FOR AMORPHOUS - all amorphous dissolve
%
%xbinst = xb - ((xc - xa) .* vf);
%gas = 8.31459;
%
% only calculate critical radius when xbinst>xa
%

  %
  % full expression for driving force from ideal solution model (Aaronson, Met Trans A, 23A, 1992 p.1915)
  %
  %driving_cryst = ((gas * tk)/vmol)*((xc.*log(xbinst./xa))+((1-xc).*log((1-xbinst)./(1-xa))));
  %
  % Shift (reduce) DG to account for higher G of amorphous structure
  % driving = driving_cryst - 2.14e8; % Using DHamorph from Massih
  % driving = driving_cryst - 4.44e8; % Using more accurate DHamorph 
  %driving = driving_cryst - 1.4803e9; % all particles > r=60nm will dissolve 
%
%fec = (1/c2) * (2 * sfen) * driving
%
% Modify driving force by strain energy
%stren = strain_co(0.017,0.34,0.31,48e9,75e9);
   %stren = 0;
%
   %resdrive = driving - stren;
   %rc = (2 * sfen)./(resdrive);
%
% if rc is -ve, there is no driving force for pptn. Make it massive
%if rc < 0, rc = 1; end
rc = 1; % ALL AMORPHOUS UNSTABLE AND WILL DISSOLVE RAPIDLY (INTERFACE CONTROL)
%if rc > 1e-3, rc = 1e-3; end
return