function [xbinst,xbinstgb] = xbinstCalcTest(xb,xc,xa,vf,GBWidth,d,h)


GBWidth = 8.15e-7;

Dist = 10e-9; %give width of 10 nm

MatrixDist = 0.9877;
PFZDist = 0.0123;


%sSay if want x % of solute attributed to GB region

ConcPerGB = 0.802;
ConcPerM = 0.198;

TotalArea = 0.0051*GBWidth;

%x is height of GB region (xbinstgb)
%y is height of matrix region (xbinst)
syms x y

eqns = [MatrixDist*y + PFZDist*x == TotalArea, PFZDist*x/(MatrixDist*y + PFZDist*x) == ConcPerGB, MatrixDist*y/(MatrixDist*y + PFZDist*x) == ConcPerM];

S = solve(eqns,[x,y]);

xbinst = (S.y)/GBWidth;
xbinstgb = (S.x)/GBWidth;

xbinst = double(xbinst);
xbinstgb = double(xbinstgb);




end