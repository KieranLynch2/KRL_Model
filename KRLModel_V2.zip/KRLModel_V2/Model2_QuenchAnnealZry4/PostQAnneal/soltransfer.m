function [xbinst,xbinstgb,TotalSolDist,xbinstTrack,xbinstgbTrack,vfTrack,vfgbTrack] = soltransfer(vfTrack,vfgbTrack,xa,xb,xc,h,d,firstit,TotalSolDist,xbinstTrack,xbinstgbTrack,vf,vfgb)

%function to calculate the trasnfer of solute from the matrix region to the
%grain boundary region during each iteration
%The movement of solute into GB region is going to be determined using
%sqrt(dt) approach
xbinstinit = xbinstTrack(end); %This will be xbinst at end of last iterataion
xbinstgbinit = xbinstgbTrack(end);
%Distance travelled by matrix solute
dist = sqrt(d*h);
TotalSolDist = [TotalSolDist dist];
TotDistAr = cumsum(TotalSolDist);
TotDist = TotDistAr(end);
%for xbinst calcs it I need to find the area/length of the zone which is
%used for, this can either be done using PFZ measurements of by calculating
%the distance moved by matrix solute each iteration and keeping track of it
%PFZ measurements are not turning out correclty at the moment, so i'll use
%distance moved by solute to determine answer.
%Gets a bit complex as precipitation is happening during the quench i.e. it
%is not just a case of solute diffusing from matrix to gb as a lot of the
%solute is pushed the the GB so there solute concentration there will be
%high (I think), might have to couple this with a grain growth model and
%predict the solute distribution across the grain as it transforms.

vfCurMax = vfTrack(end) + vfgbTrack(end); %The maxmimum current possible volume fraction
xbinstMax = xb - ((xc - xa) * vfCurMax);

%Keep track of each systems and total xbinst and vf
% if firstit == 1
%     xbinstTot = xb - ((xc - xa) * vfCurMax); %at firstit let growth etc play out naturally 
%     VfgbRat = vfgb/(vf+vfgb);
%     VfRat = vf/(vf+vfgb);
%     xbinst = xbinstTot*(1-VfRat);
%     xbinstgb = xbinstTot*(1-VfgbRat);
%     a = 4;
% elseif firstit > 1
    %after first it i need to keep track of the distance solute has
    %travelled which is essntially the PFZ assuming all solute in the GB
    %zone is used by the GB to grow
    if dist == 0
        xbinst = xbinstinit;
        xbinstgb = xbinstgbinit;
    else
    OrgRat = ((TotDist-dist)/TotDist);
    NewRat = ((dist)/TotDist);
    
    
    SolOrigRat = ((TotDist-dist)/TotDist)*xbinstgbinit;
    SolNewRat = ((dist)/TotDist)*xbinstinit;
    Newxbinstgb = SolOrigRat+SolNewRat;
%     vfit = vf + vfgb;
    %Now have to remove xbinst given to GB from matrix xbinst
    %mass balance?!?!
%     xbinst = xbinstinit - (Newxbinstgb - xbinstgbinit);
    
    xbinst = xbinstMax - Newxbinstgb;
    
    xbinstgb = Newxbinstgb;
    xbcheck = xbinstgb + xbinst;
    
    
    %Ficks second law of solute flux
    
    %This is for a semi-inifte source and is flux of atoms from matrix to
    %gb
    Jms = ((xbinstinit-xbinstgbinit)*sqrt(d))/(sqrt(pi*h)); %Yi, 2014
    
    
    
    %This is for a thin source, which i think amkes more sense.
    
    end
            xbinstTrack = [xbinstTrack xbinst];
            xbinstgbTrack = [xbinstgbTrack xbinstgb];
            vfTrack = [vfTrack vf];
            vfgbTrack = [vfgbTrack vfgb];
            
    %Check max theoretical volume fraction not exceeded
    %this method means there will be a sudden drop in xb
%   Vf_total = vfTrack(end) + vfgbTrack(end)

return