function [xbinst,xbinstgb] = xbinstCalcRun(xbinst,xbinstgb,d,h)


%Code to determine solute redistribution using Fick's second law
%From Joe, this script is what is best suited for implemntation into KWN.


k = 0.6;
cbar = 0.51;
s = 10e-9; % This is the distance between the points at which composition is calculated
GBWidth = 1.63e-6;


dt = 1e-4;
ti = 0; tf = 17;
ntsteps = (tf-ti)/dt;
QR = (1150-283)/ntsteps;
TempGrad = (1150:-QR:283);
% d = 6e-7 * exp(-15930/(tk));


% s = 10e-9;
% s=gs/(res); % This is the distance between the points at which composition is calculated
t = 0;
xbinst = cout; %Vector of local compositions - determine from Scheil Eq.
xbTrack = [];
for j = 1:length(TempGrad)
    
    d = 6e-7 * exp(-15930/(TempGrad(j)));
    diffdis = (d * dt)/(s^2); % d is the diffusion coefficient, dt is the time interval
    % Finite difference model for redistribution of solute in matrix
    %
    dc = diffdis*(xbinst(1:end-2)-(2*xbinst(2:end-1))+xbinst(3:end));
    % symmetry and constant solute limit fixes end compositions
    dcfirst=diffdis*(2*(xbinst(2)-xbinst(1)));
    dc=[dcfirst dc];
    newxbinst=[];
    newxbinst = xbinst(1:end-1) + dc;
    xlast=(sum(xbinst)-sum(newxbinst));
    newxbinst=[newxbinst xlast];
    xbinst=newxbinst;
    
    xbTrack = [xbTrack; xbinst];
end




end