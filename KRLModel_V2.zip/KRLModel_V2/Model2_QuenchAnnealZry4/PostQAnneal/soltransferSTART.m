function [xbinst3,TotalSolDist,xbinstTrack,vfTrack,xbinstTotTrack,flagSol,nucflag,Check1out,Check2out,SolSplit,Fickcheck,xbchangeFickout] = soltransferSTART(vfTrack,vfgbTrack,xa,xb,xc,h,d,firstit,TotalSolDist,xbinstTrack,xbinstgbTrack,vf3,xbout,GBWidth,xbinstTotTrack,xbinst,dtTrack,flagSol,xbinit,xbinstTotTrackEnd,vfout,nucflag,t,Check1out,Check2out,hout,r,SolSplit,xbchangeFickout,FickSwitch,xbCur,alphaTrack,StagNucFlag)

%function to calculate the trasnfer of solute from the matrix region to the
%grain boundary region at the start of each iteration, taking inputs such
%as xbinst and vf from the end of the last iteration.
%The movement of solute into GB region is going to be determined using
%sqrt(dt) approach.
%N.B. the Start and End soltransfer scripts are just to keep the xbinst
%consistent through the slopes of each full iteration, the End script
%provides output values.

    %Calculate xbinst and sol transfer here based on h/2 time
%     if firstit == 0
%         gbdist = GBDistStart;
%         MatrixDist = (GBWidth - gbdist)/GBWidth;
%         PFZDist = gbdist/GBWidth;

% xb = xbCur;

alphafrac = alphaTrack(end);
vftemp = vf3.*(1./alphafrac);
        
        %Can do a similar method as below with SolSplit array
        rsz = size(r);
        rrows = rsz(1);
        xbinst3 = [];
        for j = 1:1:rrows
            xbinst3_i = (xb.*SolSplit(j) - (vftemp(j).*(xc-xa)))/(1./rrows); %Changed (1/rrows) to (1/1)
            xbinst3 = [xbinst3 xbinst3_i];
        end
        
        %above should work but will need to be adapted when solute transfer
        %through Fick's is enabled
        
%         xbinstgb3 = (xb*SolSplitGB - (vf3gb*(xc-xa)))/PFZDist;
%         xbinst3 = (xb*SolSplitM - (vf3*(xc-xa)))/MatrixDist;
        
        vfCurMax = sum(vftemp);
        xbinstTot = xb - ((xc - xa) * vfCurMax);
        
%         TotalSolDist = [TotalSolDist 0]; %Leave as zero as sqrt(dh) is being used after next update func
        
         h = h/2;
         if FickSwitch == 1
             [xbinst3,SolSplit,Fickcheck,xbchangeFickout] = FicksLaw(xbinst3,d,h,GBWidth,rrows,vf3,xc,xa,xbchangeFickout,xbinit,StagNucFlag);
%                [xbnew,SolSplit,Fickcheck,xbchangeFickout] = Fick_PDE(xbinst,d,h,GBWidth,rrows,xbchangeFickout,xbinit);
%                xbinst3 = xbnew;
         else
             Fickcheck = 0;
         end

%         vfTrack = [vfTrack vf3];
%         vfgbTrack = [vfgbTrack vf3gb];
%         xbinstTrack = [xbinstTrack xbinst3];
%         xbinstgbTrack = [xbinstgbTrack xbinstgb3];
        xbinstTotTrack = [xbinstTotTrack xbinstTot];
        
        
        
%         hout = [hout h/2];
%         dtTrack = [];
%     else
%         %size ratios of the GB to matrix systems, this will be constant before
%         %solute sharing is enabled
%         gbdist = GBDistStart;
%         MatrixDist = (GBWidth - gbdist)/GBWidth;
%         PFZDist = gbdist/GBWidth;
%         
%         
%         xbinit = 0.0051;
%         vmax = (xbinit - xa)/(xc - xa);
%         
%         PossVfgb = vmax*0.5;  %change 0.5 depending on solute split between systems
%         PossVfM = vmax*0.5;
%         
%         VfRemgb = PossVfgb - vf3gb;
%         VfRemM = PossVfM - vf3;
%         
%         
%         
%         xbinstgb3 = (xb*SolSplitGB - (vf3gb*(xc-xa)))/PFZDist;
%         xbinst3 = (xb*SolSplitM - (vf3*(xc-xa)))/MatrixDist;
%         
%         
%         
%         %can try with these on/off to see difference
%         if xbinst3 < 1.1*xa
%             nucflag = 1;
%         end
%         if xbinstgb3 < 1.1*xa
%             nucflaggb = 1;
%         end
%         
%         if VfRemM < 1e-5 %Might change this to xbinst and xa function of
%             nucflag = 1;
%         end
%         
%         if VfRemgb < 1e-5 %Might change this to xbinst and xa function of
%             nucflaggb = 1;
%         end
%         
%         vfCurMax = vf3 + vf3gb;
%         xbinstTot = xb - ((xc - xa) * vfCurMax);
%         
%         vfTrack = [vfTrack vf3];
%         vfgbTrack = [vfgbTrack vf3gb];
%         xbinstTrack = [xbinstTrack xbinst3];
%         xbinstgbTrack = [xbinstgbTrack xbinstgb3];
%         xbinstTotTrack = [xbinstTotTrack xbinstTot]; %Need to include this so the MIDDLE script has a new value to work from
%         hout = [hout h/2];
%         
%         % Jms = ((xbinstinit-xbinstgbinit)*sqrt(d))/(sqrt(pi*h)); %Yi, 2014
%     end



    
return