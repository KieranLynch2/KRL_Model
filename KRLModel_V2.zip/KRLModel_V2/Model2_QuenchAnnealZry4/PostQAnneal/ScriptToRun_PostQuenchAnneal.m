function [r,n,rb,r_ln,n_ln,rbarout,vfout,tkout,tout,xbout,npartout,xbchangeFickout,TotModeOut] = ScriptToRun_PostQuenchAnneal(tcprof,r,rb,n,xbout,SolSplitout,xbchangeFickout,TimeTotal,QR,NSegs,FeConc,CrConc,DiffFlag,PostQAnnealOnly,RangeValue)

r_in = r(1,:);
n_in = n;
rb_in = rb(1,:);
xbinst = xbout(end,:);
SolSplit = SolSplitout(end,:);
xbinit = xbout(1,:);

[r,rb,n,tkprof,xb,xc,sfen,nsites,vmol,a,a_init,sfengb,nsitesgb,Vgrain,Agb,GBWidth,xbinst,SolSplit,xbinit,xbchangeFickout]=zr_amorph_init_noniso(tcprof,r_in,rb_in,n_in,xbinst,SolSplit,xbinit,QR,xbchangeFickout,NSegs,FeConc,CrConc);

sfen = 0.2; % For the post-quench anneal, make the interfacial energy 0.2, overriding that chosen for dislocation SPPs during quenching. 

[r,n,tout,tkout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout,xaout,growthout,grtrck2,grtrck4,grtrck6,PFZout,r_ln,n_ln,xbinstTrack,hout,Distout,TotalSolDistEnd,dtEnd,dtTrack,firstit,xbinstTotTrackEnd,vfTrack,SolSplitout,xbchangeFickout,Avout,TotModeOut,ArithMeanOut]= ...
    zr_amorph_kin_noniso(r,rb,n,tkprof,xb,xc,sfen,sfengb,nsites,vmol,a,a_init,Vgrain,Agb,GBWidth,xbinst,SolSplit,xbinit,xbchangeFickout,TimeTotal,DiffFlag,0);


radflag = 0;
for j = 1:1:NSegs
    % Catch in case n array is empty
    r_now = r(j,:);
    n_now = n(j,:);
    if sum(n_now) > 0
    rbaroutHori = rbarout';
    rbarout_now = rbaroutHori(j,:);
    vfoutHori = vfout';
    vfout_now = vfoutHori(j,:);
    [r_ln_temp,n_ln_temp] = lognrm_adjust_TEST(r_now,n_now,pgpout,rbarout_now,vfout_now);
    r_ln(j,:) = r_ln_temp;
    n_ln(j,:) = n_ln_temp;
    else
    r_ln(j,:) = r_now;
    n_ln(j,:) = n_now;
    end
end

end