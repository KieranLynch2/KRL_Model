aq = [0 0 0 0];
aw =7;

if (aq == 0)
    disp('aaa')
else
    disp('bbb')
end
