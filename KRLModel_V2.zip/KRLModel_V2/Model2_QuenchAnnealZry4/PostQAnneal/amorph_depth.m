function [ram] = amorph_depth(t)
%
% Motta et al model to predict depth of amorphous region
% in Zr(Cr,Fe)2 precipitates
%
% All parameters from Motta et al., J. Nuc. Mater. 195 (1995) pp. 277-285
%
c0 = 0.4;
ca = 0.1;
dc = 0.03;
mu = 5e-9;
phi_sigma = 5e-7; % displacement rate, dpa / s
ram = (1/6) * mu * phi_sigma * t * ((((3/2)*(c0-ca))/dc)-1);
end
