%concentration profile of Fe-Cr in the grain of alpha-Zr

% Conc = 
% r=zr_amorph_init_noniso([1050 10 289/3600]); %ABQ
% zr_amorph_init_noniso([1050 10 20.4/3600]); %OBQ
%
distout = [];
tout = [];
deeteeout = [];
for tk = 1150:-0.01:283 %Do it from when nucleation starts i.e. 1150K
    
    %3.6 k/s, 0.36 k/0.1s
    %tkprof for quench from 1150 == [1150,283,240.9]
    %0.2778 seconds per kelvin, 0.02778 seconds per 0.1k
    t = 0.002778;
    
    %51 K/s, 5.1K/0.1s
    %tkprof for quench from 1150 == [1150,283,17]
    %0.0196 seconds per kelvin, 0.00196 seconds per 0.1K
    %t = 0.000196;
    
    d = 6e-7 * exp(-15930/(tk));
    dete = d*t;
    deeteeout = [deeteeout dete];
    tout = [tout t];
end
Totaldist = cumsum(deeteeout);
FinalD = Totaldist(end);
FinalDist = sqrt(FinalD)
% TotalTime = cumsum(tout);
% plot(TotalTime,Totaldist)