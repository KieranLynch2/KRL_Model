function [grtrck2,grtrck4,grtrck6,gr2flag,gr4flag,gr6flag] = growthtrack(dr,t,gr2flag,gr4flag,gr6flag,grtrck2,grtrck4,grtrck6)

%function to keep track of the growth rates at periodic stage during the
%simulation.
%To begin with go for tracking the growth rates every 0.2 hours



if t > 0.2*3600 && gr2flag == 0
    grtrck2 = dr;
    gr2flag = 1;
elseif gr2flag == 0
    grtrck2 = [];
end
if t > 0.4*3600 && gr4flag == 0
    grtrck4 = dr;
    gr4flag = 1;
elseif gr4flag == 0
    grtrck4 = [];
end
if t > 0.6*3600 && gr6flag == 0
    grtrck6 = dr;
    gr6flag = 1;
elseif gr6flag == 0
    grtrck6 = [];
end



end