function [rcgb] = critrad_crystgb(sfengb,xa,xb,xc,vfgb,tk,vmol,sfen,xbinstgb,xbinstTot)
% function[rc] = critrad(sfen,xa,xbinst,tk)
% Calculates critical radius for growth/nucleation
%
% Inputs
% sfen      Interfacial energy of nuclei (J/m^2)
% xa        Equilibrium concentration of Zr in matrix at interface
% xb        Zr concentration in matrix (far field)
% xc        Zr concentration in dispersoids
% vf        Volume fraction of dispersoids
% tk        Temperature (K)
% Outputs
% rc        Critical radius (m)
%
sfengb = sfen; %Make the surface energy of the SPPs the same for crit rad calcs? Only change surface energy for nucrate if not using shape factor method
%
% update mean matrix concentration
%
% xbinstgb = xb - ((xc - xa) .* vfgb);
% xbinstgb = xbinstTot;
if xbinstgb < 0, xbinstgb = 0; end
gas = 8.31459;
%
% only calculate critical radius when xbinst>xa
%
%disp(['xa ' num2str(xa) ' xbinst ' num2str(xbinst)])
  %
  % full expression for driving force from ideal solution model (Aaronson, Met Trans A, 23A, 1992 p.1915)
  %
  driving = ((gas * tk)/vmol)*((xc.*log(xbinstgb./xa))+((1-xc).*log((1-xbinstgb)./(1-xa))));
  %driving = ((gas * tk)/vmol)*((xc.*log(xbinst./xa)));
  %  driving = driving - 2.14e8;
%
%fec = (1/c2) * (2 * sfen) * driving

%
% Modify driving force by strain energy
%stren = strain_co(0.017,0.34,0.31,48e9,75e9);
   stren = 0;
%
   resdrive = driving - stren;
   rcgb = (2 * sfengb)./(resdrive); %rc should still change as the matrix conc changes (xbinst)
%
% Limit maximum rc
% if rcgb > 1e-3, rcgb = 1e-3; end
return