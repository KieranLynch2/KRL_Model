function xbcheck = SolCheck(xbinst,vf,xa,xb,xc)

% Possible vf from solute in solution
vmax_tot = [];
for j = 1:1:length(xbinst)
    vmax_i = (0.1)*((xbinst(j) - xa)/(xc - xa));
    vmax_tot = [vmax_tot vmax_i];
end

SumVMax = sum(vmax_tot);

% Solute in SPPs in each bin
% SolSPPs = vf.*xc;
% 
% SolSPPsTot = sum(SolSPPs);


% Total vf 
TotPossVf = SumVMax+vf;


% Theoretical max if only simulating one bin
vmax_The = ((xb - xa)/(xc - xa));


if abs(TotPossVf-vmax_The) > 0.0001
    FlagXB = 1; 
else 
    FlagXB = 0;
end

xbcheck = FlagXB;

end