function [dy,yy,T] = beta_to_alpha(tkinit,tkfinal,tfinal,h_temp,tk,yy,h_sum)

%%Very important note: Massih, 2009 paper has two big errors! namely tauc
%%calculation for quenching and also the ys calc had the wrong sign!
% his updated 2021 paper fixes these issues.

%So far this is suitable for 0.1 < qr < 100 k/s
%will not need to go lower than 0.1 but may need to go higher than 100 i.e.
%rapid water quench...
%%
%yy fraction of beta phase
qr = -((tkinit-tkfinal)/(tfinal));

yy_init = yy;

%Calculate change in temp based on iteration number
% tkdif = tkinit-tkfinal;
% tot_temp_inc = tkdif/h_temp;
Q = qr; %Q is the quench rate in K/s and is valid between 0.1 and 100.
T = tkinit + (qr*h_sum);

% if Q == -100
%     Talpha = 950;
% else
%     Talpha = 975;
% end
Talpha = 1075 - (31.82*(abs(qr)^0.235)); %Taken from Massih, 2009. May have to adjust this?
% Talpha = 1075;
%Talpha = 1113-(8.333*(abs(Q)^0.477));
% w = 25; %This is max H impurity in wppm in zircaloy-4
% Talpha = (1113-(0.156*w))*(abs(Q)^0.0118); %This stuff is wrong as it is
% heating transition rather than cooling, can come back to fix!
Tbeta = 1302.8 - (8.333*((abs(Q))^0.477));
% Tbeta = 1250;
% 
Tcent = (Talpha + Tbeta)/2;
Tspan = (Tbeta-Tcent)/2.3;

%Tcent and span change depending on cooling rate
% 
% Tcent = 1159;
% Tspan = 44;



EKb = 16650;

k0 = 60457 + (18129*abs(Q));

ys = 0.5*(1+(tanh((T-Tcent)/Tspan)));

% tauc = 1/(k0*exp(-(EKb/T)));

%Tb = 1000; %This is added in the new paper of Massih and can be changed - perhaps for dealing with higher qr than 100K/s
if abs(qr) >= 10
Tb = 25*(abs(qr));
elseif abs(qr) >= 5
Tb = 50*abs(qr);
else
Tb = 200*abs(qr);
end


tauc = (exp(EKb/(T+Tb)))/(k0); 

dy = (h_temp)*((ys - yy_init)/tauc); %So yy here is the change in beta phase fraction per timestep

end