vf = 0.008;

GAM = gammainc(0.5,4.*vf);