function [nr,gr,CritRadFlag] = nucgrow_amorph(vf,ram,r,rb,d,t,nsites,sfen,tk,xa,xb,xc,tau,vmol,a,h,xbinst,xbinit,dgb,SolSplit,nucflag,firstit,CritRadFlag,sfengb,bin,Diffgbout,Diffout,hout,n,QR)
%
% function [nr,gr] = nucgrow(vf,rb,d,nsites,sfen,tk,xa,xb,xc)
% Inputs
% vf        Current volume fraction of dispersoids
% r         Mean size of size classes (m)
% d         Diffusion coefficient (m^2s^-1)
% nsites    Number density of nucleation sites (/m^-3)
% sfen      Interfacial energy for nucleation/growth (J/m^-2)
% tk        Temperature  (K)
% xa        Equilibrium concentration of Zr in matrix at planar interface
% xb        Current average zirconium concentration in matrix
% xc        Zirconium concentration in dispersoids
% Outputs
% nr        Nucleation rate of dispersoids (m^-3s^-1)
% gr        Growth rate of each size class (ms^-1)
%
%
% update mean matrix concentration
%
%     xbinst = xb - ((xc - xa) * vf);
%
% calculate critical radius, growth and nucleation rates
%
% xbinst is recalculated in critradco: Do not pass
    rc_cryst = critrad_cryst(sfen,xa,xb,xc,vf,tk,vmol,xbinst,r,CritRadFlag,sfengb);

    nr = nucrate_amorph(rc_cryst,sfen,nsites,xbinst,xb,d,t,tk,tau,vmol,a,xbinit,r,dgb,SolSplit,nucflag,firstit,h,sfengb,xa,xc,bin); 
    rc_amorph = 1; %Set as dummy
    gr = growth_amorph(rb,rc_cryst,rc_amorph,ram,sfen,d,xbinst,xa,xc,tk,vmol,h,t,dgb,Diffgbout,Diffout,hout,n,sfengb,r,QR,vf);
 %   if rc_cryst > max(r)
 %       disp(['stop'])
 %   end
