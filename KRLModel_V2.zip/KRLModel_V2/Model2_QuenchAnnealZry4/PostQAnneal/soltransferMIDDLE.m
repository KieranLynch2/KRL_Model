function [xbinst2,TotalSolDist,xbinstTrack,vfTrack,xbinstTotTrack,flagSol,nucflag,Check1out,Check2out,SolSplit,Fickcheck,xbchangeFickout] = soltransferMIDDLE(vfTrack,vfgbTrack,xa,xb,xc,h,d,firstit,TotalSolDist,xbinstTrack,xbinstgbTrack,vf2,xbout,GBWidth,xbinstTotTrack,xbinst,dtTrack,flagSol,xbinit,xbinstTotTrackEnd,vfout,nucflag,t,Check1out,Check2out,hout,r,SolSplit,xbchangeFickout,FickSwitch,xbCur,alphaTrack,StagNucFlag)

%function to calculate the trasnfer of solute from the matrix region to the
%grain boundary region at the start of each iteration, taking inputs such
%as xbinst and vf from the end of the last iteration.
%The movement of solute into GB region is going to be determined using
%sqrt(dt) approach.
%N.B. the Start and End soltransfer scripts are just to keep the xbinst
%consistent through the slopes of each full iteration, the End script
%provides output values.
% if flagSol == 0 && flagSolgb == 0
%xbinst3 and xbinst3gb are from the START sol transfer script
%% New mthoed here:

% xb = xbCur;

alphafrac = alphaTrack(end);
vftemp = vf2.*(1./alphafrac);

rsz = size(r);
rrows = rsz(1);
xbinst2 = [];
for j = 1:1:rrows
    xbinst2_i = (xb.*SolSplit(j) - (vftemp(j).*(xc-xa)))/(1./rrows); %Changed (1/rrows) to (1/1)
    xbinst2 = [xbinst2 xbinst2_i];
end

vfCurMax = sum(vftemp);
xbinstTot = xb - ((xc - xa) * vfCurMax);
%

if FickSwitch == 1
    [xbinst2,SolSplit,Fickcheck,xbchangeFickout] = FicksLaw(xbinst2,d,h,GBWidth,rrows,vf2,xc,xa,xbchangeFickout,xbinit,StagNucFlag);
%     [xbnew,SolSplit,Fickcheck,xbchangeFickout] = Fick_PDE(xbinst,d,h,GBWidth,rrows,xbchangeFickout,xbinit);
%     xbinst2 = xbnew;
else
    Fickcheck = 0;
end
% 
% vfTrack = [vfTrack vf2];
% xbinstTrack = [xbinstTrack xbinst2];
xbinstTotTrack = [xbinstTotTrack xbinstTot];











%% second old method
%     if firstit == 0
%         gbdist = GBDistStart;
%         MatrixDist = (GBWidth - gbdist)/GBWidth;
%         PFZDist = gbdist/GBWidth;
%         
%         xbinstgb2 = (xb*SolSplitGB - (vf2gb*(xc-xa)))/PFZDist;
%         xbinst2 = (xb*SolSplitM - (vf2*(xc-xa)))/MatrixDist;
%         
%         vfCurMax = vf2 + vf2gb;
%         xbinstTot = xb - ((xc - xa) * vfCurMax);
%         
%         TotalSolDist = [TotalSolDist 0]; %Need to update this for solute transfer..., although saying that, can probably just do solute transfer at the end of each iteration...
%         
%         vfTrack = [vfTrack vf2];
%         vfgbTrack = [vfgbTrack vf2gb];
%         xbinstTrack = [xbinstTrack xbinst2];
%         xbinstgbTrack = [xbinstgbTrack xbinstgb2];
%         xbinstTotTrack = [xbinstTotTrack xbinstTot];
%         
%         hout = [hout h];
%         dtTrack = [];
%     else
%         %size ratios of the GB to matrix systems, this will be constant before
%         %solute sharing is enabled
%         gbdist = GBDistStart;
%         MatrixDist = (GBWidth - gbdist)/GBWidth;
%         PFZDist = gbdist/GBWidth;
%         
%         
%         xbinit = 0.0051;
%         vmax = (xbinit - xa)/(xc - xa);
%         
%         PossVfgb = vmax*0.5;  %change 0.5 depending on solute split between systems
%         PossVfM = vmax*0.5;
%         
%         VfRemgb = PossVfgb - vf2gb;
%         VfRemM = PossVfM - vf2;
%         
%         
%         
%         xbinstgb2 = (xb*SolSplitGB - (vf2gb*(xc-xa)))/PFZDist;
%         xbinst2 = (xb*SolSplitM - (vf2*(xc-xa)))/MatrixDist;
%         
%         
%         
%         %can try with these on/off to see difference
%         if xbinst2 < 1.1*xa
%             nucflag = 1;
%         end
%         if xbinstgb2 < 1.1*xa
%             nucflaggb = 1;
%         end
%         
%         if VfRemM < 1e-5 %Might change this to xbinst and xa function of
%             nucflag = 1;
%         end
%         
%         if VfRemgb < 1e-5 %Might change this to xbinst and xa function of
%             nucflaggb = 1;
%         end
%         
%         vfCurMax = vf2 + vf2gb;
%         xbinstTot = xb - ((xc - xa) * vfCurMax);
%         
%         vfTrack = [vfTrack vf2];
%         vfgbTrack = [vfgbTrack vf2gb];
%         xbinstTrack = [xbinstTrack xbinst2];
%         xbinstgbTrack = [xbinstgbTrack xbinstgb2];
%         xbinstTotTrack = [xbinstTotTrack xbinstTot]; %Need to include this so the MIDDLE script has a new value to work from
%         hout = [hout h];
%         
%         % Jms = ((xbinstinit-xbinstgbinit)*sqrt(d))/(sqrt(pi*h)); %Yi, 2014
%     end



%% Below is old method - really messy
% % % xbinstinit = xbout(end); %This will be xbinst at end of last iterataion
% % % xbinstgbinit = xboutgb(end);
% % % %Distance travelled by matrix solute
% % % 
% % % dt = 0.5*(d*(h)); %One thing to note is that i'm changing the tkprof to start at 1150 K, but this shouldn't make too much of a difference as the alpha-fraction at these temperatures is very small, so likely will be a lot of segregation anyway
% % % 
% % % %need to store dt here 
% % % 
% % % % Olddt = cumsum(dtTrack);
% % % % 
% % % % Totaldt = Olddt(end) + dt;
% % % % MeanSq = sqrt(Totaldt);
% % % % 
% % % % TotDist = MeanSq;
% % % % 
% % % % dtTrack = [dtTrack dt];
% % % % 
% % % % Fin = cumsum(dtTrack);
% % % % final = Fin(end);
% % % % Sec = cumsum(dtTrack(end-1));
% % % % second = Sec(end);
% % % % dist = sqrt(final) - sqrt(second); %This is the new distance this iteration
% % % 
% % % 
% % % % % dist = sqrt(d*(h))*1e-3;
% % % % % 
% % % % % TotalSolDist = [TotalSolDist dist];
% % % % % TotDistAr = cumsum(TotalSolDist); %do i need to do something with tracking total distance of PFZ??
% % % % % TotDist = TotDistAr(end);
% % % 
% % % % %TEMP
% % % % TotDist = PFZ;
% % % % dist = PFZ-PFZTrack(end);
% % % % 
% % % % PFZTrack = [PFZTrack PFZ];
% % % %for xbinst calcs it I need to find the area/length of the zone which is
% % % %used for, this can either be done using PFZ measurements of by calculating
% % % %the distance moved by matrix solute each iteration and keeping track of it
% % % %PFZ measurements are not turning out correclty at the moment, so i'll use
% % % %distance moved by solute to determine answer.
% % % %Gets a bit complex as precipitation is happening during the quench i.e. it
% % % %is not just a case of solute diffusing from matrix to gb as a lot of the
% % % %solute is pushed the the GB so there solute concentration there will be
% % % %high (I think), might have to couple this with a grain growth model and
% % % %predict the solute distribution across the grain as it transforms.
% % % 
% % % % vfCurMax = vf2 + vf2gb;
% % % % xbinstTot = xb - ((xc - xa) * vfCurMax); 
% % % % xbinstUsed = xbinstTotTrack(end) - xbinstTot;
% % % % 
% % % % xbusedM = (vf2*xc);
% % % % xbused
% % % % 
% % % % NewVf = vf2 - vfTrack(end); %This is the new volume fraction formed on iteration
% % % % NewVfgb = vf2gb - vfgbTrack(end);
% % % % 
% % % % VfgbRat = NewVfgb/(NewVfgb+NewVf);
% % % % VfRat = NewVf/(NewVfgb+NewVf);
% % % % 
% % % % xbinstTEMP = xbinstUsed*(VfRat); %Amount of solute that has been used by each system
% % % % xbinstgbTEMP = xbinstUsed*(VfgbRat);     
% % % % 
% % % % xbinstTEMP(isnan(xbinstTEMP))=0;
% % % % xbinstgbTEMP(isnan(xbinstgbTEMP))=0;
% % % % 
% % % % 
% % % % 
% % % % 
% % % % 
% % % % vmax = (0.0051 - xa)/(xc - xa);
% % % %     
% % % % PossVfgb = vmax*0.5;  %change 0.5 depending on solute split between systems
% % % % PossVfM = vmax*0.5;
% % % % 
% % % % VfRemgb = PossVfgb - vf2gb;
% % % % VfRemM = PossVfM - vf2;
% % % % 
% % % 
% % % 
% % % % if VfRemM > 0 && VfRemgb > 0
% % % % 
% % % %     xbinst2temp2 = xbinst3-xbinstTEMP; %Original solute in each system - solute used
% % % %     xbinstgb2temp2 = xbinstgb3-xbinstgbTEMP;
% % % % 
% % % %     xbinst2 = xbinst2temp2;
% % % %     xbinstgb2 = xbinstgb2temp2;
% % % % 
% % % % else
% % % %     xbinst2 = vf2*(xc-xa);
% % % %     xbinstgb2 = vf2gb*(xc-xa);
% % % %     aa = 4;
% % % % end
% % %     
% % % %With stuff below, the old iteration is going to be taken as the end of the
% % % %last full iteration
% % % %Vf created this iteration
% % % vfCurMax = vf2 + vf2gb;
% % % NewVf = vf2 - vfout(end); %This is using vf out from true end of iteration
% % % NewVfgb = vf2gb - vfoutgb(end); 
% % % 
% % % %Ratio of vf created
% % % VfgbRat = NewVfgb/(NewVfgb+NewVf);
% % % VfRat = NewVf/(NewVfgb+NewVf);
% % % 
% % % %Total xb used this iteration
% % % xbinstTot = xb - ((xc - xa) * vfCurMax); 
% % % xbinstUsed = xbinstTotTrackEnd(end) - xbinstTot;  %have to do xbinsttot at end of full iteration 
% % % 
% % % VfOldMax = vfTrack(end)+vfgbTrack(end);
% % % xbinstTotOld = xb - ((xc - xa) * VfOldMax);
% % % xbinstusedtest = xbinstTotOld - xbinstTot;
% % % 
% % % %Amount of solute that has been used by each system
% % % xbinstTEMP = xbinstUsed*(VfRat); 
% % % xbinstgbTEMP = xbinstUsed*(VfgbRat); 
% % % 
% % % %size ratios of the GB to matrix systems, this will be constant before
% % % %solute sharing is enabled
% % % gbdist = GBDistStart;
% % % MatrixDist = (GBWidth - gbdist)/GBWidth; 
% % % PFZDist = gbdist/GBWidth;
% % % 
% % % %Previous sol conc of each system
% % % SolCM = MatrixDist*xbout(end);
% % % SolCgb = PFZDist*xboutgb(end);
% % % 
% % % %Reduce the SolC by determine amounts
% % % NewSolCM = SolCM-xbinstTEMP;
% % % NewSolCgb = SolCgb - xbinstgbTEMP;
% % % 
% % % %Resolve equation to get new xbinst values
% % % 
% % % xbinst2 = NewSolCM/(MatrixDist);
% % % xbinstgb2 = NewSolCgb/(PFZDist);
% % % xbinit = 0.0051;
% % % vmax = (xbinit - xa)/(xc - xa);
% % %     
% % % PossVfgb = vmax*0.5;  %change 0.5 depending on solute split between systems
% % % PossVfM = vmax*0.5;
% % % 
% % % VfRemgb = PossVfgb - vf2gb;
% % % VfRemM = PossVfM - vf2;
% % % 
% % % 
% % %     xbinstgb2 = (xb/2 - (vf2gb*(xc-xa)))/PFZDist;
% % %     xbinst2 = (xb/2 - (vf2*(xc-xa)))/MatrixDist;
% % % 
% % % if xbinst2 < 1.1*xa || xbinstgb2 < 1.1*xa
% % %     xbinstgb2 = (xb/2 - (vf2gb*(xc-xa)))/PFZDist;
% % %     xbinst2 = (xb/2 - (vf2*(xc-xa)))/MatrixDist;
% % %     if xbinst2 < 1.1*xa
% % %         nucflag = 1;
% % %     end
% % %     if xbinstgb2 < 1.1*xa
% % %         nucflaggb = 1;
% % %     end
% % % end
% % % 
% % % if VfRemM < 1e-5 %Might change this to xbinst and xa function of
% % %     nucflag = 1;
% % % end
% % % 
% % % if VfRemgb < 1e-5 %Might change this to xbinst and xa function of
% % %     nucflaggb = 1;
% % % end
% % % 
% % % 
% % % 
% % % 
% % % 
% % % 
% % % 
% % % 
% % % 
% % % 
% % % % if VfRemM < 1e-4
% % % %     nucflag = 1;
% % % %     xbinst2 = (xb/2 - (vf2*(xc-xa)))/MatrixDist; %Do i divide this by the PFZDist?
% % % %     xbinstgb2 = (xb/2 - (vf2gb*(xc-xa)))/PFZDist;
% % % %     %This will be full distance, have to adjust for the size of Matrix ratio, so it will be slightly higher i think
% % % %     %When one of the systems hits nucflag, need to take both off of the
% % % %     %initial method
% % % % else 
% % % %     nucflag = 0;
% % % % end
% % % % 
% % % % if VfRemgb < 1e-4
% % % %     nucflaggb = 1;
% % % %     xbinstgb2 = xb/2 - (vf2gb*(xc-xa))/PFZDist;
% % % %     xbinst2 = (xb/2 - (vf2*(xc-xa)))/MatrixDist;
% % % % else 
% % % %     nucflaggb = 0;
% % % % end
% % % 
% % % % gbdist = TotDist;
% % % % [xbinst2temp,xbinstgb2temp] = xbinstCalcRun(xb,xc,xa,GBWidth,d,h,gbdist,xbinst2temp2,xbinstgb2temp2,xbinstTot);
% % % % 
% % % 
% % % % 
% % % % % %dividing system up 
% % % % 
% % % % MatrixDist = (GBWidth - TotDist)/GBWidth;
% % % % PFZDist = TotDist/GBWidth;
% % % % 
% % % % Mfrac = xbinst2temp2 * MatrixDist;
% % % % GBfrac = xbinstgb2temp2 * PFZDist;
% % % % 
% % % % MFrac = Mfrac/(Mfrac+GBfrac);
% % % % GBFrac = GBfrac/(Mfrac+GBfrac);
% % % % 
% % % % xbinst2temp = MFrac * xbinstTot;
% % % % xbinstgb2temp = GBFrac * xbinstTot;
% % % 
% % % %Now i need to add extra solute to GB region, on top of the
% % % %newly calculated xbinst
% % % % soldeplet = (dist/(GBWidth-TotDist))*(xbinst2temp);
% % % %             
% % % % soldeplet = 0;
% % % % 
% % % % xbinst2 = xbinst2temp - soldeplet;
% % % % xbinstgb2 = xbinstgb2temp + soldeplet;
% % % % % 
% % % % % xbinst2 = xbinst2temp;
% % % % % xbinstgb2 = xbinstgb2temp;
% % % % % 
% % % % % PossVfgb = (xb-(0.4157*0.0061))/(xc-xa); %Change 0.0061 based on distances, 0.4157 on initial sol conc
% % % % % PossVfM = (xb-(0.0026*0.9939))/(xc-xa);
% % % % 
% % % %     xbinit = 0.0051;
% % % %     vmax = (xbinit - xa)/(xc - xa);
% % % %     
% % % %     PossVfgb = vmax*0.5;  %change 0.5 depending on solute split between systems
% % % %     PossVfM = vmax*0.5;
% % % % 
% % % % VfRemgb = PossVfgb - vf2gb;
% % % % VfRemM = PossVfM - vf2;
% % % % 
% % % % xbinst2temp = VfRemM*(xc); %This is amount of solute left in each system
% % % % xbinstgb2temp = VfRemgb*(xc);
% % % % 
% % % % xbinst2 = xbinst2temp + xa;
% % % % xbinstgb2 = xbinstgb2temp + xa;
% % % 
% % % 
% % % % Mrat = xbinst2temp/(xbinst2temp+xbinstgb2temp);
% % % % gbrat = xbinstgb2temp/(xbinst2temp+xbinstgb2temp);
% % % % 
% % % % ratGB = xbinstTot*gbrat;
% % % % ratM = xbinstTot*Mrat;
% % % % 
% % % % xbinstgb2 = ratGB/(0.0061);
% % % % xbinst2 = ratM/(0.9939);
% % % % 
% % % % if xbinst2 < xa*1.01 %If the matrix solute comes within 10 % of xa, then flag is activated
% % % % %  xbinst3 = xa*1;
% % % %  flagSol = 1;
% % % % end
% % % % if xbinstgb2 < xa*1.01
% % % % %  xbinstgb3 = xa*1;
% % % %  flagSolgb = 1;
% % % % end
% % % % else %If flag sol is activated the solute in the system is close enough to xa that the system is now in equilbirium
% % %     %So the two systems should now be essentially de-coupled and allowed to
% % % %     %grow/coarsen naturally.
% % % %     a = 44;
% % % %     vfCurMax = vf2 + vf2gb;
% % % %     xbinstTot = xb - ((xc - xa) * vfCurMax); 
% % % %     
% % % %         
% % % % %     PossVfgb = (xb-(0.4157*0.0061))/(xc-xa); %change max possible vf based on xa
% % % % % PossVfM = (xb-(0.0026*0.9939))/(xc-xa);
% % % % 
% % % %     xbinit = 0.0051;
% % % %     vmax = (xbinit - xa)/(xc - xa);
% % % %     
% % % %     PossVfgb = vmax*0.5;  %change 0.5 depending on solute split between systems
% % % %     PossVfM = vmax*0.5;
% % % % 
% % % % VfRemgb = PossVfgb - vf2gb;
% % % % VfRemM = PossVfM - vf2;
% % % % xbinst2temp = VfRemM*(xc);
% % % % xbinstgb2temp = VfRemgb*(xc);
% % % % 
% % % % Mrat = xbinst2temp/(xbinst2temp+xbinstgb2temp);
% % % % gbrat = xbinstgb2temp/(xbinst2temp+xbinstgb2temp);
% % % % 
% % % % ratGB = xbinstTot*gbrat;
% % % % ratM = xbinstTot*Mrat;
% % % % 
% % % % xbinstgb2 = ratGB/(0.0061);
% % % % xbinst2 = ratM/(0.9939);
% % % %     
% % % % %     %Remaining solute in Matrix system is 
% % % % %     xbinst2Rem = vf2*(xc);
% % % % % %     xbinst3Rem = vf3*(xc-xa); %try next if fails
% % % % %     xbinst2 = xbinst2Rem - (vf2*(xc-xa));
% % % % %     
% % % % %     
% % % % %     xbinst2gbRem = vf2gb*xc;   
% % % % %     xbinstgb2 = xbinst2gbRem - (vf2gb*(xc-xa));
% % % % %    
% % % % 
% % % % % if VfRemgb <= 0
% % % %     xbinstgb2 = (xbinitgb) - (vf2gb*(xc-xa));
% % % % % end
% % % % % 
% % % % % if VfRemM <= 0
% % % %     xbinst2 = (xbinitM) - (vf2*(xc-xa));
% % % % % end
% % % 
% % % % end
% % % 
% % % 
% % % vfTrack = [vfTrack vf2];
% % % vfgbTrack = [vfgbTrack vf2gb];
% % % xbinstTrack = [xbinstTrack xbinst2]; 
% % % xbinstgbTrack = [xbinstgbTrack xbinstgb2];
% % % xbinstTotTrack = [xbinstTotTrack xbinstTot];
% % % 
% % % 
% % % % Jms = ((xbinstinit-xbinstgbinit)*sqrt(d))/(sqrt(pi*h)); %Yi, 2014
    
return