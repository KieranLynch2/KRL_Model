function bin = NewSizeFunc(rrows,rc,r,rb,n,nucflag)

bin  = []; %reset bin every iteration

for j = 1:1:rrows
    newsize = 1.1 .* rc(j);
    search=0;
    search=find(rb(j,:)<newsize);
    bin_i=max(search);
    if bin_i>length(r(j,:))-1
        if nucflag(j) == 0
            disp(['New particles exceed size range in array number ' num2str(j)])
        end
        if nucflag(j) == 1
            % Nucleation is complete - no new particles, set a dummy bin
            disp(['Nucleation complete in in array number ' num2str(j)])
            bin_i = 10;
        end
    end
    Curn = n(j,:);
    if Curn(end)>0, disp(['Bin overflow error - increase maximum size range in array number ' num2str(j)]); end
    bin = [bin bin_i]; %might have to fix here
end


%
% find bin in which critical radius lies. The bin in which new
% particles nucleate must be at least 1 greater than this
%
for j = 1:1:rrows
    search=0;
    search=find(rb(j,:)<rc(j));
    rcbin=max(search);
    
    if length(bin) < rrows
        aa = 4;
    end
    
    
    bindiff=bin(j)-rcbin;
    if bindiff < 1 & nucflag(j) == 0
        disp(['WARNING! newsize and rc lie in same bin. Remesh narrower bins in array number ' num2str(j)])
    end
end

end