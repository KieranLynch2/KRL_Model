function [r_ln,n_ln] = lognrm_adjust(r,n,pgpout,rbarout,vfout)

%Take r and n and adjust the size distribution based on the shape parameter
%From work Zhao2020
%The change in shape parameter is going to be based on how the shape of a
%PSD changes with the modal diameter.
%Then using the modal diameter a shape parameter can be determined, of
%course rbar and sd will change with this too.

PGP = pgpout(end);
% s = -0.0072*PGP^(-0.314)+0.376;
s = 0.34;

%convert rbarout into m
rsz = size(r);
rrows = rsz(1);

r_ln = zeros(rrows,length(r));
n_ln = zeros(rrows,length(r));

rbarout = rbarout';

for j = 1:1:rrows

rbarout_m = rbarout(j,:).*1e-9;

x = r(j,:)./rbarout_m(end);

lnfn = (1./(sqrt(2.*pi.*s.*x))).*exp(-((log(x)+(s.^2./2)).^2)./(2.*(s.^2)));

maximum = max(n(j,:));
mode_n = find(n(j,:)==maximum); %mode_n is the bin no. of modal r value
r_here = r(j,:);
mode_r = r_here(mode_n);

maximum_lnfn = max(lnfn);
mode_lnfn = find(lnfn==maximum_lnfn);

modal_diff = mode_n - mode_lnfn;

% plot(x.*rbarout(end).*2,lnfn);
% xlim([0 400])
% 
% hold on

%x_shift = circshift(x,-modal_diff);
lnfn_shift = circshift(lnfn,modal_diff);

%plot(x_shift.*rbarout(end).*2,lnfn);
% plot(x.*rbarout(end).*2,lnfn_shift);
% 
% plot((r.*2).*(10^9),n.*(10^-18))
% xlim([0 400])
% legend('Shape factor','Shape factor shift','original')
%Need to convert the y axis back to number density
%Currently it is normalized distribution function

rbar_j = rbarout(j,:);

x_shift = x.*rbar_j(end).*1e-9; %Convert x from normalized to true SPP radius

vf_j = vfout(j,:);

vf_frac = vf_j(end);

vf_sum = [];
for k = 1:1:length(x_shift)
    n_t = sym('n_t');
    
    vf = (4/3)*pi*(((x_shift(k))).^3)*(lnfn_shift(k)*n_t);%convert xt to um from nm, so final result will be in um^-3
    
    vf_sum = [vf_sum vf];
end
vf_sum_sum = sum(vf_sum);
S = solve(vf_sum_sum == vf_frac);
n_t = 0;
n_t(1) = S; %This is the total number of SPPs 

num_den = n_t.*lnfn_shift; %This produces the number density in each size bin based on probability.


% plot((r.*2).*(10^9),n.*(10^-18))
% xlim([0 200])
% hold on
% 
% plot(x_shift.*2,num_den) %This is radius! (nm v um3)
% xlim([0 400])

%legend('Original','Shift')
%The shift function makes certain values in the array not be in the correct
%order anymore (i.e. not ascending)
%Shift number densities along instad of r array!
%Also need to make sure rb values make sense.

r_ln(j,:) = x_shift; %change r back to metres
n_ln(j,:) = num_den; %change n back to m^-3 (from um^-3)

%dbar = ((sum((r_ln.*2).*n_ln))/sum(n_ln));
vff = 4/3 * pi * sum((r_ln(j,:).^3) .* n_ln(j,:));
dbar = ((vff./((4/3) * pi * sum(n_ln(j,:))))^(1./3)).*2;

end

end



%% Determining relationship between PGP and shape factor
% S = [0.3131;0.3496;0.3698];
% PGP = [0.001;0.016;1.66];
% 
% f = fit(PGP,S,'cubicinterp');
% plot(f,PGP,S)
% set(gca, 'XScale', 'log')