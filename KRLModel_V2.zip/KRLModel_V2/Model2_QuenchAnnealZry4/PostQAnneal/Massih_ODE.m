function [t,y,qr] = Massih_ODE(tfinal,tkinit,tkfinal)
%%  ode45 MATLAB function
% tfinal = 1.4167; %85, 1.4167, 0.4250

tfinal = 0.4250; %170,85,8.5

tkinit = 1150+273;
tkfinal = 300+273;
qr = -((tkinit-tkfinal)/(tfinal));
Tspan = tkinit - 800;
tspan_end = Tspan/abs(qr); %Stop the calculation when T gets below 800 K, thi should cover up to 2000K/s

y0=1;

Talpha = 1075 - (31.82*(abs(qr)^0.235));
Tbeta = 1250 - (8.333*((abs(qr))^0.477));
Tcent = (Talpha + Tbeta)/2;
Tspan = (Tbeta-Tcent)/2.3;    


EKb = 16650;
k0 = 60457 + (18129*abs(qr));

%Tb = 1000;

if abs(qr) >= 10
Tb = 25*(abs(qr));
elseif abs(qr) >= 5
Tb = 50*abs(qr);
else
Tb = 200*abs(qr);
end

tspan = [0 tspan_end];
Tinit = tkinit;   



[t,y] = ode45(@(t,y) odefcn(Tcent,Tspan,Tinit,qr,EKb,Tb,k0,t,y), tspan, y0);

%Determine temperature using quecnh rate and time
Tout = Tinit-(t.*abs(qr));

plot(Tout,y)

function dydt = odefcn(Tcent,Tspan,Tinit,qr,EKb,Tb,k0,t,y)
    T = Tinit + t*qr; 
    Yeq = 0.5*(1+(tanh((T-Tcent)/Tspan)));
    tauc = (exp(EKb/(T+Tb)))/(k0); 
    dydt = (Yeq - y)/tauc;
end

end
