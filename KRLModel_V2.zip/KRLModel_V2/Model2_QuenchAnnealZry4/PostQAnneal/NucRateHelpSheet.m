%script to see changes to parameters in determining nucleation rate
%General rule of thumb is that as there is a higher matrix concentration
%around the GB ragion that the critical radius here is less



xb = 0.0051;
vmol = 9e-6;
GBWidth = 1.63e-6; %This is the width of the alpha-Zr grains
Vgrain = 51*1e-18; %Average grain volume
Agb = 7.43*1e6*Vgrain; %Average area of grain bounadry per unit volume
nad = 1e-3;
nadgb = 1e-11;
nsites = 4.30e28*(xb/2)*nad;
nsitesgb_temp = ((10e-10)*(4.3e28))/(GBWidth);
nsitesgb = nsitesgb_temp * (xb/2) * nadgb;
a = 0.32425e-9;
xb = 0.0051/2;

tk = 1150;

d = 6e-7 * exp(-15930/(tk));
%Calculation of GB diffusivity
gas=8.314;
Qrat = 120000;
prefac = 11000;
Drat = prefac*exp(Qrat/(gas*tk)); %Ratio of Cr gb/l diffusivity (Massih, 2003)
dgb = d*Drat;

k = 1.380662e-23;
na = 6.022045e23;
h = 6.626176e-34;

aprod = a;
vat = vmol/na;

rc = 3.0927e-10;
rcgb = 9.1724e-11;

sfen = 0.22;
sfengb = 0.22;


sigma = 0.5; %Gb energy (J/m2) from Plowman 2020, as a guide
theta = (sigma/(2*sfengb));
ShapeFac = ((2+cosd(theta))*((1-cosd(theta))^2))/2;

gstargb = 4/3 * pi * (rcgb.^2) * sfengb;
gstarHet = gstargb*ShapeFac;

gstar = 4/3 * pi * (rc.^2) * sfen;





dg = (-2 * sfen)./rc;
dggb = (-2 * sfengb)./rcgb;


zeld = (vat .* dg.^2)./(8 * pi * ((sfen^3*k.*tk).^0.5));
zeldgb = (vat .* dggb.^2)./(8 * pi * ((sfengb^3*k.*tk).^0.5));


%see if xb needs to change here
beta = (4 * pi * rc^2 * d * xb)/(aprod^4);
betagb = (4 * pi * rcgb^2 * dgb * xb)/(aprod^4);


nr = nsites.*zeld.*beta.*exp(-gstar./(k .* tk));
nrgb = nsitesgb.*zeldgb.*betagb.*exp(-gstarHet./(k .* tk));

disp(['NucRate Matrix = ' num2str(nr) '                       NucRate GB = ' num2str(nrgb)])
aa=4;