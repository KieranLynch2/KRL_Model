function CallScript(tcrun,trun,OFN,InputFlag,zirc2flagrun,radflagrun,phirun,FileName,QR)

radflag = radflagrun;

if InputFlag == 1
    load(['../Qr_' num2str(QR) '/Output_QR_' num2str(QR) '.mat'])
    r_in = r(1,:);
    n_in = n;
    rb_in = rb(1,:);
    xbinst = xbout(end,:);
    SolSplit = SolSplitout(end,:);
    xbinit = xbout(1,:);
end

if radflag == 0
    ram_total_end_r = [];
    ram_total_end_rb = [];
    time_amorph = [];
    time_amorphrb = [];
elseif radflag == 1
    tk = tc+273;
    tfinal = t*60*60; %Convert time in hours to seconds
    [ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb] = Taylor_eq10_tfinal(tk,tfinal,phi,r,rb);
end


tc = tcrun; %loading file above overwrites these input variables
t = trun;
zirc2flag = zirc2flagrun;
radflag = radflagrun;
phi = phirun;

if InputFlag == 0
    [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,xa_FeNi,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,FeCrRat,FeNiRat,a_FeNi]=zr_amorph_init(tc,t,phi,radflag,zirc2flag);

    [r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout,vf_aout,vf_totout,xbinst_tot,ramout,vfout_FeNi,rbarout_FeNi,nrout_FeNi,npartout_FeNi,r_FeNi,n_FeNi,rcout_FeNi,ram_diss,xbout_a_Cr,xbout_a_Fe,xbout_c_Fe,r_a_shell,xb_tot_check,amorph_diss_out,rbar_totout,xbout_Zirc2,vf_totalout,r_total,r_cryst,n_cryst,vf_amorphout,vf_crystout,xa_store,r_ln,n_ln,dsr1out,dsr2out,dsr3out,r_lnFeNi,n_lnFeNi,Fe2Cr_vf,Fe2Cr_rat,rb_clust,r_clust,n_clust,npart_clustout,vf_clustout,rbar_clustout,EqRadout,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,xbout_Zirc2_FeCr,xbout_Zirc2_FeNi]= ...
        zr_amorph_kin(r,n,zirc2flag,rb,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi,tk,tfinal,d,d_FeNi,xa,xb,xc,xc_a,xb_FeNi,xc_FeNi,sfen,sfen_FeNi,nsites,vmol,vmol_FeNi,a,a_init,vmax,vmax_FeNi,xc_clust,phi,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,FeCrRat,FeNiRat,xa_FeNi,a_FeNi,radflag);
elseif InputFlag == 1
%     [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,xa_FeNi,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,FeCrRat,FeNiRat,a_FeNi]=zr_amorph_init(tc,t,phi,radflag,zirc2flag,r_in,n_in,rb_in,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb);%,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi);
% 
%     [r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout,vf_aout,vf_totout,xbinst_tot,ramout,vfout_FeNi,rbarout_FeNi,nrout_FeNi,npartout_FeNi,r_FeNi,n_FeNi,rcout_FeNi,ram_diss,xbout_a_Cr,xbout_a_Fe,xbout_c_Fe,r_a_shell,xb_tot_check,amorph_diss_out,rbar_totout,xbout_Zirc2,vf_totalout,r_total,r_cryst,n_cryst,vf_amorphout,vf_crystout,xa_store,r_ln,n_ln,dsr1out,dsr2out,dsr3out,r_lnFeNi,n_lnFeNi,Fe2Cr_vf,Fe2Cr_rat,rb_clust,r_clust,n_clust,npart_clustout,vf_clustout,rbar_clustout,EqRadout,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,xbout_Zirc2_FeCr,xbout_Zirc2_FeNi]= ...
%         zr_amorph_kin(r,n,zirc2flag,rb,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi,tk,tfinal,d,d_FeNi,xa,xb,xc,xc_a,xb_FeNi,xc_FeNi,sfen,sfen_FeNi,nsites,vmol,vmol_FeNi,a,a_init,vmax,vmax_FeNi,xc_clust,phi,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,FeCrRat,FeNiRat,xa_FeNi,a_FeNi,radflag);

        tcprof = [25 700 30/3600; 700 700 t];
[r,rb,n,tkprof,xb,xc,sfen,nsites,vmol,a,a_init,sfengb,nsitesgb,Vgrain,Agb,GBWidth,xbinst,SolSplit,xbinit,xbchangeFickout]=zr_amorph_init_noniso(tcprof,r_in,rb_in,n_in,xbinst,SolSplit,xbinit,QR,xbchangeFickout);%ABQ, from Massih, 2003 the QR should be determined from 1050C to 750C, which is where the lamella thickness relationship is derived.


[r,n,tout,tkout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout,xaout,growthout,grtrck2,grtrck4,grtrck6,PFZout,r_ln,n_ln,xbinstTrack,hout,Distout,TotalSolDistEnd,dtEnd,dtTrack,firstit,xbinstTotTrackEnd,vfTrack,SolSplitout,xbchangeFickout,Avout,TotModeOut,ArithMeanOut]= ...
    zr_amorph_kin_noniso(r,rb,n,tkprof,xb,xc,sfen,sfengb,nsites,vmol,a,a_init,Vgrain,Agb,GBWidth,xbinst,SolSplit,xbinit,xbchangeFickout,0);

end

OFN = (['OutputLynch700C_' num2str(t) 'hr_QR' num2str(QR) '.mat']); % Choose an output filename 

save([OFN])


end