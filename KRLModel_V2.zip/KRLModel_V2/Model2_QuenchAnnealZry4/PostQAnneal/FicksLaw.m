function [xbinst,SolSplit,Fickcheck,xbchangeFickout] = FicksLaw(xbinst,d,h,GBWidth,rrows,vf,xc,xa,xbchangeFickout,xbinit,StagNucFlag)

    %hFick - minimum timestepp determined by a maximum amount of solute
    %transfer per iteration to stop errors forming from Fick's law
    %Fickcheck - if this is triggered, the solution won't update this
    %iteration and the timestep will be reduced
    
    % Limits implemented to only allow diffusion of segments where the beta
    % to alpha transformation has occured.
    xbinit_local = xbinst;
    xbinst = [];
    for j = 1:1:length(StagNucFlag)
        if StagNucFlag(j) == 0 %Segment is active
            xbinst = [xbinst xbinit_local(j)];
        end
    end
        



    xbstart = xbinst;
    
%     FickFlag = zeros(1,rrows);
%     for j = 1:1:rrows
%         if xbinst(j) < 1.1*xa
%             FickFlag(j) = 1; %Don't take anymore solute from the specified segment, (or actually is it because nucleation rate is still high?)
%         end
%     end

if length(xbinst)>1

    s = GBWidth/rrows; %This is the distance between points for which it is calculated
    %Need to double check whether i do full grain width or half grain width

    diffdis = (d * h)/(s^2); % d is the diffusion coefficient, dt is the time interval
    % Finite difference model for redistribution of solute in matrix
    %
    dc = diffdis*(xbinst(1:end-2)-(2*xbinst(2:end-1))+xbinst(3:end));
    % symmetry and constant solute limit fixes end compositions
    dcfirst=diffdis*(2*(xbinst(2)-xbinst(1)));
    dc=[dcfirst dc];
    newxbinst=[];
    newxbinst = xbinst(1:end-1) + dc;
    xlast=(sum(xbinst)-sum(newxbinst));
    newxbinst=[newxbinst xlast];
    xbinst=newxbinst;

    %Fickcheck determination - solute change in any segment is not allowed
    %to change by more than 0.1%
    xbPerChange = [];
    for j = 1:1:length(xbinst)
        change = (xbinst(j)-xbstart(j));
        percent_i = abs(change./xbstart(j)).*100;
        xbPerChange = [xbPerChange percent_i];
    end

    if any(xbPerChange > 1)
        Fickcheck = 1;
    else
        Fickcheck = 0;
    end









    %     xbTrack = [xbTrack; xbinst];

    xbchangeFick = xbinst - xbstart;
    Templength = rrows-length(xbchangeFick);
    AddTemp = zeros(1,Templength);
    xbchangeFickNew = [xbchangeFick AddTemp];
    xbchangeFickout = [xbchangeFickout; xbchangeFickNew];


    Fickxbchange = [];
    SolSplit = [];
    for j = 1:1:rrows
        Fickxbchange_i = (sum(xbchangeFickout(:,j)));
        Fickxbchange = [Fickxbchange Fickxbchange_i];
    end
    for j = 1:1:rrows
        newxb = xbinit(j)+Fickxbchange(j); %xbinit is xb distribution at begining of simulation
        SolSplit_i = newxb/(sum(xbinit));
        SolSplit = [SolSplit SolSplit_i];
    end
    %This should track solute split based only on fick adjustements,



    %Determine xb contained in each system via pptes and add this to the
    %new xbinst and calculate a total solute split
%     xbspp = [];
%     for j = 1:1:rrows
%         xbspp_i = vf(j)*(xc);
%         xbspp = [xbspp xbspp_i];
%     end
% 
%     TotalxbSeg = xbinst+xbspp; %The total amount of solute in each segment
% 
%     TotalxbSegStart = xbstart+xbspp;
% 
%     xbsegchange = TotalxbSeg - TotalxbSegStart;
    %Does dficks taken into account the solute trapped up in SPPs or does
    %it just use the solute in solution in the matrix? Is it a problem
    %simply with the timestep being too large? is the solute redistribution
    %happening too quick from the gb region and causing Fick to take too
    %much as precipitation is happening too

    %need a fix with xb to stop it going below xa here! (or later on, but
    %somewhere!)
    %if xb of a segment gets near xa then either nr == 0, or no solute is
    %allowed to transfer via Fick's,
    %but i then need to be able to allow more nucleation if solute then
    %transfers back from adjacent regions above sol limit.

    %     SolSplit = [];
    %     for q = 1:1:rrows
    %         SolSplit_i = TotalxbSeg(q)/(sum(TotalxbSeg));
    %         SolSplit = [SolSplit SolSplit_i];
    %     end
    %

    PrexbAv = mean(xbstart);
    PostxbAv = mean(xbinst);
    if abs(PrexbAv-PostxbAv)> 0.00001
        FlagHere = 1;
    end
else
    Fickcheck = 0;
    
    SolSplit = [];
    for j = 1:1:rrows
        SolSplit_i = xbinit_local(j)/(sum(xbinit_local));
        SolSplit = [SolSplit SolSplit_i];
    end

    xbchangeFickout = zeros(1,length(xbinit));

end

    % New addition to cope with staggered nucleation
    % Recreate full xbinst array to go back into system

    NonAcSegs = find(StagNucFlag==1);
    NonAcxb = xbinit_local(NonAcSegs);
    xbinst = [xbinst NonAcxb];



end