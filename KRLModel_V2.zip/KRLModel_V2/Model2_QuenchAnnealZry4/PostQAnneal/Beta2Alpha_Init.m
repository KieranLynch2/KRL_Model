function [SolR_T,SolR_y] = Beta2Alpha_Init(tkprof)

% Talpha+beta --> Talpha is something missing from Massih's work so I'm
% going to calculate my own estimation using the work of Forgeron et al.
% Zirconium in nuc inds 12th symp, 256-278.

for tfinal = tkprof(3)%,114]%,1140] %Slowed down for now 

tkinit = tkprof(1);
tkfinal = tkprof(2);
tk = tkinit;
yy = 1; %yy is fraction of beta phase which will be one if quenching from the beta phase
yyout = [yy];
h_tempout = [0];
h_temp = 1e-3;
h_sum = h_temp;
Tout_temp = [tkinit];
dyout = [0];

while yy > 0.01
    
%%    Runge Kutta 4th order method
    %Step 1
    [dy,yy,T] = Beta2Alpha_Kin(tkinit,tkfinal,tfinal,h_temp,tk,yy,h_sum);
    k1 = dy;
    y1 = yy + (k1*h_temp)/2;
    %step 2
    [dy,yy,T] = Beta2Alpha_Kin(tkinit,tkfinal,tfinal,h_temp,tk,yy,h_sum);
    k2 = dy;
    y2 = yy + (k2*h_temp)/2;
    %step 3
    [dy,yy,T] = Beta2Alpha_Kin(tkinit,tkfinal,tfinal,h_temp,tk,yy,h_sum);
    k3 = dy;
    y3 = yy + (k3*h_temp);
    %step 4
    [dy,yy,T] = Beta2Alpha_Kin(tkinit,tkfinal,tfinal,h_temp,tk,yy,h_sum);
    k4 = dy;
    
    yy = yy  + (k1+2*k2+2*k3+k4)*h_temp/6;

%%  Standard single timestep integration
%     [dy,yy,T] = Beta2Alpha_Kin(tkinit,tkfinal,tfinal,h_temp,tk,yy,h_sum);
%     yy = yy + dy;

    
%% Un-comment below for Runge Kutta 4th order and standard solution
    yyout = [yyout yy];
    dyout = [dyout dy];
    h_sum = h_tempout(end) + h_temp;
    h_tempout = [h_tempout h_sum]; % cumulative time output
    Tout_temp = [Tout_temp T];
end

% if tfinal == 11.4
% %     yyout_eq = yyout;
% %     Tout_eq = Tout_temp;
%     yyout_hundred = yyout;
%     Tout_hundred = Tout_temp;
% elseif tfinal  == 114
%     yyout_ten = yyout;
%     Tout_ten = Tout_temp;
% elseif tfinal  == 1140
%     yyout_one = yyout;
%     Tout_one = Tout_temp;
% end

end

% plot(Tout_one,yyout_one)
% hold on
% plot(Tout_ten,yyout_ten)
% hold on
% plot(Tout_hundred,yyout_hundred)

% plot(Tout_temp,yyout)

% b2a_r = b2a_rate(yyout,h_tempout,Tout_temp);
% 
% nad = nad_partition(b2a_r);
% 
% nsites = nad*4.30e28;



%Determine when to release solute each iteration based on temperature
%e.g. every degree release more solute available for precipitation
SolR_T = Tout_temp;
SolR_y = yyout;

plot(SolR_T,SolR_y)

end

