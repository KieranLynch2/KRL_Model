%Script to compare grain boundary to lattice diffusion of Cr in Zr.
%Can assume that the grain boundary diffusivity of Cr will be the rate
%limiting step in Fe-Cr formation as Cr is the slower diffuser.
%Have to make it clear in thesis that same analysis hasn't been carried out
%for Fe-Ni in Zircaloy-2 as data not available (unless I can find suitable
%data!)
%This relationship is taken from Massih (2003), who uses data from Argwala
%(1965) - but i can't find a copy of the Argwala paper.
%This paper - https://www.sciencedirect.com/science/article/pii/S0022311508005151?via%3Dihub
%offers a similar finding of the gb/l ratio of 1e7 at 900 K.
%N.b. Massih finds about 1e5 at 700 K.
%With Massih, at higher temperatures the ratio decreases i.e. gb diffusion
%is closer to that of lattice diffusion

% Qrat = 90000; %OBQ_1 conditions
% prefac = 6500;


Qrat = 12000;
prefac = 11000;


R = 8.314;
% Q = 25300;
% Q = 65000;
Dout = [];
tkout = [];
prefac = 1255.66;
Q = 25300;
% prefac = 5000;
for tk = 500:1:1300
DgbDl = prefac*exp(Qrat/(R*tk));
Dout = [Dout DgbDl];
tkout = [tkout tk];
end
semilogy(tkout,Dout,'-k','LineWidth',2)
xlabel('Temperature / K')
ylabel('Dgb/Dl')
hold on
scatter(900,1e7,100,'filled')
% legend('Massih, 2003 (\alpha-Zr)','Corvalan Moya, 2008 (\alpha-Zr)','OBQ best fit','ABQ best fit')
set(gca,'FontSize',18)
% legend('KWN best fit','Massih, 2003 (\alpha-Zr)','Corvalan Moya, 2008 (\alpha-Zr)')

% plot of KWN
R_KWN = 8.314;
Dout_KWN = [];
tkout_KWN = [];
prefac_KWN = 14000;
Q_KWN = 125000;
for tk_KWN = 500:1:1300
DgbDl_KWN = prefac_KWN*exp(Q_KWN/(R_KWN*tk_KWN));
Dout_KWN = [Dout_KWN DgbDl_KWN];
tkout_KWN = [tkout_KWN tk_KWN];
end
semilogy(tkout_KWN,Dout_KWN,'--k','LineWidth',2)


legend('Massih et al.','Corvalan Moya et al.')

% 
% Qout = [];
% grout = [];
% for Q = 1:10000:1e6
%     gr = exp(-Q/(8.314*973));
%     Qout = [Qout Q];
%     grout = [grout gr];
% end
% semilogy(Qout,grout)