% Script to calculate the redistribution of solute using matlabs PDE.
% For use in the quenching model, as a replacement for the Crank-Nicolson
% method

function [xbnew,SolSplit,Fickcheck,xbchangeFickout] = Fick_PDE(xbinst,d,h,GBWidth,rrows,xbchangeFickout,xbinit)

% GBWidth is the distance from grain centre to grain edge.
% rrows is the number of segments being simulated
% h is timestep
% d is diffusivity
% xbinst is initial xb distribution at this iteration
% xbinit is the initial xb distribution at t = 0

s = GBWidth/rrows; %This is the distance between points for which it is calculated
xbstart = xbinst;
%Bin Centres:
BinCentres = s/2:s:GBWidth;

% 5Might have to shift the bin centres to start from zero to make solver easier!
global BinMatrixpde
global xbinstinitpde
global diff

xbinstinitpde = xbinst;
BinMatrixpde = BinCentres;
diff = d;

m = 0; %Deals with a 1d case
x = BinMatrixpde;
t = [0 h/2 h];

sol = pdepe(m,@pdex1pde,@pdex1ic,@pdex1bc,x,t);
u = sol(3,:,1); %Extract end of timestep, i.e. h
xbnew = u;


% Seperate modelling stuff
    %Fickcheck determination - solute change in any segment is not allowed
    %to change by more than 0.1%
    xbPerChange = [];
    for j = 1:1:rrows
        change = (xbnew(j)-xbstart(j));
        percent_i = abs(change./xbstart(j)).*100;
        xbPerChange = [xbPerChange percent_i];
    end
    
    if any(xbPerChange > 1e-1)
        Fickcheck = 1;
    else
        Fickcheck = 0;
    end


    xbchangeFick = xbnew - xbstart;
    xbchangeFickout = [xbchangeFickout; xbchangeFick];

    %Check xb averages out the same before and after pde
    PrexbAv = mean(xbstart);
    PostxbAv = mean(xbnew);
    if abs(PrexbAv-PostxbAv)> 0.00001
        FlagHere = 1;
    end
    
    
    Fickxbchange = [];
    SolSplit = [];
    for j = 1:1:rrows       
        Fickxbchange_i = (sum(xbchangeFickout(:,j)));
        Fickxbchange = [Fickxbchange Fickxbchange_i];
    end
    for j = 1:1:rrows
        newxb = xbinit(j)+Fickxbchange(j);
        SolSplit_i = newxb/(sum(xbinit));
        SolSplit = [SolSplit SolSplit_i];
    end

%% PDE functions

function [c,f,s] = pdex1pde(x,t,u,DuDx)
global diff
c = 1;
f = diff .* DuDx;
s = 0;

function u0=pdex1ic(x)
global BinMatrixpde
global xbinstinitpde
u0 = interp1(BinMatrixpde,xbinstinitpde,x);

function [pl,ql,pr,qr] = pdex1bc(xl,ul,xr,ur,t)
% pl = 0;
% ql = 1;
% pr = 0;
% qr = 1;

% pl = 0;
% ql = 1;
% pr = ur;
% qr = 0;

pl = 0;
ql = 1;
pr = 0;
qr = 1;