function [grgb] = growth_amorphgb(rbgb,rc_crystgb,ram,sfengb,d,dgb,xbinstgb,xa,xc,tk,vmol,h,t)
% function [gr] = growth(r,sfen,d,xbinst,xc,xa,tk)
% Calculates growth rate of spherical Al3Zr dispersoids
%
% Inputs
% r         Particle radius (m)
% sfen      Interfacial energy (J/m^2)
% d         Diffusion coefficient (m^2/s)
% xbinst    Average Zr concentration in matrix
% xc        Concentration of Zr in dispersoids
% xa        Concentration of Zr in matrix at interface
% tk        Temperature (K)
% Output
% gr        Growth rate (ms^-1)
%
gas = 8.31459;
k = 1.3806488e-23;
hplank = 6.626e-34;
delta = 3.2e-10; % width of interface (assume approx <a> Zr)
na = 6.022045e23;
vat = vmol./na;
%cn = find(r>0);
%cy = find(r<=0);
c_crystgb = find(rbgb>ram);
c_amorphgb = find(rbgb<=ram);


%Change sfen for gb nucleation to make it easier? This will probably also
%have an effect. Also could change No. of nucleation sites (already a
%fitting parameter)

x = (2 * sfengb * vmol)/(gas * tk);
%xr(cn) = xa .* exp(x .* (1./r(cn)));
xr(c_crystgb) = xa .* ((xbinstgb./xa).^((rc_crystgb)./rbgb(c_crystgb)));
% xr(c_amorph) = xa .* ((xbinst./xa).^((rc_amorph)./r(c_amorph))); %no
% amorphization during quenches
%
%
%
%xr(cy) = 0;
%
% For very small particles capillarity equation
% gives xr > xc. Corresponds to very unstable 
% particle. For this case, growth rate will
% be very negative 
%
ind=find(xr>xc);

%Could put a quench flag here to determine when to use gb growth in future
%remember r in these scripts is actually rb.
%As in Kamp et al., 2005, heterogenous nucleation can be emperically
%modelled by adjusting the interfacial energy to effectively reduce the
%surface energy.

%Matrix SPP growth
% gr = ((xbinst - xr)./(xc - xr)) .* (d./r); % Need to make the xbinst for half the model low and then increase it for other half e.g. if solute split is 50/50


% Qrat = 90000; %OBQ_1 conditions
% prefac = 6500;

%dgb is now pre assigned in kinetic script
% Qrat = 70000;
% prefac = 4500;
% Drat = prefac*exp(Qrat/(gas*tk)); %Ratio of Cr gb/l diffusivity (Massih, 2003)
% Dgb = d*Drat; %This is once again a fitting parameter, can fit this and pottentially compare is to gb/latiice diffusivity from Massih, 2003. fig8
% Dgb = d*(1*10^(6));
Dgb = dgb;
Av = 4*pi*Dgb*t; %t is total time as Av is to do with solute depletion close to SPP.

%for now just exlcuding possibility of matrix precipitation
% if t < 0.0056667*3600
    gr = ((Av.*sqrt(d.*h))./(2*(pi^1.5).*rbgb)).*((xbinstgb - xr)./(xc - xr));
% else
%     gr = ((xbinstgb - xr)./(xc - xr)) .* (d./rbgb);
% end


%grmin = find(gr<-1e-6);
%gr(grmin) = -1e-6;
%grmax = find(gr>1e-6);
%gr(grmax) = 1e-6;
rx = isreal(xr);
rgr = isreal(gr);
if rx==0 | rgr==0
    disp(['Imaginary parts in xr and/or gr - Grain boundary'])
end
%
% alternative law for case xr > xc
%
% Maximum boundary velocity limited by interface growth
%
freq = (k .* tk)./hplank;
% for amorphous
% This will only apply when driving force is very big - ie. exp(-driving)=0
% gstar_a = 15930 * k;
% vmax_a =  abs(delta .* freq .* exp(-gstar_a/(k * tk)));
% growlim_a = find(gr(c_amorph) > vmax_a);
% dislim_a = find(gr(c_amorph) < -vmax_a);
% gr(growlim_a) = vmax_a;
% gr(dislim_a) = -vmax_a;
% for crystalline
gstar_c = 15930 * k;
vmax_c =  abs(delta .* freq .* exp(-gstar_c/(k * tk)));
growlim_c = find(gr(c_crystgb) > vmax_c);
dislim_c = find(gr(c_crystgb) < -vmax_c);
gr(growlim_c) = vmax_c;
gr(dislim_c) = -vmax_c;
% Next line critical - otherwize very small particles have +ve growth rate
gr(ind) = -vmax_c;

grgb = gr;
%
%
% 
% REMOVE THIS BIT
%nego = find(gr<0);
%gr(nego) = 0;

aa = 4;
%% Below is quench rate calculations - have to calculate everything for GB
%seperately

% xbinstgb = xb - ((xc - xa) * vfgb);%This has to be the mean matrix conc at the grain boundary, in the PFZ
% xrgb = xa .* ((xbinstgb./xa).^((rc_cryst)./rgb(c_cryst)));

% Qrat = 65000;
% prefac = 5000;
% Drat = prefac*exp(Qrat/(gas*tk)); %Ratio of Cr gb/l diffusivity (Massih, 2003)
% Dgb = d*Drat; %This is once again a fitting parameter, can fit this and pottentially compare is to gb/latiice diffusivity from Massih, 2003. fig8
% % Dgb = d*(1*10^(6));
% 
% Av = 4*pi*Dgb*t; %t is total time as Av is to do with solute depletion close to SPP.
% 
% %for now just exlcuding possibility of matrix precipitation
% gr = ((Av.*sqrt(d.*h))./(2*(pi^1.5).*r)).*((xbinst - xr)./(xc - xr));



%Below is new growth rate based on second order kinetics
% 
% QR = 500;
% gr = (exp(-QR.*(1./tk^2))).*vmol.*(xbinst-xr).^2;

return