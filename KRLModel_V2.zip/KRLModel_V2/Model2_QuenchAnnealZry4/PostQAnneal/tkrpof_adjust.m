function [tkprof] = tkrpof_adjust(tkprof,tknuc)


if tkprof(2) < tkprof(1)
%determine given quench rate assuming linear profile
%This assumes that the first line in tkprof input is the beta quench
QR = (tkprof(1,1)-tkprof(1,2))/tkprof(1,3);

HighT = tknuc; %the point where preciptiation starts (Massih, 2006)
LowT = tkprof(1,2);
% LowT = 473; %simulated down to 200 C, below this there will be minimal ppt.+growth

Tdiff = HighT-LowT;

x = (HighT-LowT)/QR;

tkprof(1,1) = [HighT];
tkprof(1,2) = [ LowT] ;
tkprof(1,3) = [ x];
end

end