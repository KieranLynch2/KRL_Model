function [tknuc,tkPhaseEnd,QuenchRate] = tkprof_Massih(tkprof,SolR_T,SolR_y)

%Find temperature where alpha phase is greater than an arbitrray % (e.g. 5)
% StartPerc = 5;
% StartFrac = StartPerc/100;
% BetaFrac = 1-StartFrac;
% 
% [y] = find(SolR_y < BetaFrac);
% 
% TempStart = SolR_T(y(1));
% 

% 18/1/23 - use the constraints i'm going with for my thesis:

qr = (tkprof(1,1)-tkprof(1,2))/tkprof(1,3);

if abs(qr) < 0.1
    Talpha = 1075;
    Tbeta = 1250;
elseif (0.1 <= abs(qr)) && (abs(qr) <= 100)
    Talpha = 1075 - (31.82*(abs(qr)^0.235)); %Taken from Massih, 2009. 
    Tbeta = 1250 - (8.333*((abs(qr))^0.477));
elseif abs(qr)>100 
    Talpha = 1075 - (31.82*(abs(100)^0.235)); %Taken from Massih, 2009
    Tbeta = 1250 - (8.333*((abs(100))^0.477));
end


% if abs(qr) < 100
%         Talpha = 1075 - (31.82*(abs(qr)^0.235)); %Taken from Massih, 2009. May have to adjust this?
%         Tbeta = 1250 - (8.333*((abs(qr))^0.477));
% elseif abs(qr)>100.1 %&& abs(qr) < 500
%         Talpha = 1075 - (34.1*(abs(qr)^0.22)); %708 --> 672
%         Tbeta = 1250 - (24.83*((abs(qr))^0.24));
% end

TempStart = Tbeta;






TempEnd = Talpha;
% if tkprof(2) < tkprof(1)
% %determine given quench rate assuming linear profile
% %This assumes that the first line in tkprof input is the beta quench
% QR = (tkprof(1,1)-tkprof(1,2))/tkprof(1,3);
% 
% HighT = TempStart; %the point where preciptiation starts (Massih, 2006)
% % LowT = tkprof(1,2);
% LowT = 473; %simulated down to 200 C, below this there will be minimal ppt.+growth
% 
% Tdiff = HighT-LowT;
% 
% x = (HighT-LowT)/QR;
% 
% tkprof(1,1) = [HighT];
% tkprof(1,2) = [ LowT] ;
% tkprof(1,3) = [ x];
% end

tknuc = TempStart;
tkPhaseEnd = TempEnd;
QuenchRate = qr;

end