function [nrgb] = nucrate_amorphgb(rcgb,sfengb,nsitesingb,xbinstgb,xb,dgb,t,tk,tau,vmol,a,d)
% function [nr] = nucratesc(rcrit,sfen,nsites,d,t,tk)
% Calculates time dependent nucleation rate in Cu-Co
% (using expression from Hyland paper)
% 

% dgb = d;
sfengb = 0.08;


k = 1.380662e-23;
na = 6.022045e23;
h = 6.626176e-34;
%
% aprod should be diffusion distance
% ie shortest lattice vector
%
% sfen = 0.15; %adjust sfen just for nucrate calcs 
aprod = a;
vat = vmol/na;


sigma = 0.5; %Gb energy (J/m2) from Plowman 2020, as a guide
theta = (sigma/(2*sfengb));
ShapeFac = ((2+cosd(theta))*((1-cosd(theta))^2))/2;

gstar = 4/3 * pi * (rcgb.^2) * sfengb;
gstarHet = gstar;%*ShapeFac;
%
% Modify nsites to account for loss of solute
%
%nsites = nsitein .* (xbinst./xb);
nsitesgb = nsitesingb;
if rcgb>0.0
dg = (-2 * sfengb)./rcgb;
zeld = (vat .* dg.^2)./(8 * pi * ((sfengb^3*k.*tk).^0.5));
%
% See stocalc.m for configuration for data sent to MJS
%
% Comment out next line for beta and tau line to get KW method
% uncomment tau in main program
% beta = (16 .* pi .* (sfen^2) .* xbinst .* d)./((dg.^2) .* (aprod^4));
% Below - beta for Aaronson from Stowell (p.6)
beta = (4 * pi * rcgb^2 * dgb * xb)/(aprod^4);
% Below - beta for KW (Servi-Turnbull method)
%betakw = (d*xbinst) /  ((0.7071*aprod)^2);
%beta = betakw;
%
% Russell beta factor (as used by Aaronson) 
% beta = betakw * 4* pi * ((rc/(0.7071*aprod))^2);
% tau from Stowell, theta from Stowell, p. 10
%theta = 1;
%tau = 1/(theta * beta * (zeld^2));
% tau from Aaronson
ktau = 8;
%tau = (ktau * k * tk * sfen * (aprod^4))/((vat^2) * (dg^2) * d * xb);
%ignore incubation time
tau=1e-100;
if t>=0
    nrgb = nsitesgb.*zeld.*beta.*exp(-gstarHet./(k .* tk));
    % Change next bit!
    % nr = nsites.*zeld.*beta.*exp(-gstar./(k .* tk));
    aa=4;
else
    nrgb = 0;
end
else
    nrgb = 0;
end
return
   