function [StagNucFlag,nucflag,StagNucFlagTrip,h,TempInitSeg] = StagNuc(StagNucFlag,tk,tknuc,tkPhaseEnd,rrows,nucflag,StagNucFlagTrip,h)

hinit = h;

%Check temperature and activate segments which require it

TempSegs = linspace(tknuc,tkPhaseEnd,rrows+1); %the +1 indicates the the full completion, but the bin before this indicates the start of the transformation at that edge

TempInitSeg = TempSegs(1:end-1);

for j = 1:1:length(TempInitSeg)
    if tk<TempInitSeg(j)
        StagNucFlag(j) = 0;
    end
end


for j = 1:1:rrows
    if StagNucFlag(j) == 1
        nucflag(j) = 1;
    elseif StagNucFlag(j) == 0
        if StagNucFlagTrip(j) == 0
            nucflag(j) = 0; %Need to limit this to only trigger once
            StagNucFlagTrip(j) = 1;
        end
    end
end



if StagNucFlagTrip(end) == 1
    h = 1e-14;
else 
    h = hinit;
end

%Set nucflags to 1 if StagNucFlag = 1, whereas if StageNucFlag = 0, then
%nucflags remain as they were





end