function [nrgb,grgb] = nucgrow_amorphgb(vfgb,ram,rbgb,d,dgb,t,nsitesgb,sfengb,tk,xa,xb,xc,tau,vmol,a,h,sfen,xbinstgb,xbinstTot)
%
% function [nr,gr] = nucgrow(vf,rb,d,nsites,sfen,tk,xa,xb,xc)
% Inputs
% vf        Current volume fraction of dispersoids
% r         Mean size of size classes (m)
% d         Diffusion coefficient (m^2s^-1)
% nsites    Number density of nucleation sites (/m^-3)
% sfen      Interfacial energy for nucleation/growth (J/m^-2)
% tk        Temperature  (K)
% xa        Equilibrium concentration of Zr in matrix at planar interface
% xb        Current average zirconium concentration in matrix
% xc        Zirconium concentration in dispersoids
% Outputs
% nr        Nucleation rate of dispersoids (m^-3s^-1)
% gr        Growth rate of each size class (ms^-1)
%
%
% update mean matrix concentration
%
%     xbinstgb = xb - ((xc - xa) * vfgb);
%
% calculate critical radius, growth and nucleation rates
%
% xbinst is recalculated in critradco: Do not pass
    rc_crystgb = critrad_crystgb(sfengb,xa,xb,xc,vfgb,tk,vmol,sfen,xbinstgb,xbinstTot);
%     rc_amorph = critrad_amorph(sfen,xa,xb,xc,vf,tk,vmol);
    nrgb = nucrate_amorphgb(rc_crystgb,sfengb,nsitesgb,xbinstgb,xb,dgb,t,tk,tau,vmol,a,d);
    grgb = growth_amorphgb(rbgb,rc_crystgb,ram,sfengb,d,dgb,xbinstgb,xa,xc,tk,vmol,h,t);
 %   if rc_cryst > max(r)
 %       disp(['stop'])
 %   end
