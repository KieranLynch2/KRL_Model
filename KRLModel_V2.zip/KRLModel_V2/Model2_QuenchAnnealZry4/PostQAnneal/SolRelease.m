function [xbinst,alphaTrack,alphaTrackAll,xbCur,xbCurTrack,VfMax,VfMaxTrack] = SolRelease(xbinit,xbinst,SolR_y,SolR_T,tk,alphaTrack,alphaTrackAll,xb,xbCurTrack,xc,xa,VfMaxTrack)

%Use xbinit to slowly release solute fractionally and add it to xbinst;

%Do it in 1 degree chunks
tkrange = 1500:-1:10;

%Round tk 
Rtk = round(tk);

%Find alpha frac based on tk
Tind = find(SolR_T<Rtk);


if length(Tind) > 1
    betaFrac = SolR_y(Tind(1));
else 
    betaFrac = 0;
end

alphaFrac = 1-betaFrac;

%Track alpha fraction
if alphaFrac ~= alphaTrack(end)
   alphaTrack = [alphaTrack alphaFrac]; %this works as tk is rounded, so alpha only changes every 1 degree, rather than every smaller increment
end

alphaTrackAll = [alphaTrackAll alphaFrac];

%Determine solute released 
if length(alphaTrack)>1
    Newalpha = alphaTrack(end)-alphaTrack(end-1);
else
    Newalpha = 0;
end

if alphaTrackAll(end) > alphaTrackAll(end-1)
SolRel = xbinit.*Newalpha;
%Add solute released to xbinst
xbinst = xbinst + (SolRel*(1/alphaTrack(end))); %Only the new solute released should be adjusted to account for supersaturation dependent on fraction of alpha phase as the previous solute has already been adjusted.
% xbinst = xbinst*(1/alphaTrack(end));

xbCur = xbinit.*alphaTrack(end); %Only a certain amount of the total xb is going to be available

VfMax = (xbCur)./xc;
else
    xbCur = xbCurTrack(end,:);
    VfMax = VfMaxTrack(end,:);
end

xbCurTrack = [xbCurTrack; xbCur];
VfMaxTrack = [VfMaxTrack; VfMax];

%flaw with this method is that there will still be regions of high
%supersaturation, even if it is say 10 % of total microstructure, they will
%still have high local conc.


end