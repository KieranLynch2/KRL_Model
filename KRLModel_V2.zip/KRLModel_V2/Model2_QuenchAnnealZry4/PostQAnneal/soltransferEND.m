function [xbinst,TotalSolDistEnd,xbinstTotTrackEnd,flagSol,flagSolgb,nucflag,SolSplit,Fickcheck,xbchangeFickout] = soltransferEND(vfTrack,vfgbTrack,xa,xb,xc,h,d,firstit,TotalSolDistEnd,xbinstTrack,vf,xbout,GBWidth,xbinstTotTrackEnd,vfout,flagSol,flagSolgb,xbinit,nucflag,r,SolSplit,xbchangeFickout,FickSwitch,xbCur,VfMax,alphaTrack,StagNucFlag)
%function to calculate the trasnfer of solute from the matrix region to the
%grain boundary region at the start of each iteration, taking inputs such
%as xbinst and vf from the end of the last iteration.
%The movement of solute into GB region is going to be determined using
%sqrt(dt) approach.
%N.B. the Start and End soltransfer scripts are just to keep the xbinst
%consistent through the slopes of each full iteration, the End script
%provides output values.

%% New method

% xb = xbCur;

alphafrac = alphaTrack(end);
vftemp = vf.*(1./alphafrac);

rsz = size(r);
rrows = rsz(1);
xbinst = [];
for j = 1:1:rrows
    xbinst_i = (xb.*SolSplit(j) - (vftemp(j).*(xc-xa)))/(1./rrows); %Changed (1/rrows) to (1/1)
%     xbinst_i = ((xb.*SolSplit(j))/(1./rrows)) - (vftemp(j).*(xc-xa)); %Changed (1/rrows) to (1/1)
    xbinst = [xbinst xbinst_i];
end



vfCurMax = sum(vftemp);
xbinstTot = xb - ((xc - xa) * vfCurMax);

xbinstTotTrackEnd = [xbinstTotTrackEnd xbinstTot];

%when Fick's law is active the value of SolSplit will have to be adjusted!

if FickSwitch == 1
    [xbinst,SolSplit,Fickcheck,xbchangeFickout] = FicksLaw(xbinst,d,h,GBWidth,rrows,vf,xc,xa,xbchangeFickout,xbinit,StagNucFlag);
%     [xbnew,SolSplit,Fickcheck,xbchangeFickout] = Fick_PDE(xbinst,d,h,GBWidth,rrows,xbchangeFickout,xbinit);
%     xbinst = xbnew;
else 
    Fickcheck = 0;
end


%% Old new mthoed here:
%     if firstit == 0
%         gbdist = GBDistStart;
%         MatrixDist = (GBWidth - gbdist)/GBWidth;
%         PFZDist = gbdist/GBWidth;
%         
%         xbinstgb = (xb*SolSplitGB - (vfgb*(xc-xa)))/PFZDist;
%         xbinst = (xb*SolSplitM - (vf*(xc-xa)))/MatrixDist;
%         
%         vfCurMax = vf + vfgb;
%         xbinstTot = xb - ((xc - xa) * vfCurMax);
%         
% %         TotalSolDist = [TotalSolDist 0]; %Need to update this for solute transfer..., although saying that, can probably just do solute transfer at the end of each iteration...
%         
% %         vfTrack = [vfTrack vf];
% %         vfgbTrack = [vfgbTrack vfgb];
% %         xbinstTrack = [xbinstTrack xbinst];
% %         xbinstgbTrack = [xbinstgbTrack xbinstgb];
%         xbinstTotTrackEnd = [xbinstTotTrackEnd xbinstTot];
%         
%         dtTrack = [];
%     else
%         %size ratios of the GB to matrix systems, this will be constant before
%         %solute sharing is enabled
%         gbdist = GBDistStart;
%         MatrixDist = (GBWidth - gbdist)/GBWidth;
%         PFZDist = gbdist/GBWidth;
%         
%         
%         xbinit = 0.0051;
%         vmax = (xbinit - xa)/(xc - xa);
%         
%         PossVfgb = vmax*0.5;  %change 0.5 depending on solute split between systems
%         PossVfM = vmax*0.5;
%         
%         VfRemgb = PossVfgb - vfgb;
%         VfRemM = PossVfM - vf;
%         
%         
%         
%         xbinstgb = (xb*SolSplitGB - (vfgb*(xc-xa)))/PFZDist;
%         xbinst = (xb*SolSplitM - (vf*(xc-xa)))/MatrixDist;
%         
%         
%         
%         %can try with these on/off to see difference
%         if xbinst < 1.1*xa
%             nucflag = 1;
%         end
%         if xbinstgb < 1.1*xa
%             nucflaggb = 1;
%         end
%         
%         if VfRemM < 1e-5 %Might change this to xbinst and xa function of
%             nucflag = 1;
%         end
%         
%         if VfRemgb < 1e-5 %Might change this to xbinst and xa function of
%             nucflaggb = 1;
%         end
%         
%         vfCurMax = vf + vfgb;
%         xbinstTot = xb - ((xc - xa) * vfCurMax);
%         
% %         vfTrack = [vfTrack vf];
% %         vfgbTrack = [vfgbTrack vfgb];
% %         xbinstTrack = [xbinstTrack xbinst];
% %         xbinstgbTrack = [xbinstgbTrack xbinstgb];
%         xbinstTotTrackEnd = [xbinstTotTrackEnd xbinstTot]; %Need to include this so the MIDDLE script has a new value to work from
%         
%         % Jms = ((xbinstinit-xbinstgbinit)*sqrt(d))/(sqrt(pi*h)); %Yi, 2014
%         
%         
%         [xbinst,xbinstgb] = xbinstCalcRun(xbinst,xbinstgb,d,h);
%     end


%% Old method

% % % %I need to use xbinst from the previous iteration at this point (i.e. END)
% % % %And the volume fractions calculated just above in kin script
% % % %I am not comparing xbinst and Vf with the slope updates, i am only
% % % %comparing it with the total end of each iteration
% % % 
% % % % if flagSol == 0 && flagSolgb == 0
% % %     
% % % xbinstinit = xbout(end); %This will be xbinst at end of last iterataion
% % % xbinstgbinit = xboutgb(end); %I need to get a total xbinst array
% % % 
% % % 
% % % %Distance travelled by matrix solute
% % % % dt = 0.5*(d*(h));
% % % % 
% % % % Olddt = cumsum(dtEnd);
% % % % 
% % % % Totaldt = Olddt(end) + dt;
% % % % MeanSq = sqrt(Totaldt);
% % % % 
% % % % TotDist = MeanSq;
% % % % 
% % % % dtEnd = [dtEnd dt];
% % % % 
% % % % Fin = cumsum(dtEnd);
% % % % final = Fin(end);
% % % % Sec = cumsum(dtEnd(end-1));
% % % % second = Sec(end);
% % % % dist = sqrt(final) - sqrt(second); %This is the new distance this iteration
% % % 
% % % % TotalSolDistEnd = [TotalSolDistEnd dist]; %Make this array only add up solute distance at end of array, exclude start and middle additions
% % % % TotDistAr = cumsum(TotalSolDistEnd); %do i need to do something with tracking total distance of PFZ??
% % % % TotDist = TotDistAr(end);
% % % 
% % % 
% % % % %TEMP
% % % % TotDist = PFZ;
% % % % dist = PFZ-PFZout(end);
% % % 
% % % 
% % % %for xbinst calcs it I need to find the area/length of the zone which is
% % % %used for, this can either be done using PFZ measurements of by calculating
% % % %the distance moved by matrix solute each iteration and keeping track of it
% % % %PFZ measurements are not turning out correclty at the moment, so i'll use
% % % %distance moved by solute to determine answer.
% % % %Gets a bit complex as precipitation is happening during the quench i.e. it
% % % %is not just a case of solute diffusing from matrix to gb as a lot of the
% % % %solute is pushed the the GB so there solute concentration there will be
% % % %high (I think), might have to couple this with a grain growth model and
% % % %predict the solute distribution across the grain as it transforms.
% % % 
% % % % vfCurMax = vf + vfgb; %These are current Vfs
% % % % xbinstTot = xb - ((xc - xa) * vfCurMax); 
% % % % xbinstUsed = xbinstTotTrackEnd(end) - xbinstTot;
% % % % 
% % % % 
% % % % 
% % % % NewVf = vf - vfout(end); %This is the new volume fraction formed on iteration
% % % % NewVfgb = vfgb - vfoutgb(end);
% % % % 
% % % % VfgbRat = NewVfgb/(NewVfgb+NewVf);
% % % % VfRat = NewVf/(NewVfgb+NewVf);
% % % % 
% % % % xbinstTEMP = xbinstUsed*(VfRat); %Amount of solute that has been used by each system
% % % % xbinstgbTEMP = xbinstUsed*(VfgbRat);     
% % % % 
% % % % 
% % % % xbinstTEMP(isnan(xbinstTEMP))=0;
% % % % xbinstgbTEMP(isnan(xbinstgbTEMP))=0;
% % % % 
% % % % % xbinsttemp = xbinstinit-xbinstTEMP; %Original solute in each system - solute used
% % % % % xbinstgbtemp = xbinstgbinit-xbinstgbTEMP;
% % % % 
% % % % 
% % % % 
% % % % xbinsttemp2 = xbinstinit-xbinstTEMP; %Original solute in each system - solute used
% % % % xbinstgbtemp2 = xbinstgbinit-xbinstgbTEMP;
% % % % 
% % % % xbinst= xbinsttemp2;
% % % % xbinstgb = xbinstgbtemp2;
% % % % 
% % % 
% % % 
% % % %Vf created this iteration
% % % vfCurMax = vf + vfgb;
% % % NewVf = vf - vfout(end); %This is using vf out from true end of iteration
% % % NewVfgb = vfgb - vfoutgb(end); 
% % % 
% % % %Ratio of vf created
% % % VfgbRat = NewVfgb/(NewVfgb+NewVf);
% % % VfRat = NewVf/(NewVfgb+NewVf);
% % % 
% % % %Total xb used this iteration
% % % xbinstTot = xb - ((xc - xa) * vfCurMax); 
% % % xbinstUsed = xbinstTotTrackEnd(end) - xbinstTot;  %have to do xbinsttot at end of full iteration 
% % % 
% % % %Amount of solute that has been used by each system
% % % xbinstTEMP = xbinstUsed*(VfRat); 
% % % xbinstgbTEMP = xbinstUsed*(VfgbRat); 
% % % 
% % % %size ratios of the GB to matrix systems, this will be constant before
% % % %solute sharing is enabled
% % % gbdist = GBDistStart;
% % % MatrixDist = (GBWidth - gbdist)/GBWidth; 
% % % PFZDist = gbdist/GBWidth;
% % % 
% % % %Previous sol conc of each system
% % % SolCM = MatrixDist*xbout(end);
% % % SolCgb = PFZDist*xboutgb(end);
% % % 
% % % %Reduce the SolC by determine amounts
% % % NewSolCM = SolCM-xbinstTEMP;
% % % NewSolCgb = SolCgb - xbinstgbTEMP;
% % % 
% % % %Resolve equation to get new xbinst values
% % % 
% % % xbinst = NewSolCM/(MatrixDist);
% % % xbinstgb = NewSolCgb/(PFZDist);
% % % 
% % % 
% % % 
% % % xbinit = 0.0051;
% % % vmax = (xbinit - xa)/(xc - xa);
% % %     
% % % PossVfgb = vmax*0.5;  %change 0.5 depending on solute split between systems
% % % PossVfM = vmax*0.5;
% % % 
% % % VfRemgb = PossVfgb - vfgb;
% % % VfRemM = PossVfM - vf;
% % % 
% % %     xbinstgb = (xb/2 - (vfgb*(xc-xa)))/PFZDist;
% % %     xbinst = (xb/2 - (vf*(xc-xa)))/MatrixDist;
% % % 
% % % if xbinst < 1.1*xa || xbinstgb < 1.1*xa
% % %     xbinstgb = (xb/2 - (vfgb*(xc-xa)))/PFZDist;
% % %     xbinst = (xb/2 - (vf*(xc-xa)))/MatrixDist;
% % %     if xbinst < 1.1*xa
% % %         nucflag = 1;
% % %     end
% % %     if xbinstgb < 1.1*xa
% % %         nucflaggb = 1;
% % %     end
% % % end
% % % 
% % % if VfRemM < 1e-5 %Might change this to xbinst and xa function of
% % %     nucflag = 1;
% % % end
% % % 
% % % if VfRemgb < 1e-5 %Might change this to xbinst and xa function of
% % %     nucflaggb = 1;
% % % end
% % % 
% % % 
% % % 
% % % 
% % % 
% % % 
% % % % if VfRemM < 1e-4
% % % %     nucflag = 1;
% % % %     xbinstgb = xb/2 - (vfgb*(xc-xa))/PFZDist;
% % % %     xbinst = (xb/2 - (vf*(xc-xa)))/MatrixDist;
% % % % else 
% % % %     nucflag = 0;
% % % % end
% % % % 
% % % % if VfRemgb < 1e-4
% % % %     nucflaggb = 1;
% % % %     xbinstgb = xb/2 - (vfgb*(xc-xa))/PFZDist;
% % % %     xbinst = (xb/2 - (vf*(xc-xa)))/MatrixDist;
% % % % else 
% % % %     nucflaggb = 0;
% % % % end
% % % 
% % % % gbdist = TotDist;
% % % % [xbinsttemp,xbinstgbtemp] = xbinstCalcRun(xb,xc,xa,GBWidth,d,h,gbdist,xbinsttemp2,xbinstgbtemp2,xbinstTot);
% % % 
% % % 
% % % % % % dividing system up 
% % % % 
% % % % MatrixDist = (GBWidth - TotDist)/GBWidth;
% % % % PFZDist = TotDist/GBWidth;
% % % % 
% % % % Mfrac = xbinsttemp2 * MatrixDist;
% % % % GBfrac = xbinstgbtemp2 * PFZDist;
% % % % 
% % % % MFrac = Mfrac/(Mfrac+GBfrac);
% % % % GBFrac = GBfrac/(Mfrac+GBfrac);
% % % % 
% % % % xbinsttemp = MFrac * xbinstTot;
% % % % xbinstgbtemp = GBFrac * xbinstTot;
% % % 
% % % 
% % % 
% % % % % VfgbRat = vfgb/(vf+vfgb);
% % % % % VfRat = vf/(vf+vfgb);
% % % % % 
% % % % % xbinstTEMP = xbinstUsed*(VfRat); %Amount of solute that has been used by each system
% % % % % xbinstgbTEMP = xbinstUsed*(VfgbRat);     
% % % % % 
% % % % % xbinsttemp = xbinstinit-xbinstTEMP; %Original solute in each system - solute used
% % % % % xbinstgbtemp = xbinstgbinit-xbinstgbTEMP;
% % % 
% % % 
% % % %Now i need to add extra solute to GB region, on top of the
% % % %newly calculated xbinst
% % % % soldeplet = (dist/(GBWidth-TotDist))*(xbinsttemp);
% % % %             
% % % % soldeplet = 0;
% % % % 
% % % % xbinst = xbinsttemp - soldeplet;
% % % % xbinstgb = xbinstgbtemp + soldeplet;
% % % % % 
% % % % % PossVfgb = (xb-(0.4157*0.0061))/(xc-xa); %Change 0.0061 based on distances, 0.4157 on initial sol conc
% % % % % PossVfM = (xb-(0.0026*0.9939))/(xc-xa);
% % % % 
% % % % 
% % % %     xbinit = 0.0051;
% % % %     vmax = (xbinit - xa)/(xc - xa);
% % % %     
% % % %     PossVfgb = vmax*0.5;  %change 0.5 depending on solute split between systems
% % % %     PossVfM = vmax*0.5;
% % % % 
% % % % VfRemgb = PossVfgb - vfgb;
% % % % VfRemM = PossVfM - vf;
% % % % 
% % % % xbinsttemp = VfRemM*(xc); %This is amount of solute left in each system
% % % % xbinstgbtemp = VfRemgb*(xc);
% % % % 
% % % % xbinst = xbinsttemp + xa;
% % % % xbinstgb = xbinstgbtemp + xa;
% % % 
% % % 
% % % % Mrat = xbinsttemp/(xbinsttemp+xbinstgbtemp);
% % % % gbrat = xbinstgbtemp/(xbinsttemp+xbinstgbtemp);
% % % % 
% % % % ratGB = xbinstTot*gbrat;
% % % % ratM = xbinstTot*Mrat;
% % % % 
% % % % xbinstgb = ratGB/(0.0061);
% % % % xbinst = ratM/(0.9939);
% % % 
% % % % if xbinst < xa*1.01 %If the matrix solute comes within 10 % of xa, then flag is activated
% % % % %  xbinst3 = xa*1;
% % % %  flagSol = 1;
% % % % end
% % % % if xbinstgb < xa*1.01
% % % % %  xbinstgb3 = xa*1;
% % % %  flagSolgb = 1;
% % % % end
% % % % 
% % % % else %If flag sol is activated the solute in the system is close enough to xa that the system is now in equilbirium
% % %     %So the two systems should now be essentially de-coupled and allowed to
% % %     %grow/coarsen naturally.
% % % %     a = 44;
% % % %     
% % % %     %     
% % % %     vfCurMax = vf + vfgb; %These are current Vfs
% % % %     xbinstTot = xb - ((xc - xa) * vfCurMax);
% % % % 
% % % %     
% % % %         
% % % % %     PossVfgb = (xb-(0.4157*0.0061))/(xc-xa); %change max possible vf based on xa
% % % % % PossVfM = (xb-(0.0026*0.9939))/(xc-xa);
% % % % 
% % % %     xbinit = 0.0051;
% % % %     vmax = (xbinit - xa)/(xc - xa);
% % % %     
% % % %     PossVfgb = vmax*0.5;  %change 0.5 depending on solute split between systems
% % % %     PossVfM = vmax*0.5;
% % % % 
% % % % 
% % % % VfRemgb = PossVfgb - vfgb;
% % % % VfRemM = PossVfM - vf;
% % % % xbinsttemp = VfRemM*(xc);
% % % % xbinstgbtemp = VfRemgb*(xc);
% % % % 
% % % % Mrat = xbinsttemp/(xbinsttemp+xbinstgbtemp);
% % % % gbrat = xbinstgbtemp/(xbinsttemp+xbinstgbtemp);
% % % % 
% % % % ratGB = xbinstTot*gbrat;
% % % % ratM = xbinstTot*Mrat;
% % % % 
% % % % xbinstgb = ratGB/(0.0061);
% % % % xbinst = ratM/(0.9939);
% % % % 
% % % % 
% % % %     
% % % % %     %Remaining solute in Matrix system is 
% % % % %     xbinstRem = vf*(xc);
% % % % % %     xbinst3Rem = vf3*(xc-xa); %try next if fails
% % % % %     xbinst = xbinstRem - (vf*(xc-xa));
% % % % %     
% % % % %     
% % % % %     xbinstgbRem = vfgb*xc;   
% % % % %     xbinstgb = xbinstgbRem - (vfgb*(xc-xa));
% % % % % if VfRemgb <= 0
% % % %     xbinstgb = (xbinitgb) - (vfgb*(xc-xa));
% % % % % end
% % % % % 
% % % % % if VfRemM <= 0
% % % %     xbinst = (xbinitM) - (vf*(xc-xa));
% % % % end
% % % % end
% % % % vfTrack = [vfTrack vf]; %vf track is used for debugging the sloped sol transfers
% % % % vfgbTrack = [vfgbTrack vfgb];
% % % % xbinstTrack = [xbinstTrack xbinst]; %similarly these are used to track xbinst in slopes for debugging
% % % % xbinstgbTrack = [xbinstgbTrack xbinstgb];
% % % xbinstTotTrackEnd = [xbinstTotTrackEnd xbinstTot]; %Needed to have previous xbinst ready for each iteration
% % % 
% % % 
% % % % Jms = ((xbinstinit-xbinstgbinit)*sqrt(d))/(sqrt(pi*h)); %Yi, 2014
    
return