function [xbinst,xbinstgb] = xbinstCalcRunTest(xb,xc,xa,GBWidth,d,h,gbdist,xbinsttemp,xbinstgbtemp,xbinstTot)


GBWidth = 8.15e-7;

% Dist = 10e-9; %give width of 10 nm

%gbdist is now the distance of the GB system

MatrixDist = 0.9877; %ratios of widths of each system
PFZDist = 0.0123;


%Concentrations are now determined by using the new xbinst of each system
%compared to the total system
% 
% gbarea = xbinstgbtemp*PFZDist;
% Marea = xbinsttemp*MatrixDist;

ConcPerGB = 0.802;
ConcPerM = 0.198;

TotalArea = 0.0051*GBWidth;

% TotalArea = xbinstTot*1; %set the hypothetical width to 1 as the gb nd M widths are in terms of ratios so add up to 1


%x is height of GB region (xbinstgb)
%y is height of matrix region (xbinst)
syms x y

eqns = [MatrixDist*y + PFZDist*x == TotalArea, PFZDist*x/(MatrixDist*y + PFZDist*x) == ConcPerGB, MatrixDist*y/(MatrixDist*y + PFZDist*x) == ConcPerM];

S = solve(eqns,[x,y]);

xbinst = (S.y)/GBWidth;
xbinstgb = (S.x)/GBWidth;

xbinst = double(xbinst);
xbinstgb = double(xbinstgb);




end