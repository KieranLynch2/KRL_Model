function PFZ = lengthpfz(xc,xa,rgb,ngb,Vgrain,Agb)

%If seperating model from GB to matrix ppts then r and n here must be rgb
%and ngb

PFZ = (2/3).*pi.*(Vgrain./Agb).*(xc./xa).*(sum(ngb.*rgb.^3));

end