
%Assume max vf i.e. nucleation is complete 

% vf = 0.007;
% xc = 0.66;
% xa = exp((-5.4e3./tk)-3.3); 
% xb = 0.0018 + 0.0033*2;
% 
% xbinst = xb - ((xc - xa) .* vf)
% 
% 
% 
% 
% nr = nsites.*zeld.*beta.*exp(-gstar./(k .* tk));
Sout = [];
Tout = [];

for sigma = 0.001:0.001:10
 %Gb energy (J/m2) from Plowman 2020, as a guide
theta = (sigma/(2*0.22));
ShapeFac = ((2+cosd(theta))*((1-cosd(theta))^2))/2;
Sout = [Sout ShapeFac];
Tout = [Tout sigma];
end
semilogy(Tout,Sout)