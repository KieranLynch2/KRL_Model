
% Explicit parallelism using 'parpool'
% nslots = str2double(getenv('NSLOTS'));
% parpool(nslots);
% pp = gcp;
% poolsize = pp.NumWorkers;

QRList = [500 6 10 20 60 126 590 309 817 1000 2000 3000];
% QRList = [817 1000 2000 3000];
for j = 1:1:length(QRList)
    load(['../Qr_' num2str(QRList(j)) '/Output_QR_' num2str(QRList(j)) '.mat'])

%     n_LogNorm = zeros(10,270); %DON'T WANT TO PERFORM LOGNORM ADJUSTING
%     UNTIL FINAL STEP IS DONE
%     r_LogNorm = zeros(10,270);
%     for k = 1:1:10
%         pgpout = [];
%         rCur = r(1,:);
%         nCur = n(k,:);
%         vfCur = vfout(:,k)';
%         rbarCur = rbarout(:,k)';
%         [r_ln,n_ln] = lognrm_adjust(rCur,nCur,pgpout,rbarCur,vfCur);
%         n_LogNorm(k,:) = n_ln;
%         r_LogNorm(k,:) = r_ln;
%     end
% 
%     r_in = r_LogNorm(1,:);
%     n_in = sum(n_LogNorm);

    %% Do not touch
    FileName = [];
    zirc2flag = 0;
    radflag = 0;
    phi = 0;
    InputFlag = 1;
    QR = QRList(j);
    for tlynch = 4
        tc = 700;
        t = tlynch;

        OFN = (['OutputLynch700C_' num2str(t) 'hr_QR' num2str(QRList(j)) '.mat']); % Choose an output filename 
        CallScript(tc,t,OFN,InputFlag,zirc2flag,radflag,phi,FileName,QR)
    end

end