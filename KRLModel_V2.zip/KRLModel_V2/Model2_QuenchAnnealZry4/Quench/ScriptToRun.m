
QR = 1000;
FeConc = 0.0033; %in at. frac.
CrConc = 0.0018; 

OFN = (['Output_QR_' num2str(QR) '.mat']);


% Do not edit below without permission!

NSegs = 10; %This is 10 by default, simulations can be sped up by decreasing - see K.Lynch thesis for full description

time = (1050-25)./QR;

[r,rb,n,tkprof,xb,xc,sfen,nsites,vmol,a,a_init,sfengb,nsitesgb,Vgrain,Agb,GBWidth]=zr_amorph_init_noniso([1050 25 (time/3600)],FeConc,CrConc,NSegs);%ABQ, from Massih, 2003 the QR should be determined from 1050C to 750C, which is where the lamella thickness relationship is derived.


[r,n,tout,tkout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout,xaout,growthout,grtrck2,grtrck4,grtrck6,PFZout,r_ln,n_ln,xbinstTrack,hout,Distout,TotalSolDistEnd,dtEnd,dtTrack,firstit,xbinstTotTrackEnd,vfTrack,SolSplitout,xbchangeFickout,Avout]= ...
    zr_amorph_kin_noniso(r,rb,n,tkprof,xb,xc,sfen,sfengb,nsites,vmol,a,a_init,Vgrain,Agb,GBWidth,0);

save([OFN])


% Can i do postQ anneal here? Just put fickswitch into off mode?














%% Misc code - might find some useful plots down here

% clear all
% load '750C12hours.mat'
% r_init = r;
% n_init = n;
% 
% [r,rb,n,tk,d,tfinal,xb,xc,xa,sfen,nsites,vmol,vmax,a,a_init]=zr_amorph_init(700,50);
% 
% [r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout]= ... 
%     zr_amorph_kin(r,n,rb,tk,tfinal,d,xa,xb,xc,sfen,nsites,vmol,a,a_init,0);
% 
% plot((r.*2).*(10^9),n.*(10^-18))
% xlim([0 200])
% % semilogx(tout,grout)

%1050 to 10 in 289 seconds
%WBQ = 480, OBQ = 51, ABQ = 3.6
% a=5;

% 13.9.22 - next step is to change the way solute is released, make more of
% it come out at the end of the transformation. This makes sense as solute
% segregation may push more solute to the betlamdaa regions.

% Simluations for thesis using orgininal parameters of Massih/Robson.
%ABQ: 10 k/s
% [r,rb,n,tkprof,xb,xc,sfen,nsites,vmol,a,a_init,sfengb,nsitesgb,Vgrain,Agb,GBWidth]=zr_amorph_init_noniso([1050 25 (102.5/3600)]);%ABQ, from Massih, 2003 the QR should be determined from 1050C to 750C, which is where the lamella thickness relationship is derived.

%WBQ: 2000 k/s
% [r,rb,n,tkprof,xb,xc,sfen,nsites,vmol,a,a_init,sfengb,nsitesgb,Vgrain,Agb,GBWidth]=zr_amorph_init_noniso([1050 25 (0.5125/3600)]);%WBQ, from Massih, 2003 the QR should be determined from 1050C to 750C, which is where the lamella thickness relationship is derived.
% 


% [r,rb,n,tkprof,xb,xc,sfen,nsites,vmol,a,a_init,sfengb,nsitesgb,Vgrain,Agb,GBWidth]=zr_amorph_init_noniso([700 700 0.1]);%ABQ, from Massih, 2003 the QR should be determined from 1050C to 750C, which is where the lamella thickness relationship is derived.


%[r,rb,n,tkprof,xb,xc,sfen,nsites,vmol,a,a_init,sfengb,nsitesgb,Vgrain,Agb,GBWidth]=zr_amorph_init_noniso([1050 750 0.5/3600]); %OBQ July 2022 TEM fit

% [r,rb,n,tkprof,xb,xc,sfen,nsites,vmol,a,a_init,sfengb,nsitesgb,Vgrain,Agb,GBWidth]=zr_amorph_init_noniso([1050 750 0.15/3600]); %WBQ July 2022 TEM fit


%test runs for Masssih plot
% [r,rb,n,tkprof,xb,xc,sfen,nsites,vmol,a,a_init,sfengb,nsitesgb,Vgrain,Agb,GBWidth]=zr_amorph_init_noniso([1050 750 0.15/3600]); %WBQ July 2022 TEM fit


%2.08

% [r,rb,n,tkprof,xb,xc,sfen,nsites,vmol,a,a_init,sfengb,nsitesgb,Vgrain,Agb,GBWidth]=zr_amorph_init_noniso([1050 10 20.4/3600]);%; 10 700 30/3600; 700 700 2]); %OBQ
% [r,rb,n,rgb,rbgb,ngb,tkprof,xb,xc,sfen,nsites,vmol,a,a_init]=zr_amorph_init_noniso([1050 10 2.2/3600]); %WBQ

% [r,rb,n,tkprof,xb,xc,sfen,nsites,vmol,a,a_init,sfengb,nsitesgb,Vgrain,Agb,GBWidth]=zr_amorph_init_noniso([600 600 0.25]);%; 600 10 30/3600; 10 10 0.1; 10 700 30/3600; 700 700 0.25]); %isothermal


% [r,rb,n,rgb,rbgb,ngb,tkprof,xb,xc,sfen,nsites,vmol,a,a_init,sfengb,nsitesgb]=zr_amorph_init_noniso([600 600 0.02]);%; 10 700 30/3600; 700 700 2]); %OBQ


%Jacob's scenarios:
%1
% [r,rb,n,tkprof,xb,xc,sfen,nsites,vmol,a,a_init,sfengb,nsitesgb,Vgrain,Agb,GBWidth]=zr_amorph_init_noniso([1020 50 30/3600; 50 768 30/3600; 768 768 0.5; 780 780 10/3600; 780 780 4; 780 760 10/3600; 760 760 4; 760 350 10/3600]);
% [r,rb,n,tkprof,xb,xc,sfen,nsites,vmol,a,a_init,sfengb,nsitesgb,Vgrain,Agb,GBWidth]=zr_amorph_init_noniso([1020 10 30/3600; 10 768 30/3600; 768 768 0.5; 780 780 10/3600; 780 780 4; 780 760 10/3600; 760 760 4; 760 350 10/3600]);

%5

% [r,rb,n,tkprof,xb,xc,sfen,nsites,vmol,a,a_init,sfengb,nsitesgb,Vgrain,Agb,GBWidth]=zr_amorph_init_noniso([1020 50 30/3600; 50 760 30/3600; 760 760 4]);
% 
% %6
% 
% 
% 
% 
% 
% [r,n,tout,tkout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout,xaout,growthout,grtrck2,grtrck4,grtrck6,PFZout,r_ln,n_ln,xbinstTrack,hout,Distout,TotalSolDistEnd,dtEnd,dtTrack,firstit,xbinstTotTrackEnd,vfTrack,SolSplitout,xbchangeFickout,Avout]= ...
%     zr_amorph_kin_noniso(r,rb,n,tkprof,xb,xc,sfen,sfengb,nsites,vmol,a,a_init,Vgrain,Agb,GBWidth,0);
% 
% filename = 'Output.mat';
% save(filename)


% subplot(1,3,1)
% rsz = size(rbarout);
% rbarrows = rsz(1);
% rbarcols = rsz(2);
% 
% % 
% for j = 10
%     semilogx(tout,rbarout(:,j).*2,'LineWidth',2)
%     hold on
% end
% legend('Matrix 1','Matrix 2','Matrix 3','Matrix 4','GB')
% xlabel('Time / s')
% ylabel('Mean diameter / nm')
% set(gca,'FontSize',18)
% % 
% % subplot(1,3,2)
% for j = 1:1:2
%     semilogx(tout,vfout(:,j),'--','LineWidth',2) %%0.0064......
%     hold on
% end
% % vmax = [0.0077,0.0077];
% % tvf = [tout(1),tout(end)];
% % semilogx(tvf,vmax,'k','LineWidth',2)
% % legend('Matrix 1','Matrix 2','Matrix 3','Matrix 4','GB')
% xlabel('Time / s')
% ylabel('Volume fraction')
% set(gca,'FontSize',18)
% % 
% vfTotout = [];
% for j = 1:1:2
%     vfTot = sum(vfout(j,:));
%     vfTotout = [vfTotout vfTot];
% end
% % 
% % subplot(1,3,3)
% for j = 1:1:10
%     loglog(tout,nrout(:,j),'--','LineWidth',2)
%     hold on
% end
% legend('Matrix 1','Matrix 2','Matrix 3','Matrix 4','GB')
% xlabel('Time / s')
% ylabel('Nucleation rate')
% set(gca,'FontSize',18)
% ylim([1e18 2e26])
% 
% 
% 
% 
% % 
% 
% 
% for j = 1:1:2
%     semilogx(tout,rbarout(:,j))
%     hold on
% end
% 
% for j = 1:1:2
%     semilogx(tout,rcout_c(:,j))
%     hold on
% end
% 
% % 
% for j = 1:1:2
%     plot((r_ln(j,:).*2).*(10^9),n_ln(j,:).*10^-18,'LineWidth',2)
% %         plot((r(j,:).*2).*(10^9),n(j,:).*(10^-18),'LineWidth',2)
% 
%     hold on
% end
% xlim([0 60])
% legend('Matrix','Grain boundary')
% % %PSD
% % plot((r.*2).*(10^9),n.*(10^-18),'LineWidth',2)
% % xlim([0 80])
% % hold on
% % plot((rgb.*2).*(10^9),ngb.*(10^-18),'LineWidth',2)
% % xlim([0 80])
% % ylabel('Number density / \mum^{-3}')
% % xlabel('Diameter / nm')
% % legend('Matrix','Grain boundary')
% % set(gca, 'FontSize', 18)
% % %Number of particles
% % semilogx(tout,npartout)
% % hold on
% % semilogx(tout,npartoutgb)
% % %Volume fraction
% % semilogx(tout,vfout,'LineWidth',2)
% % hold on
% % semilogx(tout,vfoutgb,'LineWidth',2)
% % ylabel('Volume fraction')
% % xlabel('Time / s')
% % legend('Matrix','Grain boundary')
% % set(gca, 'FontSize', 18)
% % %matrix sol conc
% % loglog(tout,xbout.*100,'LineWidth',2)
% % hold on
% % loglog(tout,xboutgb.*100,'LineWidth',2)
% % loglog(tout,xaout.*100,'--k','LineWidth',2)
% % ylabel('Solute concentration / at. %')
% % xlabel('Time / s')
% % legend('Matrix','Grain boundary')
% % set(gca, 'FontSize', 18)
% % %Nucleation rate
% % semilogx(tout,nrout)
% % hold on
% % semilogx(tout,nroutgb)
% % %Check xbinst has tracked well through the iterations
% % semilogx(hout,xbinstTrack)
% % hold on
% % semilogx(hout,xbinstgbTrack)
% % %Critical radius
% % loglog(tout,rcout_c)
% % hold on
% % loglog(tout,rcout_cgb)
% % %mean riadus
% % semilogx(tout,rbarout.*2)
% % hold on
% % semilogx(tout,rbaroutgb.*2)
% %Growth rate
% % semilogx(tout,grout)
% % hold on
% % semilogx(tout,groutgb)
% 
% % plot((r_ln.*2).*(10^9),n_ln.*(10^-18),'LineWidth',2)
% % xlabel('SPP diameter')
% % ylabel('Number density / \mum{-3}')
% % legend('KWN output','Adjusted using shape parameter')
% % set(gca,'FontSize',18)
% % subplot(1,2,2)
% % yyaxis left
% % plot(tout,PFZout.*1e6,'LineWidth',2)
% % ylabel('Length of PFZ / \mum')
% % set(gca,'FontSize',18)
% % yyaxis right
% % plot(tout,xaout.*1000000,'LineWidth',2)
% % ylabel('Solute solubility / appm')
% % set(gca,'FontSize',18)
% % xlabel('Time / s')
% % % 
% % % semilogx(tout,pgpout)
% % subplot(1,3,1)
% % semilogx(tout,rcout_c)
% % xlim([0.015 20.4])
% % title('rc')
% % subplot(1,3,2)
% % semilogx(tout,xbout)
% % xlim([0.015 20.4])
% % title('xbout')
% % subplot(1,3,3)
% % semilogx(tout,xaout)
% % title('xaout')
% % xlim([0.015 20.4])
% 
% % yyaxis left
% % semilogx(tout,rcout_c)
% % yyaxis right
% % semilogx(tout,xbout)
% % hold on
% % semilogx(tout,xaout)
% % legend('rc','xbout','xaout')
% % xlim([0.015 20.4])
% %% Stuff for second order kinetics growth rate
% % x = rb.*1e9;
% % plot(x,grtrck2,x,grtrck4,x,grtrck6)
% % symlog()
% % 
% % semilogy(rb.*1e9,grtrck2)
% % figure
% % Y = sign(grtrck2).*log10(abs(grtrck2));
% % plot(rb.*1e9,Y,'.')
% % yl = get(gca,'ytick');
% % set(gca,'yticklabel',sign(yl).*10.^abs(yl))
% % xlim([0 400])
% % 
% % semilogy(rb.*1e9,grtrck2)
% % hold on
% % semilogy(rb.*1e9,grtrck4)
% % semilogy(rb.*1e9,grtrck6)
% % legend('0.2','0.4','0.6')
% % xlabel('Particle radius')
% % ylabel('growth rate')
% % xlim([0 400])