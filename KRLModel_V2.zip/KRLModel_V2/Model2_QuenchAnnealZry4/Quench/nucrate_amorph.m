function [nr] = nucrate_amorph(rc,sfen,nsitein,xbinst,xb,d,t,tk,tau,vmol,a,xbinit,r,dgb,SolSplit,nucflag,firstit,htime,sfengb,xa,xc,bin)
% function [nr] = nucratesc(rcrit,sfen,nsites,d,t,tk)
% Calculates time dependent nucleation rate in Cu-Co
% (using expression from Hyland paper)
% 
k = 1.380662e-23;
na = 6.022045e23;
h = 6.626176e-34;
%
% aprod should be diffusion distance
% ie shortest lattice vector
%

%% Nucleation rate for matrix preciptiates

%this will be r,n 1:49
rsz = size(r);
rrows = rsz(1);
nr = zeros(1,rrows); %preallocate an array to encompass ALL segments

if t>=0
    gstar = [];
    dg = [];
    for j = 1:1:rrows-1
        aprod = a;
        vat = vmol/na;
        gstar_i = 4/3 * pi * (rc(j).^2) * sfen;
        gstar = [gstar gstar_i];
        %
        dg_i = (-2 * sfen)./rc(j);
        dg = [dg dg_i];
    end
    beta = [];
    zeld = [];
    for j = 1:1:rrows-1
        zeld_i = (vat .* dg(j).^2)./(8 * pi * ((sfen^3*k.*tk).^0.5));
        if zeld_i == inf
            zeld_i = 0;
        end

        zeld = [zeld zeld_i];
        %
        % See stocalc.m for configuration for data sent to MJS
        %
        % Comment out next line for beta and tau line to get KW method
        % uncomment tau in main program
        % beta = (16 .* pi .* (sfen^2) .* xbinst .* d)./((dg.^2) .* (aprod^4));
        % Below - beta for Aaronson from Stowell (p.6)
        %below, 8.3.22 - instead of using xb for the whole system I think it should
        %be the initial xb attributed to each segemented system, i.e. the solute
        %concentration in at. frac of each segment. Bit of confusion as to whether
        %it is initial concentration or the updated concentration e.g. xbinst.
        %xbinst seems to make more sense as beta is the rate of solute attachment.
        % beta = (4 * pi * rc(j)^2 * d * xb)/(aprod^4); %this should be xb init UP TO HERE!!!!
        
        % beta = (4 * pi * rc(j)^2 * d * xbinit(j))/(aprod^4);
        beta_i = (4 * pi * rc(j)^2 * d * xbinst(j))/(aprod^4); %This is a rearranged form of the one form Aaraonson, to keep consisten rc.
        beta = [beta beta_i];
    end
    
    
    
    % Below - beta for KW (Servi-Turnbull method)
    %betakw = (d*xbinst) /  ((0.7071*aprod)^2);
    %beta = betakw;
    %
    % Russell beta factor (as used by Aaronson)
    % beta = betakw * 4* pi * ((rc/(0.7071*aprod))^2);
    % tau from Stowell, theta from Stowell, p. 10
    %theta = 1;
    %tau = 1/(theta * beta * (zeld^2));
    % tau from Aaronson
%     ktau = 8;
%     tau = (ktau .* k .* tk .* sfen .* (aprod.^4))./((vat.^2) .* (dg.^2) .* d .* xbinit(1:end-1));
    %ignore incubation time
    %tau=1e-100;
    for j = 1:1:rrows-1
%         nsites = nsitein;
        % Modify nsites to account for loss of solute
        %
%         nsites = nsitein(j) .* (xbinst(j)./(xb.*SolSplit(j)./(1./rrows)));
        
%         nsites = nsitein(j) .* (xbinst(j)./(xbinit(j)));

        nsites = nsitein(j);

        nr(j) = nsites.*zeld(j).*beta(j).*exp(-gstar(j)./(k .* tk));
%         nr = [nr nr_i];
        % Change next bit!
        % nr = nsites.*zeld.*beta.*exp(-gstar./(k .* tk));
    end


%Check here that any segements with rc < 0  are given a nucleation rate of
%zero
for j = 1:1:rrows-1
    if rc(j) < 0
       nr(j) = 0;
    end
end
%% Nucleation rate for GB precipitates
%Will be using a unique diffusivity and potentially a unique sfen

%rrows is the total length of the number of r/n arrays and the final one of
%these is the one that deals with grain boundary precipitates.

    for j = rrows
        aprod = a;
        vat = vmol/na;
        
        sigma = 0.5; %0.5 Gb energy (J/m2) from Plowman 2020, as a guide
        theta = (sigma/(2*sfengb));
%         ShapeFac = ((2+cosd(theta))*((1-cosd(theta))^2))/2;
        ShapeFac = 1;
        
%         sfengb = 0.15;
%         sfengb = 0.25;
        
        gstar_i = 4/3 * pi * (rc(j).^2) * sfengb; %Use changed sfen for nucleation on GBs for reduction to energy barrier, but for driving force/critrad calcs keep the same?
        gstargb = gstar_i*ShapeFac;
        dg_i = (-2 * sfengb)./rc(j);
        dggb = dg_i;
    end

    for j = rrows
        zeld_i = (vat .* dggb.^2)./(8 * pi * ((sfengb^3*k.*tk).^0.5)); %only one value being calculated
        zeldgb = zeld_i;
        beta_i = (4 * pi * rc(j)^2 * d * xbinst(j))/(aprod^4); 
        
        %28.3.22 - use normal matrix diffusivity for beta factor as it is
        %the rate of solute attachment of atoms, which doesn't actually
        %depend physically on the diffusivity, rather it is used as a was
        %to *fit* it...
        
%         beta_ii = (dgb*xbinst(j))/(aprod^2);
%         zeld_ii = (gstargb)./(3.*pi.*k.*tk.*
        
        betagb = beta_i;
    end
    
    for j = rrows
%         nsites = nsitein;

%         nsites = nsitein(j) .* (xbinst(j)./(xb.*SolSplit(j)./(1./rrows)));
%         nsites = nsitein(j) .* (xbinst(j)./(xbinit(j)));

        nsites = nsitein(j); %Heteregenous nucleation not adjusted with solute as in homogenous nucleation


        nr(j) = nsites.*zeldgb.*betagb.*exp(-gstargb./(k .* tk));
%         nr = [nr nr_i];

        %28.3.22 - if struggling to get nucleation to fit, I could look
        %into site-saturated nucleation in gb region.
        
        %Site-saturated nucleation
        %In first iteration the timestep is 1e-10, so if nucletion rate is
        %1e26, then 1e16 SPPs/m3 would form == 
        %Set a number of pre-exisiting nuclei at t = 0, then after that the
        %nucleation rate drops to zero.

        % Below is for site saturated nucleation - 26/1/23
        % Calculate number of initial nuclei through max vf determination
%         % and inital crit rad.
%         if firstit == 0
%             vfmax = (1/length(xbinst)).*((xbinst(j) - (xa.*1.05))/(xc - (xa.*1.05))); %Increase xa by x.xx % to stop xbinst falling below immediately
%             npart = vfmax./((4/3).*pi.*(r(10,bin(j)).^3));
%             nr(j) = npart/htime;
%             Test = (xb.*SolSplit(j) - (vfmax.*(xc-xa)))/(1./rrows);
%         else 
%             nr(end) = 0;
%             nucflag(end) = 1;
%         end

%         if firstit == 0
% %             nr(j) = ((nsites.*xbinst(j))/5)/htime; %assume that each nuclei initially contains 4 atoms (this can be fitted)
% %             nr(j) = ((xbinst(j).*nsitein(1))./3)/htime; %Numer of solute atoms in segment / Number per critical nuecli = number of nuclei.
%               nr(j) = (nsites./16)/htime; %assume that each het site creates an initial nuclei
% 
%         else
%             nr(end) = 0;
%             nucflag(end) = 1;
%         end
%         
        
    end

% for j = rrows
%     if rc(j) <= 0
%        nr(j) = 0;
%     end
% end

nrnan = isnan(nr);

if any(nrnan==1)
    aa=4;
end

else
    nr = zeros(1,rrows); %if t is not greater than zero then all nucleation is zero.
end

return
   