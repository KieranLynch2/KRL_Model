function [rc,CritRadFlag] = critrad_cryst(sfen,xa,xb,xc,vf,tk,vmol,xbinst,r,CritRadFlag,sfengb)
% function[rc] = critrad(sfen,xa,xbinst,tk)
% Calculates critical radius for growth/nucleation
%
% Inputs
% sfen      Interfacial energy of nuclei (J/m^2)
% xa        Equilibrium concentration of Zr in matrix at interface
% xb        Zr concentration in matrix (far field)
% xc        Zr concentration in dispersoids
% vf        Volume fraction of dispersoids
% tk        Temperature (K)
% Outputs
% rc        Critical radius (m)
%
%
% update mean matrix concentration

rsz = size(r);
rrows = rsz(1);
%
% xbinst = xb - ((xc - xa) .* vf);
% xbinst = xbinstTot;
na = 6.022045e23;
vat = vmol./na;
k = 1.3806488e-23;

for j = 1:1:rrows
    if xbinst(j) < 0   %HAVE CHANGED 0 HERE TO XA, THIS IS A CHEAT AND NEEDS TO BE CHANGED BACK
        xbinst(j) = 0;
    end
end
gas = 8.31459;
%
% only calculate critical radius when xbinst>xa
%
%disp(['xa ' num2str(xa) ' xbinst ' num2str(xbinst)])
%
% full expression for driving force from ideal solution model (Aaronson, Met Trans A, 23A, 1992 p.1915)
%

driving = [];
for j = 1:1:rrows
    driving_i = ((gas * tk)/vmol)*((xc.*log(xbinst(j)./xa))+((1-xc).*log((1-xbinst(j))./(1-xa))));
    driving = [driving driving_i];
end

stren = 0;
%
rc = [];
for j = 1:1:rrows-1
    resdrive = driving(j) - stren;
    rc_i = (2 * sfen)./(resdrive);
    rc = [rc rc_i];
end

for j = rrows
    resdrive = driving(j) - stren;
    rc_i = (2 * sfengb)./(resdrive);
    rc = [rc rc_i];
end

for j = 1:1:rrows 
    if rc(j) < 0
        aa = 4;
        rc(j) = 0;
        CritRadFlag = 1;
    end
end

return