function [xbinst,xbinit,SolSplit] = xbinstCalc(xb,GBWidth,r,xc,xa,QR)

%The system arrays are going to be evenly distributed from the grain
%boundary to the grain centre (one thing to think about in the future is
%that the grain bounadry region will be the joining of two grains so the
%solute here may be twice as much as expected.)

rsz = size(r);
rrows = rsz(1);
ArrDist = GBWidth/rrows;

%% Scheil equation

% Modified scheil equation using Aziz trapping function 
% 1. Smith PM, Aziz MJ. Solute trapping in aluminum alloys. Acta Metall Mater. 1994 Oct 1;42(10):3515–25. 
% 2. Aziz 
% 
% MJ, Kaplan T. Continuous growth model for interface motion during alloy solidification. Acta Metall. 1988 Aug 1;36(8):2335–47. 
k = 0.005; % Equilbirium partition coefficient calculated from phase diagram
lamda = 0.4e-9; % Average interatomic spcaing of HCP/BCC Zr phases
dl = 4e-15; % Fitted interdiffusion coefficient
VD = dl./lamda;

a_V = 3e-08;
b_V = 0.4800;
V = a_V.*QR.^b_V;

kv = (k + (V/VD))./(1-(V./VD));

if kv > 1
    kv = 1;
end

% k = 0.0141; %k is to be fitted

% k = 1;
%Calculate concentration at edges of 50 segements
Nsteps = rrows; %GbWidth divide by 10 nm step size gives number of total points;, can change 0.01 to increase step size

Avg = 2000; %Number of compositional measurements to calcualte per segment
FracJump = (1/Nsteps)./Avg; %Make the fractional jumps more precise, then calculate the average xbinst in each segment by average filter every 100 FracJumps

fsout = [];
cout = [];
for fs = 0:FracJump:0.99999
    c = kv*xb*((1-fs)^(kv-1));
    fsout = [fsout fs];
    cout = [cout c];
end


xbinst = [];
TotalSteps = Avg*Nsteps;
for p = Avg:Avg:TotalSteps
    start = p - (Avg-1); %this 4 is realted to Avg above? replace with Avg-1?
    xbinst_i = mean(cout(start:p));
    xbinst = [xbinst xbinst_i];
end

xbinit = xbinst;

SolSplit = [];
for q = 1:1:rrows
    SolSplit_i = xbinst(q)/(sum(xbinst)); %this is the fraction of which the initial solute concentration is split between all the segments
    SolSplit = [SolSplit SolSplit_i]; %Fractional distribution of solute
end

% SolSplit = [0.004 0.996];

%This makes sure that 100% of the solute is used, as some of the solute is
%lost through use of the Scheil equation
% xbinst = sum(xbinst).*SolSplit;
% xbinit = xbinst;
% SolSplit = [0.045 0.955];
xbinst = [];
for j = 1:1:rrows
    xb_i = (xb.*SolSplit(j) - (0.*(xc-xa)))/(1./rrows); %zero here is vf
    xbinst = [xbinst xb_i];
end

xbinit = xbinst;


% xbinit(1) = 0.0048;
% xbinst(1) = 0.0048;



%% New method as of 16/12/24 - Model now takes average amtrix composition and GB composition, just two segments
% fraction of solute at grain boundary follows this empirical fit
GBFrac = 0.9514 * exp(-0.0002019*QR);
GIFrac = 1-GBFrac;

SolSplit = [GIFrac,GBFrac];

xbinst = [];
for j = 1:1:rrows
    xb_i = (xb.*SolSplit(j) - (0.*(xc-xa)))/(1./rrows); %zero here is vf
    xbinst = [xbinst xb_i];
end

xbinit = xbinst;

end