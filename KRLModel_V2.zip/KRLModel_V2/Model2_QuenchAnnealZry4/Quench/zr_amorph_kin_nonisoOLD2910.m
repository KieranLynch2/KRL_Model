function[r,n,tout,tkout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout,xaout,growthout,grtrck2,grtrck4,grtrck6,PFZout,r_ln,n_ln,xbinstTrack,hout,Distout,TotalSolDistEnd,dtEnd,dtTrack,firstit,xbinstTotTrackEnd,vfTrack,SolSplitout,xbchangeFickout,Avout]= ...
    zr_amorph_kin_noniso(r,rb,n,tkprof,xb,xc,sfen,sfengb,nsites,vmol,a,a_init,Vgrain,Agb,GBWidth,FickSwitch,GBen,w0,radflag)
% ====================================================================
%
% Calculates precipitation kinetics in Zirconium alloys
% **RUN zirconium_init.m FIRST
%
% using 2nd order Runge Kutta formula for error checking and
% adaptive timestep control
%
% Reference (to source model, originally for Al3Zr)
% J. D. Robson and P. B. Prangnell, Acta Materialia, 49, 2001, p. 599-613
%
% Inputs
% r         Size bins (mean sizes) (m)
% rb        Size bins (edge sizes) (m)
% tk        Temperature  (K)
% tfinal    Time to calculate for (s)
% d         Diffusion coefficient of solute  (m^2/s)
% xa        Solute concentration in matrix in equilibrium with precipitate
% xb		Average solute concentration in matrix
% xc		Solute concentration in precipitate
% vmax      Maximum volume fraction of precipitate
% nsites    Number of nucleation sites for precipitate (m^-3)
% sfen      Interfacial energy of precipitate for growth/nucleation (Jm^-2)
% a_init	Initial Zr lattice parameter before precipitation
% a			Final Zr lattice parameter at the end of precipitation
% radflag   Irradiation active (=1)
%
% Outputs
% r         Mean size of size bins (m)
% n         Particle number density in each size bin (particles/m^3)
% tout      Time at each time-step (s)
% vfout     Volume fraction at each time-step
% rbarout   Mean particle radius at each time-step (micron)
% npartout  Particle number density at each time-step (particles/micron^3)
% nrout     Nucleation rate at each time-step (particles/m^3)
% rcout     Critical radius at each time-step (m)
% aout		Lattice parameter of zirconium at each time-step
% fsout		Estimated strength at each time-step
% M			Movie (not used)
%
% ====================================================================
%

%Remember that now r and n are two matrices with the first row being grain
%boundary and the 50th row being grain centre.
%Have used a notation _i to represent the old variables which are now being
%calculated individually for each spacing.

na = 6.022045e23;
k = 1.380662e-23;
tau = 0;
res = length(r);
% n(1:res) = 0;



%Put in calculator function to limit precipitation until Massih given
%value, i.e. 1150 K

% [SolR_T,SolR_y] = Beta2Alpha_Init(tkprof);
SolR_T = [];
SolR_y = [];

%Should probably calculate a starting precipitation temperature when alpha
%begins to form. Use SolRelease.

%Note on 18/1/23:
% -Can probably do a function of solute release based on average grani
% velocity and width, and as the simulation proceeeds release the solute
% into each segment based on the time evoelevd and allow it to nucleate
% out. That way the grain centre will begin it's nucleation process as the
% begning to the transformation adn the grain boundary will be the last to
% be allowed to nucleate but will have the majority of solute so may result
% in the incompletion of the nucleation phase, as predicted
% experimentally.


[tknuc,tkPhaseEnd,QuenchRate] = tkprof_Massih(tkprof,SolR_T,SolR_y); %tknuc is the temperature at which nucleation begins.


% tknuc = tkprof(1);
% Temp - DONT FORGET TO REMOVE
% tkPhaseEnd = tknuc;

% tknuc = 1050;

[tkprof] = tkrpof_adjust(tkprof,tknuc); %Following Massih 2003, the quench rate should be determined from Tstart to 1023 K.
                                  %Should still simulat past 750 C, as there may be more SPP growth, so just extend the simulation time at the according rate.  


%Orginial simple tkprof assuming ppt starts at 1150 regardless of QR.
%Revery back to this rather than two above to prove some useful points for
%thesis. i.e. why it was overpredicting nucleation and growth at faster
%quenches..




tout = [];
tkout = [];
grout = [];
vfout = [];
rbarout = [];
npartout = [];
xaout = [];
growthout = [];
ndump = [];
npartcritout = [];
aout = [];
fsout = [];
npartcrit_old=[0 0 0 0 0 0];
nrcritout = [];
rcout_c = [];
rcout_a = [];
amorphout = [];
rgmax = [];
nrout = [];
M = [];
xbout=[];
%
% Empirical parameters PGP and CAP and SOCAP
% Garzarolli et al.
%
% CAP
% QR_cap = 40e3; % This is standard value from Garzarolli
QR_cap = 17e3; % Value from model that causes rbar values to collapse
cap = 0;
capout = [];
% PGP
k_pgp = 1e14;%./3600; % PGP rate factor
TA_pgp = 3.2e4;
pgp = 0;
pgpout = [];
k_socap = 1.11e-11; % SOCAP rate factor
QR_socap = 18.7e3; % SOCAP activation energy
socap = 0;
socapout = [];
rbar = [];
vf = [];
%
%
%nr = 0;
len = length(r);
gr(1:len)=0;
%grout(1:len)=0;
dr2(1:len)=0;

rsz = size(r);
rrows = rsz(1);
rcols = rsz(2);
rbcols = rcols+1;

for j = 1:1:rrows
    rbar_i = (sum(r(j,:).*n(j,:)))/sum(n(j,:));
    rbar = [rbar rbar_i];
end
for j = 1:1:rrows
    vf_i = 4/3 * pi * sum((r(j,:).^3) .* n(j,:));
    vf = [vf vf_i];
end

solsuc = 0;
solfail = 0;
nucflag(1:1:rrows) = 0;

%
% Runge-Kutta initialization - from matlab ode23old
%
t = 0;
rbar(1:end) = 0;
pow = 1/3;
tol = 1e-2;%1e-3;% - This is needed for quench rate calcs!;
% h is the value of the timestep increment
% hmax and hmin set limits on the range of timesteps
% the timestep is adjusted automatically using a 2nd order
% Runge-Kutta scheme
%
hmin = 1e-15;
hmax = 8e-5;%1e-5
hmaxTol = hmax;
mnum = 1e29;
mnumgb = 1e25;
%
% cw is KW fudge factor for tau calculation
%
cw = 1.4;
%
hmaxinit=1e-14;
h_old = 10;
h = hmaxinit;

flag_me = 0;

firstit=0;
%
% Timestep setup
%
tfinal = tkprof(1,3);
ttotal = sum(tkprof(:,3));
% initial temperature
tk = tkprof(1);
stage = 1;
steptime = 0;
disp (['Heating stage ' num2str(stage)])
disp (['Temperature degC ' num2str(tk - 273)])


gr2flag = 0;
gr4flag = 0;
gr6flag = 0;
grtrck2 = 0;
grtrck4 = 0;
grtrck6 = 0;
PFZout = [];
TotalSolDist = 0;
% CritRadFlag = 0;
%

%These are not output vectors, they are used to keep track of xbinst and vf
%at the begining, middle, and end of slopes
xbinstTrack = [];
xbinstgbTrack = [];
vfTrack = [];
vfgbTrack = [];
hout = [];
Distout = [];
TotalSolDistEnd = [];
xbinstTotTrackEnd = [];
xbinstTotTrack = [];
groutgb = [];

PFZTrack = [];
dtTrack = [];
dtEnd = [];
xbinstTotEnd = xb;
xbinstTot = xb;
flagSol = 0;
flagSolgb = 0;
Check1out = [];
Check2out = [];
SolSplitout = [];
Fickcheck = 0;
xbchangeFickout = [];

%For GB growth
Diffgbout = [];
Diffout = [];
hout = [];
Avout = [];

BinFail = 0;
% FickSwitch = 1; %FickSwitch, 0 = off, 1 = on
SSNucFlag = 0; %If modelling supersaturated nucleation
FirstitIrrad = 0;

StagNucFlag = (zeros(1,rrows))+1; %Set this flag to 1 for every segment to begin with
StagNucFlagTrip = (zeros(1,rrows));

%Set nucflag to 1 for all to start
nucflag = nucflag+1;

% When this flag becomes zero then nucleation in the segment would be
% allowed - also need to limit diffusion of segments until this becomes 0.

alphaTrack = 0; %Keeps track of solute released (alpha fraction transformed)
alphaTrackAll = 0;

VfMaxTrack = [0,0];
% load('Test_540K.mat')
%How to get adaptive timestep which is limited by a change in vf at low
%temperatures
%Is to do with the growth rate at longer times due to the use of time in
%the grain boundary growth equation
while (t<ttotal)
    if steptime + h > tkprof(stage,3), h = tkprof(stage,3) - steptime; end
    %

    % Update temperature dependent things
    %
    CritRadFlag = 0; %Reset this each iteration in acse reduction in timset
        xa = exp((-5.4e3./tk)-3.3);
    d = (6e-7 * exp(-15930/(tk))); 
%     d = 1.473e-6*exp(-(15930*1.0)/(tk)); %Robsons D
    gas = 8.314;
%     d = (6e-7 * exp(-15930/(tk))).*1; %keeping diffusivity low just for debugging


    % Function to set up a staggered nucleation process
    if any(StagNucFlagTrip==0)
    [StagNucFlag,nucflag,StagNucFlagTrip,h,TempInitSeg] = StagNuc(StagNucFlag,tk,tknuc,tkPhaseEnd,rrows,nucflag,StagNucFlagTrip,h);
%     if StagNucFlagTrip(end) == 1 %Slow things down of first iteration when gb activates
%         hmax = hmaxTol;
%     end
    end

    % Slow things down when segment adjacent to GB is active
%     if tk < TempInitSeg(end) + 2
%         hmax = hmaxTol;
%     end

%     if tk < TempInitSeg(end) + 0.0001 && tk > TempInitSeg(end) - 0.0001
%         hmax = 1e-8;
%     else
%         hmax = hmaxTol;
%     end
% 
%     if tk < TempInitSeg(end) + 0.00001 && tk > TempInitSeg(end) - 0.00001
%         hmax = 1e-10;
%     end

    if tk < TempInitSeg(end)-3 %When Nuc is done on GB.
        hmax = 3e-4; %Can speed things up for lower temperature
    end

    if StagNucFlagTrip(end) == 0 && StagNucFlagTrip(end-1) == 0 %increase speed when GB not active.
        hmax = 1e-2;
    end

    if tk < 800
        hmax = 1;
    end
    % 
    if firstit > 2
        if QuenchRate > 1000
            if tk > 1150
                if any(xbinst<xa.*2)
                    hmax = 1e-9;
                end
            end
        end
    end

    % Temp fix to control high nucleation with shape factor 
%      if firstit > 1
%          if xbinst(end)<(3*xa)
% %          nucflag(j) = 1; %terminate nucleation if xbinst close to xa?? How does this work for low conc matrix?
%             hmax = 1e-13;
%             CurNrout = nrout(end,:);
%             if xbinst(end)<(1.05*xa)
%                 nucflag(j) = 1; %terminate nucleation if xbinst close to xa?? How does this work for low conc matrix?
%             end
%             if CurNrout(end)==0
%                 hmax = 3e-4;
%             end
%          end
%      end
    
%     if firstit > 1
%     if any(nrout(end,:)>1e28) 
%         hmax = 1e-10;
%     end
%     end
    %Calculation of GB diffusivity
    Qrat = 150000; %100000;
    prefac = 28000; %8000;
%     Qrat = 25300;
%     prefac = 1255.66;
    Drat = prefac*exp(Qrat/(gas*tk)); %Ratio of Cr gb/l diffusivity (Massih, 2003)
    dgbog = d*Drat;
    
    dgb = 727*exp(-138000/(gas.*tk)); %Corvalan et al. 2015
%     dgb = d;
%     dgb = d;
    

% if firstit > 0
%     if any(xbinst2 < xa.*1.01) | any(xbinst3 < xa.*1.01) | any(xbinst < xa.*1.01)
%         xbcheck = 1;
%     else
%         xbcheck = 0;
%     end
% end
    
% if firstit > 1
% rbarmat = rbarout(:,2);
% if rbarmat(end) < rbarmat(end-1)
%     aa = 4;
% end
% end

% if firstit >2
% if rbarout(end-1,end) > rbarout(end,end)
%     aa = 5;
% end
% end

    if FirstitIrrad == 0
        [xbinst,xbinit,SolSplit] = xbinstCalc(xb,GBWidth,r,xc,xa,QuenchRate);

        %Delete next line if not running Massih model
%         xbinst = 0;
%         xbCurTrack = [0,0];
    end
    
    %Slowly releasing solute available for precipitation depending on the
    %phase % of alpha formed.
%      [xbinst,alphaTrack,alphaTrackAll,xbCur,xbCurTrack,VfMax,VfMaxTrack] = SolRelease(xbinit,xbinst,SolR_y,SolR_T,tk,alphaTrack,alphaTrackAll,xb,xbCurTrack,xc,xa,VfMaxTrack);
        xbCur = [xbinst];
%         xbCurTrack = [];
        VfMax = [];
%         VfMaxTrack = [];
        alphaTrack = 1;


    if radflag == 1
        ram = amorph_depth(t);
    else
        ram = 0;
    end
    %
    %
    if any(nucflag == 1)
        aa =4;
    end
    [rc,CritRadFlag] = critrad_cryst(sfen,xa,xb,xc,vf,tk,vmol,xbinst,r,CritRadFlag,sfengb);
    %     rc_a = critrad_amorph(sfen,xa,xb,xc,vf,tk,vmol);
    
    %     rcgb = critrad_crystgb(sfengb,xa,xb,xc,vfgb,tk,vmol,sfen,xbinstgb,xbinstTotEnd);
    %
    % Multiplication factor
    %
    
%     if xbcheck == 0


    if any(rc == 0) %This is needed!
        bin = zeros(1,rrows);
        bin = bin + 10;
%         BinFail = 1;
    else
        bin = NewSizeFunc(rrows,rc,r,rb,n,nucflag);
        BinFail = 0;
    end



%     else
%         bin = ; %Set dummy bins if xbcheck fails to let iteration fail and come back with smaller timestep
    
    
    %
    % Compute the slopes
    %
    % slopes at start of interval %Up to here, need to figure out best way to
    % do this section
    
    [nr1,gr1,CritRadFlag] = nucgrow_amorph(vf,ram,r,rb,d,t,nsites,sfen,tk,xa,xb,xc,tau,vmol,a,h,xbinst,xbinit,dgb,SolSplit,nucflag,firstit,CritRadFlag,sfengb,bin,Diffgbout,Diffout,hout,n,QuenchRate,GBen,w0);
    
    for j = 1:1:rrows
        if nucflag(j) == 1, nr1(j) = 0; end
    end
%     nr1 = zeros(1,rrows);
%     gr1 = zeros(rrows,rcols+1);
    
    %
    % slopes at middle of interval
    %
    % to calculate the slope need to know the volume fraction
    % at the middle of the interval. Need to temporarily update size
    % distribution and hence find volume fraction
    %

    vf3 = [];
    for j = 1:1:rrows
        newpart3_i = (1-vf(j)) * nr1(j) * (h/2);
        ntemp3_i = n(j,:);
        ntemp3_i(bin(j))=ntemp3_i(bin(j))+newpart3_i;
        dr3_i = gr1(j,:) * (h/2);
        
        % Temporarily update size distribution
        %
        [np yp] = update_func_mod(r(j,:),rb(j,:),ntemp3_i,dr3_i);
        ntemp3_i = np';
        vf3_i = sum(((4/3) * pi * (r(j,:).^3)) .* ntemp3_i);
        
        vf3 = [vf3 vf3_i];
    end
    
    
    
    
    
    %Ignore the PFZ for now, not sure if the mechanisms will be the same
    %for the papaer this is used in (annealing) as this situation (quench)
    %     PFZ = lengthpfz(xc,xa,rgb,ngb,Vgrain,Agb);
    
    
    [xbinst3,TotalSolDist,xbinstTrack,vfTrack,xbinstTotTrack,flagSol,nucflag,Check1out,Check2out,SolSplit,Fickcheck,xbchangeFickout] = soltransferSTART(vfTrack,vfgbTrack,xa,xb,xc,h,d,firstit,TotalSolDist,xbinstTrack,xbinstgbTrack,vf3,xbout,GBWidth,xbinstTotTrack,xbinst,dtTrack,flagSol,xbinit,xbinstTotTrackEnd,vfout,nucflag,t,Check1out,Check2out,hout,r,SolSplit,xbchangeFickout,FickSwitch,xbCur,alphaTrack,StagNucFlag);
    xbinstTot = xbinstTotTrack(end);
    %
    % Find slopes (nr & gr) at middle of interval
    %
    [nr3,gr3,CritRadFlag] = nucgrow_amorph(vf3,ram,r,rb,d,t,nsites,sfen,tk,xa,xb,xc,tau,vmol,a,h,xbinst3,xbinit,dgb,SolSplit,nucflag,firstit,CritRadFlag,sfengb,bin,Diffgbout,Diffout,hout,n,QuenchRate,GBen,w0);
    
%     nr3 = zeros(1,rrows);
%     gr3 = zeros(rrows,rcols+1); 
    
    for j = 1:1:rrows
        if nucflag(j) == 1, nr3(j) = 0; end
    end
    % nr3 = 0;
    %
    % slopes at end of interval
    % use nr & gr at middle of interval to calculate change in (r,n)
    %
    
    
    vf2 = [];
    for j = 1:1:rrows
        newpart2_i = (1-vf(j)) * nr3(j) * (h);
        ntemp2_i = n(j,:);
        ntemp2_i(bin(j))=ntemp2_i(bin(j))+newpart2_i;
        dr2_i = gr3(j,:) * (h/2);
        
        % Temporarily update size distribution
        %
        [np yp] = update_func_mod(r(j,:),rb(j,:),ntemp2_i,dr2_i);
        ntemp2_i = np';
        vf2_i = sum(((4/3) * pi * (r(j,:).^3)) .* ntemp2_i);
        
        vf2 = [vf2 vf2_i];
    end
    
    
    
    %     PFZ = lengthpfz(xc,xa,rgb,ngb,Vgrain,Agb);
    [xbinst2,TotalSolDist,xbinstTrack,vfTrack,xbinstTotTrack,flagSol,nucflag,Check1out,Check2out,SolSplit,Fickcheck,xbchangeFickout] = soltransferMIDDLE(vfTrack,vfgbTrack,xa,xb,xc,h,d,firstit,TotalSolDist,xbinstTrack,xbinstgbTrack,vf2,xbout,GBWidth,xbinstTotTrack,xbinst,dtTrack,flagSol,xbinit,xbinstTotTrackEnd,vfout,nucflag,t,Check1out,Check2out,hout,r,SolSplit,xbchangeFickout,FickSwitch,xbCur,alphaTrack,StagNucFlag);
    
    %
    % Find slopes (nr & gr) at end of interval
    %
    %     xbinstTot = xbinstTotTrack(end);
    [nr2,gr2,CritRadFlag] = nucgrow_amorph(vf2,ram,r,rb,d,t,nsites,sfen,tk,xa,xb,xc,tau,vmol,a,h,xbinst2,xbinit,dgb,SolSplit,nucflag,firstit,CritRadFlag,sfengb,bin,Diffgbout,Diffout,hout,n,QuenchRate,GBen,w0);
    
%     nr2 = zeros(1,rrows);
%     gr2 = zeros(rrows,rcols+1); 
    
    for j = 1:1:rrows
        if nucflag(j) == 1, nr2(j) = 0; end
    end
    
    % nr2 = 0;
    %

    %If modelling supersaturated nucleation
    if SSNucFlag == 1
        if nucflag(end) == 0
        if firstit == 0
            vfmax = (1/length(xbinst)).*((xbinst(rrows) - (xa.*1.2))/(xc - (xa.*1.2))); %Increase xa by x.xx % to stop xbinst falling below immediately
            npart = vfmax./((4/3).*pi.*(r(10,bin(rrows)).^3));
            nr(rrows) = npart/h;
            nr1(rrows) = nr(rrows);
            nr2(rrows) = nr(rrows);
            nr3(rrows) = nr(rrows);
            Test = (xb.*SolSplit(rrows) - (vfmax.*(xc-xa)))/(1./rrows);
        else 
            nr(end) = 0;
            nr1(rrows) = nr(rrows);
            nr2(rrows) = nr(rrows);
            nr3(rrows) = nr(rrows);
            nucflag(end) = 1;
        end
        end
    end



    % Estimate the error
    %
    % In number density
    %
    deltanum = [];
    for j = 1:1:rrows
        deltanum_i = norm(h*(nr1(j) - 2*nr3(j) + nr2(j))/3,'inf');
        deltanum = [deltanum deltanum_i];
    end
    %
    % In radius
    %
    deltarad = [];
    for j = 1:1:rrows
        deltarad_i = norm(h*(gr1(j,:) - 2*gr3(j,:) + gr2(j,:))/3,'inf');
        deltarad = [deltarad deltarad_i];
    end
    %
    % Allowable errors
    %
    %taunum = tol * 1e18;
    taunum = tol * 1e18;
    taunumgb = tol * 1e18;
    taurad = tol * 1e-9;
    tauradgb = tol * 1e-9;
    %
% %     % % % %     %More leniant error margins
% %         taunum = tol * 1e21;
% %         taunumgb = tol * 1e21;
% %         taurad = tol * 1e-7;
% %         tauradgb = tol * 1e-7;
    
    
    %
    % Limit maximum number of particles formed in each interval to mnum
    %
    newpart1 = zeros(1,rrows);
    hnuc = [];
    numrange = [];
    for j = 1:1:rrows
        newpart1(j) = nr1(j) * h;
        if newpart1(j)>mnum
            numrange_i = 1;
            % make step size half the limiting maximum
            hnuc_i = mnum/(2 * nr1(j));
%             hnuc_i = hmin;
        else
            numrange_i = 0;
            hnuc_i = hmax;
        end
        hnuc = [hnuc hnuc_i];
        numrange = [numrange numrange_i];
    end
    
    %
    % Check xbinst has not fallen too far %May have to re-implement this
    % dependning how mass balance of solute trasnfer goes
    %
    %             xbinst_tempgb = (xbinitgb) - (vfgb*(xc-xa)); %This can be a check based on the solute split at the start
    %             xbinst_tempM = (xbinitM) - (vf*(xc-xa));
    %
    %         if xbinst2 < xa
    %             xbcheck = 1;
    %         else
%     xbcheck = 0; %could implement a potential xbcheck
    %         end
    %
    %
    % Update the solution if the error is acceptable
    %
    %
    
%         if firstit > 0
%     TF = isnan(xbinst);
%     TF1 = isnan(rc);
%      TF2 = isnan(gr2);
% %     TF = isnan(xbinst);
%     if TF == 1 
%         aa = 4; end
%     if TF1 == 1 
%         aa = 4; end
%     if TF2 == 1 
%         aa = 4; end
%         end
%     if firstit == 2804
%         aa = 4;
%     end

% if firstit > 0
%     if any(xbinst2 < xa.*1.01) | any(xbinst3 < xa.*1.01) | any(xbinst < xa.*1.01)
%         xbcheck = 1;
%     else
%         xbcheck = 0;
%     end
% end
if firstit > 500
if rbarout(end-1,end) > rbarout(end,end)
    aa = 4;
end
end


% growth is high at low temps due to the time factor from plate collector,
% so may have to decrease timestep to handle changes in vf and xbinst.
    
%     if tk > 122
%         PRINTNO = 1;
%     else
        PRINTNO = 20;
%         if tk < 1041 
%             PRINTNO = 1;
%         end
%     end
    
    xbcheck = 0;

    % if any(xbinst2<xa.*1.1)
    %     %xbcheck = 1;
    %     hmax  = 1e-10;
    % end
    % 
    % 
    if any(xbinst2<xa)
        xbcheck = 1;
    end

%Stuff to print out for calibration
%Sum up all number densities and radii
Mat_n = n(1:rrows-1,:);
MatTot_n = sum(Mat_n);
% Matrixrbar = (sum(r(1,:).*MatTot_n))/sum(MatTot_n);

% Same again but for modal diameter
[val_pr,ind_pr] = (max(MatTot_n));
single_r = r(1,:);
modal_r = single_r(ind_pr);

% GB modal
[val_prgb,ind_prgb] = (max(n(rrows,:)));
modalrgb = single_r(ind_prgb);



    if (deltanum < taunum) &  (numrange==0) & (xbcheck == 0) & (Fickcheck == 0) & (BinFail == 0) & (deltarad < taurad)
        %          firstit = firstit + 1; %move this below xbinst and sol trasnfer work
        t = t + h;
        steptime = steptime + h;
        if (h == (tkprof(stage,3) - steptime));flag_me=1;end
        
        if firstit > 1
            VFTOTAL = sum(vfout(end,:));%vfout(end,1)+vfout(end,2);
        else 
            VFTOTAL = 0;
        end
        remprint = (mod(firstit,PRINTNO));
        if remprint == 0
%             disp(['Updating solution ' num2str(h) ' time/s: ' num2str(t) ' nucrateM ' num2str(nr3(1)) ' nucrateGB ' num2str(nr3(end)) ' tk ' num2str(tk) ' xbM ' num2str(xbinst(1)) ' xbGB ' num2str(xbinst(end)) ' rbarM ' num2str(rbar(1)*1e9) ' rbarGB ' num2str(rbar(end).*1e9) ' Total Vf ' num2str(VFTOTAL)])
              disp(['Updating solution ' num2str(h) ' time/s: ' num2str(t)  ' tk ' num2str(tk) ' xbM ' num2str(xbinst(1)) ' xbGB ' num2str(xbinst(end)) ' DModeMat ' num2str(modal_r.*2.*1e9) ' DModeGB ' num2str(modalrgb.*2.*1e9) ' Total Vf ' num2str(VFTOTAL)])

        end
            %
        % Calculate more accurate increment in size/number
        %
        newpart = zeros(1,rrows);
        dr = zeros(rrows,rbcols);
        npart = zeros(1,rrows);
        %If there is a problem, check here first!
        for j = 1:1:rrows
            newpart(j) = (1-vf(j))*h*(nr1(j) + 4*nr3(j) + nr2(j))/6;
            CurrN = n(j,:);
            CurrN(bin(j))=CurrN(bin(j)) + newpart(j);
            dr(j,:) = h*(gr1(j,:) + 4*gr3(j,:) + gr2(j,:))/6;
            
            [np yp]=update_func_mod(r(j,:),rb(j,:),CurrN,dr(j,:));
            n(j,:) = np';
            npart(j) = sum(n(j,:));
            vf(j) = 4/3 * pi * sum((r(j,:).^3) .* n(j,:));
            if npart(j) > 0
%                 rbar(j) = (vf(j)./((4/3) * pi * sum(n(j,:))))^(1./3);
                rbar(j) = (sum(r(j,:).*n(j,:)))./sum(n(j,:));
            else
                rbar(j) = 0;
            end
        end
        %
        % Output number of particles per um^3 and mean radius in nm
        %
        rbar_nm = zeros(1,rrows);
        for j = 1:1:rrows
            npart(j) = npart(j)/1e18;
            %
            rbar_nm(j) = rbar(j)*1e9;
        end
        
        %
        % Update CAP and PGP
        %
        cap = cap + (h .* exp(-QR_cap .* (1./tk)));
        CDR = 3.6;
        pgp = pgp + ((0.45/CDR) .* k_pgp .* (h./3600) .* exp(-TA_pgp./tk));
        socap = socap + (k_socap./tk.^2) .* exp(-QR_socap.*(1./tk)) .* h;
        
        %See how growth rate changes
        
        %[grtrck2,grtrck4,grtrck6,gr2flag,gr4flag,gr6flag] = growthtrack(dr,t,gr2flag,gr4flag,gr6flag,grtrck2,grtrck4,grtrck6);
        
        %PFZ = lengthpfz(xc,xa,rgb,ngb,Vgrain,Agb);
        
        
        %calculate xbinst for matrix and gb region and transfer of solute
        %from matrix to GB region - this will be based on the average
        %volume fractions etc. and will feed the output vectors and xbinst
        %will carry over to the begining of next iteration

        %7.9.22 trying to gradually release solute as into xbinst is being
        %made difficult by this function...
        [xbinst,TotalSolDistEnd,xbinstTotTrackEnd,flagSol,flagSolgb,nucflag,SolSplit,Fickcheck,xbchangeFickout] = soltransferEND(vfTrack,vfgbTrack,xa,xb,xc,h,d,firstit,TotalSolDistEnd,xbinstTrack,vf,xbout,GBWidth,xbinstTotTrackEnd,vfout,flagSol,flagSolgb,xbinit,nucflag,r,SolSplit,xbchangeFickout,FickSwitch,xbCur,VfMax,alphaTrack,StagNucFlag);
        
        remprint2 = (mod(firstit,PRINTNO));
        if remprint2 == 0
        vfout = [vfout; vf]; %take vfs as input, to then calculate xbinst as output for output vectors
       
        xbout = [xbout; xbinst]; %above uses xbinst track which will have most recent xbinst calculated at middle of slope, this is end of slope
        
        rbarout = [rbarout; rbar_nm];
        npartout = [npartout; npart];
        nrout = [nrout; nr3];
        rcout_c = [rcout_c; rc.*1e9];
        %          rcout_a = [rcout_a; rc_a.*1e9];
%         amorphout = [amorphout; ram.*1e9];
        SolSplitout = [SolSplitout; SolSplit];
        xaout = [xaout xa];
              tout = [tout t];
        tkout = [tkout tk];
        for j = 1:1:rrows
            Currdr = dr(j,:);
            grt_i = Currdr(bin(j))/h;
            grout = [grout grt_i];
        end

        end

        firstit = firstit + 1;
        xbinstTotEnd = xbinstTotTrackEnd(end);
        Diffgbout = [Diffgbout dgb];
        Diffout = [Diffout d];
        hout = [hout h];
        
        TotGbDiff = sqrt(sum(Diffgbout.*hout));
        Av = 4.*pi.*TotGbDiff;
        Avout = [Avout Av];



    % XBcheck
    xbcheckSegs = SolCheck(xbinst,vf,xa,xb,xc);
        
        % Check if nucleation is complete
        %
        %Might have to reinstate this once the total xbinst has fallen below a
        %certain value
        for j = 1:1:rrows
            if rbar(j) > 0 %This line gives a segment which initially had an xb lower than xa a chance to nucleate later on in quench.
                if nr3(j) < 1e-10
                    nucflag(j) = 1;
                end
            end
        end
        
        %
        % Build up output vectors
        %
%         tout = [tout t];
%         tkout = [tkout tk];
        %          vfout = [vfout vf];
%         rbarout = [rbarout; rbar_nm];
%         npartout = [npartout; npart];
%         nrout = [nrout; nr3];
%         rcout_c = [rcout_c; rc.*1e9];
%         %          rcout_a = [rcout_a; rc_a.*1e9];
%         amorphout = [amorphout; ram.*1e9];
        %          xbinst = xb - ((xc - xa) * vf);
        %          xbout = [xbout xbinst];
        %          ndump = [ndump; gr3];
%         capout = [capout cap];
%         pgpout = [pgpout pgp];
%         socapout = [socapout socap];
%         xaout = [xaout xa];
        %          PFZout = [PFZout PFZ];
        %             QuenchDist = sqrt(d.*h);
        %             Distout = [Distout QuenchDist];
        %
        % Calculation of a lattice parameter based on Vegard's law
        %
        %ainst = a + ((xbinst./xb) .* (a_init - a));
        %this will be wrong...
%         ainst = a + (((xbinst-xa)./(xb-xa)) .* (a_init - a));
%         aout = [aout ainst * 1e10];
        solsuc = solsuc + 1;
       
        
%         SolSplitout = [SolSplitout; SolSplit];
%         grout = [];
%         for j = 1:1:rrows
%             Currdr = dr(j,:);
%             grt_i = Currdr(bin(j))/h;
%             grout = [grout grt_i];
%         end
%         growthout = [growthout; grout];
        %          growth = dr(163); %bin radius of 50 nm
        %          growthout = [growthout growth];
        hfail = [];
    else
        solfail = solfail + 1;
        hfail = h.*0.1;
        if Fickcheck == 1
            disp(['Number of iterations failed (Fick) = ' num2str(solfail)])
        elseif BinFail == 1
            disp(['Number of iterations failed (Bins) = ' num2str(solfail)])
        elseif any(deltarad>taurad)
            disp(['Number of iterations failed (delrad) = ' num2str(solfail)])
        elseif any(deltanum > taunum)
            disp(['Number of iterations failed (deltanum) = ' num2str(solfail)])
        elseif any(numrange == 1)
            disp(['Number of iterations failed (numrange) = ' num2str(solfail)])
        elseif xbcheck == 1
            disp(['Number of iterations failed (xbcheck) = ' num2str(solfail)])
        else
            disp(['Number of iterations failed (Other) = ' num2str(solfail)])
        end
        
        if xbcheck == 1
            hfail = 1e-12;
        end
% 
%         if solfail > 15000
%             t = ttotal;
%         end

    end
    %
    % Update temperature for next step
    %
    if flag_me
        flag_me = 0;
        if stage<size(tkprof,1)
            stage=stage+1;
        else
            t = ttotal;
        end
        %stage = stage+1;
        tfinal=sum(tkprof(1:stage,3));
        steptime = 0;
        tk = tkprof(stage,1);
        disp (['Heating stage ' num2str(stage)])
        disp (['Temperature degC ' num2str(tk - 273)])
        h = hmin;
        firstit = 0;
    end
    if tkprof(stage,3)>0
        tk = ((steptime/tkprof(stage,3))*(tkprof(stage,2)-tkprof(stage,1)))+tkprof(stage,1);
    else
        tk = tkprof(stage-1,2);
    end
    %
    % set hmax so there are at least 20 steps per heat treatment stage
    %
    if tkprof(stage,3)>0
%         hmax = tkprof(stage,3)/20;
%         hmax = 1e-3;
    end
    %
    %
    %ERROR CHECKING - REDUCES TIMESTEP IF LARGE ERROR!
    %Up to here! Make this usable for the array system
    h1 = [];
    h2 = [];
    for j = 1:1:rrows
        if deltarad(j) ~= 0.0
            h1_i = min(hmax, 0.9 * h * (taurad/deltarad(j))^pow);
        else
            h1_i = hmax;
        end
        
        if deltanum ~= 0.0
            h2_i = min(hmax, 0.9 * h * (taunum/deltanum(j))^pow);
        else
            h2_i = hmax;
        end
        h1 = [h1 h1_i];
        h2 = [h2 h2_i];
    end
    
    
    if xbcheck == 1 %no xbcheck!
        h3 = h./1.1;
    else
        h3 = hmax;
    end
    %
    % Step size for next step is smaller of step sizes
    % calculated for growth and nucleation
    % and limited by not exceeding mnum particles in each step
    % But if in first few iterations, make sure h doesn't get too big
    % h is not allowed to increase by more than 10% between steps
    %
    if firstit>100
        hprov = [];
        for j = 1:1:rrows
            hprov_i = min([h1(j) h2(j) h3 hnuc(j) hfail]); %might need to adjust h3 here when xbcheck is applied!
            hprov = [hprov hprov_i];
%             disp(num2str([h1 h2 h3]))
%             if hprov == h1, disp(['limited by deltarad']); end;
%             if hprov == h2, disp(['limited by deltanum']); end;
%             if hprov == h3, disp(['limited by xbinst change']); end;
        end
        h = max([hmin hprov]);
    else
        hprov = [];
        for j = 1:1:rrows
            hprov_i = min([h1(j) h2(j) h3 hnuc(j) hfail]);
            hprov = [hprov hprov_i];
        end
        h = min([hprov hmaxinit]);
    end
    %      if (h>1.01*h_old), h=1.01*h_old; end
    if (h>1.1*h_old), h=1.1*h_old; end
    
    for j = 1:1:rrows
        if xbinst(j) < 5*xa
            if (h>1.01*h_old), h=1.01*h_old; end
        end
    end
    
    %
    % Check if xbinst--> xa reduce stepsize
    %
    for j = 1:1:rrows
        if xbinst(j) < 1.01*xa && nucflag(j) == 0
            h = 1e-10;
        end
    end


    % Check if tk is going to activate the GB region, if so, set h to
    % hmaxiint
    QREnd = (tkprof(1,1)-tkprof(1,2))/tkprof(1,3);
    tkstep = QREnd*h;
    if StagNucFlagTrip(end) == 0
        if (tk-tkstep) < TempInitSeg(end)
            h = hmaxinit;
        end
    end

    
    %      if xa > 0.99.*xbinst || xa > 0.99.*xbinstgb
    %         h = hmin;
    % %         firstit = 0;
    %      end
    h_old = h;
    FirstitIrrad = FirstitIrrad+1;

    

%     h = hmax;
end
%  if radflag == 0
%     [r_ln,n_ln] = lognrm_adjust(r,n,pgpout,rbarout,vfout);
%  end
r_ln = zeros(rrows,length(r));
n_ln = zeros(rrows,length(r));
% 
for j = 1:1:rrows 
    r_now = r(j,:);
    n_now = n(j,:);
    rbaroutHori = rbarout';
    rbarout_now = rbaroutHori(j,:);
    vfoutHori = vfout';
    vfout_now = vfoutHori(j,:);
  if radflag == 0
    [r_ln_temp,n_ln_temp] = lognrm_adjust_TEST(r_now,n_now,pgpout,rbarout_now,vfout_now);
  end
    r_ln(j,:) = r_ln_temp;
    n_ln(j,:) = n_ln_temp;
end
% r_ln = [];
% n_ln = [];
disp([num2str(solfail+solsuc) ' Iterations: ' num2str(solsuc) ' Successful ' num2str(solfail) ' Unsuccessful'])

