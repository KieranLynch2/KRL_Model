function [gr] = growth_amorph(rb,rc_cryst,rc_amorph,ram,sfen,d,xbinst,xa,xc,tk,vmol,h,t,dgb,Diffgbout,Diffout,hout,n,sfengb,r,QR,vf,GBen,w0)
% function [gr] = growth(r,sfen,d,xbinst,xc,xa,tk)
% Calculates growth rate of spherical Al3Zr dispersoids
%
% Inputs
% r         Particle radius (m)
% sfen      Interfacial energy (J/m^2)
% d         Diffusion coefficient (m^2/s)
% xbinst    Average Zr concentration in matrix
% xc        Concentration of Zr in dispersoids
% xa        Concentration of Zr in matrix at interface
% tk        Temperature (K)
% Output
% gr        Growth rate (ms^-1)
%
gas = 8.31459;
k = 1.3806488e-23;
hplank = 6.626e-34;
delta = 3.2e-10; % width of interface (assume approx <a> Zr)
na = 6.022045e23;
vat = vmol./na;
%cn = find(r>0);
%cy = find(r<=0);

%% Growth rate for matrix precipitates

%this will be r,n 1:49
rsz = size(rb); % I have to calculate the growth rate for every one of the 50 segements, as well as every bin in each segment!!
rrows = rsz(1);
rcols = rsz(2);
gr = zeros(rrows,rcols); %preallocate an array to encompass ALL segments



% c_cryst = find(rb>ram);
% c_amorph = find(rb<=ram);


%Change sfen for gb nucleation to make it easier? This will probably also
%have an effect. Also could change No. of nucleation sites (already a
%fitting parameter)

% x = (2 * sfen * vmol)/(gas * tk);
%xr(cn) = xa .* exp(x .* (1./r(cn)));
% xr(c_cryst) = xa .* ((xbinst./xa).^((rc_cryst)./rb(c_cryst)));
% xr(c_amorph) = xa .* ((xbinst./xa).^((rc_amorph)./rb(c_amorph)));
xr = []; %Have to calculate 

for j = 1:1:rrows
    xr_i = xa .* ((xbinst(j)./xa).^((rc_cryst(j))./rb(j,:)));
    xr = [xr; xr_i];
end
%
%
%
%xr(cy) = 0;
%
% For very small particles capillarity equation
% gives xr > xc. Corresponds to very unstable 
% particle. For this case, growth rate will
% be very negative 
%
% ind = zeros(rrows,rcols);
% for j = 1:1:rrows
%     ind(j,:) = find(xr(j,:)>xc);
%     colsWithZeros = any(ind==0);
%     ind = ind(:, ~colsWithZeros);
% end


% ind = [];
% for j = 1:1:rrows
%     ind_i = find(xr(j,:)>xc);
%     ind = [ind; ind_i];
% end
%Could put a quench flag here to determine when to use gb growth in future
%remember r in these scripts is actually rb.
%As in Kamp et al., 2005, heterogenous nucleation can be emperically
%modelled by adjusting the interfacial energy to effectively reduce the
%surface energy.


% Traditional growth rate
% for j = 1:1:rrows-1
%     gr(j,:) = ((xbinst(j) - xr(j,:))./(xc - xr(j,:))) .* (d./rb(j,:)); % Need to make the xbinst for half the model low and then increase it for other half e.g. if solute split is 50/50
% end
% Ddis = d.*1e7;

%% Changed Ddis to be equal to dgb instead of double on 26/10/24
Ddis = dgb;
% Dislocation controlled growth
for j = 1:1:rrows-1
    GAM = gammainc(0.5,4.*vf(j));
    mu = rb(j,:)./rc_cryst(j);
    N = 1;
    DissCore_r = 1e-9;
    qold = (rb(j,:).*2.*DissCore_r.*2); %Incorrect calculation! 26/10/24
    q = (2.*pi.*DissCore_r).*rb(j,:).*2; %rb is radius of SPP, we need 2r for diameter for total surface area
    ntail = (4.*(vf(j).^0.5))./((exp(4.*vf(j)).*GAM));
    gr(j,:) = ((N.*q.*Ddis.*xa.*(vmol.^2))./(2.*pi.*gas.*tk)).*(ntail.*(mu.*(mu-1))).*(1./(rb(j,:).^4)); % Need to make the xbinst for half the model low and then increase it for other half e.g. if solute split is 50/50
end

% Just for testing of script, have decommented the growth rate for GB pptes.
%% New trial to test out the standard KWN growth rate 16/12/24 --> need to clarify with joe what's best course of action here...
for j = 1:1:rrows-1
%gr(j,:) = ((xbinst(j) - xr(j,:))./(xc - xr(j,:))) .* (d./rb(j,:));
end


for j = rrows
%% Collector plate mechanism

%     if t > 0
% %     Collector plate mechanism
%     TotGbDiff = sqrt(sum(Diffgbout.*hout));
%     TotMatDiff = sqrt(sum(Diffout.*hout));
%     AverDMatrix = mean(Diffout);
%     
% %     Collector plate AA/CF
%     AvCF = 4.*pi.*sum(Diffgbout.*hout);
% 
%     %Alternative collector plate area
%     Agb = 7.43*1e6; %Gb area per unit volume for ABQ
% 
%     Na = sum(n(j,:))./Agb; %Number of SPPs/unit area, Liu 1996
%     Na(isnan(Na))=0;  % Corti, 1974
%     MFP = 0.5*(sum(Na).^-0.5);%Underwood mean free distance, Corti 1974
% 
%     Av = pi.*((MFP./2).^2);
% 
%     %if 1um is diameter of plate
% %     Av = ((5e-7/2).^2).*pi;
% 
%     gr(j,:) = ((Av.*sqrt(d))./(2.*pi.^(1.5).*(rb(j,:).^2).*(sqrt(t)))).*((xbinst(j) - xr(j,:))./(xc - xr(j,:)));
% %     gr22 = ((Av22.*sqrt(d))./(2.*pi.^(1.5).*(rb(j,:).^2).*(sqrt(t)))).*((xbinst(j) - xr(j,:))./(xc - xr(j,:)));
%     
%     else
%         gr(j,:) = zeros(1,length(rb(j,:)));
%     end


%% TradGrowth
%     gr(j,:) = ((xbinst(j) - xr(j,:))./(xc - xr(j,:))) .* (dgb./rb(j,:)); % Need to make the xbinst for half the model low and then increase it for other half e.g. if solute split is 50/50


%% Ardell, 1972
    if t > 0
        if xbinst(j)<0
            aa=4;
        end
        %GBEn = 0.6; % Plowman & Race
        %w0 = 0.9e-9; % Plowman & Race
        vf = 4/3 * pi * sum((r(j,:).^3) .* n(j,:)); %change this to r later ,...!!!

%         Na = n(j,:).*(2.*r(j,:)); %Corti, 1974 Convert number of particle in each bin per unit volume to unit area
%         Na(isnan(Na))=0;  % Corti, 1974
%         
        %assume all particles on GB segment are on GB, then number of
        %SPPs/unit volume is equal to number of SPPs/unit area
%         Agb = 7.43*1e6; %Gb area per unit volume for ABQ

        a_sv = 3.*1e4;
        b_sv = 0.7;
        Sv = a_sv.*QR.^b_sv;

        Agb = Sv;


        Na = sum(n(j,:))./Agb; %Number of SPPs/unit area, Liu 1996
        Na(isnan(Na))=0;  % Corti, 1974
        MFP = 0.5*(sum(Na).^-0.5); %Underwood mean free distance, Corti 1974

%         Nl = ((pi.*(Na.^2))./n(j,:))./4;  % Corti, 1974
%         Nl(isnan(Nl))=0;
%         MFP = (1-vf)./(sum(Nl)); % Corti, 1974
        rprime = rb(j,:)+(MFP./2); %As rprime gets smaller, the growth rate increases

        if vf == 0
            rprime = rb(j,:)+(1e-9./2); %dummy 1 nm spacing...
        end

        if GBen/sfengb == 2.00 %without this G becomes infinity
            sfengbtemp = sfengb+0.00001;
            A = (2./3)-(GBen./(2.*sfengbtemp))+((1./3).*((GBen./(2.*sfengbtemp)).^3));
            G = A./(1-((GBen./(2.*sfengbtemp)).^2)).^2;
        else
            A = (2./3)-(GBen./(2.*sfengb))+((1./3).*((GBen./(2.*sfengb)).^3));
            G = A./(1-((GBen./(2.*sfengb)).^2)).^2;
        end

%         A = (2./3)-(GBEn./(2.*sfengb))+((1./3).*((GBEn./(2.*sfengb)).^3));
%         if A == 0
%             disp('A in GB growth is zero, adjust sfengb or GBEn')
%         end
%         G = A./(1-((GBEn./(2.*sfengb)).^2)).^2;


        gr(j,:) = ((2.*sfengb.*xa.*dgb.*w0.*(vmol.^2))./(3.*G.*(rb(j,:).^3).*gas.*tk)).*(((rb(j,:)./rc_cryst(j))-1)./(log(rprime./rb(j,:))));
        gr22 = ((2.*sfengb.*xa.*dgb.*w0.*(vmol.^2))./(3.*G.*(rb(j,:).^3).*gas.*tk)).*(((rb(j,:)./rc_cryst(j))-1)./(log(rprime./rb(j,:))));
        %At the momemnt, all the SPPs are dissolving straight away, need to
        %set rc_cryst here to at least the bin before crit rad...
        Posgr = find(gr(j,:)>0);
        Posbin = min(Posgr);
        rcfind = (rb(j,:)-rc_cryst(j));
        rcbin = find((rcfind>0));
        rcbinn = min(rcbin);
%         if Posbin > rcbinn
%             rc_temp = rc_cryst(j-1);
%             gr(j,:) = ((2.*sfengb.*xa.*dgb.*w0.*(vmol.^2))./(3.*G.*(rb(j,:).^3).*gas.*tk)).*(((rb(j,:)./rc_temp)-1)./(log(rprime./rb(j,:))));
%         end


    else
        gr(j,:) = zeros(1,length(rb(j,:)));
    end

    %Ardell end




%     gr1(j,:) = ((Av.*TotMatDiff)./(2*(pi^1.5).*rb(j,:))).*((xbinst(j) - xr(j,:))./(xc - xr(j,:)));
%     gr2(j,:) = ((xbinst(j) - xr(j,:))./(xc - xr(j,:))) .* (dgb./rb(j,:)); % Need to make the xbinst for half the model low and then increase it for other half e.g. if solute split is 50/50


%     gr3(j,:) = ((Av.*sqrt(AverDMatrix))./(2.*pi.^(1.5).*(rb(j,:).^2).*(sqrt(t)))).*((xbinst(j) - xr(j,:))./(xc - xr(j,:)));

%     gr(j,:) = ((Av.*sqrt(AverDMatrix))./(2.*pi.^(1.5).*(rb(j,:).^2).*(sqrt(t)))).*((xbinst(j) - xr(j,:))./(xc - xr(j,:)));

    %OR:
%     gr(j,:) = ((Av.*sqrt(d))./(2.*pi.^(1.5).*(rb(j,:).^2).*(sqrt(t)))).*((xbinst(j) - xr(j,:))./(xc - xr(j,:)));

%     gr(j,:) = ((dgb.*sqrt(AverDMatrix))./(2.*pi.^(0.5).*(rb(j,:).^2))).*((xbinst(j) - xr(j,:))./(xc - xr(j,:)));

%     gr(j,:) = ((Av.*TotMatDiff)./(4*(pi^1.5).*(rb(j,:).^2))).*((xbinst(j) - xr(j,:))./(xc - xr(j,:)));

%     Av = 4*pi*dgb*t; %This evolves with time!
%     gr(j,:) = ((Av.*sqrt(d.*t))./(2*(pi^1.5).*rb(j,:))).*((xbinst(j) - xr(j,:))./(xc - xr(j,:)));


%     gr(j,:) = ((xbinst(j) - xr(j,:))./(xc - xr(j,:))) .* (d./rb(j,:)); % Need to make the xbinst for half the model low and then increase it for other half e.g. if solute split is 50/50

%      gr(j,:) = ((xbinst(j) - xr(j,:))./(xc - xr(j,:))) .* (dgb./rb(j,:));

%     gr33(j,:) = ((xbinst(j) - xr(j,:))./(xc - xr(j,:))) .* (dgb./rb(j,:));

% New attempt of modelling grain boundary grwoth 20/01/2023:
%     AvVar = 4*pi*dgb*t; %Need to add in a limit to the maximum Av size.
%     AvFix = 1e-3;
%     Av = min(AvVar,AvFix);
% 
%     gr(j,:) = ((Av.*sqrt(d.*t))./((4/3)*(pi^1.5).*(rb(j,:).^1))).*((xbinst(j) - xr(j,:))./(xc - xr(j,:)));
% 



end



% Below is all now redundant as it is in another script
% Qrat = 90000; %OBQ_1 conditions
% prefac = 6500;


% Qrat = 70000;
% prefac = 4500;
% Drat = prefac*exp(Qrat/(gas*tk)); %Ratio of Cr gb/l diffusivity (Massih, 2003)
% Dgb = d*Drat; %This is once again a fitting parameter, can fit this and pottentially compare is to gb/latiice diffusivity from Massih, 2003. fig8
% % Dgb = d*(1*10^(6));
% 
% Av = 4*pi*Dgb*t; %t is total time as Av is to do with solute depletion close to SPP.
% 
% %for now just exlcuding possibility of matrix precipitation
% % if t < 0.0056667*3600
%     gr = ((Av.*sqrt(d.*h))./(2*(pi^1.5).*r)).*((xbinst - xr)./(xc - xr));
% else
%     gr = ((xbinst - xr)./(xc - xr)) .* (d./r);
% end


%grmin = find(gr<-1e-6);
%gr(grmin) = -1e-6;
%grmax = find(gr>1e-6);
%gr(grmax) = 1e-6;
rx = isreal(xr);
rgr = isreal(gr);
if rx==0 | rgr==0
    disp(['Imaginary parts in xr and/or gr'])
end
%
% alternative law for case xr > xc
%
% Maximum boundary velocity limited by interface growth
%
freq = (k .* tk)./hplank;
% for amorphous
% This will only apply when driving force is very big - ie. exp(-driving)=0
% gstar_a = 15930 * k;
% vmax_a =  abs(delta .* freq .* exp(-gstar_a/(k * tk)));
% growlim_a = find(gr(j,:) > vmax_a);
% dislim_a = find(gr(c_amorph) < -vmax_a);
% gr(growlim_a) = vmax_a;
% gr(dislim_a) = -vmax_a;
% for crystalline
gstar_c = 15930 * k;
vmax_c =  abs(delta .* freq .* exp(-gstar_c/(k * tk)));

for j = 1:1:rrows
    Currgr = gr(j,:);
    growlim_c = find(Currgr > vmax_c);
    dislim_c = find(Currgr < -vmax_c);
    Currgr(growlim_c) = vmax_c;
    Currgr(dislim_c) = -vmax_c;
    % Next line critical - otherwize very small particles have +ve growth rate
    
    ind = find(xr(j,:)>xc);
    Currgr(ind) = -vmax_c;
    
    %Now put Currgr back into the gr matrix
    gr(j,:) = Currgr;
end
%
%
% 
% REMOVE THIS BIT
%nego = find(gr<0);
%gr(nego) = 0;

%% Below is quench rate calculations - have to calculate everything for GB
%seperately

% xbinstgb = xb - ((xc - xa) * vfgb);%This has to be the mean matrix conc at the grain boundary, in the PFZ
% xrgb = xa .* ((xbinstgb./xa).^((rc_cryst)./rgb(c_cryst)));

% Qrat = 65000;
% prefac = 5000;
% Drat = prefac*exp(Qrat/(gas*tk)); %Ratio of Cr gb/l diffusivity (Massih, 2003)
% Dgb = d*Drat; %This is once again a fitting parameter, can fit this and pottentially compare is to gb/latiice diffusivity from Massih, 2003. fig8
% % Dgb = d*(1*10^(6));
% 
% Av = 4*pi*Dgb*t; %t is total time as Av is to do with solute depletion close to SPP.
% 
% %for now just exlcuding possibility of matrix precipitation
% gr = ((Av.*sqrt(d.*h))./(2*(pi^1.5).*r)).*((xbinst - xr)./(xc - xr));



%Below is new growth rate based on second order kinetics
% 
% QR = 500;
% gr = (exp(-QR.*(1./tk^2))).*vmol.*(xbinst-xr).^2;

 return