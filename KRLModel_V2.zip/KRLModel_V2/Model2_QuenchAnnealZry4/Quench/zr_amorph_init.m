function[r,rb,n,tk,d,tfinal,xb,xc,xa,sfen,nsites,vmol,vmax,a,a_init]=zr_amorph_init(tc,t,r,rb,n)
%
%
% Initializes parameters for zirconium precipitation model
%   
% Need to comment out lines below depending on which alloy is being used
%
% Inputs:
% xbw       Concentration of solute (wt%) initial
% tc        Temperature (degC)
% t			Time to predict for (hrs)
%
% Outputs:
% r         Size bins (mean sizes) (m)
% rb        Size bins (edge sizes) (m)
% tk        Temperature  (K)
% tfinal    Time to calculate for (s)
% xb        Initial concentration of solute (atoms/m^3)
% nsites    Number of nucleation sites  (m^-3)
% sfen      Interfacial energy of precipitate (Jm^-2)
% vmol		Molar volume of precipitate (m^-3/mol)
% vmax		Maximum volume fraction of precipitate
% a			Lattice parameter at end of precipitation (m)
% a_init	Lattice parameter at start of precipitation (m)
%
tk = 273 + tc;
%
% nad - adjusts number of nucleation sites as a fraction of number of sites
% for homogeneous nucleation
% nad =1e-9 for Zirc-4 to fit Gros and Wadier data
%nad = 1e-9;
%
% From Massih paper (for Zirc-4)
%
vmol = 9e-6;
ram = 92.906;
a_init = 0.32388e-9;
% finds equilibrium solubility (Massih paper data)
xc = 0.66;
%xa = exp((-2.8e3./tk)-5.6);
xa = exp((-5.4e3./tk)-3.3); 
% finds diffusion coefficient - uses effective coefficient (Massih) for
% substitutional species for which there are no better data
%d = diffco_amorph(tk);
% d = 3e-7 * exp(-15930/(tk));
d = 6e-7 * exp(-15930/(tk));
%
%
% Below is for Fe
% sfen = 0.7 works for size predictions: 0.2wt%, 1h, 600
%vmol =7.83e-6;
%ram = 55.845;
%[xc,xa]=equilibriumfe(tk);
%d = diffco_fe(tk);
%
% Below is for Cr
% 
%vmol = 9.4047e-6;
%ram = 51.996;
%[xc,xa]=equilibriumcr(tk);
%d = diffco_cr(tk);
% Below is for Zirc-4
%
%vmol = 9e-6;
% Dummy RAM
%ram = 91.22;
%[xc,xa]=equilibriumzirc(tk);
%d = diffco_zirc(tk);
% a Lattice parameter for Zr at end of ppt
a = 0.32425e-9;
% xb = effective composition Fe + Cr ZIRC-4
xb = 0.0018 + 0.0033;% + 0.0018 + 0.0033;
tfinal = t*3600;
%
% sfen is interfacial energy for precipitate phase. This is a fitting
% parameter. Massih value = 0.25
%
%sfen  = 0.25;
sfen = 0.22;
% nad = 1e-9; % This gives good fit to Gros and Wadier sizes (sfen = 0.25)
nad = 1e-9; % This gives good fit to Massih et al. sizes (sfen = 0.25)
% Every lattice site in Zr potential nuc. site (Nsites = 4.30e28)
nsites = 4.30e28*nad;
vmax = (xb - xa)/(xc - xa);
disp(['Vmax ' num2str(vmax)])%
%
% Set up size bins
% 
% scale goes from 1A to um
scale = 1e-10;  
 % steps is number of bins per decade
  steps = 30;
% mindec is lowest log10(radius) in nM
  mindec = 0;
% ndec is number of decades to cover
  ndec = 9;
% number of bin edges
  nb = ndec*steps+1;
  if exist('n','var')==0
      % get bin edges
    rb = logspace(mindec,mindec+ndec,nb);
    % rb = logspace(mindec,mindec+ndec,nb);
    % get bin centers in the geometric sense
    % r = 10.^(0.5*log10(rb(1:nb-1))+0.5*log10(rb(2:nb)));
    r = 10.^(0.5*log10(rb(1:nb-1))+0.5*log10(rb(2:nb)));
    % scale to M
    % linear size binning
    %scale = 1.5e-7;
    %% Below for predictions for Aaronson paper
    %rb = linspace(0,1,5000);
    %rb = linspace(0,3200,1601);
    %r = ((rb(1:end-1)+rb(2:end))./2);
    rb = (rb*scale);
    r = (r*scale);
    len = length(r);
    n(1:len) = 0;
  end
  disp(['Remember to redefine D if necessary'])
end
