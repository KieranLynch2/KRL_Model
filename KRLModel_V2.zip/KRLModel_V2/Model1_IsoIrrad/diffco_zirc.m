function [d]=diffco_zirc(tk)
%
% Diffusion data zircaloy
% Massih et al, J. Nuc. Mater. 322, 2003, 138
% GB diffusion
gas =8.314408694;
%
%
%
d=1.473e-6.*exp(-15930/tk);