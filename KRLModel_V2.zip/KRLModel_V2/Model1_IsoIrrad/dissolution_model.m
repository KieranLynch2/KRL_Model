%
% Takes PSD and dissolves with linear r increase
% Predefine r,n
tout = [];
rbarout = [];
vfout = [];
npartout = [];
for i = 1:1000
    rdiss = i * 1e-10;
    diso = find(r<rdiss);
    n(diso) = 0;
    npart = sum(n);
    vf = 4/3 * pi * sum((r.^3) .* n);
    rbar = (vf./((4/3) * pi * npart))^(1./3);
    tout = [tout i];
    npartout = [npartout npart];
    rbarout = [rbarout rbar];
    vfout = [vfout vf];
end