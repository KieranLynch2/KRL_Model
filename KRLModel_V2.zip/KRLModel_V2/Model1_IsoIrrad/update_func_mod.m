function [Np,yp] = update_func_mod(R,Rb,N,dR,style,y,y0)
% ==================================================================
%
% function [Np,yp] = update_func30(R,Rb,N,dR,style,y,y0)
%
% Modified version of update function: uses calculated growth rates
% at bin edges, rather than interpolating growth rates - interpolated
% rates can lead to errors in size distribution evolution
%
% Inputs:
%
%   R:     "midpoint" sizes of size bins
%   Rb:    edge sizes of size bins (length one greater than R)
%   N:     number densities corresponding to size bins (length same as R)
%   dR:    growth increment at edge of size bins
%   style: flag for adjusting redistributions, based on changes in
%          the bin mean sizes (length 1)
%          (default is 0, i.e. no adjustment)
%          (this "feature" does not currently work. pass style=0
%   y:     another distribution corresponding to size bins (length same as R)
%          (to leave this portion out, simply do not pass this argument
%           or the next)
%   y0:    "background" value for y, i.e for bins with zero number density
%          (length 1)
%
% Outputs:
%
%   Np:    adjusted number densities accounting for growth increments
%          (length same as R)
%   yp:    adjusted distribution "y" corresponding to adjusted number
%          densities (length same as R)
%
% ==================================================================
%
% Check inputs.
%  if min(dR)<0
%      disp(['stop'])
%  end
if nargin<5, style=0; end;
if length(style)==0, style=0; end;
if nargin<6, y=0*R; end;
if nargin<7, y0=0; end;
R = R(:);
Rb = Rb(:);
N = N(:);
dR = dR(:);
y = y(:);
%
Np = []; yp = [];
if min(diff(R))<0,
    disp('R midpoint values must be in ascending order ...')
    return
elseif min(diff(Rb))<0,
    disp('R edge values must be in ascending order ...')
    return
end;
%
% ==================================================================
%
% Get number densities and growth increments at edges of bins.
%
len = length(R);
Rbl = Rb(1:len);
Rbu = Rb(2:len+1);
%
% dRb = interpx(Rb,R,dR,0);
% dRb = interpxq(Rb,R,dR,0);
% use actual values for size increments at bin edges, not interpolations
dRb = dR;
% dRb = [0;midpoint(dR);0];
% dRb(1) = interpx(Rb(1),R(1:2),dR(1:2),0);
% dRb(len+1) = interpx(Rb(len),R(len-1:len),dR(len-1:len),0);
%
dRbl = dRb(1:len);
dRbu = dRb(2:len+1);
%
% if max(Rb+dRb)>Rbu(len), Rbu(len)=max(Rb+dRb)+10; end;
%Nb = max(interpx(Rb,R,N,0),0);
%The following line of code is to prevent the error "The grid vector must
%contain unique points". Solution taken from MathWorks, Kieran Lynch
%06/01/2020
%Without the following code (after correcting for above error code) the R
%array length changes at it excludes the repettitive zero entries.
len_temp = length(R);
[R, index] = unique(R);
Nb = max(interp1(R,N(index),Rb),0);
len_new = length(R);
len_diff = len_temp - len_new;
Rzero_temp = zeros(1,len_diff);
Rzero_temp_trans = Rzero_temp';
R = cat(1,Rzero_temp_trans,R);


%Nb = max(interp1(R,N,Rb),0); %the final 0 changes the NaN results to 0
%Nb simply returns the number density at the bin edges
Nbl = Nb(1:len);
Nbu = Nb(2:len+1);
%Nbl = [0;N(1:end-1)];
%Nbu = [N(2:end);0];
sumN = 0*N;
sumNR = 0*N;
sumNy = 0*N;
%
% ==================================================================
%
% Loop over size bins.
%
for i=1:len,
    %
    if N(i)>0,
        %
        %     Get three values for new size and current number density for a
        %     given bin, corresponding to lower edge, middle and upper edge.
        %
        xl = Rbl(i) + dRbl(i);
        xm = R(i)   + ((dRbl(i)+dRbu(i))/2);
        xu = Rbu(i) + dRbu(i);
        %
        % If there is no growth, do not reallocate N for this bin
        %
        if dRbl(i)==0 && dRbu(i)==0
            sumN(i) = N(i);
            else
            yl = Nbl(i);
            ym = N(i);
            yu = Nbu(i);
            %
            %     Check for case where new size does not increase in order of
            %     lower edge to middle to upper edge and fudge if necessary.
            %
            if xl>xm | xm>xu,
                %        disp('Crossing ...')
                %        disp([xl,xm,xu])
                xl = min([xl,xm,xu]);
                xu = max([xl,xm,xu]);
                xm = 0.5*(xl+xu);
                yl = mean([yl,ym,yu]);
                ym = yl;
                yu = yl;
            end;
            %
            %      dxmin = 1e-6*(Rbu(i)-Rbl(i));
            %      xm = max(xm,xl+dxmin);
            %      xu = max(xu,xm+dxmin);
            %
            %     Get the list of bins who will receive some of this bin's number
            %     density. "u" is the list of bin indices. Note that if "u" is empty,
            %     it means that all of the number density in this bin moved to below
            %     the smallest size lower bound and have thus disappeared.
            %
            u = find(Rbl<xu & Rbu>xl);
            %      check = find(u==36);
            %      if length(check)>0
            %          disp([num2str(i) ' : ' num2str(u')])
            %      end
            if length(u)==0 & xu>max(Rb),
                disp(['max bin size exceeded!'])
                u=length(Rbl);
            end
            %
            if length(u)>0,
                %
                %       This bin's number density is spread out as a piecewise linear
                %       function (2 pieces, i.e. from (xl,yl) to (xm,ym) and from
                %       (xm,ym) to (xu,yu)) over the bins receiving the number density.
                %       The number density is actually the derivative
                %       of the cumulative number density. Integrate the piecewise linear
                %       function to get a piecewise quadratic function. Evaluating the
                %       piecewise quadratic function at the bin edges of the bins
                %       receiving this bin's number density gives the fractional portion
                %       of the number density each bin gets. "xx" are the edge positions
                %       of the bins receiving a portion of this bin's number density.
                %       "yy" are the cumulative fractions at these edge positions. "phi"
                %       are the fractions each bin will receive of this bin's number
                %       density. "sumN" and "sumNy" are the running totals of the
                %       redistributed number density and other distribution "y"
                %       respectively.
                %
                dx = min(Rbu(u),xu) - max(Rbl(u),xl);
                if xu>max(Rbu), ulen=length(u); dx(ulen)=xu-max(Rbl(u(ulen)),xl); end;
                xx = xl + [0;cumsum(dx)];
                m1 = (ym-yl) / (xm-xl);
                m2 = (yu-ym) / (xu-xm);
                b1 = ym - m1*xm;
                b2 = ym - m2*xm;
                yy = (xx<=xm).*(m1/2*(xx.^2-xl^2) + b1*(xx-xl)) ...
                    + (xx>xm) .*(m2/2*(xx.^2-xm^2) + b2*(xx-xm) + (ym+yl)/2*(xm-xl));
                phi = 0*u;
                whole = 0.5*(yl+ym)*(xm-xl) + 0.5*(ym+yu)*(xu-xm);
                if whole>eps, phi=max(diff(yy),0)/whole; end;
                sumN(u) = sumN(u) + N(i)*phi;
                sumNy(u) = sumNy(u) + N(i)*y(i)*phi;
                %
                %       disp([i,R(i),dR(i),N(i),length(u),min(u),max(u),phi(1)])
                %       disp([i,R(i),dR(i),N(i),length(u),min(u),max(u),phi(:)'])
                %
                %       For the "style" flag set to 1, adjust the accumulated,
                %       adjusted number densities, based on the sizes at which new
                %       number densities are added to receiving bins. Without this
                %       adjustment, the assumption is that the bins always have the
                %       same mean size. This adjustment keeps track of the how the
                %       mean size of bins are changing with the reapportionmet of
                %       bin number densities. The problem is that sometimes, the new
                %       bin mean size winds up being outside the bounds for that bin.
                %       It's not clear why this happens. For now, omit this adjustment
                %       by passing style = 0, or leaving out of the calling sequence.
                %
                if style(1)==1,
                    zzhalf = m1/3*(xm^3-xl^3) + b1/2*(xm^2-xl^2);
                    zz = (xx<=xm).*(m1/3*(xx.^3-xl^3) + b1/2*(xx.^2-xl^2)) ...
                        + (xx>xm) .*(m2/3*(xx.^3-xm^3) + b2/2*(xx.^2-xm^2) + zzhalf);
                    dz = max(diff(zz),0);
                    dy = max(diff(yy),0);
                    uu = find(dy>eps);
                    Rbar = R(u);
                    Rbar(uu) = dz(uu) ./ dy(uu);
                    sumNR(u) = sumNR(u) + N(i)*phi.*Rbar;
                    %         disp([i,N(i),length(u),min(u),max(u)])
                    uu = find(Rbar<Rbl(u) | Rbar>Rbu(u));
                    if length(uu)>0,
                        disp('Adjustment based on new mean size funky ...')
                        disp([int2str(length(uu)),' are bad ...'])
                        disp([xl,xm,xu;yl,ym,yu])
                        disp(xx')
                        disp(yy')
                        disp(zz')
                        disp([Rbl(u),Rbar,Rbu(u)])
                    end;
                end;
            end;
        end;
    end;
end;
%
% ==================================================================
%
% End loop over size bins.
% Set updated number densities and other "y" distribution.
%
Np = sumN;
yp = y0 + 0*y;
u = find(Np>0);
yp(u) = sumNy(u) ./ sumN(u);
%
% ==================================================================
%
% If adjustment of distributions based on changes to bin mean sizes
% is being done (i.e. style = 1), the running totals for number
% density and other distribution "y" must be corrected back for new
% mean bin size.
%
if style(1)==1 & sum(sumN)>0,
    Rp = R;
    Rp(u) = sumNR(u) ./ sumN(u);
    u = find(Rp<Rbl | Rp>Rbu);
    if length(u)>0,
        disp('size funky?')
        disp([u,Rp(u),Rbl(u),Rbu(u)])
        Rp(u) = 0.5*(Rbl(u) + Rbu(u));
    end
    %   Np = update_help(1,R,Rbl,Rbu,Rp,Np);
    Np = max(interp1(Rp,Np,R),0); Np=Np*sum(N)/max(sum(Np),eps);
end;
%
% ==========================================
