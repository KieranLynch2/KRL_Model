function [drdt,EqRad] = NHM(rb,d,xb,xc_a,vat,n,phi,n_clust,xc_clust,xc,vf_crat,vf_arat,vf_clustrat,xbinst,vmol,sfen,tk,xa)

% Nelson RS, Hudson JA, Mazey DJ. J Nucl Mater. 1972 Sep 1;44(3):318�30. 
% Was GS. Fundamentals of radiation materials science: Metals and alloys, second edition. 2016 Jan 1;1�1002. 

% rb=r; %This is just temp as using n array which is only compatible with r array, not rb
% nrb = 1:1:length(r);


 %if xc was left as 0.66 the mass balance with volume fractions would be off. Need vfs of each cryst,amorph,clust, beacuse then you know the total concentration of solute reatined in precipitates
xc_avg = (xc*vf_crat)+(xc_a*vf_arat)+(xc_clust*vf_clustrat);

%xc must infiact be the average composition of all precipiates and clusters
%This means that it needs to be determined using the core composition of
%SPPs, the shell composition of SPPs, + the composition of cluseters (which
%can vary quite a bit)
%alreadu have calculated xc_avg for amorphous SPPs, so just need to average
%again with clusters!

z0 = 4.5e20; %neeeded to convert dpa to atomic flux, quoted in NHM paper, n.b. 10^18 as we are working in metres

%Might need a function to convert fluence to dpa (estimation)
% k0 = 1.2e-7; %dpa/s
k0 = phi./(5e20); %Conversion from flux to dpa/s

Rg = 8.314;
% molmass = 143.9*1e-3; %convert from g/mol to kg/mol, to get si units of density
%This is an estimate of the molar mass of the amorphous phase - currently crystalline phase
% vmol = 9e-6; %TEMP
% rho = molmass/vmol; %density of the amorphous phase

%rho is actaully the PRECIPITATE DENSITY, i.e. number of precipitates per
%unit volume
%use the output of npart, which has the number of particles per um3, so
%need to multiply it by 1e18.
%for now, from the bajaj output the final number density is 2.18 SPPs/um3.
% rho = sum(n).*500;%.*0.0001;
% 
% Clusters = 1e23; %In future need to determine an estimate for the number of clusters as a function of fluence + temp, probably related to amorphization rate and solute conc in matrix.
% rho = sum(n) + Clusters;


% rho = sum(n)+sum(n_clust); %NEED TO ADD IN N_CLUST THROUGH FUNCTIONS

% d = d.*6e-6; %n.b. low temperature diffusion of Fe+Cr is not well studied...
%does d evolve with time as the number of dislocations changes?
% d = 1e-23;

% drdt = (-zeta.*k0.*vat)+((3.*d.*xb)./(4.*pi.*rb.*xc_avg))-((rb.^2).*d.*rho);

delta = exp((2.*sfen.*vmol)./(rb.*Rg.*tk));
xr = xa.*delta;

% beta = 30;
% drdt = (-zeta.*k0.*vat.*beta)+((((xb-(sum((4/3).*pi.*(rb.^3).*n.*xc_avg)))-xr)./(xc_avg-xr)).*(d./rb));

% drdtSingle = (-zeta.*k0.*vat.*beta);
% drdt = zeros(1,length(rb));
% drdt(1:length(rb)) = drdtSingle;

% drdt2 = (-zeta.*k0.*vat)+((3.*d.*xb)./(4.*pi.*rb.*xc))-((rb.^2).*d.*rho);
%Find equilibrium radius
% negind = find(drdt>0);
% EqRad = rb(max(negind));


%This is Frost & Russell
% rm = 5e-9; %Equilibrium preciptiate size of 5 nm
% L = 2000.*1e-9; %Interparticle spacing of 1 um
% theta = 1e-5; %Resolution rate per atom
% R = 10e-9;
% r = rb;
% drdt = (1-(r./rm)).*(1./(r.^2)).*(L./(L-r)).*(theta.*(R.^3)./(48));
% Frost and Russell ends

%radiation enhanced diffusion? i.e. D+D'
%     [drad] = diffrad(d,tk,phi);
%by decreasing D the growth and dissolution gets smaller... use this as the
%fitting parameter, with justification from the work of Burr et al... etc.
%d will likely change with flux and T due to point defect production and
%disolocation formation... it will be a complext combination of the two.
%increased flux increases both of them so D will increase which leads to
%enhanced dissolution - WHICH IS GOOD 
%Increased T will increase D (standard D) which is the opposite to seen
%effects, however this increase in T might alter Dirrad as increased T
%leads to more annealing of point defect/disolcations thus reducing Dirrad.
%It will be a fine balance between the effects.

%Next step is to try this on Zircaloy-2 Fe-Ni SPPs, where D is higher and
%has different compositions etc.


%Zhao modified NHM
% n(541) = 0;
rho = n;

A=0.02.*1e9;
% zeta = z0.*(1-((exp(-A.*rb))));
zeta = z0;
xc = xc_avg;

% drdt = (-zeta.*k0.*vat)+(((d.*xb)-(d.*xa))./(rb.*xc))-((4/3).*pi.*(rb.^2).*d.*rho);

% drdt = (-zeta.*k0.*vat)+((4.*d.*xbinst)./(rb.*xc)); %Zhao

beta = (1./(1+exp(0.065.*(tk-585))));
drdt = (-zeta.*k0.*vat.*beta)+((3.*d.*xbinst)./(4.*pi.*rb.*xc)); %NHM/Was
% Do drdt with xbinst-xr;


delta = exp((2.*sfen.*vmol)./(rb.*Rg.*tk));
xr = xa.*delta;
% drdt = (-zeta.*k0.*vat)+(((xbinst - xr)./(xc_avg - xr)) .* (d./rb));
% drdt = (((xbinst - xr)./(xc_avg - xr)) .* (d./rb));

negind = find(drdt>0);
EqRad = (rb(max(negind)));

% drdt = -9e-17;
end
%% This is for trial and error plotting
% 
% rho = 2e18.*500; %SPPs/m3
% vat = 1.494508925124273e-29;
% 
% xc = 0.51;
% xb = 0.0051;
% 
% rb = 0.1:0.1:500;
% rb = rb.*1e-9;
% 
% zeta = 1e18; %neeeded to convert dpa to atomic flux, quoted in NHM paper, n.b. 10^18 as we are working in meters
% 
% % Might need a function to convert fluence to dpa (estimation)
% k0 = 1.2e-7; %dpa/s
% 
% dout = [];
% drdtout = [];
% for tc = 260:30:350
%     tk = tc+273;
%         d = (6e-7 * exp(-15930/(tk)).*1e-4);
%         drdt = (-zeta.*k0.*vat)+((3.*d.*xb)./(4.*pi.*rb.*xc))-((rb.^2).*d.*rho);
%         %     drdt = ((-zeta.*k0)./(Natoms))+((3.*d.*xb)./(4.*pi.*rb.*xc))-((rb.^2).*d.*rho);
%         dout = [dout d];
%         drdtout = [drdtout; drdt];
% end
% 
% 
% 
% % 
% for j = 1:1:4
% %     semilogy(rb.*1e9,drdtout(j,:),'LineWidth',2)
%     plot(rb.*1e9,drdtout(j,:),'-','LineWidth',2);% yscale_symlog;
%     hold on
% end
% 
% 
% legend(['260 ' char(176) 'C'],['290 ' char(176) 'C'],['320 ' char(176) 'C'],['350 ' char(176) 'C'])
% % legend('1e5 - 275 C','1e10 - 275 C','1e15 - 275 C','1e20 - 275 C')
% % plot(rb.*1e9,drdtout(j,:),'LineWidth',2); yscale_symlog;
% yscale_symlog;
% set(gca,'Fontsize',18)
% xlabel('SPP radius / nm')
% ylabel('dr/dt / ms^{-1}')
% 
% %could try and plot dissolution rates using their absolute values and just
% %change the plot line to a dash 
% % ylim([-0.5 3e-13])
% 
% 
% 
% % %recreating the NHM paper data:
% % 
% % dout = [];
% % drdtout = [];
% % for tk = 523:20:623
% %     d = 6e-14;
% %     drdt = (-zeta.*k0.*vat)+((3.*d.*xb)./(4.*pi.*rb.*xc))-((rb.^2).*d.*rho);
% % %     drdt = ((-zeta.*k0)./(Natoms))+((3.*d.*xb)./(4.*pi.*rb.*xc))-((rb.^2).*d.*rho);
% %     dout = [dout d];
% %     drdtout = [drdtout; drdt];
% % end