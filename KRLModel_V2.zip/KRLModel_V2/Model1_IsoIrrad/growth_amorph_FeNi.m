function [gr_FeNi] = growth_amorph_FeNi(r_FeNi,rb_FeNi,rc_FeNi,sfen_FeNi,d_FeNi,xbinst_FeNi,xa,xc_FeNi,tk,vmol_FeNi,n_FeNi,radflag,xbinst,d,rb,rc_c,vf_FeNi,vmax_FeNi,xc_avgFeNi,n_clustFeNi,xc_clustFeNi,phi,t,tau_sl)
% function [gr] = growth(r,sfen,d,xbinst,xc,xa,tk)
% Calculates growth rate of spherical Al3Zr dispersoids
%10/1/23 - xa should be equal to xa_FeNi as called from other script
%(nucgrow_amorph)
%
% Inputs
% r         Particle radius (m) n.b. this script works with the bin edges
%           rather than the bin averages.
% sfen      Interfacial energy (J/m^2)
% d         Diffusion coefficient (m^2/s)
% xbinst    Average Zr concentration in matrix
% xc        Concentration of Zr in dispersoids
% xa        Concentration of Zr in matrix at interface
% tk        Temperature (K)
% Output
% gr        Growth rate (ms^-1)
% gr        Growth rate of the amorphous dummy SPPs
% r         Average particle radius (adjusted due to ram)
% r         Particle radius bin edges (adjusted due to ram)
%
vfmax_FeNi = vmax_FeNi;
gas = 8.31459;
k = 1.3806488e-23;
h = 6.626e-34;
delta = 3.2e-10; % width of interface (assume approx <a> Zr)
na = 6.022045e23;
vat_FeNi = vmol_FeNi./na;
%cn = find(r>0);
%cy = find(r<=0);
xc = 0.54;
%For Fe-Ni type particles no amorphization occurs, therefore there will
%only be growth and standard SPP dissolution

if radflag == 0 
    xr_FeNi = xa .* ((xbinst_FeNi./xa).^((rc_FeNi)./rb_FeNi));
    xr = xa .* ((xbinst./xa).^((rc_c)./rb));
    
    ind=find(xr_FeNi>xc_FeNi);
    gr_FeNi = ((xbinst_FeNi - xr_FeNi)./(xc_FeNi - xr_FeNi)) .* (d_FeNi./rb_FeNi);
    
    %gr = ((xbinst - xr)./(xc - xr)) .* (d./rb);
    
    
    rx_FeNi = isreal(xr_FeNi);
    rgr_FeNi = isreal(gr_FeNi);
    if rx_FeNi==0 | rgr_FeNi==0
        disp(['Imaginary parts in xr and/or gr (Fe-Ni)'])
    end
    
    freq_FeNi = (k .* tk)./h;
    gstar_FeNi = 15930 * k;
    
    vmax_FeNi =  abs(delta .* freq_FeNi .* exp(-gstar_FeNi/(k * tk)));
    growlim_FeNi = find(gr_FeNi > vmax_FeNi);
    dislim_FeNi = find(gr_FeNi < -vmax_FeNi); %May set the dissolution limit to be calculated by emperical determination
    gr_FeNi(growlim_FeNi) = vmax_FeNi;
    gr_FeNi(dislim_FeNi) = -vmax_FeNi;
    gr_FeNi(ind) = -vmax_FeNi;
    %To introduce radiation apply the above equations when radflag == 0 and
    %when radflag == 1 set growth to zero and dissolution to emperically
    %determined value
else
%     lenrb_FeNi = length(rb_FeNi);
%     gr_FeNi = zeros(1,lenrb_FeNi);
%     lengr_FeNi = length(gr_FeNi);
%     gr_FeNi(1:lengr_FeNi) = 0; % This here is the dissolution rate of Fe-Ni SPPs, model still to be determined (14.9.21)
    %gr_FeNi = 1e-16; %Just a test for now 28/7/21! %This will be the dissolution rate of the Fe-Ni type SPPs which is still to be determined and may depend on flux and temp, defintely depends on time/fluence.

%% NHM for FeNi system

%     if t > tau_sl %uncomment this if manual incubation time to dissolution is needed
%         %Function which uses rate determined emperically from Bajaj data
% %         [drdt] = AmorphDissRate(tk,phi);
%         
%         %Function which uses the NHM model --> come back to this
% %         n_FeNi(541) = 0;
% %         [drdt_FeNi,EqRad] = NHM_FeNi(rb_FeNi,d_FeNi,xc_avgFeNi,vat_FeNi,n_FeNi,phi,n_clustFeNi,xc_clustFeNi,xc_FeNi,xbinst_FeNi,vmol_FeNi,sfen_FeNi,tk,xa);
% %         
%         
%         x = xa.*(exp(((2 .* sfen_FeNi .* vmol_FeNi)./(gas .* tk)).*(1./rb_FeNi)));
% 
%         drdt_FeNi = ((xbinst_FeNi - x)./(xc_FeNi - x)) .* (d_FeNi./rb_FeNi);
% 
% 
%         gr_FeNi = drdt_FeNi;
%     else
%         
%         x = xa.*(exp(((2 .* sfen_FeNi .* vmol_FeNi)./(gas .* tk)).*(1./rb_FeNi)));

%         drdt_FeNi = ((xbinst_FeNi - x)./(xc_FeNi - x)) .* (d_FeNi./rb_FeNi);
% 
        drdt_FeNi = zeros(1,length(rb));
%         EqRad = 0;
        gr_FeNi = drdt_FeNi;
%     end




end

%Code to limit the growth of Fe-Cr SPPs when Zirc2flsag is active so that
%the system cannot exceed the maximum theoretical voluem fraction
% 
% if vf_FeNi.*1.1 > vfmax_FeNi
%             search=find(n_FeNi>0);
%         searchmin = min(search);
%     gr_positiveFeNi = find(gr_FeNi>0);
%     gr_FeNi(gr_positiveFeNi) = 0; %makes all positive growth rates equal to zero so that in this system SPPs can only dissolve, thus increasing vf in matrix and allowing other system to grow if needed
%     gr_FeNi(searchmin) = -vmax_FeNi;
% end





return