function [nr_FeNi] = nucrate_FeNi(rc_FeNi,sfen_FeNi,nsites,xbinst_FeNi,xb_FeNi,d_FeNi,t,tk,tau,vmol_FeNi,a)
% function [nr] = nucratesc(rcrit,sfen,nsites,d,t,tk)
% Calculates time dependent nucleation rate in Cu-Co
% (using expression from Hyland paper)
% 
k = 1.380662e-23;
na = 6.022045e23;
h = 6.626176e-34;
%
% aprod should be diffusion distance
% ie shortest lattice vector
%
aprod = a;
vat_FeNi = vmol_FeNi/na;
gstar_FeNi = 4/3 * pi * (rc_FeNi.^2) * sfen_FeNi;
%
% Modify nsites to account for loss of solute
%
%nsites = nsitein .* (xbinst./xb);
%nsites = nsitein;
if rc_FeNi>0.0
dg_FeNi = (-2 * sfen_FeNi)./rc_FeNi;
zeld_FeNi = (vat_FeNi .* dg_FeNi.^2)./(8 * pi * ((sfen_FeNi^3*k.*tk).^0.5));
%
% See stocalc.m for configuration for data sent to MJS
%
% Comment out next line for beta and tau line to get KW method
% uncomment tau in main program
% beta = (16 .* pi .* (sfen^2) .* xbinst .* d)./((dg.^2) .* (aprod^4));
% Below - beta for Aaronson from Stowell (p.6)
beta_FeNi = (4 * pi * rc_FeNi^2 * d_FeNi * xb_FeNi)/(aprod^4);
% Below - beta for KW (Servi-Turnbull method)
%betakw = (d*xbinst) /  ((0.7071*aprod)^2);
%beta = betakw;
%
% Russell beta factor (as used by Aaronson) 
% beta = betakw * 4* pi * ((rc/(0.7071*aprod))^2);
% tau from Stowell, theta from Stowell, p. 10
%theta = 1;
%tau = 1/(theta * beta * (zeld^2));
% tau from Aaronson
ktau = 8;
%tau = (ktau * k * tk * sfen * (aprod^4))/((vat^2) * (dg^2) * d * xb);
%ignore incubation time
tau=1e-100;
if t>=0
    nr_FeNi = nsites.*zeld_FeNi.*beta_FeNi.*exp(-gstar_FeNi./(k .* tk));
    % Change next bit!
    % nr = nsites.*zeld.*beta.*exp(-gstar./(k .* tk));
else
    nr_FeNi = 0;
end
else
    nr_FeNi = 0;
end
return
   