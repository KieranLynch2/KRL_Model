function CurModalDiameter = ModalDiameterDetermine(r,n)

[Max_n,Max_n_ind] = max(n);
Max_r = r(Max_n_ind);

CurModalDiameter = Max_r*2;

end