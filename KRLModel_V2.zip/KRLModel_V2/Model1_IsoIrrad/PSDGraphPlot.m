function PSDGraphPlot(PSDStage,Outputs,IterCount,NSteps,Alloy,radflag,r_init,n_init,r_cryst,n_cryst)


%Determine how many subplots to show
if length(PSDStage) <= 3; m = 1; n = 3; end
if length(PSDStage) > 3 && length(PSDStage) <= 6; m = 2; n = 3; end
if length(PSDStage) > 6 && length(PSDStage) <= 9; m = 3; n = 3; end

if ismember(IterCount,PSDStage) == 1
    if Alloy == 4 && radflag == 0
        SubplotNo = find(PSDStage==IterCount);
        subplot(m,n,SubplotNo); hold on;
        rad = Outputs(IterCount).Radius'.*1e9;
        nd =  Outputs(IterCount).NumDen'.*1e-18;
        rad_sog = Outputs(IterCount).Radius_ln'.*1e9;
        nd_sog = Outputs(IterCount).NumDen_ln'.*1e-18;
        plot(rad.*2,nd,'-','LineWidth',2,'Color',[0 0.4470 0.7410])
        plot(rad_sog.*2,nd_sog,'-','LineWidth',2,'Color',[0.8500 0.3250 0.0980])
        xlabel('SPP diameter / nm')
        ylabel('Number density / \mum^{-3}')
        title(['Zircaloy-' num2str(Alloy) ' Stage ' num2str(IterCount)])
        CurModalDiameter = ModalDiameterDetermine(rad,nd);
        xmax = CurModalDiameter*3;
        xlim([0 xmax])
        legend('KWN original output','SOG adjusted')
    elseif Alloy == 2 && radflag == 0
        SubplotNo = find(PSDStage==IterCount);
        subplot(m,n,SubplotNo); hold on;
        rad = Outputs(IterCount).Radius'.*1e9;
        nd =  Outputs(IterCount).NumDen'.*1e-18;
        rad_FeNi = Outputs(IterCount).RadiusFeNi'.*1e9;
        nd_FeNi = Outputs(IterCount).NumDenFeNi'.*1e-18;
        rad_sog = Outputs(IterCount).Radius_ln'.*1e9;
        nd_sog = Outputs(IterCount).NumDen_ln'.*1e-18;
        rad_sog_FeNi = Outputs(IterCount).Radius_lnFeNi'.*1e9;
        nd_sog_FeNi = Outputs(IterCount).NumDen_lnFeNi'.*1e-18;
        plot(rad.*2,nd,'--','LineWidth',2,'Color',[0 0.4470 0.7410])
        plot(rad_sog.*2,nd_sog,'-','LineWidth',2,'Color',[0 0.4470 0.7410])
        plot(rad_FeNi.*2,nd_FeNi,'--','LineWidth',2,'Color',[0.8500 0.3250 0.0980])
        plot(rad_sog_FeNi.*2,nd_sog_FeNi,'-','LineWidth',2,'Color',[0.8500 0.3250 0.0980])
        xlabel('SPP diameter / nm')
        ylabel('Number density / \mum^{-3}')
        title(['Zircaloy-' num2str(Alloy) ' Stage ' num2str(IterCount)])
        CurModalDiameter = ModalDiameterDetermine(rad_FeNi,nd_FeNi);
        xmax = CurModalDiameter*3;
        xlim([0 xmax])
        legend('KWN original output - FeCr','SOG adjusted - FeCr','KWN original output - FeNi','SOG adjusted - FeNi')
    elseif Alloy == 4 && radflag == 1
        SubplotNo = find(PSDStage==IterCount);
        subplot(m,n,SubplotNo); hold on;
        plot((r_init.*2).*(10^9),n_init.*(10^-18),'-','LineWidth',2)
        r_cryst(1) = 0;
        r_cryst_zero = find(r_cryst <= 0);
        n_cryst(r_cryst_zero) = 0;
        r_cryst_nonzero = find(r_cryst > 0);
        r_cryst_plot = r_cryst(r_cryst_nonzero);
        n_cryst_plot = n_cryst(r_cryst_nonzero);
        plot((r_cryst_plot.*2).*(10^9),n_cryst_plot.*(10^-18),'-','LineWidth',2)
        plot((Outputs(IterCount).Radius.*2).*(10^9),Outputs(IterCount).NumDen.*(10^-18),'-','LineWidth',2)
        legend('Initial SPP size distribution','Crystalline cores','Final SPP size distribution');
        xlabel('SPP diameter / nm')
        ylabel('Number density / \mum^{-3}')
        title(['Zircaloy-' num2str(Alloy) ' Stage ' num2str(IterCount)])
        CurModalDiameter = ModalDiameterDetermine(r_init,n_init);
        xmax = CurModalDiameter*3.*1e9;
        xlim([0 xmax])
    end
drawnow()
pause(3)
end

end