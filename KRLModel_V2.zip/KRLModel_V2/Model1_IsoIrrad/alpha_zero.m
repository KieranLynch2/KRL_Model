function [alpha0] = alpha_zero(tk,phi)
% %     
%      phi = 1.3e14; %flux in cm2 
%      tk = 400+273;
    
    
    kx = 27;
    kphi = 9.6e-22;
    estarR = 11600;
    alpha0 = exp((log(phi))-(log(kx/kphi))+(estarR*(1/tk)))/(exp((log(phi))-(log(kx/kphi))+(estarR*(1/tk)))+1);
end