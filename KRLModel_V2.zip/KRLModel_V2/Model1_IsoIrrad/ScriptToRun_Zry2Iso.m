%% Script for runnning Zircaloy-2 iosthermal annealing

% Are you starting from scratch or using a pre-defined input?
InputFlag = 1; % 0 is from scratch, 1 is for a pre-defined distribution
FileName = 'Shah_Zirc2Init.mat'; % Put the MATLAB output script here, e.g. 'Output.mat'

if InputFlag == 0
    clear all
    InputFlag = 0;
    FileName = [];
elseif InputFlag == 1 
    load(FileName)
end


% User inputs

tc = 700; % Temperature in Celcius
t = 0.002; % Time in hours
OFN = 'OutputTest.mat'; % Choose an output filename 



%% Do not touch
zirc2flag = 1;
radflag = 0;
phi = 0;

CallScript(tc,t,OFN,InputFlag,zirc2flag,radflag,phi,FileName)


