function[r,n,tout,tkout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout]= ... 
    zr_amorph_kin_multistep(r,n,rb,tk,tfinal,tout,tkout,vfout,rbarout,npartout,d,xa,xb,xc,sfen,nsites,vmol,a,a_init,radflag)
% ====================================================================
%
% Calculates precipitation kinetics in Zirconium alloys
% **RUN zirconium_init.m FIRST
% THIS VERSION IS FOR 2nd, 3rd STEP OF TREATMENT
% RUN zr_amorph_kin.m FOR FIRST STEP BEFORE THIS VERSION
%
% using 2nd order Runge Kutta formula for error checking and
% adaptive timestep control
%
% Reference (to source model, originally for Al3Zr)
% J. D. Robson and P. B. Prangnell, Acta Materialia, 49, 2001, p. 599-613
%
% Inputs
% r         Size bins (mean sizes) (m)
% rb        Size bins (edge sizes) (m)
% tk        Temperature  (K)
% tfinal    Time to calculate for (s)
% d         Diffusion coefficient of solute  (m^2/s)
% xa        Solute concentration in matrix in equilibrium with precipitate
% xb		Average solute concentration in matrix
% xc		Solute concentration in precipitate
% vmax      Maximum volume fraction of precipitate
% nsites    Number of nucleation sites for precipitate (m^-3)
% sfen      Interfacial energy of precipitate for growth/nucleation (Jm^-2)
% a_init	Initial Zr lattice parameter before precipitation
% a			Final Zr lattice parameter at the end of precipitation
% radflag   Irradiation active (=1)
%
% Outputs
% r         Mean size of size bins (m)
% n         Particle number density in each size bin (particles/m^3)
% tout      Time at each time-step (s)
% vfout     Volume fraction at each time-step
% rbarout   Mean particle radius at each time-step (micron)
% npartout  Particle number density at each time-step (particles/micron^3)
% nrout     Nucleation rate at each time-step (particles/m^3)
% rcout     Critical radius at each time-step (m)
% aout		Lattice parameter of zirconium at each time-step
% fsout		Estimated strength at each time-step
% M			Movie (not used)
%
% ====================================================================
%
na = 6.022045e23;
k = 1.380662e-23;
tau = 0;
%tout = [];
grout = [];
%vfout = [];
%rbarout = [];
%npartout = [];
ndump = [];
npartcritout = [];
aout = [];
fsout = [];
npartcrit_old=[0 0 0 0 0 0];
nrcritout = [];
rcout_c = [];
rcout_a = [];
amorphout = [];
rgmax = [];
nrout = [];
M = [];
xbout=[];
%
% Empirical parameters PGP and CAP
% Garzarolli et al. 
%
% CAP
% QR_cap = 40e3; % This is standard value from Garzarolli
QR_cap = 17e3; % Value from model that causes rbar values to collapse
cap = 0;
capout = [];
% PGP
k_pgp = 1e14./3600; % PGP rate factor
TA_pgp = 3.2e4;
pgp = 0;
pgpout = [];
%
%
%nr = 0;
len = length(r);
gr(1:len)=0;
%grout(1:len)=0; 
dr2(1:len)=0;
rbar = (sum(r.*n))/sum(n);
vf = 4/3 * pi * sum((r.^3) .* n);
solsuc = 0;
solfail = 0;
nucflag = 0;
%
% Runge-Kutta initialization - from matlab ode23old
%
t = 0;
rbar = 0;
pow = 1/3;
tol = 10; %tol = 0.1; %1e-3
% h is the value of the timestep increment
% hmax and hmin set limits on the range of timesteps
% the timestep is adjusted automatically using a 2nd order
% Runge-Kutta scheme
%
hmin = 1e-10;
hmax = 3e4;
mnum = 1e25;
%
% cw is KW fudge factor for tau calculation   
%
cw = 1.4;
%
hmaxinit=1e-10;
h_old = 10;
h = hmaxinit;
rc_old_c = 0;
rc_old_a = 0;
rc_c = 0;
rc_a = 0;
flag_me = 0;
coarseflag = 0;
firstit=0;
if (xb < xa)
    disp(['Alloy composition below solvus - no precipitation. *end*'])
    return
end
while (t<tfinal)
    %
    % stopper
    %if t>1.725e6
    %    disp(['stop'])
    %end
    if t + h> tfinal, h = tfinal - t; flag_me =1; end
    %
    if radflag == 1
       %
       %
       %
       ram = amorph_depth(t);
    else
       ram = 0;
    end
    %
    rc_c = critrad_cryst(sfen,xa,xb,xc,vf,tk,vmol);
    rc_a = critrad_amorph(sfen,xa,xb,xc,vf,tk,vmol);
    %
    % Multiplication factor
    %
    newsize = 1.1 * rc_c;
    search=0;
    search=find(rb<newsize);
    bin=max(search);
    if bin>length(r-1)
        if nucflag == 0
            disp 'New particles exceed size range !'
        end
        if nucflag == 1
            % Nucleation is complete - no new particles, set a dummy bin
            bin = 10;
        end
    end
    %if bin==[], disp 'New particles smaller than size range !';end
    %
    % Check that top bin is not occupied
    %
    if n(end)>0, disp 'Bin overflow error - increase maximum size range'; end
%
% find bin in which critical radius lies. The bin in which new
% particles nucleate must be at least 1 greater than this
%
    search=0;
    search=find(rb<rc_c);
    rcbin=max(search);
    bindiff=bin-rcbin;
    if bindiff<1 & nucflag == 0
        disp(['WARNING! newsize and rc lie in same bin. Remesh narrower bins'])
    end
%
% Compute the slopes
% 
% slopes at start of interval
%
    [nr1,gr1] = nucgrow_amorph(vf,ram,rb,d,t,nsites,sfen,tk,xa,xb,xc,tau,vmol,a);
    if nucflag == 1, nr1 = 0; end
   % nr1 = 0;
%
% slopes at middle of interval
%
% to calculate the slope need to know the volume fraction
% at the middle of the interval. Need to temporarily update size
% distribution and hence find volume fraction
%
    newpart3 = (1-vf) * nr1 * (h/2);
    ntemp3 = n;
    ntemp3(bin)=ntemp3(bin)+newpart3;
    dr3 = gr1 * (h/2);
%
% Temporarily update size distribution
%
    [np yp] = update_func_mod(r,rb,ntemp3,dr3);
    ntemp3 = np';    
    vf3 = sum(((4/3) * pi * (r.^3)) .* ntemp3);
%
% Find slopes (nr & gr) at middle of interval
%
    [nr3 gr3] = nucgrow_amorph(vf3,ram,rb,d,t,nsites,sfen,tk,xa,xb,xc,tau,vmol,a);
    if nucflag == 1, nr3 = 0; end

   % nr3 = 0;
%
% slopes at end of interval
% use nr & gr at middle of interval to calculate change in (r,n)
%
    newpart2 = (1-vf) * nr3 * (h);
    ntemp2 = n;
    ntemp2(bin)=ntemp2(bin)+newpart2;
    dr2 = gr3 * h;
%
% Temporarily update size distribution
%
    [np yp] = update_func_mod(r,rb,ntemp2,dr2);
    ntemp2 = np';    
    vf2 = sum(((4/3) * pi * (r.^3)) .* ntemp2);
%
% Find slopes (nr & gr) at end of interval
%
    [nr2 gr2] = nucgrow_amorph(vf2,ram,rb,d,t,nsites,sfen,tk,xa,xb,xc,tau,vmol,a);  
    if nucflag == 1, nr2 = 0; end

   % nr2 = 0;
%
% Estimate the error
%
% In number density
%
    deltanum = norm(h*(nr1 - 2*nr3 + nr2)/3,'inf');
%
% In radius
%   
    deltarad = norm(h*(gr1 - 2*gr3 + gr2)/3,'inf');
%
% Allowable errors
%
    %taunum = tol * 1e18;
    taunum = tol * 1e18;
    taurad = tol * 1e-9;
%
% Limit maximum number of particles formed in each interval to mnum
%
    newpart1 = nr1 * h;
    if newpart1>mnum 
        numrange = 1;
        % make step size half the limiting maximum
        hnuc = mnum/(2 * nr1);
    else
        numrange = 0;
        hnuc = hmax;
    end
%
% Check xbinst has not fallen too far
%
 %        xbinst_temp = xb - ((xc - xa) * vf2);
         %disp(['xa ' num2str(xa) ' xbinst_temp ' num2str(xbinst_temp)])
 %        if xbinst_temp < xa
 %            xbcheck = 1;
 %        else
             xbcheck = 0;
 %        end
%    
% Update the solution if the error is acceptable
%    
    if (deltanum <= taunum) &  (numrange==0) & (xbcheck == 0)
         firstit = firstit + 1;
         t = t + h;
         disp(['Updating solution ' num2str(h) ' time/h: ' num2str(t/3600) ' nucrate ' num2str(nr3) ' rc ' num2str(rc_c)])
         %
         % Calculate more accurate increment in size/number
         %
         newpart = (1-vf)*h*(nr1 + 4*nr3 + nr2)/6;
         n(bin)=n(bin) + newpart;
         dr = h*(gr1 + 4*gr3 + gr2)/6;
         %disp(['Bin 1-5 n ' num2str(n(1:5))])
         %disp(['dr bins 1-5 ' num2str(dr(1:5))])
         [np yp]=update_func_mod(r,rb,n,dr);
         n = np';
         npart = sum(n);
         vf = 4/3 * pi * sum((r.^3) .* n);
         if npart > 0
            rbar = (vf./((4/3) * pi * sum(n)))^(1./3);
         else
            rbar = 0;
         end
         %
         % Output number of particles per um^3 and mean radius in nm
         %
         npart = npart/1e18;
         %
         rbar_nm = rbar*1e9;
         %
         % Check if nucleation is complete
         %
         if nr3 < 1e-100
             nucflag = 1;
         end
         % Update CAP and PGP
         %
         cap = cap + (h .* exp(-QR_cap .* (1./tk)));
         pgp = pgp + (k_pgp .* h .* exp(-TA_pgp./tk));
         %
         % Build up output vectors
         %
         tout = [tout tout(end)+h];
         tkout = [tkout tk];
         vfout = [vfout vf];
         rbarout = [rbarout rbar_nm];
         npartout = [npartout npart];
         nrout = [nrout nr3*1e-6];
         rcout_c = [rcout_c rc_c*1e9];
         rcout_a = [rcout_a rc_a*1e9];
         amorphout = [amorphout ram*1e9];
         xbinst = xb - ((xc - xa) * vf);
         xbout = [xbout xbinst];
         ndump = [ndump; gr3];
         capout = [capout cap];
         pgpout = [pgpout pgp];
         %
         % Calculation of a lattice parameter based on Vegard's law
         %
         %ainst = a + ((xbinst./xb) .* (a_init - a));
         ainst = a + (((xbinst-xa)./(xb-xa)) .* (a_init - a));
         aout = [aout ainst * 1e10];
         solsuc = solsuc + 1;
         grt = dr(bin)/h;
         grout = [grout grt];
     else
         solfail = solfail + 1;
     end 
     if deltarad ~= 0.0
         h1 = min(hmax, 0.9 * h * (taurad/deltarad)^pow);
     else
         h1 = hmax;
     end
     if deltanum ~= 0.0
         h2 = min(hmax, 0.9 * h * (taunum/deltanum)^pow);
     else
         h2 = hmax;
     end 
     if xbcheck == 1
         h3 = h./1.1;
     else
         h3 = hmax;
     end
     %
     % Step size for next step is smaller of step sizes
     % calculated for growth and nucleation
     % and limited by not exceeding mnum particles in each step
     % But if in first few iterations, make sure h doesn't get too big
     % h is not allowed to increase by more than 10% between steps
     %
     if firstit>100
      hprov = min([h1 h2 h3 hnuc]);
      %disp(num2str([h1 h2 h3]))
      %if hprov == h1, disp(['limited by deltarad']); end;
      %if hprov == h2, disp(['limited by deltanum']); end;
      %if hprov == h3, disp(['limited by xbinst change']); end;
      h = max([hmin hprov]);
     else
      hprov = min([h1 h2 h3 hnuc]);
      h = min([hprov hmaxinit]);
     end
     if (h>1.1*h_old), h=1.1*h_old; end
     %
     % Check if xbinst--> xa reduce stepsize
     %
     %if xa > 0.99.*xbinst
     %    h = hmin;
     %    firstit = 0;
     %end
     h_old = h;
end
 disp([num2str(solfail+solsuc) ' Iterations: ' num2str(solsuc) ' Successful ' num2str(solfail) ' Unsuccessful'])
