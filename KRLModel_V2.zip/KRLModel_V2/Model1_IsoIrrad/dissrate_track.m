function [dsr1,dsr2,dsr3] = dissrate_track(r,n,dr,h)

maximum = max(n);
mode_n = find(n==maximum);
mode_r1 = (r(mode_n))/2;
mode_r2 = r(mode_n);
mode_r3 = (r(mode_n))*2;

a=r;%dummy data
y1=r(181); %100 nm
y2=r(199); % 200 nm
y3=r(217); % 300 nm

[val1,idx1]=min(abs(a-y1));
[val2,idx2]=min(abs(a-y2));
[val3,idx3]=min(abs(a-y3));
 %idx here gives index of r array which closest matches modal bin

dsr1 = dr(idx1);%./h;
dsr2 = dr(idx2);%./h;
dsr3 = dr(idx3);%./h;

end