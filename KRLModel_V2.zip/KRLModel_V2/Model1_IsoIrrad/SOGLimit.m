function n_out = SOGLimit(n_in,r_in);

% Based off of Gros paper the largest diameter is 3.6 Dmode, and 2.6Dmode is
% 95.5% of SPPs
% Therefore delete all those number denisities above that value
maximum = max(n_in);
mode_n = find(n_in==maximum);
d = 2.*r_in;
Dmax = (d(mode_n)).*3.6;
a=d;%dummy data
y=Dmax;
[val,idx]=min(abs(a-y));
minVal=a(idx); %idx here gives index of D array which closest matches Dmax

% delete all entries in n larger than Dmax
n_in(idx:end) = 0;
n_out = n_in;
end