function drdt = NHMDiss(rb,phi,tk)

K = phi./(5e20);

vat = 2.44e-29;

beta = 1.883e+05*exp(-0.02314.*tk); %roughly valied between 250-350 C

z0 = 5.5e20;
A = 0.02.*1e9;

zeta = z0.*(1-(1.*(exp(-A.*rb)))); 

drdt = -zeta.*K.*vat.*beta;

end


%% Determination of beta trend
% % 
% x = ([250,270,310,320,332,350]+273)';
% y = [0.95 0.85 0.3 0.1 0.08 0.04]';
% 
% f = fit(x,y,'exp1');
% 
% % y1 = polyval(f,x);
% 
% % scatter(x,y)
% % hold on
% 
% plot(f,x,y)