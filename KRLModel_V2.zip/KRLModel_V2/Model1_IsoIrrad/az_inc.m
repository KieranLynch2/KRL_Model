function tau = az_inc(tk,phi)

%This is amorphous zone dissolution tau!!!

kphi = 9.76e6.*(tk^-15.26);

tau = 1/(kphi * phi^2);

tau = 0; 

taudays = tau./86400;
end