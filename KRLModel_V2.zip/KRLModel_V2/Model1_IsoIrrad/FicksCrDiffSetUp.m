function [CrDiffProf,CrDiffProf_X,xb_initCr] = FicksCrDiffSetUp(xb_initCr)

Width = 1e-9;
CellSize = 5e-6; %larger than typical grain size


%xb_initCr = xb_init/2;

CrDiffProf_X = 0:Width:CellSize;
CrDiffProf = zeros(1,length(CrDiffProf_X))+(xb_initCr); %Assume half the solute in the matrix at the begining is Cr 

end