function [r_a_shell,amorph_diss_out,n_cryst,r_cryst,r_total] = amorph_diss(r_a_shell,phi,tfinal,h,ram,amorph_diss_out,r,n,n_cryst,r_cryst,r_total)

r_a_shell_init = r_a_shell;
n_init = n;
n_cryst_init = n_cryst;

flu_x = phi*tfinal; 
ram_y = 4.125e-30*flu_x; %ram_y is the total dissolution of amorphous zone based on tfinal
%flu_x is the flux in n/cm2, as in Taylor model

%Need to iteratively calculate dissolution of amorphous zone at each time step
%Sanity check:
    %Can't let amorphous zone exceed original SPP size
    %Once amorphous zone reaches original SPP size it has to stop growing
    %(check cryst_to_amorph script)
    %When amorphous dissolution is complete make sure it doesn't go
    %negative (also make sure amorphous dissolution isn't faster than
    %amorphization)
    %26.7.21 - At the moment, as the crystalline spp is amorphized and size
    %is reduced and it hits zero, then the amorphous rim also becomes zero.
    %Whereas, there could be a scenario where the core is gone but some
    %amorphous material remains - How to correct this? This is because the
    %crystalline cores and amorphous shells share the same number
    %densities!

frac = h/tfinal;
amorph_diss = frac*ram_y; %amorph dissolution at each iteration

if amorph_diss > ram
    amorph_diss = ram;
end

amorph_diss_out = [amorph_diss_out amorph_diss];



%amorph_diss = 0; %Use this line if you want to turn amorphization
%dissolution off

%r_a_shell = r_a_shell - amorph_diss; %Remove amorphous material according to what has dissolved

%Need to make sure the amorphous material doesn't go faster than
%crystalline to amorphous transformation
%How does the behaviour vary with temperature?

%This script is to keep track of the solute - keep Fe and Cr from here
%seperate from the original Fe.

%NEED TO MAKE SURE THAT WHEN BINS IN R ARRAY EQUAL 0 THE AMORPHOUS SHELL
%STOPS GROWING - this is done in cryst_to_amorph script

r_cryst_zero = find(r_cryst <= 0);
%r_cryst(r_cryst_zero) = 0;

r_a_shell_zero = find(r_a_shell <= 0); %
%r_a_shell(r_a_shell_zero) = 0; %Make any shells which drop below zero (i.e. negative) equal to zero 


%update n_cryst to be equal to n temporarily, before the bins which are
%less than zero are equated to zero
%n(r_a_shell_zero) = 0; %NEED TO CORECT THIS - R_A_SHELL ISN'T TOTAL!!!!!!!!!


n_cryst = n;
%n_cryst(r_cryst_zero) = 0; %change number density of cores which have fully dissolved to zero
%I need to change this number density to zero for crystalline cores, but
%not for total number density which includes amorphous rims

%Calculate vf of r_a_shell_init and r_a_shell to determine the dissolved
%volume fraction, to be used in matrix solute determinations.
%Need to add r (crystal cores) to shell rams to get total SPP size and
%accurate vf changes (larger spps lose more material due to vf maths)!





r_total_init = r_total;
%r_total = r + r_a_shell; %Need to re-do this if changes work

vf_r_total_init = ((4/3).*pi.*((r_total_init.^3).*n_cryst_init));
vf_r_total = ((4/3).*pi.*((r_total.^3).*n));

vf_r_a_shell_change = vf_r_total_init - vf_r_total; %change in vf of amorphous material due to dissolution

%vf_a_diss = sum(vf_r_a_shell_change);

%calculate vf of amorphous dissolution each iteration
%initial vf amorph - vf amorph after dissolution amount applied
%amorph_diss = initial_r_a_shell_vf - r_a_shell_vf;+
end