function [mu,ram_diss,ram_total] = amorph_diss_mu(tfinal,phi,tk)
%User inputs
kx = 27;
kphi = 9.6e-22;
estarR = 11600;
Dtay = 2.43e-20; %nm*cm2/n - Flux assisted diffusion coefficient
beta = 2.37e-3;
%First determine total ram based on input parameters
hcum = 0;
ramout = [];
tout = [];
ram = 0;
while hcum < tfinal 
    
    h = 30000; %assume the timesteps are 30000 which is the most common in KWN model


    alpha0 = exp((log(phi))-(log(kx/kphi))+(estarR*(1/tk)))/(exp((log(phi))-(log(kx/kphi))+(estarR*(1/tk)))+1);

    ram = (h*(((Dtay*phi)*(alpha0-(beta*ram)))));

    hcum = hcum + h;

    ramout = [ramout ram];
    tout = [tout h];
end
ram_cum = cumsum(ramout);
ram_end = ram_cum(end);

ramfinal = (alpha0./beta).*(1.-exp(-beta.*Dtay.*phi.*tfinal));
%Determine the amorphous dissolution based on Griffiths
%Adjustments here on 19/4/22 - This amorphization dissolution relationship
%is based on a very primative relationship derived from the singluar data
%point from Griffiths work.
%Now need to find a way to determine how much material is lost due to SPP
%dissolution (of the amorphous zone).


flu_x = phi*tfinal; 
ram_y = 4.125e-30*flu_x; %ram_y comes out in meters
ram_y_nm = ram_y*1e9;
ram_diss = ram_y; %ram_diss is amount of amorphous material dissolved in meters
%Determine constant mu to be included in Taylor model when running KWN
ram_mu = ram_end + ram_y_nm;%the original ram value plus the radius of amorphous material dissolved

ram_total = ram_mu;

syms mu_sym

eqn = ram_mu == (tfinal*(mu_sym*((Dtay*phi)*(alpha0-(beta*ram)))));
S = solve(eqn);
mu = 0;
mu(1) = S;
end