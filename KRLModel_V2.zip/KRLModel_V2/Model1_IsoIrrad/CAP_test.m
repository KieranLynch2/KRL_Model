tk = 575 + 273;
QR_cap = 17e3;
t = 25 * 3600;


cap = (t .* exp(-QR_cap .* (1./tk)));