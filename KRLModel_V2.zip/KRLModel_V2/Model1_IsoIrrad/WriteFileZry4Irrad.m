function  WriteFileZry4Irrad(Outputs,r,n,r_cryst,n_cryst,DoseToAmorphFirst,IncToDissFirst,Alloy,Time_in,Temperature_in,Flux_in,FeConc_in,CrConc_in,NiConc_in,FeCrRatio_in,FeNiRatio_in,IterCount,Motta_in,Taylor_in,OFN)


Nsteps = IterCount-1;
NStages = length(Time_in);
%% Write input parameters into a csv file
Stage = (1:1:NStages)';
Time_Days = (Time_in/24)';
Temp_C = (Temperature_in)';
Flux_n_cm2_s = (Flux_in)';
AlloyTab = zeros(1,length(Time_in))+Alloy';
Zircaloy = AlloyTab';
FeConc_atfrac = (zeros(1,length(Time_in))+FeConc_in)'; 
CrConc_atfrac = (zeros(1,length(Time_in))+CrConc_in)'; 
NiConc_atfrac = (zeros(1,length(Time_in))+NiConc_in)'; 
FeCrRatio = (zeros(1,length(Time_in))+FeCrRatio_in)';

if Taylor_in == 1
    Taylor = zeros(1,Nsteps)'+1;
    T = table(Stage,Zircaloy,Taylor,Time_Days,Temp_C,Flux_n_cm2_s,FeConc_atfrac,CrConc_atfrac,NiConc_atfrac,FeCrRatio);
elseif Motta_in == 1
    Motta = zeros(1,Nsteps)'+1;
    T = table(Stage,Zircaloy,Motta,Time_Days,Temp_C,Flux_n_cm2_s,FeConc_atfrac,CrConc_atfrac,NiConc_atfrac,FeCrRatio);
end

FileNameSimCon = (['../Outputs/' OFN '_SimulatedConditions.csv']);
writetable(T,FileNameSimCon);

%% Write plotting stuff to an excel file with seperation by sheets per stage

FileNameExcel = (['../Outputs/' OFN '_AllOutputs.xlsx']);

AmorphizationIncubation_days = DoseToAmorphFirst./86400;
DissolutionIncubation_days = IncToDissFirst./86400;
for j = 1:Nsteps
    if length(Outputs(j).Radius) < length(Outputs(j).Time)
        Time_secs = Outputs(j).Time';
        MeanRad = Outputs(j).MeanRad';
        NumDen = Outputs(j).Npart';
        FeReleaseOnAmorph_atfrac = Outputs(j).FeAmorph';
        FeReleaseTotal_atfrac = Outputs(j).FeTotal';
        CrReleaseTotal_atfrac = Outputs(j).Cr';
        RadiusOfAmorphization_nm = cumsum(Outputs(j).Ram'.*1e9);

        DumNaN = zeros(1,length(Time_secs)-length(r));
        DumNaN(DumNaN == 0) = NaN;

        RadInit_og = Outputs(j).Radius_Init'.*1e9;
        Radius_Init_nm = [RadInit_og;DumNaN'];

        NumDenInit_og = Outputs(j).NumDen_Init'.*1e-18;
        NumberDensity_Init_perum3 = [NumDenInit_og;DumNaN'];

        Radius_og = Outputs(j).Radius'.*1e9;
        Radius_nm = [Radius_og;DumNaN'];

        NumDen_og = Outputs(j).NumDen'.*1e-18;
        NumberDensity_perum3 = [NumDen_og;DumNaN'];

        TabExcelOutputs = table(Time_secs,MeanRad,NumDen,FeReleaseOnAmorph_atfrac,FeReleaseTotal_atfrac,CrReleaseTotal_atfrac,RadiusOfAmorphization_nm,Radius_Init_nm,NumberDensity_Init_perum3,Radius_nm,NumberDensity_perum3);
        writetable(TabExcelOutputs,FileNameExcel,'Sheet',j);

    else
        DumNaN = zeros(1,length(Outputs(1).Radius)-length(Outputs(j).Time));
        DumNaN(DumNaN == 0) = NaN;

        Radius_Init_nm = Outputs(j).Radius_Init'.*1e9;
        NumberDensity_Init_perum3 = Outputs(j).NumDen_Init'.*1e-18;
        Radius_nm = Outputs(j).Radius'.*1e9;
        NumberDensity_perum3 = Outputs(j).NumDen'.*1e-18;

        Time_secs_og = Outputs(j).Time';
        Time_secs = [Time_secs_og;DumNaN'];

        MeanRad_og = Outputs(j).MeanRad';
        MeanRad = [MeanRad_og;DumNaN'];

        NumDen_og = Outputs(j).Npart';
        NumDen = [NumDen_og;DumNaN'];

        FeReleaseOnAmorph_atfrac_og = Outputs(j).FeAmorph';
        FeReleaseOnAmorph_atfrac = [FeReleaseOnAmorph_atfrac_og;DumNaN'];

        FeReleaseTotal_atfrac_og = Outputs(j).FeTotal';
        FeReleaseTotal_atfrac =[FeReleaseTotal_atfrac_og;DumNaN'];

        CrReleaseTotal_atfrac_og = Outputs(j).Cr';
        CrReleaseTotal_atfrac = [CrReleaseTotal_atfrac_og;DumNaN'];

        RadiusOfAmorphization_nm_og = cumsum(Outputs(j).Ram'.*1e9);
        RadiusOfAmorphization_nm = [RadiusOfAmorphization_nm_og;DumNaN'];

        TabExcelOutputs = table(Time_secs,MeanRad,NumDen,FeReleaseOnAmorph_atfrac,FeReleaseTotal_atfrac,CrReleaseTotal_atfrac,RadiusOfAmorphization_nm,Radius_Init_nm,NumberDensity_Init_perum3,Radius_nm,NumberDensity_perum3);
        writetable(TabExcelOutputs,FileNameExcel,'Sheet',j);

    end
end

%% Write incubaion times to text file

FileNameIncTxt = (['../Outputs/' OFN '_IncPeriods.txt']);

IncOutputLine = (['Incubation time to Zr(Fe,Cr)2 amorphization was: ' num2str(AmorphizationIncubation_days) ' days. The incubation time to Zr(FeCr)2 dissolution was: ' num2str(DissolutionIncubation_days) 'days']);
% writelines(IncOutputLine,FileNameExcel,'Sheet',length(IterCount)+1); 
writelines(IncOutputLine,FileNameIncTxt); 



%% Dump the entire output history into one big csv file (only for variables that change with time)
% solute concentration is dumped as one entire list over all stages, r and
% n arrays only printed at begining and end.
FileNameCSVTime = (['../Outputs/' OFN '_TimeOutputs.csv']);

TimeTotStr = [];
FeAmorphStr = [];
FeTotStr= [];
CrTotStr = [];
RamStr= [];

% for k = 1:Nsteps
%     TimeTotStr = [TimeTotStr Outputs(k).Time'];
%     FeAmorphStr = [FeAmorphStr Outputs(k).FeAmorph'];
%     FeTotStr= [FeTotStr Outputs(k).FeTotal'];
%     CrTotStr = [CrTotStr Outputs(k).Cr'];
%     RamStr= [RamStr cumsum(Outputs(j).Ram'.*1e9)];
% end

for k = 1:Nsteps
    TimeTotStr = [TimeTotStr; Outputs(k).Time'];
    FeAmorphStr = [FeAmorphStr; Outputs(k).FeAmorph'];
    FeTotStr= [FeTotStr; Outputs(k).FeTotal'];
    CrTotStr = [CrTotStr; Outputs(k).Cr'];
    RamStr= [RamStr; cumsum(Outputs(k).Ram'.*1e9)];
end

TotTimeCSV = [TimeTotStr,FeAmorphStr,FeTotStr,CrTotStr,RamStr];

writematrix(TotTimeCSV,FileNameCSVTime,'Delimiter',',');
%% Dump initial PSD and final PSD to csv file, Most recent Radius and numden should be saved from foor loop above for xlsx write-out.
FileNameCSVPSD = (['../Outputs/' OFN '_PSDOutputs.csv']);
PSDCSV = [Radius_Init_nm,NumberDensity_Init_perum3,Radius_nm,NumberDensity_perum3];

writematrix(PSDCSV,FileNameCSVPSD,'Delimiter',',');


end
