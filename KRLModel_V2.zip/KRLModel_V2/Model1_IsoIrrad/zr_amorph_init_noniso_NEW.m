function[r,rb,n,r_a,rb_a,n_a,xb,xc,xc_a,sfen,nsites,vmol,a,a_init,r_FeNi,rb_FeNi,n_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,zirc2flag]=zr_amorph_init_noniso_NEW(tcprof,zirc2flag,r,n,rb,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi)
%
%
% Initializes parameters for zirconium precipitation model
%   
% Model for Zircaloy-2 precipitation kinetics
%
% Inputs:
% xbw       Concentration of solute (wt%) initial
% tc        Temperature (degC)
% t			Time to predict for (hrs)
% Zirc2Flag Make this == 1 when running for Zircaloy-2, when running for
%           Zircaloy-4 == 0
% Outputs:
% r         Size bins for Fe-Cr SPPs (mean sizes) (m)
% rb        Size bins for Fe-Cr SPPs (edge sizes) (m)
% n         Number desnity in each size class fore Fe-Cr SPPs (m^-3)
% r_a       Amorphous material size bins (mean sizes) (m) (for Fe-Cr type)
% rb_a      Amorphous material size bins (edge sizes) (m) (for Fe-Cr type)
% n_a       Amorphous number desnity in each size class (m^-3) (for Fe-Cr type)
% r_FeNi    Size bins for Fe-Ni SPPs (mean sizes) (m)
% rb_FeNi   Size bins for Fe-Ni SPPs (edge sizes) (m)
% n_FeNi    Number density in each size class for Fe-Ni SPPs (m^-3) 
% tk        Temperature  (K)
% tfinal    Time to calculate for (s)
% xb        Effective composition of Fe-Cr in Zircaloy-2 alloy (atoms/m^3)
% xb_FeNi   Effective composition of Fe-Ni in Zircaloy-2 alloy (atoms/m^3)
% nsites    Number of nucleation sites  (m^-3)
% sfen      Interfacial energy of precipitate (Jm^-2)
% vmol		Molar volume of precipitate (m^-3/mol)
% vmax		Maximum volume fraction of precipitate
% a			Lattice parameter at end of precipitation (m)
% a_init	Lattice parameter at start of precipitation (m)
%
tkprof(:,1)=tcprof(:,1) + 273;
tkprof(:,2)=tcprof(:,2) + 273;
tkprof(:,3)=tcprof(:,3).*3600;

if zirc2flag == 0 %i.e. Zircaloy-4
    
    vmol = 9e-6;
    a_init = 0.32388e-9;
    a = 0.32425e-9; 
    xb = 0.0018 + 0.0033;
    xb_FeNi = 0;
    xc_FeNi = 0;
    xc = 0.65;
    xc_a = 0.35;
    sfen = 0.22;
    nad = 1e-9; % This gives good fit to Massih et al. sizes (sfen = 0.25)
    % Every lattice site in Zr potential nuc. site (Nsites = 4.30e28)
    nsites = 4.30e28*nad;
%     vmax = (xb - xa)/(xc - xa);
%     disp(['Vmax Fe-Cr type ' num2str(vmax)])
    r_FeNi = 0;
    rb_FeNi = 0;
    n_FeNi = 0;
    d_FeNi = 0;
    xb_FeNi = 0;
    xc_FeNi = 0;
    sfen_FeNi = 0;
    vmol_FeNi = 0;
    vmax_FeNi = 0;
    % Set up size bins
% 
% scale goes from 1A to um %first bin will be 1A, the last will be 0.1m??
scale = 1e-10;  
 % steps is number of bins per decade
  steps = 60;
% mindec is lowest log10(radius) in nM
  mindec = 0;
% ndec is number of decades to cover
  ndec = 9; %This is how far the scale will go, determines whether it ends at 1m or 1um etc. (9 ends at 0.1m when scale is 1e-10)
% number of bin edges
  nb = ndec*steps+1;
  if exist('n','var')==0 %if an n array or 'var' doesnt exist (i.e. equals logical 0) then the script runs, otherwise it skips to end
      % get bin edges
    rb = logspace(mindec,mindec+ndec,nb);
    % rb = logspace(mindec,mindec+ndec,nb);
    % get bin centers in the geometric sense
    % r = 10.^(0.5*log10(rb(1:nb-1))+0.5*log10(rb(2:nb)));
    r = 10.^(0.5*log10(rb(1:nb-1))+0.5*log10(rb(2:nb)));
    % scale to M
    % linear size binning
    %scale = 1.5e-7;
    %% Below for predictions for Aaronson paper
    %rb = linspace(0,1,5000);
    %rb = linspace(0,3200,1601);
    %r = ((rb(1:end-1)+rb(2:end))./2);
    rb = (rb*scale);
    r = (r*scale);
    len = length(r);
    n(1:len) = 0; %sets the number density in each r bin to zero
  end
  if exist('n_a','var')==0 %if an n array or 'var' doesnt exist (i.e. equals logical 0) then the script runs, otherwise it skips to end
      % get bin edges
    rb_a = logspace(mindec,mindec+ndec,nb);
    % rb = logspace(mindec,mindec+ndec,nb);
    % get bin centers in the geometric sense
    % r = 10.^(0.5*log10(rb(1:nb-1))+0.5*log10(rb(2:nb)));
    r_a = 10.^(0.5*log10(rb_a(1:nb-1))+0.5*log10(rb_a(2:nb)));
    % scale to M
    % linear size binning
    %scale = 1.5e-7;
    %% Below for predictions for Aaronson paper
    %rb = linspace(0,1,5000);
    %rb = linspace(0,3200,1601);
    %r = ((rb(1:end-1)+rb(2:end))./2);
    rb_a = (rb_a*scale);
    r_a = (r_a*scale);
    len = length(r_a);
    n_a(1:len) = 0; %sets the number density in each r bin to zero
  end
elseif zirc2flag == 1
    
    vmol = 9e-6; %Maybe make a note about this being a literature detemined value, and calcualte theoretical values based on Fe/Cr ratio to compare.
    vmol_FeNi = 3.33e-5; 
    a_init = 0.32388e-9;
    a = 0.32425e-9;
     % Keep solubility limts the same for thermodynamic calculations, but when calculating xbinst I need to divide xa by two to get the contributions from each system.
     %original = 9e-7 * exp(-15930/(tk));
    xb = 0.00128 + 0.0018; %from lit review (0.0034)
    xb_FeNi = 0.00072 + 0.0008;
    xc = 0.54; %xc for Zirc-2 = 0.54 - Massih %Zirc-4 Annand, 2017 (0.65)
    xc_a = 0.35; %xc for amorphous material is Cr conc + 10 at.% Fe
    xc_FeNi = 0.33; 
    sfen = 0.22;
    sfen_FeNi = 0.02; 
    nad = 1e-9; % This gives good fit to Massih et al. sizes (sfen = 0.25)
    % Every lattice site in Zr potential nuc. site (Nsites = 4.30e28)
    nsites = 4.30e28*nad;
%     vmax = (xb - xa)/(xc - xa);
%     vmax_FeNi = (xb_FeNi - xa)/(xc_FeNi - xa);
%     disp(['Vmax Fe-Cr type ' num2str(vmax)])
%     disp(['Vmax Fe-Ni type ' num2str(vmax_FeNi)])
%     vmaxtot = vmax + vmax_FeNi;
%     disp(['Vmax total ' num2str(vmaxtot)])
    % Set up size bins
% 
% scale goes from 1A to um %first bin will be 1A, the last will be 0.1m??
scale = 1e-10;  
 % steps is number of bins per decade
  steps = 60;
% mindec is lowest log10(radius) in nM
  mindec = 0;
% ndec is number of decades to cover
  ndec = 9; %This is how far the scale will go, determines whether it ends at 1m or 1um etc. (9 ends at 0.1m when scale is 1e-10)
% number of bin edges
  nb = ndec*steps+1;
  if exist('n','var')==0 %if an n array or 'var' doesnt exist (i.e. equals logical 0) then the script runs, otherwise it skips to end
      % get bin edges
    rb = logspace(mindec,mindec+ndec,nb);
    % rb = logspace(mindec,mindec+ndec,nb);
    % get bin centers in the geometric sense
    % r = 10.^(0.5*log10(rb(1:nb-1))+0.5*log10(rb(2:nb)));
    r = 10.^(0.5*log10(rb(1:nb-1))+0.5*log10(rb(2:nb)));
    % scale to M
    % linear size binning
    %scale = 1.5e-7;
    %% Below for predictions for Aaronson paper
    %rb = linspace(0,1,5000);
    %rb = linspace(0,3200,1601);
    %r = ((rb(1:end-1)+rb(2:end))./2);
    rb = (rb*scale);
    r = (r*scale);
    len = length(r);
    n(1:len) = 0; %sets the number density in each r bin to zero
  end
  if exist('n_a','var')==0 %if an n array or 'var' doesnt exist (i.e. equals logical 0) then the script runs, otherwise it skips to end
      % get bin edges
    rb_a = logspace(mindec,mindec+ndec,nb);
    % rb = logspace(mindec,mindec+ndec,nb);
    % get bin centers in the geometric sense
    % r = 10.^(0.5*log10(rb(1:nb-1))+0.5*log10(rb(2:nb)));
    r_a = 10.^(0.5*log10(rb_a(1:nb-1))+0.5*log10(rb_a(2:nb)));
    % scale to M
    % linear size binning
    %scale = 1.5e-7;
    %% Below for predictions for Aaronson paper
    %rb = linspace(0,1,5000);
    %rb = linspace(0,3200,1601);
    %r = ((rb(1:end-1)+rb(2:end))./2);
    rb_a = (rb_a*scale);
    r_a = (r_a*scale);
    len = length(r_a);
    n_a(1:len) = 0; %sets the number density in each r bin to zero
  end
    if exist('n_FeNi','var')==0 %if an n array or 'var' doesnt exist (i.e. equals logical 0) then the script runs, otherwise it skips to end
      % get bin edges
    rb_FeNi = logspace(mindec,mindec+ndec,nb);
    % rb = logspace(mindec,mindec+ndec,nb);
    % get bin centers in the geometric sense
    % r = 10.^(0.5*log10(rb(1:nb-1))+0.5*log10(rb(2:nb)));
    r_FeNi = 10.^(0.5*log10(rb_FeNi(1:nb-1))+0.5*log10(rb_FeNi(2:nb)));
    % scale to M
    % linear size binning
    %scale = 1.5e-7;
    %% Below for predictions for Aaronson paper
    %rb = linspace(0,1,5000);
    %rb = linspace(0,3200,1601);
    %r = ((rb(1:end-1)+rb(2:end))./2);
    rb_FeNi = (rb_FeNi*scale);
    r_FeNi = (r_FeNi*scale);
    len_FeNi = length(r_FeNi);
    n_FeNi(1:len_FeNi) = 0; %sets the number density in each r bin to zero
  end
  disp(['Remember to redefine D if necessary'])
end

%%
%All info from below is unorganised but contains information about the
%parameters above
% %
% % nad - adjusts number of nucleation sites as a fraction of number of sites
% % for homogeneous nucleation
% % nad =1e-9 for Zirc-4 to fit Gros and Wadier data
% %nad = 1e-9;
% %
% % From Massih paper (for Zirc-4)
% %
% vmol = 9e-6;
% vmol_FeNi = 3.33e-5; %1.12e-5 From Zaheens thesis - this value does not work!!!
% %ram = 92.906;
% a_init = 0.32388e-9;
% % finds equilibrium solubility (Massih paper data)
% xa = exp((-5.4e3./tk)-3.3); % Use the same xa for both SPP types
% % finds diffusion coefficient - uses effective coefficient (Massih) for
% % substitutional species for which there are no better data
% %d = diffco_amorph(tk);
% d = 3e-7 * exp(-15930/(tk));
% d_FeNi = 3e-7 * exp(-15930/(tk));%3e-6 * exp(-15930/(tk)); %Have to determine diffusivity of these SPPs, will likely be higher by an order of magnitude or so
% % For now a diffusivity one order of magnitude greater will be used
% %
% % Below is for Fe
% % sfen = 0.7 works for size predictions: 0.2wt%, 1h, 600
% %vmol =7.83e-6;
% %ram = 55.845;
% %[xc,xa]=equilibriumfe(tk);
% %d = diffco_fe(tk);
% %
% % Below is for Cr
% % 
% %vmol = 9.4047e-6;
% %ram = 51.996;
% %[xc,xa]=equilibriumcr(tk);
% %d = diffco_cr(tk);
% % Below is for Zirc-4
% %
% %vmol = 9e-6;
% % Dummy RAM
% %ram = 91.22;
% %[xc,xa]=equilibriumzirc(tk);
% %d = diffco_zirc(tk);
% % a Lattice parameter for Zr at end of ppt
% a = 0.32425e-9;
% % xb = effective composition Fe + Cr for Fe-Cr type and Fe + Ni for Fe-Ni type ZIRC-2 (alloy composition)
% %Zircaloy-2:
% %xb = 0.00128 + 0.0018; %from lit review (0.0034)
% %xb_FeNi = 0.00072 + 0.0008;%0.00072 + 0.0008;
% %Annand is a good paper for Zirc-4 SPP composition 
% %Actually, Annand is not so good because Fe is lost to Zr2Fe so Fe in laves
% %phase SPPs is low
% %try "Studies of second phase particles in different zirconium alloys using
% %extractive carbon replica and an electrolytic anodic dissolution procedure"
% 
% %and "Analysis of atomic
% %distribution in as-fabricated Zircaloy-2 claddings by atom probe
% %tomography under high-energy pulsed laser" good for zirc-2 composition.
% xc = 0.54; %xc for Zirc-2 = 0.54 - Massih %Zirc-4 Annand, 2017 (0.65)
% xc_a = 0.35; %xc for amorphous material is Cr conc + 10 at.% Fe
% %xc_FeNi = 0.33; %0.33; %xc for FeNi is taken be stoichiometric 0.33 for now
% %xc_a taken from Taylor 1999, Annand 2017, and Motta 1991
% % Note: if you want to run the model for Zircaloy-4 i.e. only Fe-Cr type
% % SPPs:
% 
% %Zircaloy-2:
% %xc = 0.54; %xc for Zirc-2 = 0.54 - Massih %Zirc-4 Annand, 2017 (0.65)
% %xc_a = 0.35;
% %xc_FeNi = 0.33;
% %xb = 0.00128 + 0.0018; %from lit review (0.0034)
% %xb_FeNi = 0.00072 + 0.0008;
% 
% %Zircaloy-4
% xb = 0.0018 + 0.0033;
% xb_FeNi = 0;
% xc_FeNi = 0;
% xc = 0.65;
% xc_a = 0.35;
% 
% tfinal = t*3600;
% %
% % sfen is interfacial energy for precipitate phase. This is a fitting
% % parameter. Massih value = 0.25
% %
% %sfen  = 0.25;
% sfen = 0.22;
% sfen_FeNi = 0.03; %Same Surface energy for now
% % nad = 1e-9; % This gives good fit to Gros and Wadier sizes (sfen = 0.25)
% nad = 1e-9; % This gives good fit to Massih et al. sizes (sfen = 0.25)
% % Every lattice site in Zr potential nuc. site (Nsites = 4.30e28)
% nsites = 4.30e28*nad;
% %Number of lattice sites is the same for both SPPs
% vmax = (xb - xa)/(xc - xa);
% %vmax_FeNi = (xb_FeNi - xa)/(xc_FeNi - xa);
% vmax_FeNi = 0; %When running for Zircaloy-4
% 
% disp(['Vmax Fe-Cr type ' num2str(vmax)])
% disp(['Vmax Fe-Ni type ' num2str(vmax_FeNi)])
% vmaxtot = vmax + vmax_FeNi;
% disp(['Vmax total ' num2str(vmaxtot)])
