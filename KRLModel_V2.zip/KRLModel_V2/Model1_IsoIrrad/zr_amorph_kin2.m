function[r,n,tout,vfout,vfpartout2,rbarout,rbarout1,rbarout2,npartout,npartout1,npartout2,nrout,rcout_c,rcout_a,amorphout,xbout,grout]= ...
    zr_amorph_kin2(r,n,rb,tk,tfinal,d,xa,xb,xc,sfen,nsites,vmol,a,a_init,radflag)
% ====================================================================
%
% Calculates precipitation kinetics in Zirconium alloys
% **RUN zirconium_init.m FIRST
%
% **THIS VERSION ALLOWS REPRECIPITATION OF CRYSTALLINE SPPs
% DURING IRRADIATION
%
% using 2nd order Runge Kutta formula for error checking and
% adaptive timestep control
%
% Reference (to source model, originally for Al3Zr)
% J. D. Robson and P. B. Prangnell, Acta Materialia, 49, 2001, p. 599-613
%
% Inputs
% r         Size bins (mean sizes) (m)
% rb        Size bins (edge sizes) (m)
% tk        Temperature  (K)
% tfinal    Time to calculate for (s)
% d         Diffusion coefficient of solute  (m^2/s)
% xa        Solute concentration in matrix in equilibrium with precipitate
% xb		Average solute concentration in matrix
% xc		Solute concentration in precipitate
% vmax      Maximum volume fraction of precipitate
% nsites    Number of nucleation sites for precipitate (m^-3)
% sfen      Interfacial energy of precipitate for growth/nucleation (Jm^-2)
% a_init	Initial Zr lattice parameter before precipitation
% a			Final Zr lattice parameter at the end of precipitation
% radflag   Irradiation active (=1)
%
% Outputs
% r         Mean size of size bins (m)
% n         Particle number density in each size bin (particles/m^3)
% tout      Time at each time-step (s)
% vfout     Volume fraction at each time-step
% rbarout   Mean particle radius at each time-step (micron)
% npartout  Particle number density at each time-step (particles/micron^3)
% nrout     Nucleation rate at each time-step (particles/m^3)
% rcout     Critical radius at each time-step (m)
%
% ====================================================================
%
na = 6.022045e23;
k = 1.380662e-23;
tau = 0;
tout = [];
grout = [];
vfout = [];
vfpartout2 = [];
rbarout = [];
rbarout1 = [];
rbarout2 = [];
npartout = [];
npartout1 = [];
npartout2 = [];
rcout_c = [];
rcout_a = [];
amorphout = [];
rgmax = [];
nrout = [];
xbout=[];
len = length(r);
%
% Set all PSDs other than 1st row (initial PSD) to be empty
%
n(2:100,1:len) = 0;
%
rbar = (sum(r.*n(1,:)))/sum(n(1,:));
vf = 4/3 * pi * sum((r.^3) .* n(1,:));
solsuc = 0;
solfail = 0;
nucflag = 1; % nucflag = 1 means nucleation ON (change in convention)
%
% Runge-Kutta initialization - from matlab ode23old
%
t = 0;
rbar = 0;
pow = 1/3;
tol = 1;
%
% Allowable errors
%
taunum = tol * 1e21;
taurad = tol * 1e-15;
% h is the value of the timestep increment
% hmax and hmin set limits on the range of timesteps
% the timestep is adjusted automatically using a 2nd order
% Runge-Kutta scheme
%
hmin = 1e-10;
hmax = 3e4;
mnum = 1e25;
%
hmaxinit=1e-10;
h_old = 10;
h = hmaxinit;
rc_c = 0;
rc_a = 0;
firstit=0;
%
% Each nucleation event produces its own PSD
% Initial PSD is ppt = 1
%
ppt = 1;
t_nuc(1) = 0; % Nucleation start times
nrmin_stop = 1; % Minimum nucleation rate at which nr is turned off
nrmin_start = 1.5e14; % Minimum nucleation rate at which nr is turned back on
% nrmin_start = 10;
%
%
%
if (xb < xa)
    disp(['Alloy composition below solvus - no precipitation. *end*'])
    return
end
while (t(1)<tfinal)
    if t(1) + h> tfinal, h = tfinal - t(1); end
    % Update times since nucleation event for each PSD
    for psd = 1:ppt
        t(psd) = t(1) - t_nuc(psd); % t(1) is the total time since start
    end
    if radflag == 1
        ram = amorph_depth(t);
    else
        ram = 0;
    end
    %
    rc_c = critrad_cryst(sfen,xa,xb,xc,vf,tk,vmol);
    rc_a = critrad_amorph(sfen,xa,xb,xc,vf,tk,vmol);
    %
    % Multiplication factor
    %
    newsize = 1.1 * rc_c;
    search=0;
    search=find(rb<newsize);
    bin_nuc=max(search);
    if bin_nuc>length(r-1)
        if nucflag == 1 % nucflag = 1 means nucleation ON
            disp 'New particles exceed size range !'
        end
        if nucflag == 0
            % Nucleation is complete - no new particles, set a dummy bin
            bin_nuc = 10;
        end
    end
    %if bin==[], disp 'New particles smaller than size range !';end
    %
    % Check that top bin is not occupied
    %
    if n(end)>0, disp 'Bin overflow error - increase maximum size range'; end
    %
    % find bin in which critical radius lies. The bin in which new
    % particles nucleate must be at least 1 greater than this
    %
    search=0;
    search=find(rb<rc_c);
    rcbin=max(search);
    bindiff=bin_nuc-rcbin;
    if bindiff<1 & nucflag == 0
        disp(['WARNING! newsize and rc lie in same bin. Remesh narrower bins'])
    end
    %
    % Loop over *all* PSDs
    %
    for psd = 1:ppt
        %
        % Compute the slopes
        %
        % slopes at start of interval
        %
        [nr1,gr1(psd,:)] = nucgrow_amorph(vf,ram(psd),rb,d,t(1),nsites,sfen,tk,xa,xb,xc,tau,vmol,a);
        if nucflag == 0; nr1 = 0; end
        %
        % slopes at middle of interval
        %
        % to calculate the slope need to know the volume fraction
        % at the middle of the interval. Need to temporarily update size
        % distribution and hence find volume fraction
        %
        if psd == ppt
            newpart3 = (1-vf) * nr1 * (h/2); % Newly nucleated particles only add to new PSD
            bin = bin_nuc;
        else
            newpart3 = 0;
            bin = 10;
        end
        ntemp3 = n(psd,:);
        ntemp3(bin)=ntemp3(bin)+newpart3;
        dr3(psd,:) = gr1(psd,:) * (h/2);
        %
        % Temporarily update size distribution
        %
        [np yp] = update_func_mod(r,rb,ntemp3,dr3(psd,:));
        ntemp3 = np';
        % Total vf for all PSDs - previous Vf for current PSD + new Vf for
        % current PSD
        %
        vf3 = vf - sum(((4/3) * pi * (r.^3)) .* n(psd,:)) + sum(((4/3) * pi * (r.^3)) .* ntemp3);
        %
        % Find slopes (nr & gr) at middle of interval
        %
        [nr3 gr3(psd,:)] = nucgrow_amorph(vf3,ram(psd),rb,d,t(1),nsites,sfen,tk,xa,xb,xc,tau,vmol,a);
        if nucflag == 0; nr3 = 0; end
        %
        % slopes at end of interval
        % use nr & gr at middle of interval to calculate change in (r,n)
        %
        if psd == ppt
            newpart2 = (1-vf) * nr3 * (h);
            bin = bin_nuc;
        else
            newpart2 = 0;
            bin = 10;
        end
        ntemp2 = n(psd,:);
        ntemp2(bin)=ntemp2(bin)+newpart2;
        dr2(psd,:) = gr3(psd,:) * h;
        %
        % Temporarily update size distribution
        %
        [np yp] = update_func_mod(r,rb,ntemp2,dr2(psd,:));
        ntemp2 = np';
        vf2 = vf - sum(((4/3) * pi * (r.^3)) .* n(psd,:)) + sum(((4/3) * pi * (r.^3)) .* ntemp2);
        %
        % Find slopes (nr & gr) at end of interval
        %
        [nr2 gr2(psd,:)] = nucgrow_amorph(vf2,ram(psd),rb,d,t(1),nsites,sfen,tk,xa,xb,xc,tau,vmol,a);
        if nucflag ==0; nr2 = 0; end
        %
        % Estimate the error
        %
        % In number density
        %
        deltanum(psd) = norm(h*(nr1 - 2*nr3 + nr2)/3,'inf');
        %
        % In radius
        %
        deltarad(psd) = norm(h*(gr1(psd,:) - 2*gr3(psd,:) + gr2(psd,:))/3,'inf');
        %
        % Limit maximum number of particles formed in each interval to mnum
        %
        newpart1 = nr1 * h;
        if newpart1>mnum
            numrange = 1;
            % make step size half the limiting maximum
            hnuc = mnum/(2 * nr1);
        else
            numrange = 0;
            hnuc = hmax;
        end
        %
        % Check xbinst has not fallen too far
        %
        xbinst_temp = xb - ((xc - xa) * vf2);
        %disp(['xa ' num2str(xa) ' xbinst_temp ' num2str(xbinst_temp)])
        if xbinst_temp < xa
            xbcheck = 1;
        else
            xbcheck = 0;
        end
    end
    %
    % Update the solution if the error is acceptable
    % Only check error in number density (nucleation) for final PSD (=ppt)
    %
    if (deltanum(ppt) <= taunum) & (max(deltarad) <= taurad) & (numrange==0) & (xbcheck == 0)
        firstit = firstit + 1;
        t = t + h;
        disp(['Updating solution ' num2str(h) ' time/h: ' num2str(t(1)/3600) ' nucrate ' num2str(nr3) ' nucflag ' num2str(nucflag) ' rc ' num2str(rc_c)])
        %
        % Loop over all PSDs
        %
        for psd = 1:ppt
            %
            % Calculate more accurate increment in size/number
            %
            if psd == ppt
                newpart = (1-vf)*h*(nr1 + 4*nr3 + nr2)/6;
                bin = bin_nuc;
            else
                newpart = 0;
                bin = 10;
            end
            n(psd,bin)=n(psd,bin) + newpart;
            dr(psd,:) = h*(gr1(psd,:) + 4*gr3(psd,:) + gr2(psd,:))/6;
            %disp(['Bin 1-5 n ' num2str(n(1:5))])
            %disp(['dr bins 1-5 ' num2str(dr(1:5))])
            [np yp]=update_func_mod(r,rb,n(psd,:),dr(psd,:));
            n(psd,:) = np';
            vf_part(psd) = 4/3 * pi * sum((r.^3) .* n(psd,:));
        end
        %
        % Update total Vf, npart, xbinst etc...
        %
        npart = sum(n(:)); % Total number of particles in *all* PSDs
        npart1 = sum(n(1,:)); % Total number of particles in PSD 1
        npart2 = sum(n(2,:)); % Total number of particles in PSD 2
        vf = sum(vf_part); % Total volume fracton in *all* PSDs
        if npart > 0
            rbar = (vf./((4/3) * pi * npart))^(1./3); % Mean radius *all* PSDs 
            if npart1 > 0
                rbar1 = (vf_part(1)./((4/3) * pi * npart1))^(1./3);
            else
                rbar1 = 0;
            end
            if npart2 > 0
                rbar2 = (vf_part(2)./((4/3) * pi * npart2))^(1./3);
            else 
                rbar2 = 0;
            end
        else
            rbar = 0;
        end
        %
        % Check what the nucleation rate will be after updating solution
        % and act accordingly
        %
        xbinst = xb - ((xc - xa) * vf);
        rc_c_new = critrad_cryst(sfen,xa,xb,xc,vf,tk,vmol);
        [nr_new] = nucrate_amorph(rc_c_new,sfen,nsites,xbinst,xb,d,t(1),tk,tau,vmol,a);
        if nr_new < nrmin_stop
            nucflag = 0; % nucleation stop
        end
        if nr_new > nrmin_start && nucflag == 0
            nucflag = 1; % nucleation restart
            ppt = ppt + 1; % increment PSD
            disp(['Nucleation restarting - new PSD generated'])
            t_nuc(ppt) = t(1); % fix time of nucleation re-start
            h = hmin;
        end
        %
        % Output number of particles per um^3 and mean radius in nm
        %
        npart = npart/1e18;
        npart1 = npart1/1e18;
        npart2 = npart2/1e18;
        %
        rbar_nm = rbar*1e9;
        rbar1_nm = rbar1*1e9;
        rbar2_nm = rbar2*1e9;
        %
        % Build up output vectors
        %
        tout = [tout t(1)];
        vfout = [vfout vf];
        if length(vf_part) > 1
           vfpartout2 = [vfpartout2 vf_part(2)];
        end
        rbarout = [rbarout rbar_nm];
        rbarout1 = [rbarout1 rbar1_nm];
        rbarout2 = [rbarout2 rbar2_nm];
        npartout = [npartout npart];
        npartout1 = [npartout1 npart1];
        npartout2 = [npartout2 npart2];
        nrout = [nrout nr3*1e-6];
        rcout_c = [rcout_c rc_c*1e9];
        rcout_a = [rcout_a rc_a*1e9];
        amorphout = [amorphout ram(1)*1e9];
        xbout = [xbout xbinst];
        solsuc = solsuc + 1;
        grt = dr(1,bin)/h;
        grout = [grout max(deltarad)];
    else
        solfail = solfail + 1;
    end
    if max(deltarad) ~= 0.0
        h1 = min(hmax, 0.9 * h * (taurad/max(deltarad))^pow);
    else
        h1 = hmax;
    end
    if deltanum ~= 0.0
        h2 = min(hmax, 0.9 * h * (taunum/max(deltanum))^pow);
    else
        h2 = hmax;
    end
    if xbcheck == 1
        h3 = h./1.1;
    else
        h3 = hmax;
    end
    %
    % Step size for next step is smaller of step sizes
    % calculated for growth and nucleation
    % and limited by not exceeding mnum particles in each step
    % But if in first few iterations, make sure h doesn't get too big
    % h is not allowed to increase by more than 10% between steps
    %
    if firstit>100
        hprov = min([h1 h2 h3 hnuc]);
        %disp(num2str([h1 h2 h3]))
        %if hprov == h1, disp(['limited by deltarad']); end;
        %if hprov == h2, disp(['limited by deltanum']); end;
        %if hprov == h3, disp(['limited by xbinst change']); end;
        h = max([hmin hprov]);
    else
        hprov = min([h1 h2 h3 hnuc]);
        h = min([hprov hmaxinit]);
    end
    if (h>1.1*h_old), h=1.1*h_old; end
    h_old = h;
end
disp([num2str(solfail+solsuc) ' Iterations: ' num2str(solsuc) ' Successful ' num2str(solfail) ' Unsuccessful'])
disp([num2str(ppt) ' PSD(s) generated '])
