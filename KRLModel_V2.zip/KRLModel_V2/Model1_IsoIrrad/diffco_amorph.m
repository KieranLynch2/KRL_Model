function [d]=diffco_amorph(tk)
%
% Effective diffusivity in Zirc-4 (Massih)
%
d = 1.473e-6 * exp(-15930/(tk));