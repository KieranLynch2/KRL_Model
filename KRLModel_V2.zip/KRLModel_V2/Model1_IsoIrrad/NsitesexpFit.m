function [N_a,N_b] = NsitesexpFit(nsitesin,nsites_final)

N = [nsitesin,nsites_final]';
dpa = [0,1]';

f = fit(dpa,N,'exp1');

% plot(f,dpa,D)
% set(gca, 'YScale', 'log')

N_a = f.a;
N_b = f.b;

end