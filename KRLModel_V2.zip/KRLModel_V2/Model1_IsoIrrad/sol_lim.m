function [xa,xa_store,tau] = sol_lim(xa,h,firstit,xa_store,tk,phi,t,xbout_c_Fe,xbinst)

%Determine the change in solubility limit as a function of flux and T after
%the incubation time.

%The growth amorph function is entered into 3 times during slopes
%calculations for Runge Kutta

%Need to increase xa in based on the release of Fe from amorphization
%This will balance out the driving force for growth and account for the
%sudden jump in xa when the incubation time is passed for the dissolution
%process.

tau = az_inc(tk,phi);
if t < tau %Increase xa by an appropriate amount to match increase in Fe in *matrix* caused by amorphization
    if firstit == 0 
        xbFe_diff = 0;
    elseif firstit == 1
        xbFe_diff = xbout_c_Fe(end); %find difference in Fe in matrix from amorphization between last iteration and one before
        xa_store = [xa];
    else
        xbFe_diff = xbout_c_Fe(end); %The change in Fe in matrix is jsut the most recent value in that array
    end
    if firstit ~= 0
        xa_change = xa_store(end)+xbFe_diff;
        xa_store = [xa_store xa_change];
%         xa_store = [xa_store xa];
    end
end
    
if t > tau

    %gamma needs to iteravely increase xa to give a final dissolution amount
    %to fit Bajaj

    xa_rec = xa_store(end);

    gamma = 6e-10; %gamma is effectively the damage caused per second under the specific temperature and flux, causing the increase in soubility.
            %6e-10?
    %gamma is a function that needs to be determined
    %gamma will increase with less temp and higher flux

    %Gamma has to be set to a very sensitive value and xa limit has to be
    %slowed down if the dissolution of SPPs hasn't caught up, i.e. xbinst
    %should == xa, or be within a factor of 10 % or something like that
    %xbinst never fully reaches xa (need to check why) so need to slightly
    %increase it, a 5% increase (xa.*1.05) seems like a good place to start
    
    xa_temp = (gamma.*h) + xa_rec; %potential increase in xa
    
%     xa_min = (xa_temp/1.05);
%     xbmax = xbinst*1;
%     if xa_temp < xbmax %if xa goes more than 5% higher than xb, in the next iteration xa won't increase further, until xb has caught up
%         xa = xa_temp;
%     else
%         xa = xa_rec;
%     end
    
    xa = xa_temp;

    xa_store = [xa_store xa];
end


%xa is going to increase up to 1 dpa where the level of vacancies levels
%off

% doserate = phi./(5e20);
% 
% dose = doserate.*t;
% 
% xa_init = exp((-5.4e3./tk)-3.3); 
% 
% xa_final = xa_init.*10;
% 
% dpa = [0 1];
% 
% P1 = ([xa_init,dpa(1)])';
% P2 = ([xa_final,dpa(2)])';
% 
% f = fit(P1,P2,'exp1');
% 
% if dose < 1
%     xa = f.a *exp(f.b);
% else
%     xa = xa_final;
% end

xa_store = [xa_store xa];
end