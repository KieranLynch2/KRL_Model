%Test run script
%[r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init]=zr_amorph_init(tc,t,r,rb,n,r_a,rb_a,n_a)
% [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init]=zr_amorph_init(700,10);
% 
% [r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout]= ... 
%     zr_amorph_kin(r,n,rb,r_a,rb_a,n_a,tk,tfinal,d,xa,xb,xc,xc_a,sfen,nsites,vmol,a,a_init,0);
% clear all
% load '700c10hrs.mat'
% rstart = r;
% nstart = n;
% clear all
[r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init]=zr_amorph_init(500,3.5,r,n);
%[r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init]=zr_amorph_init(600,35.5);

[r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout,vf_aout,vf_totout,xbinst_tot,ramout]= ... 
    zr_amorph_kin(r,n,rb,r_a,rb_a,n_a,tk,tfinal,d,xa,xb,xc,xc_a,sfen,nsites,vmol,a,a_init,0);

% plot(rstart.*(10^9),nstart.*(10^-18))
% hold on
plot(2.*r.*(10^9),n.*(10^-18))
% legend('Start','Irradiation')
% xlim([0,100])
