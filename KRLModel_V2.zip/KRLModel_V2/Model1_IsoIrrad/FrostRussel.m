
r = (1:1:500).*1e-9;
rm = 5e-9; %Equilibrium preciptiate size of 5 nm
% L = (1440.*1e-6)/2; %Interparticle spacing 
L = (629.*1e-9)/2;
theta = 5e-4; %Resolution rate per atom
R = 8e-10;


drout = [];
thetaout = [];
% for R = [5e-9,10e-9,20e-9]
drdt = (1-(r./rm)).*(1./(r.^2)).*(L./(L-r)).*(theta.*(R.^3)./(48));


% drout = [drout; drdt];
% thetaout = [thetaout theta];
% end

% for j = 1:1:3
% plot(r.*1e9,drout(j,:),'LineWidth',2)
plot(r.*1e9,drdt,'LineWidth',2)
% hold on
% end
yscale_symlog;

% legend('500','1000','2000')

%Large SPPs tau
% R = 5e-9;
tauB = (24.*rm.*r.^2)./(theta.*(R.^3));
tauBDays = tauB./86400;

%Output the dissolution rate of a particle with radius = 100 nm
DissRate = drdt(100);

xlabel('SPP diameter')
ylabel('dr/dt / m s^{-1}')
legend('Bajaj: Average interparticle spacing = 1440 nm','Valizadeh: Average interparticle spacing = 629 nm')
set(gca,'FontSize',18)