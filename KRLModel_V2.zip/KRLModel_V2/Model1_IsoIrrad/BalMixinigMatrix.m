function [NewCrDiffProf] = BalMixinigMatrix(zeta,phi,OldCrDiffProf,s,h)

% Calcualte a hypothetical drdt for each interface of each matrix bin
OldCrDiffProf_IN = OldCrDiffProf;
NZr = 4.3e28;
for j = 1:1:length(OldCrDiffProf)-1

    CurBin = OldCrDiffProf(j);
    RHSBin = OldCrDiffProf(j+1);
    BinWidth = s;

    %Calcualte hypothetical interface mixing distance
    NCr = NZr*CurBin;
    drdt = zeta*(phi/5e20).*1/NZr;
    dist = drdt*NCr.*h;

    %Determine original average between both bins for mass balance
    AvConc = (CurBin+RHSBin)./2;
    
    %Calcualte area of solute conc. * distance of mixing for each bin
    LHSMix= CurBin.*dist;
    RHSMix = RHSBin*dist;
    AvgConcMix = (LHSMix+RHSMix)./2;

    LHSNewConc = AvgConcMix.*(dist/BinWidth) + CurBin*((BinWidth-dist)./BinWidth);
    %Determine RHS conc through mass balance
    RHSNewConc = ((AvConc*2) - LHSNewConc);


    OldCrDiffProf_IN(j) = LHSNewConc;
    OldCrDiffProf_IN(j+1) = RHSNewConc;


if any(OldCrDiffProf_IN > 0.8e-6)
    a=5;
end

    a=5;


end

NewCrDiffProf = OldCrDiffProf_IN;