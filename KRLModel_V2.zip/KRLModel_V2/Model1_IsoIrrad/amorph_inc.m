function tauamorph = amorph_inc(tk,phi)

%% Old method 
%This is amorphization tau!!!
% Oldkphi = ((-2.8306e-23)*(tk)) + 1.8258e-20;
% Oldkphi = (-2.8e-23.*tk) + (1.8e-20);

kphi = 6.307e27*(tk^-17.65);

tauamorph_OLD = 1/(kphi * phi);

% OLDtauamorph = 1/(kphi * Oldkphi);
% tau_days = tauamorph_OLD./86400;
% Oldtau_days = OLDtauamorph./86400;

%% New Arrhenius method
Q = 1.38; %ev
flux = phi*1e4; %convert to n/m2/s
kb = 8.617e-5;
A = 1.37e33; %4.33e32 in cm

d2a = A/((flux)^(1/8)) *exp(-Q/(2*kb*tk));

%% Change made on 15/05/2025 - based on review of ASTM paper, remove the dose to amorphization 
d2a = 0;

%convert fluece to a time
tauamorph = d2a/flux;

end

