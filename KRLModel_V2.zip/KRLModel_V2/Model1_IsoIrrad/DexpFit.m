%Figuring out how to create a relationship between two logartihmic points
%based on a steady increase up until 1 dpa where it pleatues.

function [D_a,D_b] = DexpFit(D_init,D_final)

% D_init = 1e-20;
% D_final = 1e-24;


D = [D_init,D_final]';
dpa = [0,1]';
% dpa2 = [1,5];
% D2 = [D_final,D_final];


f = fit(dpa,D,'exp1');
% ff = f(dpa);
% 
% plot(dpa,ff,'-b','LineWidth',2)
% set(gca, 'YScale', 'log')
% hold on
% plot(dpa2,D2,'-b','LineWidth',2)
% set(gca,'FontSize',18)
% xlabel('dpa')
% ylabel('Diffusivity / m^{-2} s^{-1}')

D_a = f.a;
D_b = f.b;
end
