clear all
%Bin centre adjustment
r = [135.3];% 400 200];
tk = 316 + 273;
T = tk;
t = 568*24*60*60;
R_t = r;
phi = 1.887e14;

beta = 2.37e-3;
D = 2.34e-20;
estarR = 11600;
kx = 27;
kphi = 9.6e-22;

a0 = (exp((log(phi))-(log(kx/kphi))+(estarR*(1/T)))/(exp((log(phi))-(log(kx/kphi))+(estarR*(1/T)))+1));
%a0 = 0.694;
% B = beta./(3.*(R_t.^2));
% a = (D*phi).*(((B.*R_t).^3)-a0);
% b = -D.*phi.*B;
% k = ((a0./B)-(R_t.^3)).^(1/3);
B = beta/(3*(R_t^2));
a = (D*phi)*(((B*(R_t^3))-a0));
b = -D*phi*B;
k = ((a0/B)-(R_t^3))^(1/3);

%warning('off','all')



%syms r_t
r_t = sym('r_t',[1 1]);
eqn = t == ((k/(6*a))*log(((k+r_t)^2)/((k^2)-(k*r_t)+(r_t^2))))+((k/(a*sqrt(3)))*(atan(((2*r_t)-k)/(k*sqrt(3)))))-((k/(6*a))*(log(((k+R_t)^2)/((k^2)-(k*R_t)+(R_t^2)))))-((k/(a*sqrt(3)))*atan(((2*R_t)-k)/(k*sqrt(3))));

S = solve(eqn,r_t);

rout = 0;
rout(1) = S;