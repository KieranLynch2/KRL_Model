
 d_final  = [6.00E-24		6.00E-24	 	6.00E-24	 	1.00E-23	 	7.00E-24	 	8.00E-24	 	9.00E-24	 	1.00E-23];
 n_final = [ 1.50E+23	1.50E+23	 	1.00E+24	 	1.00E+19	 	5.00E+22	 	4.00E+22	 	8.00E+18	 	6.00E+18];
nfinallog = log(n_final);
dfinallog = log(d_final); 
alpha0 = [ 0.7294		0.7294		0.89		0.4892		0.6692		0.6513		0.531		0.4753];

% scatter(alpha0,d_final,'filled')
% scatter(alpha0,nfinallog)
scatter(alpha0,n_final,'filled')
set(gca, 'YScale', 'log')

% f = fit(alpha0',d_final','poly1');
% f = fit(alpha0',n_final','power2');

a0 = 0:0.01:1;
% dval = (-1.32e-23.*a0)+1.614e-23; %OLD fit
dval = 5.213e-24.*a0.^-0.8431; %NEW good fit
% nval = f(a0);

nvallog = 6.9.*tanh(9.*(a0-0.615))+48.35; %Good log fit!
nval = exp(nvallog); %Just raise the log fit by exp
% nval = 

% dval = (-1.32e-23.*a0)+1.614e-23;
% nval = 1.91e17.*exp(18.62.*a0);
hold on
plot(a0,nval,'LineWidth',2)
% plot(a0,dval,'LineWidth',2)
xlabel('\alpha_0')
% ylabel('Solute diffusivity / m^{2}s^{-1}')
ylabel('Number of nucleation sites / m^{-3}')
xlim([0 1])

legend('Bajaj et al.')
set(gca,'FontSize',18)
%d_final eq: (1.47e-23*a0^2)-(3.275e-23*a0)+2.238e-23
%n_final eq: 1.91e17*exp(18.62*a0)


%Log fits:
%n_final eq: 31.68*exp(0.6924.*a0)
%d_final eq: -52.12.*exp(0.03362.*ao)

% n_trial = 1.7297e+25.*(a0.^15.0406)+(2.3986e+21);


% y = alpha0;
% x = n_final;
% 
% Y = sigmoid(x);



%% first attempt - not very good 
% rbarend = [1.20E+02		9.70E+01		7.90E+01		1.13E+02		1.19E+02		1.15E+02];
% alpha0 = [0.7294		0.7294		0.89		0.4892		0.6692		0.6513,0.531,0.4753];
% 
% nsites_final = [ 2.9e21,2.9e21,3.5e24,8e20,1e21,1e23,1e21,1e21];
%   = [4e-23,4e-23,5e-24,3.5e-23,6e-23,6e-24,3e-24,3e-24];
% 
% scatter(alpha0, )
% set(gca, 'YScale', 'log')
% 
% f = fit(alpha0',nsites_final','exp1');
% fval = f(alpha0);
% hold on
% plot(alpha0,fval)

%% Plots of change in diffusivity and nsites with alpha0
% yyaxis left
% 
% pdum = plot([0,0],[0,0],'Color',[0 0.4470 0.7410],'LineWidth',2);
% pdum.LineStyle = '--';
% hold on
% pdum = plot([0,0],[0,0],'Color',[0 0.4470 0.7410],'LineWidth',2);
% pdum.LineStyle = '-';
% pdum = plot([0,0],[0,0],'Color',[0.8500 0.3250 0.0980],'LineWidth',2);
% pdum.LineStyle = '--';
% pdum = plot([0,0],[0,0],'Color',[0.8500 0.3250 0.0980],'LineWidth',2);
% pdum.LineStyle = '-';
% 
%   = 1e-23;
% D_init = 1e-20;
% 
% D = [D_init, ]';
% dpa = [0,1]';
% 
% f = fit(dpa,D,'exp1');
% fvals = f(dpa);
% 
% 
% dpa_end = [1,3];
% D_end = [ , ];
% 
% p = plot(dpa,fvals,'Color',[0 0.4470 0.7410],'LineWidth',2,'Marker','none');
% p.LineStyle = '--';
% set(gca, 'YScale', 'log')
% hold on
% p2 = plot(dpa_end,D_end,'Color',[0 0.4470 0.7410],'LineWidth',2,'Marker','none');
% p2.LineStyle = '--';
% 
% D_a = f.a;
% D_b = f.b;
% 
%   = 1e-24;
% D_init = 1e-20;
% 
% D = [D_init, ]';
% dpa = [0,1]';
% 
% f = fit(dpa,D,'exp1');
% fvals = f(dpa);
% 
% 
% dpa_end = [1,3];
% D_end = [ , ];
% 
% p = plot(dpa,fvals,'Color',[0 0.4470 0.7410],'LineWidth',2,'Marker','none');
% p.LineStyle = '-';
% set(gca, 'YScale', 'log')
% hold on
% p2 = plot(dpa_end,D_end,'Color',[0 0.4470 0.7410],'LineWidth',2,'Marker','none');
% p2.LineStyle = '-';
% 
% ylabel('Diffusivity / m^{2}s^{-1}')
% ylim([5e-25,5e-20]);
% yyaxis right
% 
%   = 1e21;
% D_init = 1e19;
% 
% D = [D_init, ]';
% dpa = [0,1]';
% 
% f = fit(dpa,D,'exp1');
% fvals = f(dpa);
% 
% 
% dpa_end = [1,3];
% D_end = [ , ];
% 
% p = plot(dpa,fvals,'Color',[0.8500 0.3250 0.0980],'LineWidth',2);
% p.LineStyle = '--';
% set(gca, 'YScale', 'log')
% hold on
% p2 = plot(dpa_end,D_end,'Color',[0.8500 0.3250 0.0980],'LineWidth',2);
% p2.LineStyle = '--';
% 
% 
%   = 1e22;
% D_init = 1e19;
% 
% D = [D_init, ]';
% dpa = [0,1]';
% 
% f = fit(dpa,D,'exp1');
% fvals = f(dpa);
% 
% 
% dpa_end = [1,3];
% D_end = [ , ];
% 
% p = plot(dpa,fvals,'Color',[0.8500 0.3250 0.0980],'LineWidth',2);
% p.LineStyle = '-';
% set(gca, 'YScale', 'log')
% hold on
% p2 = plot(dpa_end,D_end,'Color',[0.8500 0.3250 0.0980],'LineWidth',2);
% p2.LineStyle = '-';
% 
% ylabel('Nucleation site density / m^{-3}')
% xlabel('dpa')
% ylim([5e18,5e22]);
% 
% legend('Low \alpha0','High \alpha0','Low \alpha0','High \alpha0')
% set(gca,'FontSize',18)