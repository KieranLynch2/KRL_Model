%
% Script to run ppt model for different temperatures
%
%
clear all
% Temps to run for (in s)
tc_aim = [400 500 600 700 800];
%
% Run without irradiation for 5 temperatures
%
[r,rb,n,tk,d,tfinal,xb,xc,xa,sfen,nsites,vmol,vmax,a,a_init]=zr_amorph_init(tc_aim(1),20000);
[r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout]=zr_amorph_kin(r,n,rb,tk,tfinal,d,xa,xb,xc,sfen,nsites,vmol,a,a_init,0);
%
tout_1 = tout;
rbar_1= rbarout;
vf_1 = vfout;
xb_1 = xbout;
np_1 = npartout;
cap_1 = capout;
pgp_1 = pgpout;
socap_1 = socapout;
n_1 = n;
%
%
n(:) = 0;
%
[r,rb,n,tk,d,tfinal,xb,xc,xa,sfen,nsites,vmol,vmax,a,a_init]=zr_amorph_init(tc_aim(2),200);
[r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout]=zr_amorph_kin(r,n,rb,tk,tfinal,d,xa,xb,xc,sfen,nsites,vmol,a,a_init,0);
%
tout_2 = tout;
rbar_2= rbarout;
vf_2 = vfout;
xb_2 = xbout;
np_2 = npartout;
cap_2 = capout;
pgp_2 = pgpout;
socap_2 = socapout;
n_2 = n;
%
%
n(:) = 0;
%
[r,rb,n,tk,d,tfinal,xb,xc,xa,sfen,nsites,vmol,vmax,a,a_init]=zr_amorph_init(tc_aim(3),10);
[r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout]=zr_amorph_kin(r,n,rb,tk,tfinal,d,xa,xb,xc,sfen,nsites,vmol,a,a_init,0);
%
tout_3 = tout;
rbar_3= rbarout;
vf_3 = vfout;
xb_3 = xbout;
np_3 = npartout;
cap_3 = capout;
pgp_3 = pgpout;
socap_3 = socapout;
n_3 = n;
n(:) = 0;
%
[r,rb,n,tk,d,tfinal,xb,xc,xa,sfen,nsites,vmol,vmax,a,a_init]=zr_amorph_init(tc_aim(4),5);
[r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout]=zr_amorph_kin(r,n,rb,tk,tfinal,d,xa,xb,xc,sfen,nsites,vmol,a,a_init,0);
%
tout_4 = tout;
rbar_4= rbarout;
vf_4 = vfout;
xb_4 = xbout;
np_4 = npartout;
cap_4 = capout;
pgp_4 = pgpout;
socap_4 = socapout;
n_4 = n;
n(:) = 0;
%
[r,rb,n,tk,d,tfinal,xb,xc,xa,sfen,nsites,vmol,vmax,a,a_init]=zr_amorph_init(tc_aim(5),5);
[r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout]=zr_amorph_kin(r,n,rb,tk,tfinal,d,xa,xb,xc,sfen,nsites,vmol,a,a_init,0);
%
tout_5 = tout;
rbar_5= rbarout;
vf_5 = vfout;
xb_5 = xbout;
np_5 = npartout;
cap_5 = capout;
pgp_5 = pgpout;
socap_5 = socapout;
n_5 = n;