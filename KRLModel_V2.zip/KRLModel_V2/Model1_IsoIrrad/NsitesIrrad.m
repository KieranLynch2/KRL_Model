function [nsites,N_a,N_b] = NsitesIrrad(nsitesin,t,phi,N_a,N_b,firstit,nsites_final,c_loop)   


%I probably need to increase nsites at a constant rate, up until ~1 dpa, after
%which it should plateu at a given value

doserate = phi./(5e20);

dose = doserate.*t;

if firstit == 0
    [N_a,N_b] = NsitesexpFit(nsitesin,nsites_final);
end

%This section covers the number density of a-loops

if dose < 3.84
    nsites_a = N_a.*exp(N_b.*dose);
else
    nsites_a = nsites_final; 
end

nsites = nsites_a + c_loop;


% if dose < 1e-6
%     nsites = nsitesin;
% elseif dose > 1e-6 && dose < 1e-4
%     nsites = N_a.*exp(N_b.*dose);
% else
%     nsites = nsites_final;
% end

end