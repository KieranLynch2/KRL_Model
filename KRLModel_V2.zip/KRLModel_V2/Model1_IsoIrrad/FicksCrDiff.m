function [NewCrDiffProf,FickFlag] = FicksCrDiff(CrDiffProf,CrDiffProf_X,d,h,CrSumTotal,xb_initCr,CrDiffProfout,zeta,phi)

%Function to determine the solute diffusion in the matrix evolution to
%calculate solute diffusion at the interface and how it evolves with time. 
% This is for a dissolution model that assumes interface-controlled
% dissolution is the rate controlling step, which might physically
% represent the transfer of Cr atoms across the interface, switching with
% Zr SIAs.


%Before doing solute diffusion adjustments Increase the bin adjecnt to the
%SPP(s) according to the amount of dissolution. The amount of Cr released
%can be used to do this... add the Cr concentraiton in the first bin by the
%proportionate amount according to the CrRelease tracking array - make the
%average of all bins equal to the most up to date CrReleased value. This
%will make the first bin proporitonately higher.
% Increase the total averaged Cr_xbinst to be equal to the CrRelease array (+1/2 xbinst_init),
% as this essentially equals the Cr concentraiton in the matrix, but just
% purely by increasing the first bin
xc_Cr = 0.22; %Cr concentration in the amorphous phase

TotCrConc = CrSumTotal(end) + xb_initCr;
OldCrConc = mean(CrDiffProf);
NBins = length(CrDiffProf);
AvAllMatBins = mean(CrDiffProf(2:end)); %Find average of all far-field matrix bins to determine what the interface bin concentration needs to be

InterfacialBin = (TotCrConc*NBins)-sum(CrDiffProf(2:end));


% new method to only account for excess solute - hopefully improves
% modelling at v high doses/low temps
%InitMatConc = CrDiffProfout(1,:);


if InterfacialBin < 0
    sdfdsf=5;
end

CrDiffProf(1) = InterfacialBin;

%% Using finite difference method for solute diffusion

%Load in current 

preFick = CrDiffProf;

s = CrDiffProf_X(2)-CrDiffProf_X(1);

diffdis = (d * h)/(s^2); % d is the diffusion coefficient, h is the time interval

% Finite difference model for redistribution of solute in matrix
dc = diffdis*(CrDiffProf(1:end-2)-(2*CrDiffProf(2:end-1))+CrDiffProf(3:end));

% symmetry and constant solute limit fixes end compositions
dclast=diffdis*(2*(CrDiffProf(end-1)-CrDiffProf(end)));
dc = [dc dclast];

NewCrDiffProf = [];
NewCrDiffProf = CrDiffProf(2:end) + dc;
CrFirst = (sum(CrDiffProf)-sum(NewCrDiffProf));
NewCrDiffProf = [CrFirst NewCrDiffProf];

postFick = NewCrDiffProf;


%% Don't allow solute concentration of any bin to change more than 2 %.
FickFlag = FickCheck(postFick,preFick);

%% Function to account for atomic mixing of solute in the matrix
%[NewCrDiffProf] = BalMixinigMatrix(zeta,phi,NewCrDiffProf,s,h);
end
