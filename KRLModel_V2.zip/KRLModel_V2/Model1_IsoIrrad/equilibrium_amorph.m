function [xcr,xa]=equilibrium_amorph(tk)
% 
% Calculates effective xa [Cr + Fe], Massih
%
xa = exp(-2.8e3/tk) -5.6;
return