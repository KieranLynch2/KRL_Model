nucflag = [1];
        if nucflag == 0, n = 1; end
            
      
