function [gr,gr_a,r,rb,n_a,EqRad] = growth_amorph(r,r_a,rb,rb_a,rc_cryst,rc_amorph,ram,sfen,d,xbinst,xa,xc,xc_a,tk,vmol,n,n_a,radflag,tfinal,ram_diss,ram_total,t,tau_sl,vf,zirc2flag,vmax,phi,xb,sfen_amorph_diss,vmol_diss,InvCorseFlag,CrSumTotal,FeSumTotal,FeSumAmorph,CrDiffProf,QIntConGrw,zeta,zirc2flag_Irrad)
% function [gr] = growth(r,sfen,d,xbinst,xc,xa,tk)
% Calculates growth rate of spherical Al3Zr dispersoids
%
% Inputs
% r         Particle radius (m) n.b. this script works with the bin edges
%           rather than the bin averages.
% sfen      Interfacial energy (J/m^2)
% d         Diffusion coefficient (m^2/s)
% xbinst    Average Zr concentration in matrix
% xc        Concentration of Zr in dispersoids
% xa        Concentration of Zr in matrix at interface
% tk        Temperature (K)
% Output
% gr        Growth rate (ms^-1)
% gr        Growth rate of the amorphous dummy SPPs
% r         Average particle radius (adjusted due to ram)
% rb         Particle radius bin edges (adjusted due to ram)
%
vfmax = vmax;
gas = 8.31459;
k = 1.3806488e-23;
h = 6.626e-34;
delta = 3.2e-10; % width of interface (assume approx <a> Zr)
na = 6.022045e23;
vat = vmol./na;
%cn = find(r>0);
%cy = find(r<=0);
%Without irradiation growth rates are determined using default method

if radflag == 0 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    c_cryst = find(rb>ram);
    c_amorph = find(rb<=ram);
    x = xa.*(exp(((2 .* sfen .* vmol)./(gas .* tk)).*(1./rb)));
    xr(c_cryst) = xa .* ((xbinst./xa).^((rc_cryst)./rb(c_cryst)));
    xr(c_amorph) = xa .* ((xbinst./xa).^((rc_amorph)./rb(c_amorph)));
    ind=find(xr>xc);

    gr = ((xbinst - xr)./(xc - xr)) .* (d./rb);
    grOG = ((xbinst - x)./(xc - x)) .* (d./rb);

    % % % playing with new form of NHM

    % k0 = 1e-7;
    %
    % q = 50; % Mixing rate - take this as 50 for now, can be determined more accurately with rpa calculations
    % phi = k0; % Dose rate (dpa/s)
    % lam = 6e-10; % Average displacement distance - take as 5 nm for now, again atomistic sims can help here
    % xa = exp((-5.4e3./tk)-3.3).*1e0;
    % rg = 8.314;
    %
    % delta = (q.*phi.*(lam.^2))./(d.*xa);
    % R_cap = (2.*sfen.*vmol)./(rg.*tk);
    % R_i_cap = ((4.*R_cap)-(5.*lam.*delta))./(4.*(1+delta));
    % % Ci = xa.*(1+delta);
    % Ci = xa;
    % ModGT = Ci.*(1+(R_i_cap./rb));
    %
    % gr = ((xbinst - ModGT)./(xc - ModGT)) .* (d./rb);

    % % %



    % k2=100000;
    % grKinit = k2.*vmol.*((xbinst-xr).^2);
    % rcbin = find(rb<rc_cryst);
    % grKneg = grKinit(rcbin).*-1;
    % pos = find(rb>rc_cryst);
    % grKpos = grKinit(pos).*1;
    %
    % grK = [grKneg grKpos];

    % gr = grK;

    % xr(c_cryst) = xa*exp(((2*sfen*vat)./(tk*k))*(1./rb)); %From Robson, 2001
    % gr = ((xbinst - xr)./(xc - xr)) .* (d./rb);

    rx = isreal(xr);
    rgr = isreal(gr);
    if rx==0 | rgr==0
        disp(['Imaginary parts in xr and/or gr'])
    end
    freq = (k .* tk)./h;
    gstar_a = 15930 * k;
    vmax_a =  abs(delta .* freq .* exp(-gstar_a/(k * tk)));
    growlim_a = find(gr(c_amorph) > vmax_a);
    dislim_a = find(gr(c_amorph) < -vmax_a);
    gr(growlim_a) = vmax_a;
    gr(dislim_a) = -vmax_a;
    gstar_c = 15930 * k;
    vmax_c =  abs(delta .* freq .* exp(-gstar_c/(k * tk)));
    growlim_c = find(gr(c_cryst) > vmax_c);
    dislim_c = find(gr(c_cryst) < -vmax_c);
    gr(growlim_c) = vmax_c;
    gr(dislim_c) = -vmax_c;
    gr(ind) = -vmax_c;
    %Fill in arbitrarily the amorphous arrays
    len = length(gr);
    gr_a(1:len) = 0;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    EqRad = 0; %Temp to stop script failing.
else

    %% Below here is for SPP growth/dissolution under irradiation
    
    %if ram > 0 %i.e., phase is not crystalline, amorphous zone dissolution
    
    if length(FeSumTotal) > 1
        %Determine Cr concentration of amorphous phase depending on alloy -
        %increased relative to crysalline phase as Fe has
        %left2.24e28+2.24e29

        %zirc2flag_Irrad = 0; %21/11/24 - for BOR60 analysis - need a better switch for this that is automated

        if zirc2flag_Irrad == 0
            xc_Cr = 0.39;
        elseif zirc2flag_Irrad == 1
            xc_Cr = 0.485;
        end

        xbinst_Cr = CrSumTotal(end); %As dissolution only conisders Cr, the xc and xbinst values to drive growth/coarsening are solely for Cr
        %xa_cr_irr = xa - FeSumTotal(end); %remaining space in the matrix to accomodate Cr to allow it's dissolution
        xa_cr_irr = xa; %Just use this one when not using this method of Fe taking up available space in the matrix - Additional Ni in Zirc-2 could also drive this


        if InvCorseFlag == 1
            % Equations from Heinig, 2003

            xa_eq = exp((-5.4e3./tk)-3.3); %This is standard solubility without irradiation effects
            lam = 1e-9; %Average displacment distance of a sputtered atom

            xa_irr = xa_cr_irr; %xa increases in the main script with dose/temp

            %Work back for delta based on xa_irr and xa;
            delta = (xa_irr/xa_eq)-1;

            Rcap = ((2 * sfen_amorph_diss * vmol_diss)/(gas * tk));
            Rcap_irr = ((4.*Rcap)-(5.*lam.*delta))./(4.*(1+delta));
            xr_irr = xa_irr * (1 + (Rcap_irr./rb));

            drdt_InvCoarse = ((xbinst_Cr - xr_irr)./(xc_Cr - xr_irr)) .* (d./rb); %All focused on Cr phase

            gr = drdt_InvCoarse;
            gr_a = drdt_InvCoarse;

        elseif InvCorseFlag == 0

            gr = ((xbinst_Cr - xa_cr_irr)./(xc_Cr - xa_cr_irr)) .* (d./rb);
            gr_a = ((xbinst_Cr - xa_cr_irr)./(xc_Cr - xa_cr_irr)) .* (d./rb_a); %xa is now irradaition-enchaned xa. Use planar interface assumption, ignoring capillary effects.

           

        elseif InvCorseFlag == 2
            % % This is the original way of modelling dissolution - uniform empirical dissolution rate across all SPP size classes.
            if t <= tau_sl
                gr(1:lengr) = 0;
            end

            pstgr = find(gr>0);
            gr(pstgr) = 0;

            if t > tau_sl %uncomment this if manual incubation time to dissolution is needed
                %Function which uses rate determined emperically from Bajaj data
                [drdt] = AmorphDissRate(tk,phi);
                EqRad = 0;
            else
                EqRad = 0;
                drdt = 0;
            end

            gr(1:lengr) = drdt;

        elseif InvCorseFlag == 3 %Interface controlled dissolution mechanism - just an idea to explore (OLD now, don't use anymore!!!!!)
        %There's no radius dependency, so it levels out the dissolution
        %rates of the small and large SPPs. Value to be determined is Cif.
        
        % First attempt, assume that xbinst_Cr is the interface
        % concentration
        b = 0.323*1e-9;
        vj = (k*tk)/h;
        Qi = 214000;
        

        Cif = xbinst_Cr;
        if Cif == 0
            Cif = xa; %This is wrong - might need to do Ficks law on a sample situation - infinite source diffusion?
        end

        Cif = FicksCrDiff(xa); %Need change in radius from previos timesteps - this should be SPP size independent so can be easily tracked.

        delG = (gas*tk)*log(Cif/xa); %Use irradiation increased solubility limit
        M = ((b*vj)/(gas*tk))*exp(Qi/(gas*tk));
        drdt = M*delG;
        gr = (zeros(1,size(rb,2))+1)*drdt;
        gr_a = (zeros(1,size(rb,2))+1)*drdt; %Could 

        elseif InvCorseFlag == 4
            % Could develop on the method above to 1) include a dr/dt
            % contribution from ballistic mixing; 2) calcualte new
            % interface concentration; 3) calculate dr/dt induced by
            % increased xa (from interface controlled growth model); and 4) calcualte diffusion profiles - can be done at the end of each iteration (or the start).
            %zeta = 1e20;
            %K0 = 5e-7; %doserate
            K0 = phi./(5e20);
            %N = 4.5e28; %Change this to number of Cr atoms as they are meant to be rate controlling in this mechanism. Fe is not thought to affect dimensions of amorphous phase, i.e., Fe cna be sputtered or diffuse out without change morphology etc,
            %N = 1.47e28; % Just number of Cr atoms in Zircaloy-4 SPP

                    %For Zirc2 SPPs temp4
            % N = 2.23e28; % Just number of Cr atoms in Zircaloy-4 SPPs
            
           
            if zirc2flag_Irrad == 0
                N = 3.85e28;
            elseif zirc2flag_Irrad == 1
                N = 4.62e28;
            end

            Cif = CrDiffProf(1); %Need change in radius from previos timesteps - this should be SPP size independent so can be easily tracked.

            NHMdrdt = -zeta*K0*(1/N); 


            % Ballistic sputtering back of Cr atoms from interface
            NHMdrdt_growth = (Cif/xc_Cr)*(zeta*K0*(1/N)); %Thsi is +ve (growth)

            %NHMdrdt_growth = 0; %Set to zero as determination of zeta was experimental and wil inherently take into account backsputter.

            gr_NHM = (zeros(1,size(rb,2))+1)*(NHMdrdt+NHMdrdt_growth);
            gr_aNHM = (zeros(1,size(rb,2))+1)*(NHMdrdt+NHMdrdt_growth); 

            %Interface-controlled growth
            b = 0.323*1e-9;
            vj = (k*tk)/h;
            
            Qi = QIntConGrw;

            %Qi = 210000;


            %QHoodHigh = 155000;
            %QHoodLow = 134000;
            %Qi = 155000;

            % Stop solute diffusion creating imaginary numbers
            if Cif < 0 
                Cif = CrDiffProf(2);
            end

            delG = (gas*tk)*log(Cif/xa_cr_irr); %Use irradiation increased solubility limit
            M = ((b*vj)/(gas*tk))*exp(-Qi/(gas*tk));
            drdt_IFC = M*delG;

            gr_IFC = (zeros(1,size(rb,2))+1)*drdt_IFC;
            gr_aIFC = (zeros(1,size(rb,2))+1)*drdt_IFC; %Could


            %Overall dissolution rate considering ballistic transfer and
            %thermodynamic destabilization

            gr = gr_NHM + gr_IFC;
            gr_a = gr_aNHM + gr_aIFC;

            %% Below is temp to invetigate some amophization only conditions - 15/05/25
            %gr = zeros(1,length(gr_NHM));
            %gr_a = zeros(1,length(gr_NHM));
    
            %Need to prevent model growing beyond max thoretical volume
            %fraction - assume planr interface solubility?
            % No, simplification is that amorphous phase is not allowed to
            % grow! (but below crystalline phase can coarsen)...

            %Need to change this, but limit it in terms of max vol frac,
            %i.e., no growth allowed if CrRel <= 0 

            %MAKE CHANGES HERE !!!
            if CrSumTotal(end) <= 0 % No growth if no excess solute in matrix
            if any(gr>0)
                %gr = ((xbinst_Cr - xa)./(xc_Cr - xa)) .* (d./rb);
                %gr_a = gr;

                gr(:) = 0;
                gr_a = gr;
            end
            end

%       Need to account for back sputtering of solute atoms, so at high
%       doses with limited diffusivity there is not unrealistic sputtering

            if gr > 0 %i.e. if preciptiate is predicted to grow, can we assume that there are no Cr concentration profiles, so typical SPP coarsening continues using classical equation?
                %Growth implies that xbinst>xa, therefore matrix solute
                %concentration will develop concentration graidents back to
                %SPP, reveerting to diffsuion controlled mechanism (if
                %interface controlled growth is appled to system it will
                %exceed the solubility limit. -- 16/10/24 - need to think
                %about this potential issue. Rationalize it with previous
                %justification??? Alternatively, I could check if the
                %interfacial matrix solute conc bin is less than the other
                %adjacent bins... Or do these calculations, determine if
                %xbinst of adjacent bin is less than avergae matrix conc
                %and then apply the conventional precipitate theory growth
                %law, i.e., long range diffusion.

                % ctach could be if ballistic mixing (-ve) + ICG (-ve or
                % +ve) > 0, i.e., phase is growing, then conventional
                % coarsening is predicted. ICG mechanisms is still at play
                % but convenitonal coarsening might dominate.

                %If this catch is met, see if amorphous phase is there, if
                %not use standard growth equation on crytsalline phase -
                %might need to put another parameter to track current
                %raidus of amorphization, i.e., if amorphous rim is
                %dissolving faster than SPP

            end


            %If high temperature effects aren't caught, I can put a catch in to
            %revert to diffusion controlled growth, as there will not be a
            %Cr gradient from the SPP interface so long-range diffusion can
            %proceed
            %
        
        elseif InvCorseFlag == 5
            %    % increased xa (from interface controlled growth model); and 4) calcualte diffusion profiles - can be done at the end of each iteration (or the start).
            % %zeta = 1.9e18;
            % %K0 = 5e-7; %doserate
            % K0 = phi./(5e20);
            % %N = 4.5e28; %Change this to number of Cr atoms as they are meant to be rate controlling in this mechanism. Fe is not thought to affect dimensions of amorphous phase, i.e., Fe cna be sputtered or diffuse out without change morphology etc,
            % N = 1.47e28; % Just number of Cr atoms in Zircaloy-4 SPPs
            % 
            % NHMdrdt = -zeta*K0*(1/N); 
            % 
            % % Ballistic sputtering back of Cr atoms from interface
            % 
            % gr_NHM = (zeros(1,size(rb,2))+1)*(NHMdrdt);
            % gr_aNHM = (zeros(1,size(rb,2))+1)*(NHMdrdt); 
            % 
            % gr_KWN = ((xbinst_Cr - xa_cr_irr)./(xc_Cr - xa_cr_irr)) .* (d./rb);
            % gr_aKWN = ((xbinst_Cr - xa_cr_irr)./(xc_Cr - xa_cr_irr)) .* (d./rb_a); %xa is now irradaition-enchaned xa. Use planar interface assumption, ignoring capillary effects.
            % 
            % gr = gr_NHM + gr_KWN;
            % gr_a = gr;

            % - Normal NHM model
                   if zirc2flag_Irrad == 0
                N = 3.85e28;
            elseif zirc2flag_Irrad == 1
                N = 4.62e28;
                   end
                               K0 = phi./(5e20);

            NHM = -zeta*K0*(1/N) + ((3.*d.*xbinst_Cr)./(4.*pi.*rb.*xc_Cr)); 
            gr = NHM;
            gr_a = NHM;

            % if any(gr>0) %Can't do this for NHM as it predicts a process
            % of inverse coarseing where there will be positive growth
            % rates for smaller SPPs
            %     %gr = ((xbinst_Cr - xa)./(xc_Cr - xa)) .* (d./rb);
            %     %gr_a = gr;
            % 
            %     gr(:) = 0;
            %     gr_a = gr;
            % end

        end
    else
        %                 % For now, if amorphization is not seen yet, assume no dissolution - realistically, if i removed the emperical amorphization incubation period, i could allow dissolution, but it might just happen faster than amorphization rate so is neveer seen
%                 % This model could be used to explore this aspect...
                gr = (zeros(1,size(rb,2))+1);
                gr_a = gr;

    end

%     elseif ram == 0 %i.e., phase is crystalline %n.b. what if ram > 0  but immediately dissolves so is never seen
%         % Use xc and xbinst for pesudo-binary crystalline phase. Growth or
%         % dissolution can occur depending on the balance between solubility limits
%         % and instantanous solute matrix concentration
%         %Determine Cr concentration of amorphous phase depending on alloy.
%         if zirc2flag_Irrad == 0
%             xc_Cr = 0.39;
%         elseif zirc2flag_Irrad == 1
%             xc_Cr = 0.485;
%         end
% 
%         if InvCorseFlag == 1
%             % Equations from Heinig, 2003
% 
%             xa_eq = exp((-5.4e3./tk)-3.3); %This is standard solubility without irradiation effects
%             lam = 1e-9; %Average displacment distance of a sputtered atom
% 
%             xa_irr = xa; %xa increases in the main script with dose/temp
% 
%             %Work back for delta based on xa_irr and xa;
%             delta = (xa_irr/xa_eq)-1;
% 
%             Rcap = ((2 * sfen * vmol)/(gas * tk)); %revert back to standard sfen and vmol of crystalline phase
%             Rcap_irr = ((4.*Rcap)-(5.*lam.*delta))./(4.*(1+delta));
%             xr_irr = xa_irr * (1 + (Rcap_irr./rb));
% 
%             drdt_InvCoarse = ((xbinst - xr_irr)./(xc - xr_irr)) .* (d./rb); %Move back to pseudo-binary Fe-Cr phase/solute (obviosuly, this might change sfen/vmol), d is likely different here...although still potentially rate-controlled by Cr
% 
%             gr = drdt_InvCoarse;
%             gr_a = drdt_InvCoarse;
% 
%         elseif InvCorseFlag == 0 | InvCorseFlag == 3 
% 
%             gr = ((xbinst - xa)./(xc - xa)) .* (d./rb);
%             gr_a = ((xbinst - xa)./(xc - xa)) .* (d./rb_a); %xa is now irradaition-enchaned xa. Use planar interface assumption, ignoring capillary effects.
% 
% 
%         elseif InvCorseFlag == 2
%             % % This is the original way of modelling dissolution - uniform empirical dissolution rate across all SPP size classes.
%             % if t <= tau_sl
%             %     gr(1:lengr) = 0;
%             % end
%             %
%             % pstgr = find(gr>0);
%             % gr(pstgr) = 0;
%             %
%             % if t > tau_sl %uncomment this if manual incubation time to dissolution is needed
%             %     %Function which uses rate determined emperically from Bajaj data
%             %     [drdt] = AmorphDissRate(tk,phi);
%             %     EqRad = 0;
%             % else
%             %     EqRad = 0;
%             %     drdt = 0;
%             % end
%             %
%             % gr(1:lengr) = drdt;
%         elseif InvCorseFlag == 4
% 
%           %zeta = 1.9e18;
%             %K0 = 5e-7; %doserate
%             K0 = phi./(5e20);
%             %N = 4.5e28; %Change this to number of Cr atoms as they are meant to be rate controlling in this mechanism. Fe is not thought to affect dimensions of amorphous phase, i.e., Fe cna be sputtered or diffuse out without change morphology etc,
%             N = 1.47e28; % Just number of Cr atoms in Zircaloy-4 SPPs
% 
%                         Cif = CrDiffProf(1); %Need change in radius from previos timesteps - this should be SPP size independent so can be easily tracked.
% 
%             NHMdrdt = -zeta*K0*(1/N); 
% 
%             % Ballistic sputtering back of Cr atoms from interface
%             NHMdrdt_growth = (Cif/xc_Cr)*(zeta*K0*(1/N)); %Thsi is +ve (growth)
% 
%             gr_NHM = (zeros(1,size(rb,2))+1)*(NHMdrdt+NHMdrdt_growth);
%             gr_aNHM = (zeros(1,size(rb,2))+1)*(NHMdrdt+NHMdrdt_growth); 
% 
%             %Interface-controlled growth
%             b = 0.323*1e-9;
%             vj = (k*tk)/h;
%             Qi = 220000;
%             %QHoodHigh = 155000;
%             %QHoodLow = 134000;
%             %Qi = 155000;
% 
%             delG = (gas*tk)*log(Cif/xa); %Use irradiation increased solubility limit
%             M = ((b*vj)/(gas*tk))*exp(-Qi/(gas*tk));
%             drdt_IFC = M*delG;
% 
%             gr_IFC = (zeros(1,size(rb,2))+1)*drdt_IFC;
%             gr_aIFC = (zeros(1,size(rb,2))+1)*drdt_IFC; %Could
% 
% 
%             %Overall dissolution rate considering ballistic transfer and
%             %thermodynamic destabilization
% 
%             gr = gr_NHM + gr_IFC;
%             gr_a = gr_aNHM + gr_aIFC;
% 
%             % If positive growth predicted, correct it using classical
%             % long-range diffusion as diffusion feilds won't rpevent
%             % diffusion towards SPPs
%             if any(gr>0)
%                 c_cryst = find(rb>ram);
%                 c_amorph = find(rb<=ram);
%                 x = xa.*(exp(((2 .* sfen .* vmol)./(gas .* tk)).*(1./rb)));
%                 xr(c_cryst) = xa .* ((xbinst./xa).^((rc_cryst)./rb(c_cryst)));
%                 xr(c_amorph) = xa .* ((xbinst./xa).^((rc_amorph)./rb(c_amorph)));
%                 ind=find(xr>xc);
% 
%                 gr = ((xbinst - xr)./(xc - xr)) .* (d./rb);
%                 gr_a = gr;
% 
% 
%                 % For now, if amorphization is not seen yet, assume no dissolution - realistically, if i removed the emperical amorphization incubation period, i could allow dissolution, but it might just happen faster than amorphization rate so is neveer seen
%                 % This model could be used to explore this aspect...
%                 gr(:) = 0;
%                 gr_a = gr;
%             else
%                 % For now, if amorphization is not seen yet, assume no dissolution - realistically, if i removed the emperical amorphization incubation period, i could allow dissolution, but it might just happen faster than amorphization rate so is neveer seen
%                 % This model could be used to explore this aspect...
%                 gr(:) = 0;
%                 gr_a = gr;
%             end
% %ABOVE: it either 1) grows/coarsens as a crystalline phase or 2) does not
% %dissolve [ point 2) can be revisted if i took away the constraint on
% %amorphous incubation period ].
%         elseif InvCorseFlag == 5
% 
%                         gr = ((xbinst - xa)./(xc - xa)) .* (d./rb);
%             gr_a = ((xbinst - xa)./(xc - xa)) .* (d./rb_a); %xa is now irradaition-enchaned xa. Use planar interface assumption, ignoring capillary effects.
% 
% 
%             % Current simplification is that no amorphous zone dissolution
%             % until amoorphization begins - in reaility we need a more
%             % complete model that takes into account solubility limit
%             % increasese in both amorphization and dissolution
%                             gr(:) = 0;
%                 gr_a = gr;
%         end
% 
%     end

    if InvCorseFlag == 6 %Using simple empirical fit, which has its own incubation period... ignores all stuff above which relies on amorphization incubation
        %get inc time
        %get dissolution rate


    end

    EqRad = 0; %Just parse this value through for now - can figure out how to determine it if needed

end

return