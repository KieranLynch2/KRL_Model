%
% Script to run ppt model for different temperatures
%
%
clear all
%
% Run temperature step models to same CAP (change order of steps)
%
[r,rb,n,tkprof,xb,xc,sfen,nsites,vmol,a,a_init]=zr_amorph_init_noniso([700 700 1; 700 350 10/3600; 350 350 100]);
%[r,rb,n,tkprof,xb,xc,sfen,nsites,vmol,a,a_init]=zr_amorph_init_noniso([700 350 10]);
[r,n,tout,tkout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout]= ... 
    zr_amorph_kin_noniso(r,rb,tkprof,xb,xc,sfen,nsites,vmol,a,a_init,0);
tout_1 = tout;
tkout_1 = tkout;
rbar_1= rbarout;
vf_1 = vfout;
xb_1 = xbout;
np_1 = npartout;
cap_1 = capout;
socap_1 = socapout;
pgp_1 = pgpout;
n_1 = n;
%
%
n(:) = 0;
%
[r,rb,n,tkprof,xb,xc,sfen,nsites,vmol,a,a_init]=zr_amorph_init_noniso([350 350 100; 350 700 10/3600; 700 700 1]);
%[r,rb,n,tkprof,xb,xc,sfen,nsites,vmol,a,a_init]=zr_amorph_init_noniso([350 700 10]);
[r,n,tout,tkout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout]= ... 
    zr_amorph_kin_noniso(r,rb,tkprof,xb,xc,sfen,nsites,vmol,a,a_init,0);
tout_2 = tout;
tkout_2 = tkout;
rbar_2= rbarout;
vf_2 = vfout;
xb_2 = xbout;
np_2 = npartout;
cap_2 = capout;
socap_2 = socapout;
pgp_2 = pgpout;
n_2 = n;
%
%
