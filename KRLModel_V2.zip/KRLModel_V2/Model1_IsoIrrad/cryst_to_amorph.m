function[r_cryst,rb_cryst,n_a,n_cryst,r_a_shell,rb_a_shell,ramtot,ram,DissrTrack] = cryst_to_amorph(r_cryst,r_a,rb_cryst,n_a,ram,r_a_shell,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,tauamorph,h,d,xb,xc_a,vat,n,phi,n_clust,xc_clust,xc,vf_crat,vf_arat,vf_clustrat,r,xbinst,vmol,sfen,tk,xa,ramtot,r_old,rb_old,rb,r_total,r_total_old,rb_total,rb_total_old,tau_sl,t,DissrTrack,tfinal_step)

    %New updated method using conventional binning procedure (7/6/21)
    %Still need to keep track of the change in vf of crystalline material, which can now be done towards to end of the main script. 
    n_cryst = n;
    n_init = n_cryst;
    r_init = r_cryst;

r_a_shell = []; 
rb_a_shell = [];


    %Below is old method when subtracting ram value from r array.
%     r_init = r;
%     r = r-ram;
%     n_init = n;
%     %When the crystalline radius hits zero, the number density of the bin
%     %has to become zero too
%     rzero = find(r<=0);
%     n(rzero) = 0;
%     r(rzero) = 0;
%    
%     rb_init = rb;
%     rb = rb-ram;
%     rbzero = find(rb<=0);
%     rb(rbzero) = 0;
%     
%     %
%     vf_lost = ((4/3).*pi.*((r_init.^3).*n_init) - ((4/3).*pi.*((r.^3).*n)));
%     %Above and below use average bin sizes
%     n_a = n_a + (vf_lost./((4/3).*pi.*r_a.^3));
    
    %Change of how to model the amorphization
    %This needs uncommeting for Taylor equations from paper 1
%     r_cryst = r_cryst-ram;
%     r_cryst_zero = find(r_cryst<=0);
%     r_cryst(r_cryst_zero) = 0;
%     %n_cryst(r_cryst_zero) = 0;
% 
%     rb_cryst = rb_cryst-ram;
%     rbzero_cryst = find(rb_cryst<=0);
%     rb_cryst(rbzero_cryst) = 0;
%     
%     %When cryst-to-amorph transfomation for each bin is complete, r_a_shell
%     %has to stop adding ram to those bins. 
%     r_non_zero = find(r_cryst>0);
%     r_a_shell(r_non_zero) = r_a_shell(r_non_zero) + ram;
%     
%     rb_a_shell_start = (r_a_shell(:,1:end-1) + r_a_shell(:,2:end)) / 2;
%     twoends = [rb_a_shell_start(end) rb_a_shell_start(end)];
%     rb_a_shell = cat(2,rb_a_shell_start,twoends);
    %Create bin edges for the amorphous shell array so it can be passed
    %into r_total and then passed through update functions etc.
    
   % vf_c_change = sum(vf_lost); %volume fraction of crystalline material lost to amorphization
   
   
   
%     vf_lost = ((4/3).*pi.*((r_init.^3).*n_init) - ((4/3).*pi.*((r.^3).*n_cryst))); %n_cryst is the same as n and it doesn't change for crystalline array
%     VfSanCheck = [VfSanCheck

%Using Taylor eq.10 with varied amorphization rates
%The actual rate of amorphization will in increased based on incubation
%time where no amorphization is happening.
time_amorph_inc = time_amorph;% - tauamorph;
time_amorphrb_inc = time_amorphrb;% - tauamorph;

AmorphRater = ram_total_end_r./time_amorph_inc; %In m/s
AmorphRaterb = ram_total_end_rb./time_amorphrb_inc; %In m/s

AmorphWidth = AmorphRater .*h;
AmorphWidthrb = AmorphRaterb .*h;

AmorphWidth = ram;  % ramtot;
AmorphWidthrb = ram; %ramtot;

%Apply NHM model to current r_cryst and rb_cryst bins to determine
%dissolution rate/amount this iteration and add this to amorphization width

[drdt,EqRad] = NHM(r_cryst,d,xb,xc_a,vat,n,phi,n_clust,xc_clust,xc,vf_crat,vf_arat,vf_clustrat,xbinst,vmol,sfen,tk,xa);

n(541)=0;
[drdtrb,EqRad] = NHM(rb_cryst,d,xb,xc_a,vat,n,phi,n_clust,xc_clust,xc,vf_crat,vf_arat,vf_clustrat,xbinst,vmol,sfen,tk,xa);


%Temp using emperical relatiionship
[drdt] = AmorphDissRate(tk,phi);
[drdtrb] = AmorphDissRate(tk,phi);
drdtzer = zeros(1,length(r));
drdtzer(1:end) = drdt;
drdt = drdtzer;
drdtrbzer = zeros(1,length(rb_cryst));
drdtrbzer(1:end) = drdtrb;
drdtrb = drdtrbzer;


% %Temp using NHM Diss only
% drdt = NHMDiss(r_cryst,phi,tk);
% drdtrb = NHMDiss(rb_cryst,phi,tk);



drdt(isinf(drdt)|isnan(drdt)) = 0;
drdtrb(isinf(drdtrb)|isnan(drdtrb)) = 0;

%need to limit the maximum dissolution rates otherwise the system goes
%uncontrollable
rmax = find(r>500e-9); %i.e. all bins with radius of 500 nm are redundent
minbin = min(rmax);

maxdr = drdt(minbin);
maxdrb = drdtrb(minbin);


drdt(rmax) = maxdr;
drdtrb(rmax) = maxdrb;

% if t > tau_sl
%     Dissr = drdt.*h;
%     Dissrb = drdtrb.*h;
% else
%     Dissr = 0;
%     Dissrb = 0;
% end

% DissrTrack = [DissrTrack Dissr(1)];

DissRate_r = (tfinal_step-tau_sl).*drdt;
DissThisTime_r = DissRate_r.*(h/(tfinal_step-tau_sl));
DissRate_rb = (tfinal_step-tau_sl).*drdtrb;
DissThisTime_rb = DissRate_rb.*(h/(tfinal_step-tau_sl));
if t > tau_sl
    Dissr = DissThisTime_r;
    Dissrb = DissThisTime_rb;
else
    Dissr = 0;
    Dissrb = 0;
end
DissrTrack = [DissrTrack Dissr(1)];
% Dissr = r_total_old-r_total;
% Dissrb = rb_total_old-rb_total;

% Dissr = 0;
% Dissrb = 0;


%Below is essentially the mu parameter to account for the extra
%amoprhization width which is the true ram, keeping in mind that the Taylor
%model only predicts the observed amorphization width.
ram = AmorphWidth - Dissr; %Need to minus this as dissolution rates are negative and growth rates are positive
ramrb = AmorphWidthrb - Dissrb; %If SPP is growing the predicted amophous zone width is less than actual one
%For now exclude the positive growth rates from this adjustment to ram,
%because the hypothesis is that new clusters are forming and growing which
%are irradiation resistant relative to the original SPPs.
%So, essentially the SPPs which are growing are not Zr(Fe,Cr)2-- to account
%for this I could look at the SPP size involved (will be small as these are
%the only ones growing) and say from the off that even though rate of
%amorphization may be less than the rate of growth, overall complete
%amorphization will occur.

    r_cryst = r_cryst-ram;
    r_cryst_zero = find(r_cryst<=3e-11);
    r_cryst(r_cryst_zero) = 0;
    %n_cryst(r_cryst_zero) = 0;

    rb_cryst = rb_cryst-ramrb;
    rbzero_cryst = find(rb_cryst<=3e-11);
    rb_cryst(rbzero_cryst) = 0;

end