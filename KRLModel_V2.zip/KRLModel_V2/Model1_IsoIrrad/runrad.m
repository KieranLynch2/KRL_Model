%
% Script to run irradiation model and store useful stuff
%
clear all
%
% Load initial PSD
load 'alpha_annealed_massih.mat'
%
%
% Run for 1 year without irradiation effect
[r,rb,tk,d,tfinal,xb,xc,xa,sfen,nsites,vmol,vmax,a,a_init]=zr_amorph_init(307,365.25*24);
d = diffco_cr(tk);
[r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump]=zr_amorph_kin(r,n,rb,tk,tfinal,d,xa,xb,xc,sfen,nsites,vmol,a,a_init,0);
%
% hang on to useful stuff
%
r_ni = r;
n_ni = n;
tout_ni = tout;
rc_ni = rcout_c;
rbar_ni = rbarout;
vf_ni = vfout;
npart_ni = npartout;
xb_ni = xbout;
%
%
% Run for 1 year with irradiation effect
%
load 'alpha_annealed_massih.mat'
[r,rb,tk,d,tfinal,xb,xc,xa,sfen,nsites,vmol,vmax,a,a_init]=zr_amorph_init(307,365.25*24);
d = diffco_cr(tk);
[r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump]=zr_amorph_kin(r,n,rb,tk,tfinal,d,xa,xb,xc,sfen,nsites,vmol,a,a_init,1);
%
% hang on to useful stuff
%
r_i = r;
n_i = n;
tout_i = tout;
rc_c_i = rcout_c;
rc_a_i = rcout_a;
rbar_i = rbarout;
vf_i = vfout;
npart_i = npartout;
xb_i = xbout;
%
% Do some smoothing
% over limited time range
smoothit = find(tout>1.5e6);
s1 = min(smoothit);
vfout_crop = vfout(smoothit)-vfout(s1);
xbout_crop = xbout(smoothit)-xbout(s1);
rbarout_crop = rbarout(smoothit)-rbarout(s1);
rcout_c_crop = rcout_c(smoothit)-rcout_c(s1);
rcout_a_crop = rcout_a(smoothit)-rcout_a(s1);
npartout_crop = npartout(smoothit)-npartout(s1);
wndwSize = 150;
h = ones(1,wndwSize)/wndwSize;
vf_i(smoothit) = filter(h,1,vfout_crop)+vfout(s1);
xb_i(smoothit) = filter(h,1,xbout_crop)+xbout(s1);
rbar_i(smoothit) = filter(h,1,rbarout_crop)+rbarout(s1);
rc_c_i(smoothit) = filter(h,1,rcout_c_crop)+rcout_c(s1);
rc_a_i(smoothit) = filter(h,1,rcout_a_crop)+rcout_a(s1);
npart_i(smoothit) = filter(h,1,npartout_crop)+npartout(s1);



