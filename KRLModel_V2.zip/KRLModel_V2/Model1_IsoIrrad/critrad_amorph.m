function [rc] = critrad_amorph(sfen,xa,xb,xc,xc_a,vf_cryst,vf_a,tk,vmol,radflag,vf_total,vf,vf_clust,vf_amorph,xc_clust)
% function[rc] = critrad(sfen,xa,xbinst,tk)
% Calculates critical radius for growth/nucleation
%
% Inputs
% sfen      Interfacial energy of nuclei (J/m^2)
% xa        Equilibrium concentration of Zr in matrix at interface
% xb        Zr concentration in matrix (far field)
% xc        Zr concentration in dispersoids
% vf        Volume fraction of dispersoids
% tk        Temperature (K)
% Outputs
% rc        Critical radius (m)
%
%
% update mean matrix concentration
%
%          if radflag == 1
%             if vf_total == 0
%                 xbinst = xb;
%             else
%                 vf_crat = vf_cryst/(vf_cryst+vf_amorph);
%                 vf_arat = vf_amorph/(vf_cryst+vf_amorph);
%                 xc_avg = (xc*vf_crat)+(xc_a*vf_arat);
%                 xbinst = xb - ((xc_avg - xa) * vf_total);                
%             end

k = 1.3806488e-23;
na = 6.022045e23;
vat = vmol/na;

if radflag == 0
    xbinst = xb - ((xc - xa) .* vf);
else
    vf_tot = vf_total;
    if vf_total+vf_clust == 0
        xbinst = xb;
    else
        vf_crat = vf_cryst/(vf_cryst+vf_amorph+vf_clust);
        vf_arat = vf_amorph/(vf_cryst+vf_amorph+vf_clust);
        vf_clustrat = vf_clust/(vf_cryst+vf_amorph+vf_clust);
        
        xc_avg = (xc*vf_crat)+(xc_a*vf_arat)+(xc_clust*vf_clustrat);
        xbinst = xb - ((xc_avg - xa) * (vf_total+vf_clust));
    end  
    %     vf_tot = vf_total;
    %     if vf_tot == 0
    %         xbinst = xb;
    %     else
    %         vf_crat = vf_cryst/(vf_cryst+vf_a);
    %         vf_arat = vf_a/(vf_cryst+vf_a);
    %         xc_avg = (xc*vf_crat)+(xc_a*vf_arat);
    %         xbinst = xb - ((xc_avg - xa) * vf_tot);
    %     end
end
if xbinst < 0, xbinst = 0; end
gas = 8.31459;
%
% only calculate critical radius when xbinst>xa
%
%disp(['xa ' num2str(xa) ' xbinst ' num2str(xbinst)])
  %
  % full expression for driving force from ideal solution model (Aaronson, Met Trans A, 23A, 1992 p.1915)
  %
%   if radflag == 0
      driving = ((gas * tk)/vmol)*((xc_a.*log(xbinst./xa))+((1-xc_a).*log((1-xbinst)./(1-xa))));
%   else
% %       vmol_clust = 1.1e-5;
%       vmol_clust = vmol;
%       driving = ((gas * tk)/vmol_clust)*((xc_clust.*log(xbinst./xa))+((1-xc_clust).*log((1-xbinst)./(1-xa))));
%   end
  %driving = ((gas * tk)/vmol)*((xc.*log(xbinst./xa)));
  %  driving = driving - 2.14e8;
%
%fec = (1/c2) * (2 * sfen) * driving

%
% Modify driving force by strain energy
%stren = strain_co(0.017,0.34,0.31,48e9,75e9);
   stren = 0;
   if radflag == 1
%        sfen = 0.01;
   end
%
   resdrive = driving - stren;
   rc = (2 * sfen)./(resdrive);
   
   if rc<0
       a=5;
       rc = 1; %this happens when solute concentration in the matrix is less than the solubility limit
   end
   %rc = (2*sfen*vat)/(k*tk*log(xbinst/xa));
%
% Limit maximum rc
%if rc > 1e-3, rc = 1e-3; end
return