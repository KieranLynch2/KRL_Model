





function [nr_FeNi,gr_FeNi] = nucgrow_amorph_FeNi(vf_FeNi,r_FeNi,rb_FeNi,d_FeNi,t,nsites,sfen_FeNi,tk,xa,xa_FeNi,xb_FeNi,xc_FeNi,tau,vmol_FeNi,a_FeNi,n_FeNi,radflag,xb,xc,vf,d,rb,rc_c,vmax_FeNi,r_clustFeNi,n_clustFeNi,vf_clustFeNi,xc_clustFeNi,phi,tau_sl,xc_avgFeNi)
%
% Function follows same syntax as Joe's original script. In the
% zr_amorph_kin script the function calls rb and rb_a, but in this script
% it changes it to r and r_a - which act as the bin edges for the
% growth_amorph script. EDIT: As i need to change the bin averages and the
% edges i need to deviate from this syntax and bring in both the edges and
% averages through this function.
%
% function [nr,gr] = nucgrow(vf,rb,d,nsites,sfen,tk,xa,xb,xc)
% Inputs
% vf        Current volume fraction of dispersoids
% r         Mean size of size classes (m)
% d         Diffusion coefficient (m^2s^-1)
% nsites    Number density of nucleation sites (/m^-3)
% sfen      Interfacial energy for nucleation/growth (J/m^-2)
% tk        Temperature  (K)
% xa        Equilibrium concentration of Zr in matrix at planar interface
% xb        Current average zirconium concentration in matrix
% xc        Zirconium concentration in dispersoids
% Outputs
% nr        Nucleation rate of dispersoids (m^-3s^-1)
% gr        Growth rate of each size class (ms^-1)
%
%
% update mean matrix concentration
%
%   xbinst = xb - ((xc - xa) * vf);


if radflag == 0
    xbinst_FeNi = xb_FeNi - ((xc_FeNi - xa_FeNi) .* vf_FeNi); %this should calculate Fe + Ni concentration in matrix
    xbinst = xb - ((xc - xa) .* vf);
        vf_ratFeNi = [];
        vf_clustratFeNi = [];
else

        vf_ratFeNi = vf_FeNi/(vf_FeNi+vf_clustFeNi);
        vf_clustratFeNi = vf_clustFeNi/(vf_FeNi+vf_clustFeNi);
        
        xc_avgFeNi = (xc_FeNi.*vf_ratFeNi)+(xc_clustFeNi.*vf_clustratFeNi);
        xbinst_FeNi = xb_FeNi - ((xc_avgFeNi - xa_FeNi) * (vf_FeNi+vf_clustFeNi));
        xbinst = xb - ((xc - xa) .* vf);
    end
    
    % vf_tot = vf_total; %vf == vf_cryst when radflag == 1, vf_a is amorphous vf
    % if vf_tot == 0
    %     xbinst = xb;
    % else
    % vf_crat = vf/(vf+vf_a);
    % vf_arat = vf_a/(vf+vf_a);
    % xc_avg = (xc*vf_crat)+(xc_a*vf_arat);
    % xbinst = xb - ((xc_avg - xa) * vf_tot);
    % end

if xbinst < 0, xbinst = 0; end






if xbinst_FeNi < 0, xbinst_FeNi = 0; end
%
% calculate critical radius, growth and nucleation rates
%
% xbinst is recalculated in critradco: Do not pass
    rc_FeNi = critrad_cryst_FeNi(sfen_FeNi,xa_FeNi,xb_FeNi,xc_FeNi,vf_FeNi,tk,vmol_FeNi,xb,xc,vf);
    nr_FeNi = nucrate_FeNi(rc_FeNi,sfen_FeNi,nsites,xbinst_FeNi,xb_FeNi,d_FeNi,t,tk,tau,vmol_FeNi,a_FeNi);
    gr_FeNi = growth_amorph_FeNi(r_FeNi,rb_FeNi,rc_FeNi,sfen_FeNi,d_FeNi,xbinst_FeNi,xa_FeNi,xc_FeNi,tk,vmol_FeNi,n_FeNi,radflag,xbinst,d,rb,rc_c,vf_FeNi,vmax_FeNi,xc_avgFeNi,n_clustFeNi,xc_clustFeNi,phi,t,tau_sl);
 %   if rc_cryst > max(r)
 %       disp(['stop'])
 end
