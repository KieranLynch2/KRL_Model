function [nr,N_a,N_b] = nucrate_amorph(rc,sfen,nsitein,xbinst,xb,d,t,tk,tau,vmol,a,radflag,tfinal,phi,N_a,N_b,firstit,c_loop)
% function [nr] = nucratesc(rcrit,sfen,nsites,d,t,tk)
% Calculates time dependent nucleation rate in Cu-Co
% (using expression from Hyland paper)
% 
k = 1.380662e-23;
na = 6.022045e23;
h = 6.626176e-34;
%
% aprod should be diffusion distance
% ie shortest lattice vector
%

% nsites = nsitein;
if radflag == 1
%     nsites_final = nsitesin.*3e5;
    
    nsitein = 1e20;
    nsites_final = 1e21; %This is maximum number of possible a-loops

    [nsites,N_a,N_b] = NsitesIrrad(nsitein,t,phi,N_a,N_b,firstit,nsites_final,c_loop);    
    
    sfen = 0.02;
else
    nsites = nsitein;
end

aprod = a;
vat = vmol/na;
gstar = 4/3 * pi * (rc.^2) * sfen;
%
% Modify nsites to account for loss of solute
%
%nsites = nsitein .* (xbinst./xb);


if rc>0.0
dg = (-2 * sfen)./rc;
zeld = (vat .* dg.^2)./(8 * pi * ((sfen^3*k.*tk).^0.5));
%
% See stocalc.m for configuration for data sent to MJS
%
% Comment out next line for beta and tau line to get KW method
% uncomment tau in main program
% beta = (16 .* pi .* (sfen^2) .* xbinst .* d)./((dg.^2) .* (aprod^4));
% Below - beta for Aaronson from Stowell (p.6)
beta = (4 * pi * rc^2 * d * xb)/(aprod^4);
% Below - beta for KW (Servi-Turnbull method)
%betakw = (d*xbinst) /  ((0.7071*aprod)^2);
%beta = betakw;
%
% Russell beta factor (as used by Aaronson) 
% beta = betakw * 4* pi * ((rc/(0.7071*aprod))^2);
% tau from Stowell, theta from Stowell, p. 10
%theta = 1;
%tau = 1/(theta * beta * (zeld^2));
% tau from Aaronson
ktau = 8;
% tau = (ktau * k * tk * sfen * (aprod^4))/((vat^2) * (dg^2) * d * xb);
%ignore incubation time
tau=1e-100;
if t>=0
    nr = nsites.*zeld.*beta.*exp(-gstar./(k .* tk));
    % Change next bit!
    % nr = nsites.*zeld.*beta.*exp(-gstar./(k .* tk));
else
    nr = 0;
end
else
    nr = 0;
end
return
   