function [rc_FeNi] = critrad_cryst_FeNi(sfen_FeNi,xa,xb_FeNi,xc_FeNi,vf_FeNi,tk,vmol_FeNi,xb,xc,vf)
% function[rc] = critrad(sfen,xa,xbinst,tk)
% Calculates critical radius for growth/nucleation
%
% Inputs
% sfen      Interfacial energy of nuclei (J/m^2)
% xa        Equilibrium concentration of Zr in matrix at interface
% xb        Zr concentration in matrix (far field)
% xc        Zr concentration in dispersoids
% vf        Volume fraction of dispersoids
% tk        Temperature (K)
% Outputs
% rc        Critical radius (m)
%
%
% update mean matrix concentration
%
xbinst = xb - ((xc - xa) .* vf);
xbinst_FeNi = xb_FeNi - ((xc_FeNi - xa) .* vf_FeNi);

if xbinst_FeNi < 0, xbinst_FeNi = 0; end
gas = 8.31459;
%
% only calculate critical radius when xbinst>xa
%
%disp(['xa ' num2str(xa) ' xbinst ' num2str(xbinst)])
  %
  % full expression for driving force from ideal solution model (Aaronson, Met Trans A, 23A, 1992 p.1915)
  %
  driving_FeNi = ((gas * tk)/vmol_FeNi)*((xc_FeNi.*log(xbinst_FeNi./xa))+((1-xc_FeNi).*log((1-xbinst_FeNi)./(1-xa))));
  %driving = ((gas * tk)/vmol)*((xc.*log(xbinst./xa)));
  %  driving = driving - 2.14e8;
  driving = ((gas * tk)/vmol_FeNi)*((xc.*log(xbinst./xa))+((1-xc).*log((1-xbinst)./(1-xa))));
%
%fec = (1/c2) * (2 * sfen) * driving

%
% Modify driving force by strain energy
%stren = strain_co(0.017,0.34,0.31,48e9,75e9);
   stren = 0;
%
   resdrive_FeNi = driving_FeNi - stren;
   rc_FeNi = (2 * sfen_FeNi)./(resdrive_FeNi);
%
% Limit maximum rc
%if rc > 1e-3, rc = 1e-3; end
return