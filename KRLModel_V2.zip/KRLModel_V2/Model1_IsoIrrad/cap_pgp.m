%
% Calculates CAP and PGP for a
% range of t,Tks
% Empirical parameters PGP and CAP
% Garzarolli et al. 
%
QR_cap = 40e3; % This is standard value from Garzarolli
% QR_cap = 17e3; % Value from model that causes rbar values to collapse
% PGP
k_pgp = 1e14./3600; % PGP rate factor
TA_pgp = 3.2e4;
k_socap = 1.11e-11; % SOCAP rate factor
QR_socap = 18.7e3; % SOCAP activation energy
t = logspace(0,6);
tkt = linspace(300,800) + 273;
for i=1:100
    disp([num2str(i)])
    tk = tkt(i);
    cap(i,1:50) = (t .* exp(-QR_cap .* (1./tk)))./3600;
    pgp(i,1:50) = k_pgp .* t .* exp(-TA_pgp./tk);
    socap(i,1:50) = (k_socap./tk.^2) .* exp(-QR_socap.*(1./tk)) .* t;
end