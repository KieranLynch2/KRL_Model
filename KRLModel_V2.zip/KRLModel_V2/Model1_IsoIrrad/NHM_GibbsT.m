% function [drdt,EqRad] = NHM(rb,d,xb,xc_a,vat,n,phi,n_clust,xc_clust,xc,vf_crat,vf_arat,vf_clustrat)

% Nelson RS, Hudson JA, Mazey DJ. J Nucl Mater. 1972 Sep 1;44(3):318–30. 
% Was GS. Fundamentals of radiation materials science: Metals and alloys, second edition. 2016 Jan 1;1–1002. 

 %if xc was left as 0.66 the mass balance with volume fractions would be off. Need vfs of each cryst,amorph,clust, beacuse then you know the total concentration of solute reatined in precipitates
% xc_avg = (xc*vf_crat)+(xc_a*vf_arat)+(xc_clust*vf_clustrat);


%rho should in fact be the number density of each individual bin associated
%with r bins. Best way to do this is to load in some arbitray data, so
%let's start with Bajaj pre-irradiation stuff.

load Bajaj_dbar240.mat
% load Valizadeh.mat %Remember xb is different for this one!

r=r_ln;
n = n_ln.*1;

rb=r; %Set this for now as the n array has to match the dimensions of r, and it doesn't match rb as rb is 1 more.

xc_avg = 0.66; %Set for now 

phi = 1e14;

%xc must infiact be the average composition of all precipiates and clusters
%This means that it needs to be determined using the core composition of
%SPPs, the shell composition of SPPs, + the composition of cluseters (which
%can vary quite a bit)
%alreadu have calculated xc_avg for amorphous SPPs, so just need to average
%again with clusters!

zeta = 1e18; %neeeded to convert dpa to atomic flux, quoted in NHM paper, n.b. 10^18 as we are working in metres

%Might need a function to convert fluence to dpa (estimation)
% k0 = 1.2e-7; %dpa/s
k0 = phi./(5e20); %Conversion from flux to dpa/s


% molmass = 143.9*1e-3; %convert from g/mol to kg/mol, to get si units of density
%This is an estimate of the molar mass of the amorphous phase - currently crystalline phase
% vmol = 9e-6; %TEMP
% rho = molmass/vmol; %density of the amorphous phase

%rho is actaully the PRECIPITATE DENSITY, i.e. number of precipitates per
%unit volume
%use the output of npart, which has the number of particles per um3, so
%need to multiply it by 1e18.
%for now, from the bajaj output the final number density is 2.18 SPPs/um3.
% rho = sum(n).*500;%.*0.0001;
% 
% Clusters = 1e23; %In future need to determine an estimate for the number of clusters as a function of fluence + temp, probably related to amorphization rate and solute conc in matrix.
% rho = sum(n) + Clusters;


% rho = sum(n)+sum(n_clust); %NEED TO ADD IN N_CLUST THROUGH FUNCTIONS

% d = d.*6e-6; %n.b. low temperature diffusion of Fe+Cr is not well studied...
%does d evolve with time as the number of dislocations changes?
% d = 1e-23;

sfen = 0.22;
vmol = 9e-6;
Rg = 8.314;
% rb = 1:1:500;
% rb = rb.*1e-9;
tk = 573;
na = 6.022045e23;
vat = vmol./na;
% xa = 1e-5;
xa = exp((-5.4e3./tk)-3.3).*1e0; 

% d = 1e-20;
xb = 0.0051;
% xbinst = 0.001;

drdtout = [];
drdtoutog = [];
drdtoutNew = [];
grout = [];
rc_cryst = 1e-9;

% rb = 100e-9;

%rho should in fact be the number density of each individual bin associated
%with r bins. Best way to do this is to load in some arbitray data, so
%let's start with Bajaj pre-irradiation stuff.

% n=1e20;
% rho=n;
for d = [1e-19,1e-20]

DissFac = 100;

% d=1e-19;

delta = exp((2.*sfen.*vmol)./(rb.*Rg.*tk));

% delta = ((xbinst./xa).^((rc_cryst)./rb));

% rho = 1e20;

% delta = 1;

xr = xa.*delta;

Diss = (-zeta.*k0.*vat);
% Growth = ((((xb-((4/3).*pi.*(rb(200).^3).*n(200).*xc_avg))-xr)./(xc_avg-xr)).*(d./rb(200)));

% Growth = ((((xb-(sum((4./3).*pi.*(rb.^3).*n.*xc_avg)))-xr)./(xc_avg-xr)).*(d./rb));
% Growth=((-d.*xr)-((-d.*xb)+(d.*sum((4/3).*pi.*rb.^3.*n.*xc)))./rb);
Growth = ((((xb-(sum((4/3).*pi.*(rb.^3).*n.*xc_avg)))-xr)./(xc_avg-xr)).*(d./rb));
Growthog = ((3.*d.*xb)./(4.*pi.*rb.*xc_avg))-((rb.^2).*d.*rho);

drdtNew = (-zeta.*k0.*vat.*DissFac)+((((xb-(sum((4/3).*pi.*(rb.^3).*n.*xc_avg)))-xr)./(xc_avg-xr)).*(d./rb));
% drdtNew = (-zeta.*k0.*vat.*5e2)+((-d.*xr)-((-d.*xb)+(d.*sum((4/3).*pi.*rb.^3.*n.*xc)))./rb);

drdt = (-zeta.*k0.*vat)+((3.*d.*xb.*delta)./(4.*pi.*rb.*xc_avg))-((rb.^2).*d.*rho.*delta);

drdtog = (-zeta.*k0.*vat)+((3.*d.*xb)./(4.*pi.*rb.*xc_avg))-((rb.^2).*d.*rho);

drdtout = [drdtout; drdt];

drdtoutog = [drdtoutog; drdtog];

drdtoutNew = [drdtoutNew; drdtNew.*1];

grout = [grout; Growth];
end

for j = 1:1:2
plot(rb.*1e9,drdtoutNew(j,:),'-','LineWidth',2);
hold on
end

% for j = 1:1:2
% plot(rb.*1e9,drdtoutog(j,:),'--','LineWidth',2);
% hold on
% end

yscale_symlog;
set(gca,'Fontsize',18)
xlabel('SPP radius / nm')
ylabel('dr/dt / ms^{-1}')

xlim([0 500])

legend('Diffusivity = 1\times10^{-19}','Diffusivity = 1\times10^{-20}')
set(gca,'XScale','log')

% legend('\beta = 50','\beta = 100','\beta = 500')

%Find equilibrium radius
% negind = find(drdt>0);
% EqRad = rb(max(negind));


% drdt = drdt.*1e-2;

%radiation enhanced diffusion? i.e. D+D'
%     [drad] = diffrad(d,tk,phi);
%by decreasing D the growth and dissolution gets smaller... use this as the
%fitting parameter, with justification from the work of Burr et al... etc.
%d will likely change with flux and T due to point defect production and
%disolocation formation... it will be a complext combination of the two.
%increased flux increases both of them so D will increase which leads to
%enhanced dissolution - WHICH IS GOOD 
%Increased T will increase D (standard D) which is the opposite to seen
%effects, however this increase in T might alter Dirrad as increased T
%leads to more annealing of point defect/disolcations thus reducing Dirrad.
%It will be a fine balance between the effects.

%Next step is to try this on Zircaloy-2 Fe-Ni SPPs, where D is higher and
%has different compositions etc.

% end
%% This is for trial and error plotting
% 
% rho = 2e18.*500; %SPPs/m3
% vat = 1.494508925124273e-29;
% 
% xc = 0.51;
% xb = 0.0051;
% 
% rb = 0.1:0.1:500;
% rb = rb.*1e-9;
% 
% zeta = 1e18; %neeeded to convert dpa to atomic flux, quoted in NHM paper, n.b. 10^18 as we are working in meters
% 
% % Might need a function to convert fluence to dpa (estimation)
% k0 = 1.2e-7; %dpa/s
% 
% dout = [];
% drdtout = [];
% for tc = 260:30:350
%     tk = tc+273;
%         d = (6e-7 * exp(-15930/(tk)).*1e-4);
%         drdt = (-zeta.*k0.*vat)+((3.*d.*xb)./(4.*pi.*rb.*xc))-((rb.^2).*d.*rho);
%         %     drdt = ((-zeta.*k0)./(Natoms))+((3.*d.*xb)./(4.*pi.*rb.*xc))-((rb.^2).*d.*rho);
%         dout = [dout d];
%         drdtout = [drdtout; drdt];
% end
% 
% 
% 
% % 
% for j = 1:1:4
% %     semilogy(rb.*1e9,drdtout(j,:),'LineWidth',2)
%     plot(rb.*1e9,drdtout(j,:),'-','LineWidth',2);% yscale_symlog;
%     hold on
% end
% 
% 
% legend(['260 ' char(176) 'C'],['290 ' char(176) 'C'],['320 ' char(176) 'C'],['350 ' char(176) 'C'])
% % legend('1e5 - 275 C','1e10 - 275 C','1e15 - 275 C','1e20 - 275 C')
% % plot(rb.*1e9,drdtout(j,:),'LineWidth',2); yscale_symlog;
% yscale_symlog;
% set(gca,'Fontsize',18)
% xlabel('SPP radius / nm')
% ylabel('dr/dt / ms^{-1}')
% 
% %could try and plot dissolution rates using their absolute values and just
% %change the plot line to a dash 
% % ylim([-0.5 3e-13])
% 
% 
% 
% % %recreating the NHM paper data:
% % 
% % dout = [];
% % drdtout = [];
% % for tk = 523:20:623
% %     d = 6e-14;
% %     drdt = (-zeta.*k0.*vat)+((3.*d.*xb)./(4.*pi.*rb.*xc))-((rb.^2).*d.*rho);
% % %     drdt = ((-zeta.*k0)./(Natoms))+((3.*d.*xb)./(4.*pi.*rb.*xc))-((rb.^2).*d.*rho);
% %     dout = [dout d];
% %     drdtout = [drdtout; drdt];
% % end