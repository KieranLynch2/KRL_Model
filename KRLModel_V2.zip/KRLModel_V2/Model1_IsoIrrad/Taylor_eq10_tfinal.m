function [ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb] = Taylor_eq10_tfinal(tk,tfinal,phi,r,rb)

% Outputs:
% ram_total_end_r - The final size of the crystalline cores centres of SPP bins
% ram_total_end_rb - The final size of the crystalline core edges of SPP bins
% time_amorph - The time taken to achieve the level of amorphization predcited by the Taylor model in the current conditions 
% time_amorphrb - The time taken to achieve the level of amorphization predcited by the Taylor model in the current conditions for bin edges




T = tk;
t = tfinal;
R_t_init = r*1e9;

beta = 2.37e-3;
D = 2.34e-20;
estarR = 11600;
kx = 27;
kphi = 9.6e-22;

a0 = (exp((log(phi))-(log(kx/kphi))+(estarR*(1/T)))/(exp((log(phi))-(log(kx/kphi))+(estarR*(1/T)))+1));

lenR = length(R_t_init);
r_core = [];
ram_amorphout = [];
    for i = 1:1:lenR

        R_t = R_t_init(i);
    
        B = beta./(3.*(R_t.^2));
        a = (D*phi).*(((B.*(R_t.^3))-a0));
        b = -D.*phi.*B;
        k = ((a0./B)-(R_t.^3)).^(1/3);
        
        
    if R_t > 0
        syms r_t

%         eqn = ((k./(6.*a)).*log(((k+r_t).^2)./((k.^2)-(k.*r_t)+(r_t.^2))))+((k./(a.*sqrt(3))).*(atan(((2.*r_t)-k)./(k.*sqrt(3)))))-((k./(6.*a)).*(log(((k+R_t).^2)/((k.^2)-(k.*R_t)+(R_t.^2)))))-((k./(a.*sqrt(3))).*atan(((2.*R_t)-k)./(k.*sqrt(3)))) == t;

        eqn = t == ((k/(6*a))*log(((k+r_t)^2)/((k^2)-(k*r_t)+(r_t^2))))+((k/(a*sqrt(3)))*(atan(((2*r_t)-k)/(k*sqrt(3)))))-((k/(6*a))*(log(((k+R_t)^2)/((k^2)-(k*R_t)+(R_t^2)))))-((k/(a*sqrt(3)))*atan(((2*R_t)-k)/(k*sqrt(3))));


        S = vpasolve(eqn,r_t);
%         SS = solve(eqn,r_t);

if isempty(S)
    if isempty(r_core)
        S = 0;
        disp(['vpasolve has failed for SPP size ' num2str(R_t) ' nm, r_core is set the previous bin size'])
    else
        S = r_core(end);
        disp(['vpasolve has failed for SPP size ' num2str(R_t) ' nm, r_core is set the previous bin size'])
    end
    %This little fix is only needed for really small SPP sizes <0.5 nm so
    %it should not affect results. Worth keeping an eye on every time
    %though.
end

        tf = isreal(S);
        if tf == 0
            aaa = 4;
            disp(['Complex number in Taylor eq. 10, SPP sizes beyond ' num2str(R_t) ' nm are not valid and ram is set as dummy values'])
            %This dummy value will be the radius of amoprhization for the
            %last valid bin applied to all larger sizes.
            %Last valid bin's radius of amorphization
            rout = R_t_init(i) - ram_amorphout(end);
        end

        if tf == 1
            rout = 0;
            rout(1) = S;
        end
        if rout < 0
            rout = 0;
        end
    else 
        rout = 0;
    end
         r_core = [r_core rout]; %this is the size of the crystalline cores after amorphization
         ram_amorph = R_t - rout;
         ram_amorphout = [ram_amorphout ram_amorph];
    end
    ram_total_end_r = r*1e9 - r_core; 
    ram_total_end_r = ram_total_end_r*1e-9;
    
    %I could also calculate the time taken for amorphization to be complete
    %for those SPPs which undergo complete amorphization. This can then
    %feed into the amorphization rates which will be faster for the smaller
    %SPPs, and for the larger ones where amorphization is not complete, a
    %constant amorphization rate will be determined for each bin based on
    %the total time and the amorphous zone width.
    %Could just do time to complete amorphization for every bin to
    %determine individual amorphization rates using the remaining time in
    %reactor to acheive full amorphization and some maths.

    time_amorph = [];
    for i = 1:1:length(R_t_init)
        
        R_t = R_t_init(i);
        r_t = r_core(i); %core = 0;
        
        B = beta./(3.*(R_t.^2));
        a = (D*phi).*(((B.*(R_t.^3))-a0));
        b = -D.*phi.*B;
        k = ((a0./B)-(R_t.^3)).^(1/3);
        
        
        
        t = ((k/(6*a))*log(((k+r_t)^2)/((k^2)-(k*r_t)+(r_t^2))))+((k/(a*sqrt(3)))*(atan(((2*r_t)-k)/(k*sqrt(3)))))-((k/(6*a))*(log(((k+R_t)^2)/((k^2)-(k*R_t)+(R_t^2)))))-((k/(a*sqrt(3)))*atan(((2*R_t)-k)/(k*sqrt(3))));
        
        tft = isreal(t);
        if tft == 0
            disp(['Complex number in Taylor eq. 10, SPP sizes beyond ' num2str(R_t) ' nm are not valid and time is set as dummy values'])
            t = time_amorph(end);
        end
        
        
        time_amorph = [time_amorph t];
    end
    
    
    
%% bin edge adjustment
    
    lenrb = length(rb);
    Rb_t_init = rb*1e9; %convert to nm for Taylor eq.
rb_core = [];
ramb_amorphout = [];
trb = tfinal;
    for i = 1:1:lenrb

        Rb_t = Rb_t_init(i);
    
        B = beta./(3.*(Rb_t.^2));
        a = (D*phi).*(((B.*(Rb_t.^3))-a0));
        b = -D.*phi.*B;
        k = ((a0./B)-(Rb_t.^3)).^(1/3);
        
        
    if Rb_t > 0
        syms rb_t

%         eqn = ((k./(6.*a)).*log(((k+r_t).^2)./((k.^2)-(k.*r_t)+(r_t.^2))))+((k./(a.*sqrt(3))).*(atan(((2.*r_t)-k)./(k.*sqrt(3)))))-((k./(6.*a)).*(log(((k+R_t).^2)/((k.^2)-(k.*R_t)+(R_t.^2)))))-((k./(a.*sqrt(3))).*atan(((2.*R_t)-k)./(k.*sqrt(3)))) == t;

        eqn2 = trb == ((k/(6*a))*log(((k+rb_t)^2)/((k^2)-(k*rb_t)+(rb_t^2))))+((k/(a*sqrt(3)))*(atan(((2*rb_t)-k)/(k*sqrt(3)))))-((k/(6*a))*(log(((k+Rb_t)^2)/((k^2)-(k*Rb_t)+(Rb_t^2)))))-((k/(a*sqrt(3)))*atan(((2*Rb_t)-k)/(k*sqrt(3))));


        S = vpasolve(eqn2,rb_t);
%         SS = solve(eqn,r_t);

if isempty(S)

    if isempty(rb_core)
        S = 0;
        disp(['vpasolve has failed for SPP edge size ' num2str(R_t) ' nm, rb_core is set the previous bin edge size'])
    else
        S = rb_core(end);
        disp(['vpasolve has failed for SPP edge size ' num2str(R_t) ' nm, rb_core is set the previous bin edge size'])
    end
    %This little fix is only needed for really small SPP sizes <0.5 nm so
    %it should not affect results. Worth keeping an eye on every time
    %though.
end

        tf = isreal(S);
        if tf == 0
            aaa = 4;
            disp(['Complex number in Taylor eq. 10, SPP sizes beyond ' num2str(Rb_t) ' nm are not valid and ram_rb is set as dummy values'])
            %This dummy value will be the radius of amoprhization for the
            %last valid bin applied to all larger sizes.
            %Last valid bin's radius of amorphization
            rbout = Rb_t_init(i) - ramb_amorphout(end);
        end
        
        if tf == 1
            rbout = 0;
            rbout(1) = S;
        end
        if rbout < 0
            rbout = 0;
        end
    else 
        rbout = 0;
    end
         rb_core = [rb_core rbout]; %this is the size of the crystalline cores after full amorphization
         ramb_amorph = Rb_t - rbout;
         ramb_amorphout = [ramb_amorphout ramb_amorph];
    end
    ram_total_end_rb = rb*1e9 - rb_core; 
    ram_total_end_rb = ram_total_end_rb*1e-9;
    
    %I could also calculate the time taken for amorphization to be complete
    %for those SPPs which undergo complete amorphization. This can then
    %feed into the amorphization rates which will be faster for the smaller
    %SPPs, and for the larger ones where amorphization is not complete, a
    %constant amorphization rate will be determined for each bin based on
    %the total time and the amorphous zone width.
    %Could just do time to complete amorphization for every bin to
    %determine individual amorphization rates using the remaining time in
    %reactor to acheive full amorphization and some maths.

    time_amorphrb = [];
    for i = 1:1:length(Rb_t_init)
        
        Rb_t = Rb_t_init(i);
        rb_t = rb_core(i); %core = 0;
        
        B = beta./(3.*(Rb_t.^2));
        a = (D*phi).*(((B.*(Rb_t.^3))-a0));
        b = -D.*phi.*B;
        k = ((a0./B)-(Rb_t.^3)).^(1/3);
        
        trb = ((k/(6*a))*log(((k+rb_t)^2)/((k^2)-(k*rb_t)+(rb_t^2))))+((k/(a*sqrt(3)))*(atan(((2*rb_t)-k)/(k*sqrt(3)))))-((k/(6*a))*(log(((k+Rb_t)^2)/((k^2)-(k*Rb_t)+(Rb_t^2)))))-((k/(a*sqrt(3)))*atan(((2*Rb_t)-k)/(k*sqrt(3))));

        tft = isreal(trb);
        if tft == 0
            disp(['Complex number in Taylor eq. 10, SPP sizes beyond ' num2str(Rb_t) ' nm are not valid and time_rb is set as dummy values'])
            trb = time_amorphrb(end);
        end
        
        
        time_amorphrb = [time_amorphrb trb];
    end
    
    

%Apply Taylor's more simple equation of uniform amorphization if eq.10
%fails with complex numbers at too low SPP radii.
%This is equation 8 from his first paper
% Dtay = 2.43e-20; %nm*cm2/n - Flux assisted diffusion coefficient
% beta = 2.37e-3; %/nm - Normalizing constant
% ram = (a0/beta).*(1-exp(-beta.*Dtay.*phi.*tfinal));
    
    
    
    
    
    
    

% lenRb = length(rb);
% 
% Rb_t_init = rb*1e9; %convert to nm for Taylor eq.
% rb_core = [];
%     for j = 1:1:lenRb
%     
%         Rb_t = Rb_t_init(j);
%     
%         B = beta./(3.*(Rb_t.^2));
%         a = (D*phi).*(((B.*(Rb_t.^3))-a0));
%         b = -D.*phi.*B;
%         k = ((a0./B)-(Rb_t.^3)).^(1/3);
% 
%     if Rb_t > 0
%         syms rb_t
% 
%         eqn2 = ((k./(6.*a)).*log(((k+rb_t).^2)./((k.^2)-(k.*rb_t)+(rb_t.^2))))+((k./(a.*sqrt(3))).*(atan(((2.*rb_t)-k)./(k.*sqrt(3)))))-((k./(6.*a)).*(log(((k+Rb_t).^2)/((k.^2)-(k.*Rb_t)+(Rb_t.^2)))))-((k./(a.*sqrt(3))).*atan(((2.*Rb_t)-k)./(k.*sqrt(3)))) == t;
% 
% 
%         Srb = solve(eqn2,rb_t);
% 
% 
%         rbout = 0;
%         rbout(1) = Srb;
%         if rbout < 0
%             rbout = 0;
%         end
%     else
%         rbout = 0;
%     end
%         rb_core = [rb_core rbout];
%     end
%     ram_total_end_rb = rb*1e9 - rb_core; %convert all to nm
%     ram_total_end_rb = ram_total_end_rb*1e-9; %convert back to m
%     
%     %Currently, all the SPPs which are fully amorphized at the end of
%     %simulation approach zero nm crystalline radius at the same time,
%     %wheras the smaller SPPs will reach zero first
end