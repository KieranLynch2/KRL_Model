function [ram,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,ramtot] = amorph_depth_taylor(h,ram,phi,alpha0,mu,tfinal_step,tk,r,rb,firstit,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,ramtot,tauamorph,Motta,Taylor)

if Taylor == 1

    %Taken from Taylor (1999) paper - for times, temperatures and flux typical of commercial reactors

    % mu = 1; %de-comment this when you want amorphous dissolution off %Should
    %use the calcuated input of mu generally

    Dtay = 2.43e-20; %nm*cm2/n - Flux assisted diffusion coefficient
    %phi = 2.48e13; %n/cm2/s - Flux
    %alpha0 = 0.76; %constant taken from paper
    beta = 2.37e-3; %/nm - Normalizing constant
    kx = 27;
    kphi = 9.6e-22;
    estarR = 11600;

    alpha0 = exp((log(phi))-(log(kx/kphi))+(estarR*(1/tk)))/(exp((log(phi))-(log(kx/kphi))+(estarR*(1/tk)))+1);

    ram = ram*1e9; %Need to convert the input ram (m) back into nm for use in the equation below
    %After it has been used (in nm) in the equation it is then converted back
    %to m for the output.

    %Need/can change this function by introducing an incubation period
    %Can also adjust this to account for amorphous zone dissolution

    % ram = 1e-9*(h*(mu*((Dtay*phi)*(alpha0-(beta*ram))))); %ram from Taylor is in nm by default, so need to be converted to m

    ramfinal = (alpha0./beta).*(1.-exp(-beta.*Dtay.*phi.*tfinal_step));

    % mu is used to enahnce amorphizatino to account for incubation time.
    tpostinc = tfinal_step - tauamorph;
    if tpostinc < 0
        tpostinc = 0;
    end
    orig_ramrate = ramfinal./tfinal_step;
    New_ramrate = ramfinal./tpostinc;
    mu = New_ramrate./orig_ramrate;
    if isinf(mu)
        mu = 0;
    end

%     ramog = (alpha0./beta).*(1.-exp(-beta.*Dtay.*phi.*h));
% 
%     ramtot = mu.*ramog.*1e-9;
% 
%     ram = ramtot;

    ram = New_ramrate.*h.*1e-9;

elseif Motta == 1

    rammot = amorph_depth(h,phi);
    ramfinal = amorph_depth(tfinal_step,phi);
    tpostinc = tfinal_step - tauamorph;
    if tpostinc < 0
        tpostinc = 0;
    end
    orig_ramrate = ramfinal./tfinal_step;
    New_ramrate = ramfinal./tpostinc;
    mu = New_ramrate./orig_ramrate;
    if isinf(mu)
        mu = 0;
    end
    ram = rammot*mu;

end

end

%% Alternative way to calculate the radius of amorphization using Eq. 10 from Taylor's second paper

%Rather than using mu calculated from the simple Griffith's relationship, I
%need to estiamte the quantity to increase ram by at each iteration based
%on the current iteration dissolution rate.

% if firstit == 0
% [ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb] = Taylor_eq10_tfinal(tk,tfinal,phi,r,rb);
% end

%% Just doing amorph depth calcs without running full scripts

% phi = 0.6e14; %n/cm2/s - Flux
% T = 320+273;
% tk = T;
% flu = 1.6e22;
% tfinal = flu./phi;
%
% beta = 2.37e-3; %/nm - Normalizing constant
% Dtay = 2.43e-20; %nm*cm2/n - Flux assisted diffusion coefficient
%
% kx = 27;
% kphi = 9.6e-22;
% estarR = 11600;
%
%
% alpha0 = exp((log(phi))-(log(kx/kphi))+(estarR*(1/T)))/(exp((log(phi))-(log(kx/kphi))+(estarR*(1/T)))+1);
%
% ram = (alpha0./beta).*(1.-exp(-beta.*Dtay.*phi.*tfinal));
%
% tout_330_12 = [];
% fluence_330_12 = [];
% ramout_330_12 = [];
% ram = 0;
%
%
% kphi = 6.307e27*(tk^-17.65);
% tauamorph = 1/(kphi * phi);
% tau_days = tauamorph./86400;
% tau_Fluence_330_12 = tau_days.*86400.*phi;
%
%
% for h = 0:100000:tfinal
%     ram = 1e-9*(h*(((Dtay*phi)*(alpha0-(beta*ram)))));
%
%     tout_330_12 = [tout_330_12 h];
%     fluence_330_12 = [fluence_330_12 h.*phi];
%     ramout_330_12 = [ramout_330_12 ram.*1e9];
% end
%
% plot(fluence,ramout);


% end