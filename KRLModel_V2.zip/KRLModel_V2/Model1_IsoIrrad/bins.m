scale = 1e-10;  
 % steps is number of bins per decade
  steps = 30;
% mindec is lowest log10(radius) in nM
  mindec = 0;
% ndec is number of decades to cover
  ndec = 9;
% number of bin edges
  nb = ndec*steps+1;
  if exist('n','var')==0
      % get bin edges
    rb = logspace(mindec,mindec+ndec,nb);
    % rb = logspace(mindec,mindec+ndec,nb);
    % get bin centers in the geometric sense
    % r = 10.^(0.5*log10(rb(1:nb-1))+0.5*log10(rb(2:nb)));
    r = 10.^(0.5*log10(rb(1:nb-1))+0.5*log10(rb(2:nb)));
    % scale to M
    % linear size binning
    %scale = 1.5e-7;
    %% Below for predictions for Aaronson paper
    %rb = linspace(0,1,5000);
    %rb = linspace(0,3200,1601);
    %r = ((rb(1:end-1)+rb(2:end))./2);
    rb = (rb*scale);
    r = (r*scale);
    len = length(r);
    n(1:len) = 0;
  end