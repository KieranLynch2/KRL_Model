%
% Script to run irradiation model and store psd at different times
%
%
clear all
% times to run for (in s)
t_aim = [5e5 2.76e7 365.25*24*3600];
%
% Run without irradiation for 3 times
%
load 'alpha_annealed_massih.mat'
[r,rb,tk,d,tfinal,xb,xc,xa,sfen,nsites,vmol,vmax,a,a_init]=zr_amorph_init(307,t_aim(1)./3600);
d = diffco_cr(tk);
[r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump]=zr_amorph_kin(r,n,rb,tk,tfinal,d,xa,xb,xc,sfen,nsites,vmol,a,a_init,0);
n_ni_1 = n;
%
%
%
load 'alpha_annealed_massih.mat'
[r,rb,tk,d,tfinal,xb,xc,xa,sfen,nsites,vmol,vmax,a,a_init]=zr_amorph_init(307,t_aim(2)./3600);
d = diffco_cr(tk);
[r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump]=zr_amorph_kin(r,n,rb,tk,tfinal,d,xa,xb,xc,sfen,nsites,vmol,a,a_init,0);
n_ni_2 = n;
%
%
%
load 'alpha_annealed_massih.mat'
[r,rb,tk,d,tfinal,xb,xc,xa,sfen,nsites,vmol,vmax,a,a_init]=zr_amorph_init(307,t_aim(3)./3600);
d = diffco_cr(tk);
[r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump]=zr_amorph_kin(r,n,rb,tk,tfinal,d,xa,xb,xc,sfen,nsites,vmol,a,a_init,0);
n_ni_3 = n;
%
% Run with irradiation for 3 times
%
load 'alpha_annealed_massih.mat'
[r,rb,tk,d,tfinal,xb,xc,xa,sfen,nsites,vmol,vmax,a,a_init]=zr_amorph_init(307,t_aim(1)./3600);
d = diffco_cr(tk);
[r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump]=zr_amorph_kin(r,n,rb,tk,tfinal,d,xa,xb,xc,sfen,nsites,vmol,a,a_init,1);
n_i_1 = n;
%
%
%
load 'alpha_annealed_massih.mat'
[r,rb,tk,d,tfinal,xb,xc,xa,sfen,nsites,vmol,vmax,a,a_init]=zr_amorph_init(307,t_aim(2)./3600);
d = diffco_cr(tk);
[r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump]=zr_amorph_kin(r,n,rb,tk,tfinal,d,xa,xb,xc,sfen,nsites,vmol,a,a_init,1);
n_i_2 = n;
%
%
%
load 'alpha_annealed_massih.mat'
[r,rb,tk,d,tfinal,xb,xc,xa,sfen,nsites,vmol,vmax,a,a_init]=zr_amorph_init(307,t_aim(3)./3600);
d = diffco_cr(tk);
[r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump]=zr_amorph_kin(r,n,rb,tk,tfinal,d,xa,xb,xc,sfen,nsites,vmol,a,a_init,1);
n_i_3 = n;