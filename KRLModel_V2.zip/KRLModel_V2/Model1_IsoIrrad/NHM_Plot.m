% function [drdt] = NHM(rb,d,xb,xc,vat,vmol)
% 
% % Nelson RS, Hudson JA, Mazey DJ. J Nucl Mater. 1972 Sep 1;44(3):318�30. 
% % Was GS. Fundamentals of radiation materials science: Metals and alloys, second edition. 2016 Jan 1;1�1002. 
% 
% 
load 'Bajaj_dbar240.mat'
xa = exp((-5.4e3./tk)-3.3).*1; 
xbinst = (xb - ((xc - xa) * vfout(end))).*1;
% 
% rb = r_ln;
% rho = n_ln;

% load Bajaj_dbar133.mat

% rb = r./2;
rho = n.*1;


rb = r./1;

zeta0 = 4.5e20; %neeeded to convert dpa to atomic flux, quoted in NHM paper, n.b. 10^18 as we are working in meters
zeta = zeta0.*(1-exp(-2e7.*r));
% zeta = zeta0;

% 
% %Might need a function to convert fluence to dpa (estimation)
% k0 = 1e-7; %dpa/s
% phi = 0.368e14;
phi = 0.68e14;

k0 = phi./(5e20);
% molmass = 143.9*1e-3; %convert from g/mol to kg/mol, to get si units of density
% %This is an estimate of the molar mass of the amorphous phase - currently crystalline phase
vmol = 9e-6; %TEMP
% % rho = molmass/vmol; %density of the amorphous phase
% 
% %rho is actaully the PRECIPITATE DENSITY, i.e. number of precipitates per
% %unit volume
% %use the output of npart, which has the number of particles per um3, so
% %need to multiply it by 1e18.
% %for now, from the bajaj output the final number density is 2.18 SPPs/um3.
% % rho = 2e18;%+5e23;
% 
na = 6.022045e23;
vat = vmol/na;
% 
% %Temp parameters just to plot effects
xb = 0.0051;
% rb = (0.02:0.02:500).*1e-9;
% 
% rb = (1:1:500).*1e-9;
% % d = 6e-7 * exp(-15930/(tk));
% % d = 5.0619e-19; %d at 300 C
% % xc = (0.25+0.26);
% 
xc = 0.66;
% 
% %radiation enhanced diffusion? i.e. D+D'
% %     [drad] = diffrad(d,tk,phi);
% %by decreasing D the growth and dissolution gets smaller... use this as the
% %fitting parameter, with justification from the work of Burr et al... etc.
% %d will likely change with flux and T due to point defect production and
% %disolocation formation... it will be a complext combination of the two.
% %increased flux increases both of them so D will increase which leads to
% %enhanced dissolution - WHICH IS GOOD 
% %Increased T will increase D (standard D) which is the opposite to seen
% %effects, however this increase in T might alter Dirrad as increased T
% %leads to more annealing of point defect/disolcations thus reducing Dirrad.
% %It will be a fine balance between the effects.
% 
%Next step is to try this on Zircaloy-2 Fe-Ni SPPs, where D is higher and
%has different compositions etc.
% xa = 1e-5;
dout = [];
drdtout = zeros(1,1000);
drdtout = [];
drdtout_temp = [];
rhout = [];
rhout_temp = []; 

y = logspace(18,24,1000);
y = 1e18;
% rho = n_ln;
 %rho values saved: [1e23,5e23,10e23]%[1e18,5e18,1e19,3e19,6e19]%[1e23,5e23,10e23]%
% for %rb = [50,100,200].*1e-9
    drdtout_temp = [];
%     rhout_temp = []; 
% rho = 1e18;
EqRadout = [];
tk = 360+273;
%         for d = [ 1.0895e-19,4.3582e-22,2.2026e-18, 8.8102e-21] %Continue fitting the final D to Bajaj data, can probs be better
        for d = (6e-7 * exp(-(15930*1.0)/(tk))).*1e-4 %4e-3
% tk = 300+273;
%         d = (6e-7 * exp(-(15930*1.0)/(tk))).*1e-2;
%         xa = exp((-5.4e3./tk)-3.3); 
%     rho = 1e23;
%         tk = 300+273;
%         d = (6e-7 * exp(-15930/(tk)).*1e-0);
%         rb = 100.*1e-9;
%         drdt = ((3.*d.*xb)./(4.*pi.*rb.*xc))-((rb.^2).*d.*rho);
        beta = (1./(1+exp(0.065.*(tk-585))));
        beta = 1;
xbinst = 0.5;
        drdt = (-zeta.*k0.*vat.*beta)+((3.*d.*xbinst)./(4.*pi.*rb.*xc));


        %     drdt = ((-zeta.*k0)./(Natoms))+((3.*d.*xb)./(4.*pi.*rb.*xc))-((rb.^2).*d.*rho);

% drdtMOD = (-zeta.*k0.*vat)+((d.*xb)./(rb.^2.*xc))-((4/3).*d.*pi.*rb.*rho)-((d.*xa)./(rb.^2.*xc)); %Edited on principal from Zhao 2022
% drdtMOD2 = (-zeta.*k0.*vat)+(((4.*pi.*d).*((xb-((4/3).*pi.*(rb.^3).*xc.*rho))-xa))./(xc));

bracket = xb-((4/3).*pi.*(rb.^3).*rho.*xc)-xa.*5e2;
drdtMOD = (-zeta.*k0.*vat)+((d).*bracket)./((rb).*xc);

% bracket2 = xb-((4/3).*pi.*(rb.^3).*rho.*xc)-0.005;
% drdtMOD2 = (-zeta.*k0.*vat)+((d).*bracket2)./((rb).*xc);

drdtMOD3 = (-zeta.*k0.*vat)+(((d.*xb)-(d.*xa))./(rb.*xc))-((4/3).*pi.*(rb.^2).*d.*rho);

% drdtMOD3 = (((d.*xb)-(d.*xa))./(rb.*xc))-((4/3).*pi.*(rb.^2).*d.*rho);


NHMGROWTH = (((d.*xb)-(d.*xa))./(rb.*xc))-((4/3).*pi.*(rb.^2).*d.*rho);

xr = xa;
vf = sum((4/3).*pi.*(rb.^3).*rho);
xbinst = xb - ((xc - xa) * vf);
KWNgrowth = ((xbinst - xr)./(xc - xr)) .* (d./rb);

sfen = 0.22;
gas = 8.314;
tk = 573;
xrgt = xa.*exp((2 .* sfen .* vmol)./(rb.*gas .* tk));
KWNGT = ((xbinst - xrgt)./(xc - xrgt)) .* (d./rb);


q = 50; % Mixing rate - take this as 50 for now, can be determined more accurately with rpa calculations
phi = k0; % Dose rate (dpa/s)
lam = 8e-10; % Average displacement distance - take as 5 nm for now, again atomistic sims can help here
xa = exp((-5.4e3./tk)-3.3).*1e0; 
rg = 8.314;

delta = (q.*phi.*(lam.^2))./(d.*xa);
R_cap = (2.*sfen.*vmol)./(rg.*tk);  
R_i_cap = ((4.*R_cap)-(5.*lam.*delta))./(4.*(1+delta));
Ci = xa.*(1+delta);
ModGT = Ci.*(1+(R_i_cap./rb));

% xbinst=xbinst.*1e2;

% drdt = (-zeta.*k0.*vat)+(((xbinst - ModGT)./(xc - ModGT)) .* (d./rb));
% drdt = (((xbinst - ModGT)./(xc - ModGT)) .* (d./rb));
% drdt = (-zeta.*k0.*vat)+(((xbinst - KWNGT)./(xc - KWNGT)) .* (d./rb));
% drdt=((xbinst - xr)./(xc - xr)) .* (d./rb);

% bracket3 = (xb-(4/3).*pi.*(rb.^3).*rho
% drdtMOD3 = (-zeta.*k0.*vat)+

%Frost and Russell
% rb = (1:1:500).*1e-9;
% rm = 5e-9; %Equilibrium preciptiate size of 5 nm
% L = 2000.*1e-9; %Interparticle spacing of 1 um
% theta = 1e-4; %Resolution rate per atom
% R = 10e-9;
% drdtFR = (1-(rb./rm)).*(1./(rb.^2)).*(L./(L-rb)).*(theta.*(R.^3)./(48));



%         dout = [dout d];
%         rhout_temp = [rhout_temp rho];
        drdtoutMOD = [drdtout; drdtMOD3];
        drdtout6 = [drdtout; drdt];
%         drdtout = [drdtout_temp drdt];
        negind = find(drdt>0);
%         EqRad = rb(max(negind));
%         EqRadout = [EqRadout EqRad];
        end
       
%         drdtout = [drdtout; drdtout_temp];
%      drdtout_temp = [];
%     rhout = [rhout; rhout_temp];
%     drdtout = [drdtout; drdtout_temp];
% end

% subplot(1,2,2)


% plot(rb.*1e9,drdt,'-','LineWidth',2);
% hold on
% plot(rb,drdtMOD,'-','LineWidth',2);
% hold on
% % plot(rb.*1e9,drdtMOD2,'-','LineWidth',2);
% plot(rb.*1e9,drdtMOD3,'-','LineWidth',2);
% % plot(rb.*1e9,drdtFR,'-','LineWidth',2);
% xlim([0 500])

% plot(rb.*1e9,NHMGROWTH,'-','LineWidth',2);
% hold on
% plot(rb.*1e9,KWNgrowth,'-','LineWidth',2);
% plot(rb.*1e9,KWNGT,'-','LineWidth',2);
% xlim([0 500])
% legend('NHM','Zhao')

% for j = 1:1:1
% %     plot(rb.*1e9,drdtoutMOD(j,:),'LineWidth',2);
% % hold on      
% plot(rb.*1e9,drdtout(j,:),'-','LineWidth',2);
% %     loglog(y(1:900),EqRadout(1:900),'-','LineWidth',2);
%     xlim([0 500])
%     hold on
% end

plot(rb.*1e9,drdtout6,'-','LineWidth',2);
hold on

yscale_symlog


% legend(['260 ' char(176) 'C'],['290 ' char(176) 'C'],['320 ' char(176) 'C'],['350 ' char(176) 'C'])
% legend('1e5 - 275 C','1e10 - 275 C','1e15 - 275 C','1e20 - 275 C')
% plot(rb.*1e9,drdtout(j,:),'LineWidth',2); yscale_symlog;

% legend('1\times10^{18} SPPs m^{-3}','5\times10^{18} SPPs m^{-3}','1\times10^{19} SPPs m^{-3}','3\times10^{19} SPPs m^{-3}','6\times10^{19} SPPs m^{-3}')

% legend('1\times10^{23} SPPs m^{-3}','5\times10^{23} SPPs m^{-3}','1\times10^{24} SPPs m^{-3}')%,'3\times10^{19} SPPs m^{-3}','6\times10^{19} SPPs m^{-3}')

% legend('D = 1\times10^{-19} m^{2} s^{-1}','D = 1\times10^{-20} m^{2} s^{-1}','D = 1\times10^{-21} m^{2} s^{-1}'),'D = 1\times10^{-25} m^{2} s^{-1}')

% legend('SPP radius = 50 nm','SPP radius = 100 nm','SPP radius = 200 nm')

% legend('1\times10^{18} SPPs m^{-3}','1\times10^{23} SPPs m^{-3}')


% yscale_symlog; %uncomment this to get good transition between positive
% and negative log values
hold on


% semilogy(rhout,drdtout,'LineWidth',2)
set(gca,'Fontsize',18)
xlabel('SPP radius / nm')
% xlabel('Precipitate number density / SPPs m^{-3}')
ylabel('dr/dt / m s^{-1}')
xlim([0 500])
% xlabel('diff')
% ylabel('Eqrad')
% legend('Original NHM model','Effect of \beta','Effect of variable \zeta','Effect of \beta and \zeta')

%could try and plot dissolution rates using their absolute values and just
%change the plot line to a dash 
% ylim([-0.5 3e-13])

%Order of saves for 1/7/2022
% drdtout1* = Change D, D = 1e-18, xbinst = 1.44e-4, zeta = 4e20, k0 = 1e-7
% drdtout2 = Change D, D = 1e-19, xbinst = 1.44e-4, zeta = 4e20, k0 = 1e-7
% drdtout3* = Change zeta, zeta = 4e20, D = 1e-18, xbinst = 1.44e-4, k0 = 1e-7
% drdtout4 = Change zeta, zeta = 4e21, D = 1e-18, xbinst = 1.44e-4, k0 = 1e-7
% drdtout5* = Change xbinst, xbinst = 1.44e-4, zeta = 4e20, D = 1e-18, k0 = 1e-7
% drdtout6 = Change xbinst, xbinst = 1.44e-3, zeta = 4e20, D = 1e-18, k0 = 1e-7
%* These are all the same

% plot(rb.*1e9,drdtout1,'-k','LineWidth',2);
% hold on
% plot(rb.*1e9,drdtout2,'-','LineWidth',2);
% hold on
% plot(rb.*1e9,drdtout4,'-','LineWidth',2);
% plot(rb.*1e9,drdtout6,'-','LineWidth',2);
% yscale_symlog
% set(gca,'Fontsize',18)
% xlabel('SPP radius / nm')
% % xlabel('Precipitate number density / SPPs m^{-3}')
% ylabel('dr/dt / m s^{-1}')
% xlim([0 500])
% 
% % legend('D = 1\times10^{-18} m^2 s^{-1}, C_{inst} = 1.44\times10^{-4} at. frac., \zeta = 4\times10^{20} atoms m^{-2} dpa^{-1}, K = 1\times10^{-7} dpa s^{-1}','D = 1\times10^{-19} m^2 s^{-1}, C_{inst} = 1.44\times10^{-4} at. frac., \zeta = 4\times10^{20} atoms m^{-2} dpa^{-1}, K = 1\times10^{-7} dpa s^{-1}','D = 1\times10^{-18} m^2 s^{-1}, C_{inst} = 1.44\times10^{-4} at. frac., \zeta = 4\times10^{21} atoms m^{-2} dpa^{-1}, K = 1\times10^{-7} dpa s^{-1}','D = 1\times10^{-18} m^2 s^{-1}, C_{inst} = 1.44\times10^{-3} at. frac., \zeta = 4\times10^{20} atoms m^{-2} dpa^{-1}, K = 1\times10^{-7} dpa s^{-1}')
% lgd = legend('D = 1\times10^{-18} m^2 s^{-1}, \zeta = 4\times10^{20} atoms m^{-2} dpa^{-1}, C_{inst} = 1.44\times10^{-4} at. frac.','D = 1\times10^{-19} m^2 s^{-1}','\zeta = 4\times10^{21} atoms m^{-2} dpa^{-1}','C_{inst} = 1.44\times10^{-3} at. frac.');
% lgd.FontSize = 16;
%% Determine equilibrium size vs precipitate number density

% rb = (0.02:0.02:500).*1e-9;
% zeta = 1e18;
% % y = logspace(18,24,1000);
% y = logspace(-18,-25,1000);
% eqrout = [];
% vmol = 9e-6;
% na = 6.022045e23;
% vat = vmol/na;
% xb = 0.0051;
% k0 = 5e-7;
% 
%  xc = 0.66;
%  
%      drdtout_temp = [];
%     eqrout = [];
%  iter = 0;
% for d = y
%     tk = 300+273;
% %     d = (6e-7 * exp(-15930/(tk)).*1e-0);
%     rho = 1e24;
%     drdt = (-zeta.*k0.*vat)+((3.*d.*xb)./(4.*pi.*rb.*xc))-((rb.^2).*d.*rho);
%     
% %     Take equilibrium value as the bin with the smallest positive
% %     growth rate.
% %     Find all positive bins
%     posdr = find(drdt>0);
% %     Find end of all positive bins
% 
% if iter == 970
%     q=4;
% end
%     bin = posdr(end);
% %     Extract SPP size from rb array
%     eqr = rb(bin);
%     
%     
% %         drdt = ((-zeta.*k0)./(Natoms))+((3.*d.*xb)./(4.*pi.*rb.*xc))-((rb.^2).*d.*rho);
% %     dout = [dout d];
% %     rhout_temp = [rhout_temp rho];
% %             drdtout = [drdtout; drdt];
% %     drdtout_temp = [drdtout_temp drdt];
%     eqrout = [eqrout eqr];
%     iter = iter + 1;
% end
% 
% eqr_nm = eqrout.*1e9;
% semilogx(y,eqr_nm,'-m','LineWidth',2)
% hold on
% ylabel('Equilibrium SPP radius / nm')
% xlabel('Diffusivity / m^{2} s^{-1}')
% legend('5x10^{-7} dpa/s & 1x10^{18} SPPs m^{-3}','5x10^{-8} dpa/s & 1x10^{18} SPPs m^{-3}','5x10^{-8} dpa/s & 1x10^{20} SPPs m^{-3}')
% % % 
% % % 
% % % 
% % % 
% % % % %recreating the NHM paper data:
% % % % 
% % % % dout = [];
% % % % drdtout = [];
% % % % for tk = 523:20:623
% % % %     d = 6e-14;
% % % %     drdt = (-zeta.*k0.*vat)+((3.*d.*xb)./(4.*pi.*rb.*xc))-((rb.^2).*d.*rho);
% % % % %     drdt = ((-zeta.*k0)./(Natoms))+((3.*d.*xb)./(4.*pi.*rb.*xc))-((rb.^2).*d.*rho);
% % % %     dout = [dout d];
% % % %     drdtout = [drdtout; drdt];
% % % % end