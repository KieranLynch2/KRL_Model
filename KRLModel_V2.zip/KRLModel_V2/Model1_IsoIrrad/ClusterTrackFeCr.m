function [Fe2Cr_vf,Fe2Cr_rat] = ClusterTrackFeCr(newpart,bin,r_total,xbout_a_Cr,xbout_a_Fe,xbout_c_Fe,Fe2Cr_vf,Fe2Cr_rat)


%Using newpart and bin determine the number of new particles in the radius
%bin matching n.
%Can then determine a vf of new particles on this iteration and using
%solute changes in the matrix figure out average vf/composition to
%determine xc_avg.

%How to determine the difference between the newly crated clusters and the
%original size distribution, so it is possible to seperately calculate the
%xc of clusters in total and then of the PSD, taking into account the
%amorphous shell.

% Need to have r_init and n_init recorded, then the bins where init is
% smaller than current means that this is where the clusters are, but you
% don't know how many.... 

%ram should't be applied to the clusters.

TotalFe = xbout_a_Fe(end) + xbout_c_Fe(end);
Cr = xbout_a_Cr(end);

ElemRat = TotalFe./(TotalFe+Cr); %This should prove that the clusters forming towards end of irradiaiton have higher Cr levels
%This will be NaN prior any amorphization, so any nucleation when it is NaN
%is essentially equal to the stoichiometric levels, i.e. 2 for standard
%Zry-4, can change for Zry-2
% ElemRat(isnan(ElemRat))=1;

%Could plot a cumulative volume fraction of clusters against the Fe/Cr
%ratio?.. something like that anyway...

n = zeros(1,length(r_total));
n(bin) = n(bin) + newpart;

vf_new = 4/3 * pi * sum((r_total.^3) .* n);

%At start getting some nucleation due to excess solute in solution from
%annealing stage prior this lower temp simulation

Fe2Cr_vf = [Fe2Cr_vf vf_new];
Fe2Cr_rat = [Fe2Cr_rat ElemRat];




end