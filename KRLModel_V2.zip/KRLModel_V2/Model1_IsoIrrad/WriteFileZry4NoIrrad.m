function WriteFileZry4NoIrrad(Outputs,r,n,r_ln,n_ln,Alloy,Time_in,Temperature_in,FeConc_in,CrConc_in,NiConc_in,FeCrRatio_in,FeNiRatio,IterCount,tcprof,OFN)

Nsteps = IterCount-1;

% convert tcprof to printable data. Format of [iso,ramp,iso,ramp];
NStages = size(tcprof,1); %Number of stages in tcprof
% NTimes = NStages/3;
Time_in = [];
Temperature_in_init = [];
Temperature_in_end = [];
for kj = 1:1:NStages
    Time_in = [Time_in;tcprof(kj,3)];
    Temperature_in_init = [Temperature_in_init;tcprof(kj,1)];
    Temperature_in_end = [Temperature_in_end;tcprof(kj,2)];
end

%% Write input parameters into a csv file
Stage = (1:1:NStages)';
Time_hours = (Time_in);
Temp_C_Start = (Temperature_in_init);
Temp_C_End = (Temperature_in_end);
Flux_n_cm2_s = (zeros(1,length(Time_in)))';
AlloyTab = zeros(1,length(Time_in))+Alloy';
Zircaloy = AlloyTab';
FeConc_atfrac = (zeros(1,length(Time_in))+FeConc_in)'; 
CrConc_atfrac = (zeros(1,length(Time_in))+CrConc_in)'; 
NiConc_atfrac = (zeros(1,length(Time_in))+NiConc_in)'; 
FeCrRatio = (zeros(1,length(Time_in))+FeCrRatio_in)';

T = table(Stage,Zircaloy,Time_hours,Temp_C_Start,Temp_C_End,Flux_n_cm2_s,FeConc_atfrac,CrConc_atfrac,NiConc_atfrac,FeCrRatio);


FileNameSimCon = (['../Outputs/' OFN '_SimulatedConditions.csv']);
writetable(T,FileNameSimCon);

%% Write plotting stuff to an excel file with seperation by sheets per stage

FileNameExcel = (['../Outputs/' OFN '_AllOutputs.xlsx']);

for j = 1:Nsteps


    if length(Outputs(j).Radius) < length(Outputs(j).Time)
        Time_secs = Outputs(j).Time';
        MatrixSoluteConc_FeCr_atfrac = Outputs(j).SolConc';
        TotNumberDensitywTime_perum3 = Outputs(j).NumDenwTime';
        MeanRadius_nm = Outputs(j).MeanRad';
        VolumeFraction = Outputs(j).VolFrac';

        DumNaN = zeros(1,length(Time_secs)-length(Outputs(1).Radius));
        DumNaN(DumNaN == 0) = NaN;

        Radius_og = Outputs(j).Radius'.*1e9;
        Radius_nm = [Radius_og;DumNaN'];

        NumDen_og = Outputs(j).NumDen'.*1e-18;
        NumberDensity_perum3 = [NumDen_og;DumNaN'];

        Radius_SOG_nm = [Outputs(j).Radius_ln'.*1e9;DumNaN'];
        NumberDensity_SOG_perum3 = [Outputs(j).NumDen_ln'.*1e-18;DumNaN'];

        TabExcelOutputs = table(Time_secs,MatrixSoluteConc_FeCr_atfrac,VolumeFraction,MeanRadius_nm,TotNumberDensitywTime_perum3,Radius_nm,NumberDensity_perum3,Radius_SOG_nm,NumberDensity_SOG_perum3);
        writetable(TabExcelOutputs,FileNameExcel,'Sheet',j);

    else
        DumNaN = zeros(1,length(Outputs(1).Radius)-length(Outputs(j).Time));
        DumNaN(DumNaN == 0) = NaN;

        Radius_nm = Outputs(j).Radius'.*1e9;
        NumberDensity_perum3 = Outputs(j).NumDen'.*1e-18;
        Radius_SOG_nm = Outputs(j).Radius_ln'.*1e9;
        NumberDensity_SOG_perum3 = Outputs(j).NumDen_ln'.*1e-18;

        Time_secs_og = Outputs(j).Time';
        Time_secs = [Time_secs_og;DumNaN'];

        MatrixSoluteConc_FeCr_atfrac_og = Outputs(j).SolConc';
        MatrixSoluteConc_FeCr_atfrac = [MatrixSoluteConc_FeCr_atfrac_og;DumNaN'];

        TotNumberDensitywTime_perum3_og = Outputs(j).NumDenwTime';
        TotNumberDensitywTime_perum3 = [TotNumberDensitywTime_perum3_og;DumNaN'];

        MeanRadius_nm_og = Outputs(j).MeanRad';
        MeanRadius_nm = [MeanRadius_nm_og;DumNaN'];

        VolumeFraction_og = Outputs(j).VolFrac';
        VolumeFraction = [VolumeFraction_og;DumNaN'];

        TabExcelOutputs = table(Time_secs,MatrixSoluteConc_FeCr_atfrac,VolumeFraction,MeanRadius_nm,TotNumberDensitywTime_perum3,NumberDensity_perum3,Radius_nm,Radius_SOG_nm,NumberDensity_SOG_perum3);
        writetable(TabExcelOutputs,FileNameExcel,'Sheet',j);

    end
end


%% Dump the entire output history into one big csv file (only for variables that change with time)
% solute concentration is dumped as one entire list over all stages, r and
% n arrays only printed at begining and end.
FileNameCSVTime = (['../Outputs/' OFN '_TimeOutputs.csv']);


TimeTotStr = [];
SolConcStr = [];
NumDenStr= [];
MeanRadStr = [];
VolFracStr= [];

for k = 1:Nsteps
    TimeTotStr = [TimeTotStr;Outputs(k).Time'];
    SolConcStr = [SolConcStr; Outputs(k).SolConc'];
    NumDenStr= [NumDenStr; Outputs(k).NumDenwTime'];
    MeanRadStr = [MeanRadStr; Outputs(k).MeanRad'];
    VolFracStr= [VolFracStr; Outputs(k).VolFrac'];
end

TotTimeCSV = [TimeTotStr,SolConcStr,NumDenStr,MeanRadStr,VolFracStr];

writematrix(TotTimeCSV,FileNameCSVTime,'Delimiter',',');
%% Dump final PSD to csv file, Most recent Radius and numden should be saved from foor loop above for xlsx write-out.
FileNameCSVPSD = (['../Outputs/' OFN '_PSDOutputs.csv']);
PSDCSV = [Radius_nm,NumberDensity_perum3,Radius_SOG_nm,NumberDensity_SOG_perum3];

writematrix(PSDCSV,FileNameCSVPSD,'Delimiter',',');


end