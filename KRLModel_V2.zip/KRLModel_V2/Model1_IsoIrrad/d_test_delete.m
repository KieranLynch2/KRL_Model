d1out = [];
d2out = [];
d3out = [];
tkout = [];
for Q = 15000:1000:17000
    for tk = 1:1:800
        d = 6e-7 * exp(-Q/(tk));
        if Q == 15000
            d1out = [d1out d];
            tkout = [tkout tk];
        elseif Q == 16000
            d2out = [d2out d];
        elseif Q == 17000
            d3out = [d3out d];
        end
    end
end
semilogy(tkout,d1out)
hold on
semilogy(tkout,d2out)
semilogy(tkout,d3out)
legend('d1','d2','d3')