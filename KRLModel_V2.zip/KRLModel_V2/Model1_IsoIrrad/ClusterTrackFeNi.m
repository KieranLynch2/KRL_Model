function [Fe2Ni_vf,Fe2Ni_rat] = ClusterTrackFeNi(newpart_FeNi,bin_FeNi,r_clustFeNi,xboutFeNi_Fe,xboutFeNi_Ni,Fe2Ni_vf,Fe2Ni_rat)
                
% The FeCr clusters are taken to be stoichiometric of the Fe and Cr
% contents in the matrix. It has been shown (Eriksson 2021) that Fe/Ni ratio in those clusters
% is around Fe/Ni=2. This doesn't match solute relased from SPPs, which is
% Fe/Ni = 0.9. Indicating that either Fe from FeCr SPPs goes to FeNi
% clusters or that Ni has higher solubility and is happy to remain in
% matrix/solution.


Fe = xboutFeNi_Fe;
Ni = xboutFeNi_Ni;

ElemRat = Fe./(Fe+Ni); %This is wrong and will predict the Fe/(Fe+Ni) ratio will be equal to that of the SPPs FeNi.

%Could plot a cumulative volume fraction of clusters against the Fe/Cr
%ratio?.. something like that anyway...

n = zeros(1,length(r_clustFeNi));
n(bin_FeNi) = n(bin_FeNi) + newpart_FeNi;

vf_new = 4/3 * pi * sum((r_clustFeNi.^3) .* n);

%At start getting some nucleation due to excess solute in solution from
%annealing stage prior this lower temp simulation

Fe2Ni_vf = [Fe2Ni_vf vf_new];
Fe2Ni_rat = [Fe2Ni_rat ElemRat];




end