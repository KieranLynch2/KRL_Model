function [r_cryst,n_cryst,r_total,n] = tidyup(r_cryst,n_cryst,r_total,n) 

        r_total_zero = find(r_total <= 0);
        r_total(r_total_zero) = 0;
        %n(r_total_zero) = 0;
        
        r_cryst_zero = find(r_cryst <= 0);
        r_cryst(r_cryst_zero) = 0;
        n_cryst(r_cryst_zero) = 0;
end