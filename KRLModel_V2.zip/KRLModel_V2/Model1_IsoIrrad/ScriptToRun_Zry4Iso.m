%% Script for runnning Zircaloy-4 iosthermal annealing

% Explicit parallelism using 'parpool'
nslots = str2double(getenv('NSLOTS'));
parpool(nslots);
pp = gcp;
poolsize = pp.NumWorkers;


% Are you starting from scratch or using a pre-defined input?
InputFlag = 1; % 0 is from scratch, 1 is for a pre-defined distribution
FileName = 'Gros_Start_120nm.mat'; % Put the MATLAB output script here, e.g. 'Output.mat'

if InputFlag == 0
    clear all
    InputFlag = 0;
    FileName = [];
elseif InputFlag == 1 
    load(FileName)
end


% User inputs


for tempc = [650,700,750,780]
    for tgros = [5,15,30,50]
% tc = 700; % Temperature in Celcius
% t = 0.002; % Time in hours
OFN = (['OutputGros' num2str(tempc) 'C_' num2str(tgros) 'hours' '.mat']); % Choose an output filename 

%% Do not touch
zirc2flag = 0;
radflag = 0;
phi = 0;

tc = tempc;
t = tgros;

CallScript(tc,t,OFN,InputFlag,zirc2flag,radflag,phi,FileName)
    end
end


