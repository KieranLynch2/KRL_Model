function [r,rb,n_a,n] = Taylor_eq10(r,r_a,rb,n_a,n,tk,h,phi)

%Function to determine the change in radius of SPPs - from Taylor's second
%paper, it accounts for the enhanced amorphization of smaller SPPs
%realtively to larger SPPs.
%
% Inputs:
% R = Array of starting SPP radii
% t = Timestep (h from the KWN model)
% phi = flux 
% T = temperature (K)
%
% Outputs:
% rad = Array of final SPP radii


%Bin centre adjustment

T = tk;
t = h;
R_t_init = r;

beta = 2.37e-3;
D = 2.34e-20;
estarR = 11600;
kx = 27;
kphi = 9.6e-22;

a0 = (exp((log(phi))-(log(kx/kphi))+(estarR*(1/T)))/(exp((log(phi))-(log(kx/kphi))+(estarR*(1/T)))+1));

lenR = length(R_t_init);
r = [];
    for i = 1:1:lenR

        R_t = R_t_init(i);
    
        B = beta./(3.*(R_t.^2));
        a = (D*phi).*(((B.*(R_t.^3))-a0));
        b = -D.*phi.*B;
        k = ((a0./B)-(R_t.^3)).^(1/3);

        syms r_t

        eqn = ((k./(6.*a)).*log(((k+r_t).^2)./((k.^2)-(k.*r_t)+(r_t.^2))))+((k./(a.*sqrt(3))).*(atan(((2.*r_t)-k)./(k.*sqrt(3)))))-((k./(6.*a)).*(log(((k+R_t).^2)/((k.^2)-(k.*R_t)+(R_t.^2)))))-((k./(a.*sqrt(3))).*atan(((2.*R_t)-k)./(k.*sqrt(3)))) == t;


        S = vpasolve(eqn,r_t);

        rout = 0;
        rout(1) = S;

        r = [r rout];
    end


%bin edge adjustment

lenRb = length(rb);

Rb_t_init = rb;
rb = [];
    for j = 1:1:lenRb
    
        Rb_t = Rb_t_init(j);
    
        B = beta./(3.*(Rb_t.^2));
        a = (D*phi).*(((B.*(Rb_t.^3))-a0));
        b = -D.*phi.*B;
        k = ((a0./B)-(Rb_t.^3)).^(1/3);


        syms rb_t

        eqn = ((k./(6.*a)).*log(((k+rb_t).^2)./((k.^2)-(k.*rb_t)+(rb_t.^2))))+((k./(a.*sqrt(3))).*(atan(((2.*rb_t)-k)./(k.*sqrt(3)))))-((k./(6.*a)).*(log(((k+Rb_t).^2)/((k.^2)-(k.*Rb_t)+(Rb_t.^2)))))-((k./(a.*sqrt(3))).*atan(((2.*Rb_t)-k)./(k.*sqrt(3)))) == t;


        S = vpasolve(eqn,rb_t);


        rbout = 0;
        rbout(1) = S;

        rb = [rb rbout];
    end

n_init = n;

rzero = find(r<=0);
n(rzero) = 0;
r(rzero) = 0;

rbzero = find(rb<=0);
rb(rbzero) = 0;

vf_lost = ((4/3).*pi.*((R_t_init.^3).*n_init) - ((4/3).*pi.*((r.^3).*n)));
%Above and below use average bin sizes
n_a = n_a + (vf_lost./((4/3).*pi.*r_a.^3));

end

