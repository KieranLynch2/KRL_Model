function [drdt,EqRad] = NHM_FeNi(rb_FeNi,d_FeNi,xc_avgFeNi,vat_FeNi,n_FeNi,phi,n_clustFeNi,xc_clustFeNi,xc_FeNi,xbinst_FeNi,vmol_FeNi,sfen_FeNi,tk,xa);


% Nelson RS, Hudson JA, Mazey DJ. J Nucl Mater. 1972 Sep 1;44(3):318–30. 
% Was GS. Fundamentals of radiation materials science: Metals and alloys, second edition. 2016 Jan 1;1–1002. 

%xc_avg gets more complicated when Ni containing clusters are considered...
%Need to track extra Fe and Ni loss via Fe-Ni SPP dissolution using
%stoichiometric knowledge
% xc_avg = (xc_FeNi*vf_ratFeNi)+(xc_clustFeNi*vf_clustratFeNi);

d_FeNi = d_FeNi.*5e-3;

z0 = 4e20; %neeeded to convert dpa to atomic flux, quoted in NHM paper, n.b. 10^18 as we are working in metres

k0 = phi./(5e20); %Conversion from flux to dpa/s

Rg = 8.314;

delta = exp((2.*sfen_FeNi.*vmol_FeNi)./(rb_FeNi.*Rg.*tk));
xr = xa.*delta;


rho = n_FeNi;

A=0.02.*1e9;
zeta = z0.*(1-((exp(-A.*rb_FeNi))));

xc = xc_avgFeNi;

drdt = (-zeta.*k0.*vat_FeNi)+(4.*d_FeNi.*xbinst_FeNi)./(rb_FeNi.*xc_FeNi);


negind = find(drdt>0);
EqRad = (rb_FeNi(max(negind)));
end
