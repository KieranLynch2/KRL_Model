function [drdt] = AmorphDissRate(tk,phi)

x = tk;
y = phi.*1e4; %convert from n/cm2/s to n/m2/s

p00 =  -1.543e-15;
p10 =   4.357e-18;
p01 =  -1.712e-32;
p20 =  -2.976e-21;
p11 =   2.763e-35;

drdt = p00 + p10*x + p01*y + p20*x^2 + p11*x*y;

drdt = 0; %Temporary add 9/10/24 to investigate effect of increased solubility

end


