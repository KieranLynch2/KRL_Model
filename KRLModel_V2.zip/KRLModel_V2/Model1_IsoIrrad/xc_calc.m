%Script to calculate the xc in each bin and then average out across all
%bins to determine a mean xc value for the amorphous material each
%iteration
%Assuming the Fe content (density) is 0.4 in crystalline/amorphous interface and 0.1 at
%amorphous/matrix interface and that the Cr content stays constant (Bajaj
%work shows that there may, in fact, be a slight increase). So the value of
%xc for the amorphous zone will be the calculated Fe content plus the 0.1
%at.% from Cr.
% 
% rho_c = 0.4; %Fe content at crystalline/amorphous interface
% rho_a = 0.1;
% r_c = 50e2;
% r_a = 0;
% 
% m = (rho_a-rho_c)./(r_a-r_c);
% 
% Fe_cont = 4.*pi.*(((rho_c./3).*r_c.^3) + ((m./4).*r_a.^4) + ((r_a.^3./3).*(rho_c-(m*r_c))) - ((m./4).*(r_c.^4)) - ((r_c.^3./3).*(rho_c-(m*r_c))));

%New method
ram = 1e-9;
x1 = 0; %Position equal to the crystalline/amorphous interface
x2 = ram; %Distance between c/a and a/m interfaces
c1 = 0.1; %Fe concentration at crystalline/amorphous interface
c2 = 0.4; %Fe concentration at amorphous/matrix interface

m = (c2-c1)/(x1-x2);

%x1 will always be zero
%The average value is calculated using an integration
area = (((m.*x2.^2)/2)+(x2.*c2));

Fe_conc = (1/(x2-x1)).*area;

% if Fe_conc ISNaN;
%     Fe_conc = 0;
% end