function[r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout,vf_aout,vf_totout,xbinst_tot,ramout,vfout_FeNi,rbarout_FeNi,nrout_FeNi,npartout_FeNi,r_FeNi,n_FeNi,rcout_FeNi,ram_diss,xbout_a_Cr,xbout_a_Fe,xbout_c_Fe,r_final,r_a_shell,xb_tot_check,amorph_diss_out,rbar_totout,xbout_Zirc2]= ... 
    zr_amorph_kin_noniso_NEW(r,n,zirc2flag,rb,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi,tkprof,xb,xc,xc_a,xb_FeNi,xc_FeNi,sfen,sfen_FeNi,nsites,vmol,vmol_FeNi,a,a_init,radflag)
% ====================================================================
%
% Calculates precipitation kinetics in Zirconium alloys
% **RUN zirconium_init.m FIRST
%
%
% NEED TO ADD IN OUTPUTS FOR FE-NI SPPS
%
% using 2nd order Runge Kutta formula for error checking and
% adaptive timestep control
%
% Reference (to source model, originally for Al3Zr)
% J. D. Robson and P. B. Prangnell, Acta Materialia, 49, 2001, p. 599-613
%
% Inputs
% r         Size bins (mean sizes) (m)
% rb        Size bins (edge sizes) (m)
% tk        Temperature  (K)
% tfinal    Time to calculate for (s)
% d         Diffusion coefficient of solute  (m^2/s)
% xa        Solute concentration in matrix in equilibrium with precipitate
% xb		Average solute concentration in matrix
% xc		Solute concentration in precipitate
% vmax      Maximum volume fraction of precipitate
% nsites    Number of nucleation sites for precipitate (m^-3)
% sfen      Interfacial energy of precipitate for growth/nucleation (Jm^-2)
% a_init	Initial Zr lattice parameter before precipitation
% a			Final Zr lattice parameter at the end of precipitation
% radflag   Irradiation active (=1)
%
% Outputs
% r         Mean size of size bins (m)
% n         Particle number density in each size bin (particles/m^3)
% tout      Time at each time-step (s)
% vfout     Volume fraction at each time-step
% rbarout   Mean particle radius at each time-step (micron)
% npartout  Particle number density at each time-step (particles/micron^3)
% nrout     Nucleation rate at each time-step (particles/m^3)
% rcout     Critical radius at each time-step (m)
% aout		Lattice parameter of zirconium at each time-step
% fsout		Estimated strength at each time-step
% M			Movie (not used)
%
% ====================================================================
%
na = 6.022045e23;
k = 1.380662e-23;
tau = 0;
tout = [];
tkout = [];
grout = [];
vfout = [];
rbarout = [];
npartout = [];
ndump = [];
npartcritout = [];
aout = [];
fsout = [];
npartcrit_old=[0 0 0 0 0 0];
nrcritout = [];
rcout_c = [];
rcout_a = [];
amorphout = [];
rgmax = [];
nrout = [];
M = [];
xbout=[];
vf_aout = [];
vf_totout = [];
xbinst_tot = [];
ramout = [];
xbout_a_Cr = [];
xbout_a_Fe = [];
xbout_c_Fe = [];
xb_tot_check = [];
amorph_diss_out = [];
rbar_totout = [];
vf_c_track = [];

%All outputs for Fe-Ni type SPPs
%If any term does not have _FeNi suffix then it is of Fe-Cr type and can be
%crystalline or amorphous
grout_FeNi = [];
vfout_FeNi = [];
rbarout_FeNi = [];
npartout_FeNi = [];
ndump_FeNi = [];
npartcritout_FeNi = [];
aout_FeNi = [];
rcout_FeNi = [];
nrout_FeNi = [];
xbout_Zirc2 = [];

%
% Empirical parameters PGP, CAP, and SOCAP
% Garzarolli et al. 
%
% CAP
% QR_cap = 40e3; % This is standard value from Garzarolli
QR_cap = 17e3; % Value from model that causes rbar values to collapse
cap = 0;
capout = [];
% PGP
k_pgp = 1e14./3600; % PGP rate factor
TA_pgp = 3.2e4;
pgp = 0;
pgpout = [];
k_socap = 1.11e-11; % SOCAP rate factor
QR_socap = 18.7e3; % SOCAP activation energy
socap = 0;
socapout = [];
%
%
if radflag == 1
%Create an array of amorphous shells which are initially equal to zero
lenr_a = length(r_a);
r_a_shell = zeros(1,lenr_a);
else 
    r_a_shell = zeros(1,length(r));
end
%nr = 0;
len = length(r);
gr(1:len)=0;
%grout(1:len)=0; 
dr2(1:len)=0;
rbar = (sum(r.*n))/sum(n);
rbar = (sum(r_FeNi.*n_FeNi))/sum(n_FeNi);
vf = 4/3 * pi * sum((r.^3) .* n);
if radflag == 1
%Determine crystal vf per bin
vf_bin = 4/3 * pi * ((r.^3) .* n);
%Determine total SPP size vf per bin by adding core radius to shell radius;
vf_tot_bin = 4/3 * pi * (((r+r_a_shell).^3) .* n);
vf_a_bin = vf_tot_bin-vf_bin;
vf_a = sum(vf_a_bin); %Total volume fraction of amorphous material is the sum of each bin
else
    vf_a = 0;
end
vf_FeNi = 4/3 * pi * sum((r_FeNi.^3) .* n_FeNi);
solsuc = 0;
solfail = 0;
nucflag = 0;
nucflag_FeNi = 0;
%
% Runge-Kutta initialization - from matlab ode23old
%
t = 0;
rbar = 0;
pow = 1/3;
tol = 0.1; %1e-3
% h is the value of the timestep increment
% hmax and hmin set limits on the range of timesteps
% the timestep is adjusted automatically using a 2nd order
% Runge-Kutta scheme
%
hmin = 1e-10;
hmax = 3e4;
mnum = 1e25;
%
% cw is KW fudge factor for tau calculation   
%
cw = 1.4;
%
ram = 0;
phi = 0.6e14; %User input required (n/cm2/s)
%
hmaxinit=1e-10;
h_old = 10;
h = hmaxinit;
rc_old_c = 0;
rc_old_a = 0;
rc_c = 0;
rc_a = 0;
flag_me = 0;
coarseflag = 0;
firstit=0;
% if (xb < xa)
%     disp(['Alloy composition below solvus (Fe-Cr) - no precipitation. *end*'])
%     return
% end
% if zirc2flag == 1
% if (xb_FeNi < xa)
%     disp(['Alloy composition below solvus (Fe-Ni) - no precipitation. *end*'])
%     return
% end
% end
%ram_diss is the dissolution of the amorphous rims
%output mu is the factor required for Taylor model enhanced amorphization
[mu,ram_diss,ram_total] = amorph_diss_mu(tfinal,phi,tk);

%r_init = r;
%n_a_shell = n; %Number density of amorphous shell equals n 
xb_init = xb - ((xc - xa) * vf); %Matrix solute concentration before amorphization begins


tfinal = tkprof(1,3);
ttotal = sum(tkprof(:,3));
% initial temperature
tk = tkprof(1);
stage = 1;
steptime = 0; 
disp (['Heating stage ' num2str(stage)])
disp (['Temperature degC ' num2str(tk - 273)])
while (t<tfinal)
    %
    % stopper
    %if t>1.725e6
    %    disp(['stop'])
    %end
    xa = exp((-5.4e3./tk)-3.3);
    d = 3e-7 * exp(-15930/(tk));
    
    if zirc2flag == 1
        d_FeNi = 2.75e-6 * exp(-16500/(tk));
        d = 3e-7 * exp(-15930/(tk));
    end
    
    if steptime + h > tkprof(stage,3), h = tkprof(stage,3) - steptime; end
    %
    if radflag == 1
    alpha0 = alpha_zero(tk,phi);
    end
    %
    if radflag == 1
       %
       %
       %
       ram = amorph_depth_taylor(h,ram,phi,alpha0,mu);
    else
       ram = 0;
    end
    %
    %Update crystalline core and amorphous rim (dummy SPP) arrays
    if radflag == 1
    [r,rb,n_a,n,r_a_shell] = cryst_to_amorph(r,r_a,rb,n_a,n,ram,r_a_shell);
    %
    %Dissolution of the amorphous zone/array
    %This was going to be done in growth amorph, but that method doesn't
    %seem suitable
    [r_a_shell,vf_a_diss,amorph_diss_out] = amorph_diss(r_a_shell,phi,tfinal,h,ram,amorph_diss_out,r,n);
    end
    %
    rc_c = critrad_cryst(sfen,xa,xb,xc,xc_a,vf,vf_a,tk,vmol,radflag);
    rc_a = critrad_amorph(sfen,xa,xb,xc,vf,tk,vmol);
    %
    %Critical radius for Fe-Ni SPPs
    if zirc2flag == 1
    rc_FeNi = critrad_cryst_FeNi(sfen_FeNi,xa,xb_FeNi,xc_FeNi,vf_FeNi,tk,vmol_FeNi,xb,xc,vf);
    end
    % Multiplication factor
    %
    %Turn off these when irradiation is on (no new nucleation, for now)
    if radflag == 1
        nucflag = 1;
    end
    newsize = 1.1 * rc_c;
    search=0;
    search=find(rb<newsize); %gets bin edge positions less than the newsize
    bin=max(search); %finds largest radius bin edge position smaller than newsize
    if bin>length(r-1) %if the largest bin edge position which is less than the newsize (critical radius + 10%) is greater than the second last r bin position
        if nucflag == 0
            disp 'New particles exceed size range (Fe-Cr)!'
        end
        if nucflag == 1
            % Nucleation is complete - no new particles, set a dummy bin
            bin = 10;
        end
    end
    %Above ^ if the critical radius exceeds the size range of the r array
    %then new particles will never nucleate!
    if zirc2flag == 1
    newsize_FeNi = 1.1 * rc_FeNi;
    search_FeNi=0;
    search_FeNi=find(rb_FeNi<newsize_FeNi); %gets bin edge positions less than the newsize
    bin_FeNi=max(search_FeNi); %finds largest radius bin edge position smaller than newsize
    if bin_FeNi>length(r_FeNi-1) %if the largest bin edge position which is less than the newsize (critical radius + 10%) is greater than the second last r bin position
        if nucflag_FeNi == 0
            disp 'New particles exceed size range (Fe-Ni)!'
        end
        if nucflag_FeNi == 1
            % Nucleation is complete - no new particles, set a dummy bin
            bin = 10;
        end
    end
    end
    %
    %if bin==[], disp 'New particles smaller than size range !';end
    %
    % Check that top bin is not occupied
    %
    if n(end)>0, disp 'Bin overflow error - increase maximum size range'; end
    if zirc2flag == 1
    if n_FeNi(end)>0, disp 'Bin overflow error - increase maximum size range'; end
    end
%
% find bin in which critical radius lies. The bin in which new
% particles nucleate must be at least 1 greater than this
%
    search=0;
    search=find(rb<rc_c);
    rcbin=max(search);
    bindiff=bin-rcbin;
    if bindiff<1 & nucflag == 0
        disp(['WARNING! newsize and rc lie in same bin (Fe-Cr). Remesh narrower bins'])
    end
    
    %Fe-Ni
    if zirc2flag == 1
    search_FeNi=0;
    search_FeNi=find(rb_FeNi<rc_FeNi);
    rcbin_FeNi=max(search_FeNi);
    bindiff_FeNi=bin_FeNi-rcbin_FeNi;
    if bindiff_FeNi<1 & nucflag_FeNi == 0
        disp(['WARNING! newsize and rc lie in same bin (Fe-Ni). Remesh narrower bins'])
    end
    end
%
% Compute the slopes
% 
% slopes at start of interval%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%No need for nr_a1 as no amorphous SPPs will nucleate?
%Taken out r and r_a as growth_amorph function works on bin edges not mean
%size
%As r-ram and rb-ram only needs to happen once, so they should be
%output from nucgrow_amorph only once. Same as n_a which is updated in
%growth_amorph but only needs to be updated once
    [nr1,gr1,gr_a1] = nucgrow_amorph(vf,vf_a,ram,r,r_a,rb,rb_a,d,t,nsites,sfen,tk,xa,xb,xc,xc_a,tau,vmol,a,n,n_a,radflag,tfinal,ram_diss,ram_total);
    if nucflag == 1, nr1 = 0; end
    
    %Fe-Ni 
    if zirc2flag == 1
    [nr1_FeNi,gr1_FeNi] = nucgrow_amorph_FeNi(vf_FeNi,r_FeNi,rb_FeNi,d_FeNi,t,nsites,sfen_FeNi,tk,xa,xb_FeNi,xc_FeNi,tau,vmol_FeNi,a,n_FeNi,radflag,xb,xc,vf,d,rb,rc_c);
    if nucflag_FeNi == 1, nr1 = 0; end
    end
   % nr1 = 0;
%
% slopes at middle of interval%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% to calculate the slope need to know the volume fraction
% at the middle of the interval. Need to temporarily update size
% distribution and hence find volume fraction
%
    newpart3 = (1-vf) * nr1 * (h/2);
    ntemp3 = n;
    ntemp3(bin)=ntemp3(bin)+newpart3;
    dr3 = gr1 * (h/2);
%
% Fe-Ni
if zirc2flag == 1
    newpart3_FeNi = (1-vf_FeNi) * nr1_FeNi * (h/2);
    ntemp3_FeNi = n_FeNi;
    ntemp3_FeNi(bin_FeNi)=ntemp3_FeNi(bin_FeNi)+newpart3_FeNi; %Nucleate new particles 10 % greater than crit rad
    dr3_FeNi = gr1_FeNi * (h/2);
end
% No need to add new particles to amorphous array as the nucleation rate is
% zero

    dr3_a = gr_a1 * (h/2);
    ntemp3_a = n_a;

%
% Temporarily update size distribution
%
% Crystalline cores and amorphous dummy SPPs
    %Crystalline
    [np yp] = update_func_mod(r,rb,ntemp3,dr3);
    ntemp3 = np';    
    vf3 = sum(((4/3) * pi * (r.^3)) .* ntemp3);
    %Amorphous
    [np_a yp_a] = update_func_mod(r_a,rb_a,ntemp3_a,dr3_a);
    ntemp3_a = np_a';    
    vf3_a = sum(((4/3) * pi * (r_a.^3)) .* ntemp3_a);
    %Fe-Ni
    if zirc2flag == 1
    [np_FeNi yp_FeNi] = update_func_mod(r_FeNi,rb_FeNi,ntemp3_FeNi,dr3_FeNi);
    ntemp3_FeNi = np_FeNi';    
    vf3_FeNi = sum(((4/3) * pi * (r_FeNi.^3)) .* ntemp3_FeNi);
    end
%
% Find slopes (nr & gr) at middle of interval
%
    [nr3,gr3,gr_a3] = nucgrow_amorph(vf3,vf3_a,ram,r,r_a,rb,rb_a,d,t,nsites,sfen,tk,xa,xb,xc,xc_a,tau,vmol,a,n,n_a,radflag,tfinal,ram_diss,ram_total);
    if nucflag == 1, nr3 = 0; end

    % Fe-Ni
    if zirc2flag == 1
    [nr3_FeNi,gr3_FeNi] = nucgrow_amorph_FeNi(vf3_FeNi,r_FeNi,rb_FeNi,d_FeNi,t,nsites,sfen_FeNi,tk,xa,xb_FeNi,xc_FeNi,tau,vmol_FeNi,a,n_FeNi,radflag,xb,xc,vf,d,rb,rc_c);
    if nucflag_FeNi == 1, nr3_FeNi = 0; end
    end
   % nr3 = 0;
%
% slopes at end of interval%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% use nr & gr at middle of interval to calculate change in (r,n)
%
    newpart2 = (1-vf) * nr3 * (h);
    ntemp2 = n;
    ntemp2(bin)=ntemp2(bin)+newpart2;
    dr2 = gr3 * h;
    %
    %Fe-Ni
    if zirc2flag == 1
    newpart2_FeNi = (1-vf_FeNi) * nr3_FeNi * (h);
    ntemp2_FeNi = n_FeNi;
    ntemp2_FeNi(bin_FeNi)=ntemp2_FeNi(bin_FeNi)+newpart2_FeNi;
    dr2_FeNi = gr3_FeNi * h;
    end

    dr2_a = gr_a3 * (h);
    ntemp2_a = n_a;
% N ARAY FOR FE-NI IS NOT X1018 LIKE FE-CR
%
% Temporarily update size distribution
%
    %crystalline
    [np yp] = update_func_mod(r,rb,ntemp2,dr2);
    ntemp2 = np';    
    vf2 = sum(((4/3) * pi * (r.^3)) .* ntemp2);
    %amorphous
    [np_a yp_a] = update_func_mod(r_a,rb_a,ntemp2_a,dr2_a);
    ntemp2_a = np_a';    
    vf2_a = sum(((4/3) * pi * (r_a.^3)) .* ntemp2_a);
    %Fe-Ni
    if zirc2flag == 1
    [np_FeNi yp_FeNi] = update_func_mod(r_FeNi,rb_FeNi,ntemp2_FeNi,dr2_FeNi);
    ntemp2_FeNi = np_FeNi';    
    vf2_FeNi = sum(((4/3) * pi * (r_FeNi.^3)) .* ntemp2_FeNi);
    end
%
%
%
% Find slopes (nr & gr) at end of interval
% 
    [nr2,gr2,gr_a2] = nucgrow_amorph(vf2,vf2_a,ram,r,r_a,rb,rb_a,d,t,nsites,sfen,tk,xa,xb,xc,xc_a,tau,vmol,a,n,n_a,radflag,tfinal,ram_diss,ram_total);  
    if nucflag == 1, nr2 = 0; end
    
    %Fe-Ni
    if zirc2flag == 1
    [nr2_FeNi,gr2_FeNi] = nucgrow_amorph_FeNi(vf2_FeNi,r_FeNi,rb_FeNi,d_FeNi,t,nsites,sfen_FeNi,tk,xa,xb_FeNi,xc_FeNi,tau,vmol_FeNi,a,n_FeNi,radflag,xb,xc,vf,d,rb,rc_c);
    if nucflag_FeNi == 1, nr2_FeNi = 0; end
    end
   % nr2 = 0;
%
% Estimate the error
%
% In number density
%
    deltanum = norm(h*(nr1 - 2*nr3 + nr2)/3,'inf');
    if zirc2flag == 1
    deltanum_FeNi = norm(h*(nr1_FeNi - 2*nr3_FeNi + nr2_FeNi)/3,'inf');
    end
% Don't need during irradiation as no nucleation allowed
%
% In radius
%   %norm calculates the magnitude of the vector
% 'inf', then n is the maximum absolute row sum of the matrix.
    deltarad = norm(h*(gr1 - 2*gr3 + gr2)/3,'inf');
    if radflag == 1
        deltarad_a = norm(h*(gr_a1 - 2*gr_a3 + gr_a2)/3,'inf');
    else 
        deltarad_a = deltarad;
    end
    if zirc2flag == 1
    deltarad_FeNi = norm(h*(gr1_FeNi - 2*gr3_FeNi + gr2_FeNi)/3,'inf');
    end
    %
% Allowable errors
%
    %taunum = tol * 1e18;
    taunum = tol * 1e18; 
    taurad = tol * 1e-9;
%
% Limit maximum number of particles formed in each interval to mnum
% Don't need to change this as no nucleation in amorphization
    newpart1 = nr1 * h;
    if newpart1>mnum 
        numrange = 1;
        % make step size half the limiting maximum
        hnuc = mnum/(2 * nr1);
    else
        numrange = 0;
        hnuc = hmax;
    end
    
    %Fe-Ni
    if zirc2flag == 1
    newpart1_FeNi = nr1_FeNi * h;
    if newpart1_FeNi>mnum 
        numrange_FeNi = 1;
        % make step size half the limiting maximum
        hnuc_FeNi = mnum/(2 * nr1_FeNi);
    else
        numrange_FeNi = 0;
        hnuc_FeNi = hmax;
    end
    end
% Check total xbinst has not fallen too far
        if radflag == 1
            vf2_tot = vf2 + vf2_a;
            if vf2_tot == 0
                xbinst_temp = xb;
            else
                vf2_crat = vf2/(vf2+vf2_a);
                vf2_arat = vf2_a/(vf2+vf2_a);
                xc_avg = (xc*vf2_crat)+(xc_a*vf2_arat);
                xbinst_temp = xb - ((xc_avg - xa) * vf2_tot);                
            end
            if xbinst_temp < xa
                xbcheck = 1;
            else
                xbcheck = 0;
            end
        else
         xbinst_temp = xb - ((xc - xa) * vf2);
         %disp(['xa ' num2str(xa) ' xbinst_temp ' num2str(xbinst_temp)])
         if xbinst_temp < xa
             xbcheck = 1;
         else
             xbcheck = 0;
         end
        end   
        
%Xbinst check for Fe-Ni SPPs, also need to check xbinst for Fe-Cr system in
%zirc-2, then combine the total xbinst.
        if zirc2flag == 1
         xbinst_temp = xb - ((xc - xa/2) * vf2);
         xbinst_temp_FeNi = xb_FeNi - ((xc_FeNi - xa/2) * vf2_FeNi);
         %disp(['xa ' num2str(xa) ' xbinst_temp ' num2str(xbinst_temp)])
         xbinst_temp_tot = xbinst_temp + xbinst_temp_FeNi;
         if xbinst_temp_tot < xa
             xbcheck_Zirc2 = 1;
         else
             xbcheck_Zirc2 = 0;
         end
        end

% Update the solution if the error is acceptable
%    
%Put in dummy errors for when Zircaloy-4 is running
if zirc2flag == 0
deltanum_FeNi = 0;
numrange_FeNi = 0;
xbcheck_Zirc2 = 0;
end
xbcheck = 0; % This has been added when creating the noniso script, copying the same method in the first noniso script 23/7/2021
    if (deltanum <= taunum) &  (numrange==0) & (xbcheck == 0) & (deltanum_FeNi <= taunum) &  (numrange_FeNi==0) & (xbcheck_Zirc2 == 0)
         firstit = firstit + 1;
         t = t + h;
         steptime = steptime + h;
         if (h == (tkprof(stage,3) - steptime));flag_me=1;end
         if zirc2flag == 1
         disp(['Updating solution ' num2str(h) ' time/h: ' num2str(t/3600) ' nucrate ' num2str(nr3) ' rc ' num2str(rc_c) ' nucrate_FeNi ' num2str(nr3_FeNi) ' rc_FeNi ' num2str(rc_FeNi)])
         else
         disp(['Updating solution ' num2str(h) ' time/h: ' num2str(t/3600) ' nucrate ' num2str(nr3) ' rc ' num2str(rc_c)])
         end
         %
         % Calculate more accurate increment in size/number
         %
         % No new particles during irradiation
         newpart = (1-vf)*h*(nr1 + 4*nr3 + nr2)/6;
         n(bin)=n(bin) + newpart;
         dr = h*(gr1 + 4*gr3 + gr2)/6;
         if radflag == 1
         dr_a = h*(gr_a1 + 4*gr_a3 + gr_a2)/6;
         end
         
         %Fe-Ni
         if zirc2flag == 1
         newpart_FeNi = (1-vf_FeNi)*h*(nr1_FeNi + 4*nr3_FeNi + nr2_FeNi)/6;
         n_FeNi(bin_FeNi)=n_FeNi(bin_FeNi) + newpart_FeNi;
         dr_FeNi = h*(gr1_FeNi + 4*gr3_FeNi + gr2_FeNi)/6;
         end

         
         %disp(['Bin 1-5 n ' num2str(n(1:5))])
         %disp(['dr bins 1-5 ' num2str(dr(1:5))])
         %
         %
         [np yp]=update_func_mod(r,rb,n,dr);
         n = np';
         npart = sum(n);
         vf = 4/3 * pi * sum((r.^3) .* n);
         if npart > 0
            rbar = (vf./((4/3) * pi * sum(n)))^(1./3);
         else
            rbar = 0;
         end   
         %Update amorphous array, don't need to update rbar as they are
         %only arbitrary spherical SPPs
         if radflag == 1
         [np_a,yp_a]=update_func_mod(r_a,rb_a,n_a,dr_a);
         n_a = np_a';
         npart_a = sum(n_a);
         
         %vf_a = 4/3 * pi * sum((r_a.^3) .* n_a);
         %Determine crystal vf per bin
         vf_bin = 4/3 * pi * ((r.^3) .* n);
         %Determine total SPP size vf per bin by adding core radius to shell radius;
         vf_tot_bin = 4/3 * pi * (((r+r_a_shell).^3) .* n); %n is the crystalline cores number density, so is wrong. If you use n_a_shell it works as the number density in both is the same, but the amorphous array is last to dissolve.
         vf_a_bin = vf_tot_bin-vf_bin;
         vf_a = sum(vf_a_bin); %Total volume fraction of amorphous material is the sum of each bin
         
         %Calculate total mean radius - cores + amorphous shells
         npart_tot = sum(n);
         if npart_tot > 0
             %Need to get total vf and use n array of amorphous shells as
             %this outlasts the crysalline number densities.
             vf_tot_sum = sum(vf_tot_bin);
             rbar_tot = (vf_tot_sum./((4/3) * pi * sum(n)))^(1./3);
         else 
             rbar_tot = 0;
         end
         end
         %
         %Fe_Ni
         if zirc2flag == 1
         [np_FeNi yp_FeNi]=update_func_mod(r_FeNi,rb_FeNi,n_FeNi,dr_FeNi);
         n_FeNi = np_FeNi';
         npart_FeNi = sum(n_FeNi);
         vf_FeNi = 4/3 * pi * sum((r_FeNi.^3) .* n_FeNi);
         if npart_FeNi > 0
            rbar_FeNi = (vf_FeNi./((4/3) * pi * sum(n_FeNi)))^(1./3);
         else
            rbar_FeNi = 0;
         end  
         end
         
         %
         % Output number of particles per um^3 and mean radius in nm
         % not interested in amorphous SPP rbar or npart
         %
         npart = npart/1e18;
         %
         rbar_nm = rbar*1e9;
         %
         %Fe-Ni
         if zirc2flag == 1
         npart_FeNi= npart_FeNi/1e18;
         %
         rbar_nm_FeNi = rbar_FeNi*1e9;
         end
         % Check if nucleation is complete
         %
         if nr3 < 1e-100
             nucflag = 1;
         end
         %Fe-Ni
         if zirc2flag == 1
         if nr3_FeNi < 1e-100
             nucflag_FeNi = 1;
         end
         end
         % Update CAP and PGP
         %
         cap = cap + (h .* exp(-QR_cap .* (1./tk)));
         pgp = pgp + (k_pgp .* h .* exp(-TA_pgp./tk));
         socap = socap + (k_socap./tk.^2) .* exp(-QR_socap.*(1./tk)) .* h;
         %
         % Build up output vectors
         %
         tout = [tout t];
         tkout = [tkout tk];
         vfout = [vfout vf]; %This now should only track crystalline cores
         rbarout = [rbarout rbar_nm];
         if radflag == 1
         rbar_totout = [rbar_totout rbar_tot.*1e9]; %mean radius of entire SPP, including crystalline cores and amorphous rims
         end
         npartout = [npartout npart];
         nrout = [nrout nr3];
         rcout_c = [rcout_c rc_c*1e9];
         rcout_a = [rcout_a rc_a*1e9];
         amorphout = [amorphout ram*1e9];
         xbinst = xb - ((xc - xa) * vf); %This will be instanteneous solute matrix concentration based only on crystalline cores, some extra solute will be stored in amorphous material
         xbout = [xbout xbinst];
         ndump = [ndump; gr3];
         capout = [capout cap];
         pgpout = [pgpout pgp];
         socapout = [socapout socap];
         ramout = [ramout ram]; %sum of ramout will give the total ram.
         %
         %New output vectors for amorphous case
         vf_aout = [vf_aout vf_a];
         %Calculate xbinst using just amorphous array to determine solute
         %released from amorphous SPPs
         %Calculate total xbinst to determine total matrix solute concentration
         vf_tot = vf + vf_a;
         vf_totout = [vf_totout vf_tot]; %This is the total volume fraction which should equal the volume fraction of the amorphous and crystalline parts combined.
         if radflag == 1
            if vf_tot == 0
                xbinst = xb;
            else
                vf_crat = vf/(vf+vf_a);
                vf_arat = vf_a/(vf+vf_a);
                xc_avg = (xc*vf_crat)+(xc_a*vf_arat);
                xbinst = xb - ((xc_avg - xa) * vf_tot);                
            end
         xbinst_tot = [xbinst_tot xbinst]; %This is the solute matrix concentration, as no dissolution of amorphous material yet this is essentially purely Fe
         end
         if radflag == 1
             
             vf_c_track = [vf_c_track vf];
             if firstit == 1
                vf_c_change = 0;
             else
                vf_c_change = vf_c_track(end) - vf_c_track(end-1);
             end
             
             vf_c_rat = vf_c_change/(vf_c_change + vf_a_diss);
             TF_c = isnan(vf_c_rat);
             if TF_c == 1
                 vf_c_rat = 0;
             end
             vf_a_rat = vf_a_diss/(vf_c_change + vf_a_diss);
             TF_a = isnan(vf_a_rat);
             if TF_a == 1
                 vf_a_rat = 0;
             end
             %May have to change amorphous section - the change in vf
             %doesn't represent to amount of dissolved material, as there
             %is contribution from new added amoprhous material from c-t-a
             %transition. 
             %Find the change in xbinst between interations, as this is the
             %amount of solute released
             if length(xbinst_tot) <= 1
                 xb_change = xbinst_tot(end) - xbinst_tot(end);%on first iteration set it to be no change between volume fractions - can change this to carry over the end of specific arrays from the non irradiation run
             else
                 xb_change = xbinst_tot(end) - xbinst_tot(end-1); %change in crystalline vf by subtracting the vf of previous iteration from vf of current iteration            
                 %xb_change = abs(xb_change);
             end
             
             cryst_sol_loss = vf_c_rat*xb_change;
             amorph_sol_loss = vf_a_rat*xb_change;
             amorph_Cr_loss = (0.25/0.35)*amorph_sol_loss;
             amorph_Fe_loss = (0.1/0.35)*amorph_sol_loss;
             
             %The cumsum of these arrays gives the total matrix
             %concentration. To get the total matrix concentration I have
             %to take the final xbinst value determined from the pre-irradiation case and add that, although for that case I do not know the ratio of Fe/Cr. 
             xbout_a_Cr = [xbout_a_Cr amorph_Cr_loss]; %These arrays are the solute released at each iteration, whilst xbinst_tot is the total matrix solute concentration at that time
             xbout_a_Fe = [xbout_a_Fe amorph_Fe_loss];
             xbout_c_Fe = [xbout_c_Fe cryst_sol_loss]; %The sum of these three solutes and xb_init should equate to xbinst_tot.
             
             %Need to add some code to distribute the starting xbinst
             %between the solutes to make sure graph makes complete sense
             
             if firstit == 1
                xbsum = amorph_Cr_loss + amorph_Fe_loss + cryst_sol_loss + xb_init;
                xb_tot_check = [xb_tot_check xbsum];
             else
                xbsum = amorph_Cr_loss + amorph_Fe_loss + cryst_sol_loss;
                xb_tot_check = [xb_tot_check xbsum];
             end
         end
         % Calculation of a lattice parameter based on Vegard's law
         % 
         %ainst = a + ((xbinst./xb) .* (a_init - a));
         % Not edited this to account for amorphization case yet
         ainst = a + (((xbinst-xa)./(xb-xa)) .* (a_init - a));
         aout = [aout ainst * 1e10];
         solsuc = solsuc + 1;
         grt = dr(bin)/h;
         grout = [grout grt];
         %Output vectors for only Fe-Ni SPPs 
         if zirc2flag == 1
         vfout_FeNi = [vfout_FeNi vf_FeNi];
         rbarout_FeNi = [rbarout_FeNi rbar_nm_FeNi];
         nrout_FeNi = [nrout_FeNi nr3_FeNi];
         npartout_FeNi = [npartout_FeNi npart_FeNi];
         rcout_FeNi = [rcout_FeNi rc_FeNi*1e9];
         
         xbinst_temp_end = xb - ((xc - xa/2) * vf2);
         xbinst_temp_FeNi_end = xb_FeNi - ((xc_FeNi - xa/2) * vf2_FeNi);
         %disp(['xa ' num2str(xa) ' xbinst_temp ' num2str(xbinst_temp)])
         xbinst_temp_tot_end = xbinst_temp_end + xbinst_temp_FeNi_end;
         
         xbout_Zirc2 = [xbout_Zirc2 xbinst_temp_tot_end];
         end
         %Output vectors for useful combined info - matrix conc. etc.
     else
         solfail = solfail + 1;
     end 
     
            % Update temperature for next step
        %
        if flag_me
           flag_me = 0;           
           if stage<size(tkprof,1) 
               stage=stage+1;
           else
               t = ttotal;
           end          
           %stage = stage+1;
           tfinal=sum(tkprof(1:stage,3));            
           steptime = 0;
           tk = tkprof(stage,1);
           disp (['Heating stage ' num2str(stage)])
           disp (['Temperature degC ' num2str(tk - 273)])
           h = hmin;
           firstit = 0;
       end
           if tkprof(stage,3)>0
             tk = ((steptime/tkprof(stage,3))*(tkprof(stage,2)-tkprof(stage,1)))+tkprof(stage,1);
           else
             tk = tkprof(stage-1,2);
           end   
       %
    % set hmax so there are at least 20 steps per heat treatment stage
    %
    if tkprof(stage,3)>0
      hmax = tkprof(stage,3)/20;
    end 
    
    
     %
     if zirc2flag == 0
         deltarad_FeNi = 0;
     end
     if deltarad ~= 0.0 || deltarad_a ~= 0.0 || deltarad_FeNi ~= 0.0
         h1 = min(hmax, 0.9 * h * (taurad/deltarad)^pow);
     else
         h1 = hmax;
     end
     if zirc2flag == 1
     if deltarad_FeNi ~= 0.0 
         h1_FeNi = min(hmax, 0.9 * h * (taurad/deltarad_FeNi)^pow);
     else
         h1_FeNi = hmax;
     end
     end
     %
     if deltanum ~= 0.0 || deltanum_FeNi ~= 0.0
         h2 = min(hmax, 0.9 * h * (taunum/deltanum)^pow);
     else
         h2 = hmax;
     end 
     if zirc2flag == 1
     if deltanum_FeNi ~= 0.0
         h2_FeNi = min(hmax, 0.9 * h * (taunum/deltanum_FeNi)^pow);
     else
         h2_FeNi = hmax;
     end 
     end
     %
     if xbcheck == 1
         h3 = h./1.1;
     else
         h3 = hmax;
     end
     if zirc2flag == 1
     if xbcheck_FeNi == 1
         h3_FeNi = h./1.1;
     else
         h3_FeNi = hmax;
     end
     end
     %
     % Step size for next step is smaller of step sizes
     % calculated for growth and nucleation
     % and limited by not exceeding mnum particles in each step
     % But if in first few iterations, make sure h doesn't get too big
     % h is not allowed to increase by more than 10% between steps
     %
     if firstit>100
      if zirc2flag == 1
      hprov = min([h1 h2 h3 hnuc h1_FeNi h2_FeNi h3_FeNi hnuc_FeNi]);
      else
      hprov = min([h1 h2 h3 hnuc]);
      end
      %disp(num2str([h1 h2 h3]))
      %if hprov == h1, disp(['limited by deltarad']); end;
      %if hprov == h2, disp(['limited by deltanum']); end;
      %if hprov == h3, disp(['limited by xbinst change']); end;
      h = max([hmin hprov]);
     else
      if zirc2flag == 1
      hprov = min([h1 h2 h3 hnuc h1_FeNi h2_FeNi h3_FeNi hnuc_FeNi]);
      h = min([hprov hmaxinit]);
      else
      hprov = min([h1 h2 h3 hnuc]);
      h = min([hprov hmaxinit]);
      end
     end
     if (h>1.1*h_old), h=1.1*h_old; end
     %
     % Check if xbinst--> xa reduce stepsize
     %
     %if xa > 0.99.*xbinst
     %    h = hmin;
     %    firstit = 0;
     %end
     h_old = h;
end
 disp([num2str(solfail+solsuc) ' Iterations: ' num2str(solsuc) ' Successful ' num2str(solfail) ' Unsuccessful'])
 %Determination of final PSD - 
 if radflag == 1
 r_final = r+r_a_shell;
 else
     r_final = 0;
 end