% Quick script to run without having to use the GUI
% Mainly for programming adjustments
% Need to remember in final model to change backward slashes in app code to
% forward slashes

% Focus on three temps and three fluxes:
% T = [270, 300, 330]
% phi = [0.5e14, 1e14, 2e14];

% BajFlux = [0.4,0.4,1.2,0.6,1.3,1.2,1.5,1.2].*1e14;
% BajFlu = [1.39,2.77,2.77,2.05,1.62,3.96
% ,1.56,4.86].*1e21;
% BajTemp = [270,270,270,310,310,310,332,332];
% xa_finaldpa = [5,10,15,20];
% DiffMod = [5000,50000,500000];
% PhiCons = [1,2,3]*1e-10;

% Parameters to vary
Flux = 1.4e14; %n/cm2
%Fluence = 1.62e21;%2.77e21;
Fluence = 2.77e21;
Time = (Fluence/Flux)/3600; %hours
Temperature = 270; %degrees C
PhiCons = 1.5e-10;
xa_finaldpa = 2.5; %This is the point where the effective solubility limit saturates
DiffMod = 700; %factor to reduce diffusion by - D_irr = d_sia_bas * DiffMod

sfen_amorph_diss = 0.1;
vmol_diss = 9e-6;
InvCorseFlag = 4; % 0 = KWN mean filed growth, 1 = Heinig model, 2 = empirical fit, 4 = ballistic mixing. (for model calibration, simplfiy things and go for 0 and 4 only)

% Set parameters
Alloy = 4; %
SetConc = 1;
FeConc = [];
CrConc = [];
NiConc = [];
radflag = 1;
TargetMode = 0;
TargetModeDiameter = [];
Taylor = 1;
Motta = 0;
PreFile = 'Bajaj_dbar240';
%PreFile = 'Garz1989_290C';
tcprof = [];
OFN = convertStringsToChars('TestRun');
PSDSnap = 1;
PSDStage = 1;
d=[];

%Make both solubility and diffusivity a function of vacancy
%supersaturation, explore the effects this has...(u
VacSuper = [5,6,7]; %Vacancy super saturation 1x10^(x)

% This is in Model1_IsoIrrad_v1.1
cd Model1_IsoIrrad_v1.1/
OutputStatement = ScriptToRunIsoIrrad(Alloy,SetConc,FeConc,CrConc,NiConc,radflag,TargetMode,TargetModeDiameter,Taylor,Motta,PreFile,Time,Temperature,Flux,tcprof,OFN,PSDSnap,PSDStage,PhiCons,xa_finaldpa,DiffMod,sfen_amorph_diss,vmol_diss,InvCorseFlag,d,VacSuper);
cd ../
