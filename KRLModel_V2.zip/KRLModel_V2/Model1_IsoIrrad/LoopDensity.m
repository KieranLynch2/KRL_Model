function [c_loop,Ncout] = LoopDensity(phi,t,Ncout,firstit)
% 
% %This just tracks c-loop denisty and is combined with a-loop density
% withn nucrate function
% 
doserate = phi./(5e20);

dose = doserate.*t;

% doseout = [0];
% Ncout = [0];
% Nc = 0;

if firstit == 0
    Nc = 0;
end


A = 5;
% dose = 20;
% if (3 < dose)
%     if dose < 23
%         if Ncout(end) < 1e21
%             Nc = 1e21.*(A.*exp(A*(dose-3)/(23-3)))/((23-3)*(exp(A)-1));
%         end
%     end
% end

if (3 < dose) && (dose < 23) && (Ncout(end) < 1e21)
    Nc = 1e21.*(A.*exp(A*(dose-3)/(23-3)))/((23-3)*(exp(A)-1));
else
    Nc = 0;
end


% doseout = [doseout dose];
if firstit == 0
    Nc_tot = Nc;
else
    Nc_tot = Nc + Ncout(end);
end

Ncout = [Ncout Nc_tot];

c_loop = Ncout(end);

end



% plot(doseout,Ncout)


% %From: Barashev A V., Golubov SI, Stoller RE. Theoretical investigation of microstructure evolution and deformation of zirconium under neutron irradiation. J Nucl Mater. 2015 Jun 1;461:85–94. 
% 
% dpa = phi./(5e20); %This is dpa/s
% 
% dose = dpa.*t; %dpa/s .* time = dpa i.e. dose
% 
% 
% NvaMax = 1e22;
% NiaMax = 1e22;
% NcMax = 1e21;
% Doseamax = 3.84;
% 
% if Na1v < NvaMax/3
%     dNa1v = NvaMax/(3.*Doseamax);
% else
%     dNa1v = 0;
% end
% 
% if Na2v < NvaMax/3
%     dNa2v = NvaMax/(3.*Doseamax);
% else
%     dNa2v = 0;
% end
% 
% if Na3v < NvaMax/3
%     dNa3v = NvaMax/(3.*Doseamax);
% else
%     dNa3v = 0;
% end
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% % end
% 
% 
% 
% 
% 


%% Below is trial work from 1. Patra A, Tomé CN, Golubov SI. Crystal plasticity modeling of irradiation growth in Zircaloy-2. http://dx.doi.org/101080/1478643520171324648. 2017 Aug 13;97(23):2018–51. 


% doseout = [];
% loopdenout = [];
% 
% for t = 100000:100000:365*24*60*60*4
% phi = 0.5e14;
% % t = 365*24*60*60*2;
% 
% dpa = phi./(5e20); %This is dpa/s
% 
% dose = dpa.*t; %dpa/s .* time = dpa i.e. dose
% 
% a_loop = (1.98e11*(dose^2))-(6.23e12*(dose))+4.76e13;
% 
% c_loop = (1.87e11*(dose^2))-(4.58e12*(dose))+3.26e13;
% 
% loop_den = a_loop + c_loop;
% 
% doseout = [doseout dose];
% loopdenout = [loopdenout loop_den];
% end
% 
% semilogy(doseout,cumsum(loopdenout))
