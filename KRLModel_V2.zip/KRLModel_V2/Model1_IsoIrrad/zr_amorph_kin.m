function[r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout,vf_aout,vf_totout,xbinst_tot,ramout,vfout_FeNi,rbarout_FeNi,nrout_FeNi,npartout_FeNi,r_FeNi,n_FeNi,rcout_FeNi,ram_diss,xbout_a_Cr,xbout_a_Fe,xbout_c_Fe,r_a_shell,xb_tot_check,amorph_diss_out,rbar_totout,xbout_Zirc2,vf_totalout,r_total,r_cryst,n_cryst,vf_amorphout,vf_crystout,xa_store,r_ln,n_ln,dsr1out,dsr2out,dsr3out,r_lnFeNi,n_lnFeNi,Fe2Cr_vf,Fe2Cr_rat,rb_clust,r_clust,n_clust,npart_clustout,vf_clustout,rbar_clustout,EqRadout,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,xbout_Zirc2_FeCr,xbout_Zirc2_FeNi,FeSumAmorph,FeSumTotal,CrSumTotal,tauamorph,tau_sl,CrDiffProfout]= ... 
    zr_amorph_kin(r,n,zirc2flag,rb,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi,tk,tfinal,d,d_FeNi,xa,xb,xc,xc_a,xb_FeNi,xc_FeNi,sfen,sfen_FeNi,nsites,vmol,vmol_FeNi,a,a_init,vmax,vmax_FeNi,xc_clust,phi,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,FeCrRat,FeNiRat,xa_FeNi,a_FeNi,Motta,Taylor,TimeTotal,ramTotal,FeAmorphDissTotal,CrTotal,FeAmorphTotal,r_cryst_in,n_cryst_in,MultiStepFlag,AmorphIncFlag,DissIncFlag,AmorphIncTimeDone,DissIncTimeDone,FeConc,CrConc,NiConc,TargetMode,TargetModeDiameter,tkprof,radflag,PhiCons,xa_finaldpa,DiffMod,sfen_amorph_diss,vmol_diss,InvCorseFlag,VacSuper,d_final_dpa,SolubIradMultiply,QIntConGrw,zeta,zirc2flag_Irrad,DiffFlag)
% ====================================================================
%
% Calculates precipitation kinetics in Zirconium alloys
% **RUN zirconium_init.m FIRST
%
%
% NEED TO ADD IN OUTPUTS FOR FE-NI SPPS
%
% using 2nd order Runge Kutta formula for error checking and
% adaptive timestep control
%
% Reference (to source model, originally for Al3Zr)
% J. D. Robson and P. B. Prangnell, Acta Materialia, 49, 2001, p. 599-613
%
% Inputs
% r         Size bins (mean sizes) (m)
% rb        Size bins (edge sizes) (m)
% tk        Temperature  (K)
% tfinal    Time to calculate for (s)
% d         Diffusion coefficient of solute  (m^2/s)
% xa        Solute concentration in matrix in equilibrium with precipitate
% xb		Average solute concentration in matrix
% xc		Solute concentration in precipitate
% vmax      Maximum volume fraction of precipitate
% nsites    Number of nucleation sites for precipitate (m^-3)
% sfen      Interfacial energy of precipitate for growth/nucleation (Jm^-2)
% a_init	Initial Zr lattice parameter before precipitation
% a			Final Zr lattice parameter at the end of precipitation
% radflag   Irradiation active (=1)
%
% Outputs
% r         Mean size of size bins (m)
% n         Particle number density in each size bin (particles/m^3)
% tout      Time at each time-step (s)
% vfout     Volume fraction at each time-step
% rbarout   Mean particle radius at each time-step (micron)
% npartout  Particle number density at each time-step (particles/micron^3)
% nrout     Nucleation rate at each time-step (particles/m^3)
% rcout     Critical radius at each time-step (m)
% aout		Lattice parameter of zirconium at each time-step
% fsout		Estimated strength at each time-step
% M			Movie (not used)
%
% ====================================================================
%
na = 6.022045e23;
k = 1.380662e-23;
tau = 0;
tout = [];
tkout = [];
grout = [];
vfout = [];
rbarout = [];
npartout = [];
ndump = [];
npartcritout = [];
aout = [];
fsout = [];
npartcrit_old=[0 0 0 0 0 0];
nrcritout = [];
rcout_c = [];
rcout_a = [];
amorphout = [];
rgmax = [];
nrout = [];
M = [];
xbout=[];
vf_aout = [];
vf_totout = [];
xbinst_tot = [];
ramout = [];
xbout_a_Cr = [];
xbout_a_Fe = [];
xbout_c_Fe = [];
xb_tot_check = [];
amorph_diss_out = [];
rbar_totout = [];
vf_c_track = [];
vf_totalout = [];
vf_amorphout = [];
vf_crystout = [];
vf_a_track = [];
xa_store = [];
ModalRadout = [];
CrDiffProfout = [];
%All outputs for Fe-Ni type SPPs
%If any term does not have _FeNi suffix then it is of Fe-Cr type and can be
%crystalline or amorphous
grout_FeNi = [];
vfout_FeNi = [];
rbarout_FeNi = [];
npartout_FeNi = [];
ndump_FeNi = [];
npartcritout_FeNi = [];
aout_FeNi = [];
rcout_FeNi = [];
nrout_FeNi = [];
xbout_Zirc2 = [];
rbar_FeNi = 0;
% Below are fpr when iradiation is off but running zirc2
r_clustFeNi = [];
n_clustFeNi = [];
vf_clustFeNi = [];
xc_clustFeNi = [];
xc_avgFeNi = [];
xbout_Zirc2_FeCr = []; 
xbout_Zirc2_FeNi = []; 
npart_clustFeNi = 0;
% Empirical parameters PGP, CAP, and SOCAP
% Garzarolli et al. 
%
% CAP
% QR_cap = 40e3; % This is standard value from Garzarolli
QR_cap = 17e3; % Value from model that causes rbar values to collapse
cap = 0;
capout = [];
% PGP
k_pgp = 1e14./3600; % PGP rate factor
TA_pgp = 3.2e4;
pgp = 0;
pgpout = [];
k_socap = 1.11e-11; % SOCAP rate factor
QR_socap = 18.7e3; % SOCAP activation energy
socap = 0;
socapout = [];
%
%
if radflag == 1
%Create an array of amorphous shells which are initially equal to zero
lenr_a = length(r_a);
r_a_shell = zeros(1,lenr_a);
else 
    r_a_shell = zeros(1,length(r));
end
%nr = 0;
len = length(r);
gr(1:len)=0;
%grout(1:len)=0; 
dr2(1:len)=0;
rbar = (sum(r.*n))/sum(n);
rbar = (sum(r_FeNi.*n_FeNi))/sum(n_FeNi);
vf = 4/3 * pi * sum((r.^3) .* n);
vf_init = vf;
if radflag == 1
%Determine crystal vf per bin
vf_bin = 4/3 * pi * ((r.^3) .* n);
%Determine total SPP size vf per bin by adding core radius to shell radius;
vf_tot_bin = 4/3 * pi * (((r+r_a_shell).^3) .* n);
vf_a_bin = vf_tot_bin-vf_bin;
vf_a = sum(vf_a_bin); %Total volume fraction of amorphous material is the sum of each bin
else
    vf_a = 0;
    vf_amorph = 0;
end
vf_FeNi = 4/3 * pi * sum((r_FeNi.^3) .* n_FeNi);
solsuc = 0;
solfail = 0;
nucflag = 0;
nucflag_FeNi = 0;
%
% Runge-Kutta initialization - from matlab ode23old
%
t = 0;
rbar = 0;
pow = 1/3;
tol = 1e-3; % 0.1
% h is the value of the timestep increment
% hmax and hmin set limits on the range of timesteps
% the timestep is adjusted automatically using a 2nd order
% Runge-Kutta scheme
%
hmin = 1e-10;
hmax = 3e4;

if radflag == 1 && InvCorseFlag == 4
    hmax = 3e4;
end

% hmax = 1000;
mnum = 1e25;
%
% cw is KW fudge factor for tau calculation   
%
cw = 1.4;
%
ram = 0;
% phi = 1.2e14; %User input required (n/cm2/s)
%
hmaxinit=1e-10;
h_old = 10;
h = hmaxinit;
rc_old_c = 0;
rc_old_a = 0;
rc_c = 0;
rc_a = 0;
flag_me = 0;
coarseflag = 0;
firstit=0;
if (xb < xa)
    disp(['Alloy composition below solvus (Fe-Cr) - no precipitation. *end*'])
    return
end
if zirc2flag == 1
if (xb_FeNi < xa)
    disp(['Alloy composition below solvus (Fe-Ni) - no precipitation. *end*'])
    return
end
end
%ram_diss is the dissolution of the amorphous rims
%output mu is the factor required for Taylor model enhanced amorphization

%r_init = r;
%n_a_shell = n; %Number density of amorphous shell equals n 
xb_init = xb - ((xc - xa) * vf); %Matrix solute concentration before amorphization begins
if radflag == 1
    if isempty(n_cryst_in) == 1
        n_cryst = n; %n_cryst is to go with r, which will be crystalline cores
    else
        n_cryst = n_cryst_in;
    end
    if isempty(r_cryst_in) == 1
        r_cryst = r;
    else
        r_cryst = r_cryst_in;
    end
rb_cryst = rb;
r_total = r;
vf_total = 4/3 * pi * sum((r_total.^3) .* n);
rb_total = rb;
dsr1out = [];
dsr2out = [];
dsr3out = [];
r_ln = [];
n_ln = [];
r_lnFeNi = [];
n_lnFeNi = [];
end

%Set up some dummy variables for non-irradiated case. Most of these
%variables aren't used anymore, I just need to clean up the code.]
if radflag == 0
   % vf2_a = [];
   r_total = [];
   r_cryst = [];
   n_cryst = [];
   vf_amorphout = [];
   vf_crystout = [];
   vf_total = 4/3 * pi * sum((r.^3) .* n);
end
xbinst = [];
vf_cryst = vf_init; %For now, can change to calculate later

if radflag == 1
    n_clust = zeros(1,length(n));
    r_clust = r_total;
    rb_clust = rb_total;
    vf_clust = 4/3 * pi * sum((r_clust.^3) .* n_clust);
%      d = 6.5e-25; %Needed for irradiation case
    d_init = d;
% d_init = 6e-19;
    d_final = d_init.*4e-3;
    D_a = 0;
    D_b = 0;
    %N_a/b and D_a/b are coefficients for change in irradiation induced
    %nucleation site density and diffusivity.
    N_a = 0;
    N_b = 0;
    if zirc2flag == 1
        n_clustFeNi = zeros(1,length(n_FeNi));
        r_clustFeNi = r_FeNi;
        rb_clustFeNi = rb_FeNi;
        xc_clustFeNi = 0.09;
        Fe2Ni_vf = [];
        Fe2Ni_rat = [];
        xbinst_spptotFeNi = [];
        xboutFeNi_Fe = [];
        xboutFeNi_Ni = [];
    end
end
    N_a = 0;
    N_b = 0;
    Ncout = [];
    vf_amorph = 0; %Vol fraction of amorphous material at the start of irradiation = 0
Fe2Cr_vf = []; 
Fe2Cr_rat = [];
xbinst_spptot = [];
npart_clustout = [];
vf_clustout = [];
rbar_clustout = [];
EqRadout = [];

if radflag == 0
    vf_clust = 0;
    n_clust = zeros(1,length(n));
    r_clust = r;
    rb_clust = rb;
    c_loop=0;
    phi = 0;
end

r_old = r;
rb_old = rb;
n_old = n;
r_cryst_old = r_cryst;
n_cryst_old = n_cryst;
AmorphFeTrack = [];
TotalCrTrack = [];
TotalFeTrack = [];
xc_Fec_Track = zeros(1,length(r))+0.2; %Change 0.44 to a variable!
FeSumAmorph = [];
FeSumTotal = [];
CrSumTotal = [];
ramtot = 0;
hcheck_FeAmorph = 0;
if radflag == 1
    nucflag = 1;
    r_init = r;
    n_init = n;
end

tfinal_step = tfinal; %Save tfinal of the current step...

%For carrying several heat treatments/irradiations through.
if MultiStepFlag == 1
t = TimeTotal;
tfinal = tfinal + t;
if radflag == 1
ram = ramTotal;
ramtot = ram;
ramout = ram;
FeSumAmorph_FirstIt = FeAmorphTotal; %Need two for way i've modelled it later on
FeSumTotal_FirstIt = [FeAmorphDissTotal];
CrSumTotal_FirstIt = [CrTotal];
FeSumAmorph = [FeAmorphTotal];
FeSumTotal =[FeAmorphDissTotal];
CrSumTotal =[CrTotal];
tout = [t];
rbar_totout = [((sum(r_total.*n))./sum(n)).*1e9];
npartout = [sum(n)./1e18];
end
end

if isempty(tkprof) == 0
% Timestep setup for new tkprof method
t = TimeTotal;
tfinal_stepprof = tkprof(1,3);
tfinal = t + tfinal_stepprof;
ttotal = sum(tkprof(:,3));
% initial temperature
tk = tkprof(1);
stage = 1;
steptime = 0;
disp (['Heating stage ' num2str(stage)])
disp (['Temperature degC ' num2str(tk - 273)])
else
    ttotal = tfinal;
end


if radflag == 1
[mu,ram_diss,ram_total] = amorph_diss_mu(tfinal,phi,tk);
else
    mu = 0; ram_diss = 0; ram_total = 0;
end

tauamorph = amorph_inc(tk,phi);

if radflag == 1
    r_total_old = r_total;
    rb_total_old = rb_total;
    DissrTrack = [];

    xastart = xa;
    dstart = d;
    m_IrradDif=[]; 
    k_IrradDif = [];
    m_IrradDif2 = [];
    k_IrradDif2 = [];
    m_IrradDif3 = [];
    k_IrradDif3 = [];
    
    %Set up the diffusion cell for Cr 
    if InvCorseFlag == 4

    end
end

if radflag == 0
    CrDiffProf = [];
                FickFlag = 0;

end

while (t<tfinal)
     if isempty(tkprof) == 0
     if steptime + h > tkprof(stage,3), h = tkprof(stage,3) - steptime; end
     end



     % Temp dependent variables which adjust with non-isothermal temp
     if zirc2flag == 0
         xa = exp((-5.4e3./tk)-3.3);

         %% Uncommented this on 27/10/24 for diffusino trials for Gross - might need to do for Zircaloy-2
         %d = 6e-7 * exp(-(15930*1.0)/(tk)); %Changed this on 11/1/23 for some simulations

         %% Trials for 16/12/24 investigation - using standard KWN growth in the matrix
         dLow = 9.47e-6*exp(-1.61/(8.6e-5*tk)); %Perpendicular to c-axis is lower.
         dAv = ((9.47e-6*exp(-1.61/(8.6e-5*tk)))+(2.35e-6*exp(-1.39/(8.6e-5*tk))))/2;
         dHigh = 2.35e-6*exp(-1.39/(8.6e-5*tk)); %Parallel to c-axis is higer.

         if DiffFlag == 1
             d = dLow;
         elseif DiffFlag ==2
             d = dAv;
         elseif DiffFlag ==3
             d = dHigh;
         end

     elseif zirc2flag == 1
         xa = exp((-5.4e3./tk)-3.3);
         xa_FeNi = exp((-5.8e3./tk)-3.6);
         d_FeNi = 8.5e-7 * exp(-15700/(tk));

         dLow = 9.47e-6*exp(-1.61/(8.6e-5*tk)); %Perpendicular to c-axis is lower.
         dAv = ((9.47e-6*exp(-1.61/(8.6e-5*tk)))+(2.35e-6*exp(-1.39/(8.6e-5*tk))))/2;
         dHigh = 2.35e-6*exp(-1.39/(8.6e-5*tk)); %Parallel to c-axis is higer.

         if DiffFlag == 1
             d = dLow;
         elseif DiffFlag ==2
             d = dAv;
         elseif DiffFlag ==3
             d = dHigh;
         end
     end

     if radflag == 1 %% Additions on 10/10/24 to destabilise the SPPs via solubility increase
        if InvCorseFlag == 4 & firstit == 0
        %% Setup and track Cr diffusion profile for a driver behind SPP dissolution
            xb_initCr = exp((-5400/tk)-4.1);
            [CrDiffProf,CrDiffProf_X,xb_initCr] = FicksCrDiffSetUp(xb_initCr);
            FickFlag = 0;
        elseif  InvCorseFlag ~= 4
             xb_initCr = exp((-5400/tk)-4.1);
            [CrDiffProf,CrDiffProf_X,xb_initCr] = FicksCrDiffSetUp(xb_initCr);
            FickFlag = 0;
        end

         Tmax = 600;
         Tmin = 400;
         %PhiCons = 2e-10; %These are currently being parsed through to
         %calibrate the model
         %xa_finaldpa = 20; %This is the point where the effective solubility limit saturates

         %% determination of xa_max
         %xamax = xastart .* (1+ (( (Tmax - tk)./(Tmax - Tmin) ) .* phi * PhiCons) );
         Tmax = 645;
         Tmin = 380;
         Tmid = 543;
          % if InvCorseFlag == 5
          %     SolubIradMultiply = 250; %flux indepedent solubility
          % else 
          %     SolubIradMultiply = phi * PhiCons;
          % end
         if tk < Tmid
             Xa_irr = xastart .* (1+ (( (Tmax - tk)./(Tmax - Tmin) ) .* SolubIradMultiply) );
         elseif Tmid <= tk && tk <=  Tmax
             Xa_irr_peak = xastart .* (1+ (( (Tmax - tk)./(Tmax - Tmin) ) .* SolubIradMultiply) );%(y1)
             Xa_irr_end = exp((-5.4e3./Tmax) - 3.3); %(y2)
             k = log(Xa_irr_end/Xa_irr_peak) / (Tmax - Tmid);
             Xa_irr = Xa_irr_peak * exp(k * (tk - Tmid));
         elseif tk > Tmax
             Xa_irr = xastart;
         end
        xamax = Xa_irr;
        
         xa_X = [0 xa_finaldpa];
         xa_Y = [xastart xamax];
         doserate = phi./(5e20);
         dose = doserate.*t;

         if dose < xa_finaldpa
             xaInterp = interp1(xa_X,xa_Y,dose);
             xa = xaInterp;
         else
             xa = xamax;
         end

        % xa model technique for 11/11/24 (for both models 4 and 5)
        Tmax = 377 + 273;
        Tmin = 147 + 273;

        Xa_eq = exp((-5.4e3./tk) - 3.3);
        Xa_eqCr = exp((-5400/tk)-4.1);
        Xa_irr = Xa_eqCr .* (1+ (( (Tmax - tk)./(Tmax - Tmin) ) .* SolubIradMultiply) );
        xa = Xa_irr;

        %% New model technique 1511/24 - constant irradiation-altered
        %solubility -- DELETE THIS IS RETURNING TO SOLUBILITY THAT CHANGES
        %WITH TEMPERATURE
        %
        Xa_irr = SolubIradMultiply;
        xa = Xa_irr;


         %xa = xastart*1000;
         %% Irradiation altered diffusivity and solubility to control SPP dissolution
         %d = dstart./DiffMod; %Using equilibiurm Fe-Cr diffusion fitted to
         %KWN model

        % d = ( ( 9e-5 * exp((-3.17/(8.6173e-5*tk))) ) / 0.65 ) * DiffMod; %original expression from Hood 1997
        % d = ( 1.44e-6 *exp((-1.83/(8.6173e-5*tk))) ) * DiffMod; % From Jain et al. - can correlate the optimal diffusion to this equation multiplied by the DiffMod, which should indicate the vacancy supersturation levels.
        
        %% Irradiation altered diffusion - depends on vacancy supersaturation

        [d,m_IrradDif,k_IrradDif,m_IrradDif2,k_IrradDif2,m_IrradDif3,k_IrradDif3] = IrradDif(tk,VacSuper,firstit,m_IrradDif,k_IrradDif,m_IrradDif2,k_IrradDif2,m_IrradDif3,k_IrradDif3,d_final_dpa,phi,t);

        % Next step is to put in a < 548 K other diffusivity as mechanism
        % switches from interstitial to vacancy (Eq. 6.22 in KL thesis)

        % xa_eq = exp((-5.4e3./tk)-3.3);
        % k0 = phi./(5e20);
        % q = 50;
        % lam = 1e-9;
        % delta = (q.*k0.*(lam.^2))./(d.*xa_eq);
        % xa_irr = xa_eq*(1+delta);
        % xa = xa_irr;

        xc_a = 0.27+0.22;

        %% Interface controlled growth and ballistic dissolution diffusion here
        if InvCorseFlag == 4
            %Need to determine how much solute was added to the first bin
            %from dissolution of SPP in previous interation. As this method
            %uses a 1D approach, dissolution rate is consistent across all
            %SPP size classes
            if firstit > 0
                 [CrDiffProf,FickFlag] = FicksCrDiff(CrDiffProf,CrDiffProf_X,d,h,CrSumTotal,xb_initCr,CrDiffProfout,zeta,phi);
            end

            if firstit > 3

                if tout(end) < tauamorph
                    if tout(end) + 30000 > tauamorph
                        hmax = 5;
                    else
                        hmax = 30000;
                        if tk > 333+273
                            hmax = 2000;
                        end
                    end
                else
                    hmax = 30000;
                    if tk > 333+273
                        hmax = 2000;
                    end
                end

            end
        end

     end

%     nucflag = 1; %This is temporary and just for the Zirc-4 long-term irrad studies
    %
    %Adjusting sfen of Fe-Ni SPPs to fit low and high CAP results
%     if zirc2flag == 1
%         if rbar_FeNi < 30
%              sfen_FeNi = 0.005;
%         else
%              sfen_FeNi = 0.01;
%         end
%     end
    
    % stopper
    %if t>1.725e6
    %    disp(['stop'])
    %end
    if t + h > tfinal, h = tfinal - t; flag_me =1; end
    %
    if radflag == 1
        %This has to be implemented to stop excess solute from the 700C
        %anneal nucleating as new particles during ~300 C irradiations.
        %If i want to track cluster nucleation i have to create a seperate
        %nucflag for that. 26/5/22
%         nucflag = 1;
    end


    if radflag == 1
%         [d] = IrradDif(d_init,tfinal,t);
        % [d,D_a,D_b] = IrradDif(d_init,d_final,t,phi,D_a,D_b,firstit);  %commented out on 9/10/24 - could rexplore this, as vacancies increase, d will decrease
        
%         [c_loop,Ncout] = LoopDensity(phi,t,Ncout,firstit);
        c_loop = [];
        Ncout = [];
        alpha0 = alpha_zero(tk,phi);
    
                
        %Calculate change in xa leading to amorphization dissolution
        %Adjusting solubility limits to induce amorphous zone dissolution
%         [xa,xa_store,tau_sl] = sol_lim(xa,h,firstit,xa_store,tk,phi,t,xbout_c_Fe,xbinst);
%         xa = exp((-5.4e3./tk)-3.3); 
        tau_sl = az_inc(tk,phi);
        if DissIncFlag == 1
            tau_sl = 0;
        end 

    else
        tau_sl = [];
    end

    if d < 2e-20
        aaaa = 44;
    end
    % 
%     if radflag == 1
%        %
%        %
%        %
%        if t > tauamorph
%            ram = amorph_depth_taylor(h,ram,phi,alpha0,mu);
%        else
%            ram = 0;
%        end
%     else
%        ram = 0;
%     end
%     %
%     %Update crystalline core and amorphous rim (dummy SPP) arrays
%     if radflag == 1
%         [r_cryst,rb_cryst,n_a,n_cryst,r_a_shell,rb_a_shell] = cryst_to_amorph(r_cryst,r_a,rb_cryst,n_a,n,ram,r_a_shell);
%     %
%     %Dissolution of the amorphous zone/array
%     %This was going to be done in growth amorph, but that method doesn't
%     %seem suitable
%     %25.1.22 - This funciton is redundant as amorphous zone dissolution now
%     %happens to r_total in growth_amorph.
% %     [r_a_shell,amorph_diss_out,n_cryst,r_cryst,r_total] = amorph_diss(r_a_shell,phi,tfinal,h,ram,amorph_diss_out,r,n,n_cryst,r_cryst,r_total);
%     end
    %
    rc_c = critrad_cryst(sfen,xa,xb,xc,xc_a,vf_cryst,vf_a,tk,vmol,radflag,vf_total,vf,vf_clust,vf_amorph,xc_clust);
    if radflag == 1
          rc_a = critrad_amorph(sfen,xa,xb,xc,xc_a,vf_cryst,vf_a,tk,vmol,radflag,vf_total,vf,vf_clust,vf_amorph,xc_clust);
    else
        rc_a = 1;
    end
    %
    %Critical radius for Fe-Ni SPPs
    if zirc2flag == 1
    rc_FeNi = critrad_cryst_FeNi(sfen_FeNi,xa_FeNi,xb_FeNi,xc_FeNi,vf_FeNi,tk,vmol_FeNi,xb,xc,vf);
    end

    if radflag == 1
        %r_total = r_cryst + r_a_shell;
        %rb_total = rb_cryst + rb_a_shell;
        %Make sure that when r_total == 0, n drops to zero
        %r_total_zero = find(r_total <= 0);
        %r_total(r_total_zero) = 0;
        %%%%%%%%%n(r_total_zero) = 0;
    end


    % Multiplication factor
    %
    %Turn off these when irradiation is on (no new nucleation, for now)
    if radflag == 1
%         nucflag = 1;
        nucflag_FeNi = 1;
    end
    newsize = 1.1 * rc_c;
    search=0;
    search=find(rb<newsize); %gets bin edge positions less than the newsize
    bin=max(search); %finds largest radius bin edge position smaller than newsize
    if bin>length(r-1) %if the largest bin edge position which is less than the newsize (critical radius + 10%) is greater than the second last r bin position
        if nucflag == 0
            disp 'New particles exceed size range (Fe-Cr)!'
        end
        if nucflag == 1
            % Nucleation is complete - no new particles, set a dummy bin
            bin = 10;
        end
    end
    %Above ^ if the critical radius exceeds the size range of the r array
    %then new particles will never nucleate!
    if zirc2flag == 1
    newsize_FeNi = 1.1 * rc_FeNi;
    search_FeNi=0;
    search_FeNi=find(rb_FeNi<newsize_FeNi); %gets bin edge positions less than the newsize
    bin_FeNi=max(search_FeNi); %finds largest radius bin edge position smaller than newsize
    if bin_FeNi>length(r_FeNi-1) %if the largest bin edge position which is less than the newsize (critical radius + 10%) is greater than the second last r bin position
        if nucflag_FeNi == 0
            disp 'New particles exceed size range (Fe-Ni)!'
        end
        if nucflag_FeNi == 1
            % Nucleation is complete - no new particles, set a dummy bin
            bin = 10;
        end
    end
    end
    %
    %if bin==[], disp 'New particles smaller than size range !';end
    %
    % Check that top bin is not occupied
    %
    if n(end)>0, disp 'Bin overflow error - increase maximum size range'; end
    if zirc2flag == 1
    if n_FeNi(end)>0, disp 'Bin overflow error - increase maximum size range'; end
    end
%
% find bin in which critical radius lies. The bin in which new
% particles nucleate must be at least 1 greater than this
%
    search=0;
    search=find(rb<rc_c);
    rcbin=max(search);
    bindiff=bin-rcbin;
    if bindiff<1 & nucflag == 0
        disp(['WARNING! newsize and rc lie in same bin (Fe-Cr). Remesh narrower bins'])
    end
    
    %Fe-Ni
    if zirc2flag == 1
    search_FeNi=0;
    search_FeNi=find(rb_FeNi<rc_FeNi);
    rcbin_FeNi=max(search_FeNi);
    bindiff_FeNi=bin_FeNi-rcbin_FeNi;
    if bindiff_FeNi<1 & nucflag_FeNi == 0
        disp(['WARNING! newsize and rc lie in same bin (Fe-Ni). Remesh narrower bins'])
    end
    end
%
% Compute the slopes
% 
% slopes at start of interval%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%No need for nr_a1 as no amorphous SPPs will nucleate?
%Taken out r and r_a as growth_amorph function works on bin edges not mean
%size
%As r-ram and rb-ram only needs to happen once, so they should be
%output from nucgrow_amorph only once. Same as n_a which is updated in
%growth_amorph but only needs to be updated once

%Get vf of amorphous and crystalline arrays
if radflag == 1
         vf_total = 4/3 * pi * sum((r_total.^3) .* n);
         vf_cryst = 4/3 * pi * sum((r_cryst.^3) .* n_cryst); %Update vf_cryst for output purposes e.g. matrix solute conc.
         vf_clust = 4/3 * pi * sum((r_clust.^3) .* n_clust);
         vf_amorph = vf_total - vf_cryst; %vf_a is the same as vf_amorph! Not sure why i changed naming convention
    if zirc2flag == 1
        vf_FeNi = 4/3 * pi * sum((r_FeNi.^3) .* n_FeNi);
        vf_clustFeNi = 4/3 * pi * sum((r_clustFeNi.^3) .* n_clustFeNi);
    end
else
    vf_cryst = vf;
    rb_total = rb;
    r_total = r;
end

    if radflag == 1
        [nr1,gr1,gr_a1,EqRad,N_a,N_b] = nucgrow_amorph(vf_cryst,vf_a,ram,r_total,r_a,rb_total,rb_a,d,t,nsites,sfen,tk,xa,xb,xc,xc_a,tau,vmol,a,n,n_a,radflag,tfinal,ram_diss,ram_total,tau_sl,vf_total,zirc2flag,vmax,phi,n_clust,vf_clust,vf_amorph,xc_clust,N_a,N_b,firstit,c_loop,sfen_amorph_diss,vmol_diss,InvCorseFlag,CrSumTotal,FeSumTotal,FeSumAmorph,CrDiffProf,QIntConGrw,zeta,zirc2flag_Irrad);
    a=5;
    else
        [nr1,gr1,gr_a1,EqRad,N_a,N_b] = nucgrow_amorph(vf_cryst,vf_a,ram,r_total,r_a,rb_total,rb_a,d,t,nsites,sfen,tk,xa,xb,xc,xc_a,tau,vmol,a,n,n_a,radflag,tfinal,ram_diss,ram_total,tau_sl,vf_total,zirc2flag,vmax,phi,n_clust,vf_clust,vf_amorph,xc_clust,N_a,N_b,firstit,c_loop,sfen_amorph_diss,vmol_diss,InvCorseFlag,CrSumTotal,FeSumTotal,FeSumAmorph,CrDiffProf,QIntConGrw,zeta,zirc2flag_Irrad);
    end
    if nucflag == 1, nr1 = 0; end
    %Fe-Ni 
    if zirc2flag == 1
    [nr1_FeNi,gr1_FeNi] = nucgrow_amorph_FeNi(vf_FeNi,r_FeNi,rb_FeNi,d_FeNi,t,nsites,sfen_FeNi,tk,xa,xa_FeNi,xb_FeNi,xc_FeNi,tau,vmol_FeNi,a_FeNi,n_FeNi,radflag,xb,xc,vf,d,rb,rc_c,vmax_FeNi,r_clustFeNi,n_clustFeNi,vf_clustFeNi,xc_clustFeNi,phi,tau_sl,xc_avgFeNi);
    if nucflag_FeNi == 1, nr1_FeNi = 0; end
    end
   % nr1 = 0;
%
% slopes at middle of interval%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% to calculate the slope need to know the volume fraction
% at the middle of the interval. Need to temporarily update size
% distribution and hence find volume fraction
%
    newpart3 = (1-vf) * nr1 * (h/2);
    ntemp3 = n;
    ntemp3(bin)=ntemp3(bin)+newpart3;
    dr3 = gr1 * (h/2);
%
% Fe-Ni
if zirc2flag == 1
    newpart3_FeNi = (1-vf_FeNi) * nr1_FeNi * (h/2);
    ntemp3_FeNi = n_FeNi;
    ntemp3_FeNi(bin_FeNi)=ntemp3_FeNi(bin_FeNi)+newpart3_FeNi; %Nucleate new particles 10 % greater than crit rad
    dr3_FeNi = gr1_FeNi * (h/2);
end
% No need to add new particles to amorphous array as the nucleation rate is
% zero

    dr3_a = gr_a1 * (h/2);
    ntemp3_a = n_a;

%
% Temporarily update size distribution
%
% Crystalline cores and amorphous dummy SPPs
    if radflag == 0
    %Crystalline
    [np yp] = update_func_mod(r,rb,ntemp3,dr3);
    ntemp3 = np';    
    vf3 = sum(((4/3) * pi * (r.^3)) .* ntemp3);
    vf3_amorph = 0;
    end
    %Amorphous
    [np_a yp_a] = update_func_mod(r_a,rb_a,ntemp3_a,dr3_a);
    ntemp3_a = np_a';    
    vf3_a = sum(((4/3) * pi * (r_a.^3)) .* ntemp3_a);
    
    
    if radflag == 1
        
    [np yp] = update_func_mod(r_total,rb_total,ntemp3,dr3);
    ntemp3 = np';    
    n_cryst = ntemp3;
    vf3_cryst = sum(((4/3) * pi * (r_cryst.^3)) .* n_cryst); 
    vf3 = sum(((4/3) * pi * (r_total.^3)) .* ntemp3);
    vf3_amorph = vf3 - vf3_cryst;
    else
        vf3_cryst = vf;
    end
    %Fe-Ni
    if zirc2flag == 1
    [np_FeNi yp_FeNi] = update_func_mod(r_FeNi,rb_FeNi,ntemp3_FeNi,dr3_FeNi);
    ntemp3_FeNi = np_FeNi';    
    vf3_FeNi = sum(((4/3) * pi * (r_FeNi.^3)) .* ntemp3_FeNi);
    end
%
% Find slopes (nr & gr) at middle of interval
%
    if radflag == 1
        [nr3,gr3,gr_a3,EqRad,N_a,N_b] = nucgrow_amorph(vf3_cryst,vf3_a,ram,r_total,r_a,rb_total,rb_a,d,t,nsites,sfen,tk,xa,xb,xc,xc_a,tau,vmol,a,n,n_a,radflag,tfinal,ram_diss,ram_total,tau_sl,vf_total,zirc2flag,vmax,phi,n_clust,vf_clust,vf3_amorph,xc_clust,N_a,N_b,firstit,c_loop,sfen_amorph_diss,vmol_diss,InvCorseFlag,CrSumTotal,FeSumTotal,FeSumAmorph,CrDiffProf,QIntConGrw,zeta,zirc2flag_Irrad); 
    else
        [nr3,gr3,gr_a3,EqRad,N_a,N_b] = nucgrow_amorph(vf3_cryst,vf3_a,ram,r_total,r_a,rb_total,rb_a,d,t,nsites,sfen,tk,xa,xb,xc,xc_a,tau,vmol,a,n,n_a,radflag,tfinal,ram_diss,ram_total,tau_sl,vf_total,zirc2flag,vmax,phi,n_clust,vf_clust,vf3_amorph,xc_clust,N_a,N_b,firstit,c_loop,sfen_amorph_diss,vmol_diss,InvCorseFlag,CrSumTotal,FeSumTotal,FeSumAmorph,CrDiffProf,QIntConGrw,zeta,zirc2flag_Irrad); 
    end
    if nucflag == 1, nr3 = 0; end

    % Fe-Ni
    if zirc2flag == 1
    [nr3_FeNi,gr3_FeNi] = nucgrow_amorph_FeNi(vf3_FeNi,r_FeNi,rb_FeNi,d_FeNi,t,nsites,sfen_FeNi,tk,xa,xa_FeNi,xb_FeNi,xc_FeNi,tau,vmol_FeNi,a_FeNi,n_FeNi,radflag,xb,xc,vf,d,rb,rc_c,vmax_FeNi,r_clustFeNi,n_clustFeNi,vf_clustFeNi,xc_clustFeNi,phi,tau_sl,xc_avgFeNi);
    if nucflag_FeNi == 1, nr3_FeNi = 0; end
    end
   % nr3 = 0;
%
% slopes at end of interval%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% use nr & gr at middle of interval to calculate change in (r,n)
%
    newpart2 = (1-vf) * nr3 * (h);
    ntemp2 = n;
    ntemp2(bin)=ntemp2(bin)+newpart2;
    dr2 = gr3 * h;
    %
    %Fe-Ni
    if zirc2flag == 1
    newpart2_FeNi = (1-vf_FeNi) * nr3_FeNi * (h);
    ntemp2_FeNi = n_FeNi;
    ntemp2_FeNi(bin_FeNi)=ntemp2_FeNi(bin_FeNi)+newpart2_FeNi;
    dr2_FeNi = gr3_FeNi * h;
    end

    dr2_a = gr_a3 * (h);
    ntemp2_a = n_a;
% N ARAY FOR FE-NI IS NOT X1018 LIKE FE-CR
%
% Temporarily update size distribution
%
    if radflag == 0
    %crystalline
    [np yp] = update_func_mod(r,rb,ntemp2,dr2);
    ntemp2 = np';    
    vf2 = sum(((4/3) * pi * (r.^3)) .* ntemp2);
    vf2_amorph = 0;
    end
    %amorphous
    [np_a yp_a] = update_func_mod(r_a,rb_a,ntemp2_a,dr2_a);
    ntemp2_a = np_a';    
    vf2_a = sum(((4/3) * pi * (r_a.^3)) .* ntemp2_a);
    if radflag == 1
    %crystal vf only
    %Total

    if firstit > 2 && tout(end)/86400 > 0.033
        a = 5;
    end


    [np yp] = update_func_mod(r_total,rb_total,ntemp2,dr2);
    ntemp2 = np';    
    n_cryst = ntemp2;
    vf2_cryst = sum(((4/3) * pi * (r_cryst.^3)) .* n_cryst); 
    vf2 = sum(((4/3) * pi * (r_total.^3)) .* ntemp2);
    vf2_amorph = vf2 - vf2_cryst;
    else
        vf2_cryst = vf2;
    end
    %Fe-Ni
    if zirc2flag == 1
    [np_FeNi yp_FeNi] = update_func_mod(r_FeNi,rb_FeNi,ntemp2_FeNi,dr2_FeNi);
    ntemp2_FeNi = np_FeNi';    
    vf2_FeNi = sum(((4/3) * pi * (r_FeNi.^3)) .* ntemp2_FeNi);
    end
%
%
%
% Find slopes (nr & gr) at end of interval
% 
    if radflag == 1
        [nr2,gr2,gr_a2,EqRad,N_a,N_b] = nucgrow_amorph(vf2_cryst,vf2_a,ram,r_total,r_a,rb_total,rb_a,d,t,nsites,sfen,tk,xa,xb,xc,xc_a,tau,vmol,a,n,n_a,radflag,tfinal,ram_diss,ram_total,tau_sl,vf_total,zirc2flag,vmax,phi,n_clust,vf_clust,vf2_amorph,xc_clust,N_a,N_b,firstit,c_loop,sfen_amorph_diss,vmol_diss,InvCorseFlag,CrSumTotal,FeSumTotal,FeSumAmorph,CrDiffProf,QIntConGrw,zeta,zirc2flag_Irrad);  
    else
        [nr2,gr2,gr_a2,EqRad,N_a,N_b] = nucgrow_amorph(vf2_cryst,vf2_a,ram,r_total,r_a,rb_total,rb_a,d,t,nsites,sfen,tk,xa,xb,xc,xc_a,tau,vmol,a,n,n_a,radflag,tfinal,ram_diss,ram_total,tau_sl,vf_total,zirc2flag,vmax,phi,n_clust,vf_clust,vf2_amorph,xc_clust,N_a,N_b,firstit,c_loop,sfen_amorph_diss,vmol_diss,InvCorseFlag,CrSumTotal,FeSumTotal,FeSumAmorph,CrDiffProf,QIntConGrw,zeta,zirc2flag_Irrad);  
    end
    if nucflag == 1, nr2 = 0; end
    
    %Fe-Ni
    if zirc2flag == 1
    [nr2_FeNi,gr2_FeNi] = nucgrow_amorph_FeNi(vf2_FeNi,r_FeNi,rb_FeNi,d_FeNi,t,nsites,sfen_FeNi,tk,xa,xa_FeNi,xb_FeNi,xc_FeNi,tau,vmol_FeNi,a_FeNi,n_FeNi,radflag,xb,xc,vf,d,rb,rc_c,vmax_FeNi,r_clustFeNi,n_clustFeNi,vf_clustFeNi,xc_clustFeNi,phi,tau_sl,xc_avgFeNi);
    if nucflag_FeNi == 1, nr2_FeNi = 0; end
    end
   % nr2 = 0;
%

%amorphization process

if radflag == 1
%     if firstit == 0
%         [ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb] = Taylor_eq10_tfinal(tk,tfinal,phi,r,rb);
%       break
%     end
%     tauamorph = 0; %Only for calibration purposes 22/3/23 - REMEMBER TO REMOVE FOR REAL RUNS!
        if AmorphIncFlag == 1
            tauamorph = 0;
        end
    if t > tauamorph %tauamorph should be here normally.
        [ram,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,ramtot] = amorph_depth_taylor(h,ram,phi,alpha0,mu,tfinal_step,tk,r,rb,firstit,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,ramtot,tauamorph,Motta,Taylor); %Use this if wanting to revert back to Taylor equation from paper 1 
        vf_crat = vf_cryst/(vf_cryst+vf_amorph+vf_clust);
        vf_arat = vf_amorph/(vf_cryst+vf_amorph+vf_clust);
        vf_clustrat = vf_clust/(vf_cryst+vf_amorph+vf_clust);
        vat = vmol/6.022045e23;
        
    vf_tot = vf_total;
    vf_cryst = vf;
    if vf_total+vf_clust == 0
        xbinst = xb;
    else
        vf_crat = vf_cryst/(vf_cryst+vf_amorph+vf_clust);
        vf_arat = vf_amorph/(vf_cryst+vf_amorph+vf_clust);
        vf_clustrat = vf_clust/(vf_cryst+vf_amorph+vf_clust);
        
        xc_avg = (xc*vf_crat)+(xc_a*vf_arat)+(xc_clust*vf_clustrat);
        xbinst = xb - ((xc_avg - xa) * (vf_total+vf_clust));
    end
        [r_cryst,rb_cryst,n_a,n_cryst,r_a_shell,rb_a_shell,ramtot,ram,DissrTrack] = cryst_to_amorph(r_cryst,r_a,rb_cryst,n_a,ram,r_a_shell,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,tauamorph,h,d,xb,xc_a,vat,n,phi,n_clust,xc_clust,xc,vf_crat,vf_arat,vf_clustrat,r,xbinst,vmol,sfen,tk,xa,ramtot,r_old,rb_old,rb,r_total,r_total_old,rb_total,rb_total_old,tau_sl,t,DissrTrack,tfinal_step);
    else
        ram = 0;
    end
else
    ram = 0;
end






% Estimate the error
%
% In number density
%
    deltanum = norm(h*(nr1 - 2*nr3 + nr2)/3,'inf');
    if zirc2flag == 1
    deltanum_FeNi = norm(h*(nr1_FeNi - 2*nr3_FeNi + nr2_FeNi)/3,'inf');
    end
% Don't need during irradiation as no nucleation allowed
%
% In radius
%   %norm calculates the magnitude of the vector
% 'inf', then n is the maximum absolute row sum of the matrix.
    deltarad = norm(h*(gr1 - 2*gr3 + gr2)/3,'inf');
    
    %The difference in growth rates between intervals is causing the large
    %error, when irradiation is off it is fine, so something probs wrong
    %with irradiation growth rates calcs...
    gr1nrm = norm(h*gr1,'inf');
    gr2nrm = norm(h*gr2,'inf');
    gr3nrm = norm(h*gr3,'inf');
    if radflag == 1
        deltarad_a = norm(h*(gr_a1 - 2*gr_a3 + gr_a2)/3,'inf');
    else 
        deltarad_a = deltarad;
    end
    if zirc2flag == 1
    deltarad_FeNi = norm(h*(gr1_FeNi - 2*gr3_FeNi + gr2_FeNi)/3,'inf');
    end
    %
% Allowable errors
%
    %taunum = tol * 1e18;
    taunum = tol * 1e18; 
    taurad = tol * 1e-9;
%
% Limit maximum number of particles formed in each interval to mnum
% Don't need to change this as no nucleation in amorphization
    newpart1 = nr1 * h;
    if newpart1>mnum 
        numrange = 1;
        % make step size half the limiting maximum
        hnuc = mnum/(2 * nr1);
    else
        numrange = 0;
        hnuc = hmax;
    end
    
    %Fe-Ni
    if zirc2flag == 1
    newpart1_FeNi = nr1_FeNi * h;
    if newpart1_FeNi>mnum 
        numrange_FeNi = 1;
        % make step size half the limiting maximum
        hnuc_FeNi = mnum/(2 * nr1_FeNi);
    else
        numrange_FeNi = 0;
        hnuc_FeNi = hmax;
    end
    end
% Check total xbinst has not fallen too far
if radflag == 1
    if vf_total+vf_clust == 0
        xbinst = xb;
    else
        vf_crat = vf_cryst/(vf_cryst+vf_amorph+vf_clust);
        vf_arat = vf_amorph/(vf_cryst+vf_amorph+vf_clust);
        vf_clustrat = vf_clust/(vf_cryst+vf_amorph+vf_clust);
        
        xc_avg = (xc*vf_crat)+(xc_a*vf_arat)+(xc_clust*vf_clustrat);
        xbinst_temp = xb - ((xc_avg - xa) * (vf_total+vf_clust));
    end
    if xbinst_temp < xa
        xbcheck = 1;
    else
        xbcheck = 0;
    end
else
    xbinst_temp = xb - ((xc - xa) * vf2);
    %disp(['xa ' num2str(xa) ' xbinst_temp ' num2str(xbinst_temp)])
    if xbinst_temp < xa
        xbcheck = 1;
    else
        xbcheck = 0;
    end
end
        
%Xbinst check for Fe-Ni SPPs
%Update 28/7/21: use xa as normal for both systems, but then as the amount
%of Fe in the xbinst determination will be double it should be halved and
%the total solute concentration updated.
        if zirc2flag == 1
            
            
         xbinst_temp = xb - ((xc - xa) * vf2);
         xbinst_temp_FeNi = xb_FeNi - ((xc_FeNi - xa_FeNi) * vf2_FeNi);
         %disp(['xa ' num2str(xa) ' xbinst_temp ' num2str(xbinst_temp)])
         xbinst_temp_tot = xbinst_temp + xbinst_temp_FeNi;
         xbinst_temp_Fe = 0.24*xbinst_temp_tot; %Why 0.24????
         xbinst_temp_tot = xbinst_temp_tot*0.76 + xbinst_temp_Fe/2; %this will be Fe+Cr+Ni matrix solute conc., therefore not approraite for nucleation/growth equations - need to just do all Fe+Cr and all Fe+Ni for seperate systems.
         %Maybe for the 0.76*xbinst... above divide that by two to seperate
         %Ni and Cr?... Or change xa to include Fe+Cr+Ni?
         if xbinst_temp_FeNi< xa_FeNi %THIS XA is just Fe+Cr or Fe+Ni, whereas xbinst_temp_tot is Fe+Cr+Ni...
             xbcheck_Zirc2 = 1;
         else
             xbcheck_Zirc2 = 0;
         end

         if xbinst_temp< xa %THIS XA is just Fe+Cr or Fe+Ni, whereas xbinst_temp_tot is Fe+Cr+Ni...
             xbcheck_Zirc2 = 1;
         else
             xbcheck_Zirc2 = 0;
         end
        end

% Update the solution if the error is acceptable
%    
%Put in dummy errors for when Zircaloy-4 is running
if zirc2flag == 0
deltanum_FeNi = 0;
numrange_FeNi = 0;
xbcheck_Zirc2 = 0;
end

%Could add in another condition below, but this is just saying that during
%irradiation there is an increase in solubility in the matrix and so the
%matrix solute concentration will fall below the solubility limit
if radflag == 1
    xbcheck = 0; %Required as by nature xbinst will be less than xa during irradiation
end
xbcheck = 0; %should this be removed from non-irradiated case?
xbcheck_Zirc2 = 0;

%catch to speed things up if amorphous zone is not dissolving at all
%(mainly for testing purposes)
if firstit > 1
    if radflag == 1
        if CrSumTotal(end) == 0
            CrDiffProf = CrDiffProfout(1,:);
            FickFlag = 0;
        end
    end
end


    if (deltanum <= taunum) &  (numrange==0) & (xbcheck == 0) & (deltanum_FeNi <= taunum) &  (numrange_FeNi==0) & (xbcheck_Zirc2 == 0) & (FickFlag == 0)
         firstit = firstit + 1;

        t = t + h;

        if isempty(tkprof) == 0
        steptime = steptime + h;
        if (h == (tkprof(stage,3) - steptime));flag_me=1;end
        end

         if zirc2flag == 1
%          disp(['Updating solution ' num2str(h) ' time/h: ' num2str(t/3600) ' nucrate ' num2str(nr3) ' rc ' num2str(rc_c) ' nucrate_FeNi ' num2str(nr3_FeNi) ' rc_FeNi ' num2str(rc_FeNi)])
         

            rbarTOT = (sum(r_total.*n))./sum(n);
            rbarTOT_m = rbarTOT*1e9;
            
            numclus = sum(n_clust); 

            rbarTotFeNi = (sum(r_FeNi.*n_FeNi))./sum(n_FeNi).*1e9;
            % disp(['Updating solution ' num2str(h) ' time/h: ' num2str(t/3600) ' nucrate ' num2str(nr3) ' rc ' num2str(rc_c)  ' rbar ' num2str(rbarTOT_m) ' Num Clust ' num2str(numclus,4) ' EqRad ' num2str(EqRad.*1e9,4)])
            disp(['Updating solution ' num2str(h) ' time/h: ' num2str(t/3600) ' nucrate ' num2str(nr3) ' rc ' num2str(rc_c)  ' rbar ' num2str(rbarTOT_m) ' rbar_FeNi ' num2str(rbarTotFeNi)  ' Temp ' num2str(tk-273) ' C'])
        
         else
             
             %temp addition below
%              vf_total = 4/3 * pi * sum((r_total.^3) .* n);
%             rbarTOT = (vf_total./((4/3) * pi * sum(n)))^(1./3);
            rbarTOT = (sum(r_total.*n))./sum(n);
            rbarTOT_m = rbarTOT*1e9;
            
            numclus = sum(n_clust); 

            rbar_clust =((sum(r_clust.*n_clust))./sum(n_clust)).*1e9;
         
%             if firstit == 1
%                 npartout = 1;
%             end
           if radflag == 1
               CurModalDiameter = ModalDiameterDetermine(r,n);
               ModalRad = (CurModalDiameter/2).*1e9;
                if firstit >= 2
                   ModalDissRate = ((ModalRad.*1e-9)-(ModalRadout(1).*1e-9))/tout(end);
                   MeanRadDissRate = ( (rbar_totout(end).*1e-9)-(rbar_totout(1).*1e-9) )./tout(end);
                   MeanRadDissRateDPA = ( (rbar_totout(end).*1e-9)-(rbar_totout(1).*1e-9) )./ (tout(end).*(phi./5e20) );
                end
               if length(FeSumAmorph) > 1
             disp(['Updating ' num2str(h) ' time/d: ' num2str(t/86400) ' FeRelAmorph: ' num2str(FeSumAmorph(end)) ' FeRelTot: ' num2str(FeSumTotal(end))  ' CrRel: ' num2str(CrSumTotal(end)) ' rbar: ' num2str(rbarTOT_m) ' Modal radius: ' num2str(ModalRad) 'MeanRadDissRate(m/dpa): ' num2str(MeanRadDissRateDPA) ' MeanRadDissRate(m/s):' num2str(MeanRadDissRate) ' Temp: ' num2str(tk-273) ' C ' ' Flux: ' num2str(phi.*1e-14) 'x10^{14} n/cm2/s' ' ram: ' num2str(sum(ramout).*1e9) ' nm '])
               end
               else
            disp(['Updating solution ' num2str(h) ' time/h: ' num2str(t/3600) ' nucrate ' num2str(nr3) ' rc ' num2str(rc_c)  ' rbar ' num2str(rbarTOT_m) ' Temp ' num2str(tk-273) ' C'])
           end
            if firstit > 1
                 maximum = max(max(n));
                 nmax = find(n==maximum);
         dmode = (r(nmax)).*2;

         if dmode > 150e-9
             aa = 4;

         end
         
%          disp(['Updating solution ' num2str(h) ' time/h: ' num2str(t/3600) ' nucrate ' num2str(nr3) ' rc ' num2str(rc_c)  ' DMODE ' num2str(dmode.*1e9)])
         end

         end
         %
         % Calculate more accurate increment in size/number
         %
         if radflag == 0
             newpart = (1-vf)*h*(nr1 + 4*nr3 + nr2)/6;
             n(bin)=n(bin) + newpart;
             dr = h*(gr1 + 4*gr3 + gr2)/6;
         else
             newpart = (1-vf)*h*(nr1 + 4*nr3 + nr2)/6;
             n_clust(bin)=n_clust(bin) + newpart;
             dr = h*(gr1 + 4*gr3 + gr2)/6;
             
             [np yp]=update_func_mod(r_clust,rb_clust,n_clust,dr);
             n_clust = np';
             npart_clust = sum(n_clust);
             vf_clust = 4/3 * pi * sum((r_clust.^3) .* n_clust);
             if npart_clust > 0
                 %             rbar = (vf./((4/3) * pi * sum(n)))^(1./3);
                 rbar_clust = (sum(r_clust.*n_clust))./sum(n_clust);
             else
                 rbar_clust = 0;
             end    
         end
         
         if radflag == 1
         dr_a = h*(gr_a1 + 4*gr_a3 + gr_a2)/6;
         end
   
         %Fe-Ni
         if zirc2flag == 1
             if radflag == 0
                 newpart_FeNi = (1-vf_FeNi)*h*(nr1_FeNi + 4*nr3_FeNi + nr2_FeNi)/6;
                 n_FeNi(bin_FeNi)=n_FeNi(bin_FeNi) + newpart_FeNi;
                 dr_FeNi = h*(gr1_FeNi + 4*gr3_FeNi + gr2_FeNi)/6;
             else
                 newpart_FeNi = (1-vf_FeNi)*h*(nr1_FeNi + 4*nr3_FeNi + nr2_FeNi)/6;
                 n_clustFeNi(bin_FeNi) = n_clustFeNi(bin_FeNi) + newpart_FeNi;
                 dr_FeNi = h*(gr1_FeNi + 4*gr3_FeNi + gr2_FeNi)/6;

                 [np_FeNi yp_FeNi]=update_func_mod(r_clustFeNi,rb_clustFeNi,n_clustFeNi,dr_FeNi);
                 n_clustFeNi = np_FeNi';
                 npart_clustFeNi = sum(n_clustFeNi);
                 vf_clustFeNi = 4/3 * pi * sum((r_clustFeNi.^3) .* n_clustFeNi);
             end
             if npart_clustFeNi > 0
                 %             rbar = (vf./((4/3) * pi * sum(n)))^(1./3);
                 rbar_clustFeNi = (sum(r_clustFeNi.*n_clustFeNi))./sum(n_clustFeNi);
             else
                 rbar_clustFeNi = 0;
             end    
         end

         
         %disp(['Bin 1-5 n ' num2str(n(1:5))])
         %disp(['dr bins 1-5 ' num2str(dr(1:5))])
         %
         %
         if radflag == 0
         [np yp]=update_func_mod(r,rb,n,dr);
         n = np';
         npart = sum(n);
         vf = 4/3 * pi * sum((r.^3) .* n);
         if npart > 0
%             rbar = (vf./((4/3) * pi * sum(n)))^(1./3);
            rbar = (sum(r.*n))./sum(n);
         else
            rbar = 0;
         end
         else
         [np yp]=update_func_mod(r_total,rb_total,n,dr);
         n = np';
         npart = sum(n);
         
         
         
         vf_clust = 4/3 * pi * sum((r_clust.^3) .* n_clust);
         vf_total = (4/3 * pi * sum((r_total.^3) .* n)); %Total vf of SPP array minus Vf taken by clusters
         vf_cryst = 4/3 * pi * sum((r_cryst.^3) .* n_cryst); %Update vf_cryst for output purposes e.g. matrix solute conc.
         vf_amorph = vf_total - vf_cryst;
         if npart > 0
%             rbar_total = (vf_total./((4/3) * pi * sum(n)))^(1./3);
            rbar_total = (sum(r_total.*n))./sum(n);
         else
            rbar_total = 0;
         end
         end
         %Update amorphous array, don't need to update rbar as they are
         %only arbitrary spherical SPPs
         if radflag == 1
         [np_a,yp_a]=update_func_mod(r_a,rb_a,n_a,dr_a);
         n_a = np_a';
         npart_a = sum(n_a);
       
         %vf_a = 4/3 * pi * sum((r_a.^3) .* n_a);
         %Determine crystal vf per bin
%          vf_bin = 4/3 * pi * ((r_cryst.^3) .* n);
%          %Determine total SPP size vf per bin by adding core radius to shell radius;
%          vf_tot_bin = 4/3 * pi * (((r_cryst+r_a_shell).^3) .* n);
%          vf_a_bin = vf_tot_bin-vf_bin;
%          vf_a = sum(vf_a_bin); %Total volume fraction of amorphous material is the sum of each bin
         
         %Calculate total mean radius - cores + amorphous shells
         npart_tot = sum(n);
         if npart_tot > 0
             %Need to get total vf and use n array of amorphous shells as
             %this outlasts the crysalline number densities.
             vf_tot_sum = sum(vf_tot_bin);
             rbar_tot = (vf_tot_sum./((4/3) * pi * sum(n)))^(1./3);
         else 
             rbar_tot = 0;
         end
         end
         %
         %Fe_Ni
         if zirc2flag == 1
         [np_FeNi yp_FeNi]=update_func_mod(r_FeNi,rb_FeNi,n_FeNi,dr_FeNi);
         n_FeNi = np_FeNi';
         npart_FeNi = sum(n_FeNi);
         vf_FeNi = 4/3 * pi * sum((r_FeNi.^3) .* n_FeNi);
         if npart_FeNi > 0
%             rbar_FeNi = (vf_FeNi./((4/3) * pi * sum(n_FeNi)))^(1./3); %Might change this to the other mean
            rbar_FeNi = (sum(r_FeNi.*n_FeNi))./sum(n_FeNi);
         else
            rbar_FeNi = 0;
         end  
         end
         
         %
         % Output number of particles per um^3 and mean radius in nm
         % not interested in amorphous SPP rbar or npart
         %
         npart = npart/1e18;
         %
         rbar_nm = rbar*1e9;
         %
         %Fe-Ni
         if zirc2flag == 1
         npart_FeNi= npart_FeNi/1e18;
         %
         rbar_nm_FeNi = rbar_FeNi*1e9;
         end
         % Check if nucleation is complete
         %
         if nr3 < 1e-100
             if radflag == 0 %nucrate might initially be small for irradiation clusters
             nucflag = 1;
             end
         end
         %Fe-Ni
         if zirc2flag == 1
         if nr3_FeNi < 1e-100
             nucflag_FeNi = 1;
         end
         end
         % Update CAP and PGP
         %
         cap = cap + (h .* exp(-QR_cap .* (1./tk)));
         CDR = 480; %Cancel this out when no quench is active, i.e. make == 0.45
         pgp = pgp + ((0.45/CDR) .* k_pgp .* (h./3600) .* exp(-TA_pgp./tk));
         socap = socap + (k_socap./tk.^2) .* exp(-QR_socap.*(1./tk)) .* h;
         %
         % Build up output vectors
         %
         tout = [tout t];
         tkout = [tkout tk];
         vfout = [vfout vf]; %This now should only track crystalline cores
         rbarout = [rbarout rbar_nm];
         if radflag == 1
         rbar_totout = [rbar_totout rbar_total.*1e9]; %mean radius of entire SPP, including crystalline cores and amorphous rims
         vf_totalout = [vf_totalout vf_total]; %total vf of crystalline + amorphous rims
         vf_crystout = [vf_crystout vf_cryst];
         vf_amorphout = [vf_amorphout vf_amorph];
         end
         npartout = [npartout npart];
         nrout = [nrout nr3];
         rcout_c = [rcout_c rc_c*1e9];
         rcout_a = [rcout_a rc_a*1e9];
         amorphout = [amorphout ram*1e9];
         xbinst = xb - ((xc - xa) * vf); %This will be instanteneous solute matrix concentration based only on crystalline cores, some extra solute will be stored in amorphous material
         xbout = [xbout xbinst];
         ndump = [ndump; gr3];
         capout = [capout cap];
         pgpout = [pgpout pgp];
         socapout = [socapout socap];
         ramout = [ramout ram(1)]; %sum of ramout will give the total ram.
         %
         %Calculate xbinst using just amorphous array to determine solute
         %released from amorphous SPPs
         %Calculate total xbinst to determine total matrix solute concentration
         if radflag == 1
            if vf_total+vf_clust == 0
                xbinst = xb;
            else
                vf_crat = vf_cryst/(vf_cryst+vf_amorph+vf_clust);
                vf_arat = vf_amorph/(vf_cryst+vf_amorph+vf_clust);
                vf_clustrat = vf_clust/(vf_cryst+vf_amorph+vf_clust);
                
                xc_avg = (xc*vf_crat)+(xc_a*vf_arat)+(xc_clust*vf_clustrat);
                xbinst = xb - ((xc_avg - xa) * (vf_total+vf_clust));                
            end
         xbinst_tot = [xbinst_tot xbinst]; %This is the solute matrix concentration
         end
         if radflag == 1
             
             %This section is messed up now as the amorphous zone is
             %dissolving too.
             %Crystal part is easy to track as it will constantly be
             %decreasing
             %Amorphous part is more difficult as material is being created
             %and destroyed concurrently. Need to check vf before and after
             %crystal --> amorph transformation as this gives amount of
             %material created. Then the amount of dissolved material will
             %be vf change - vf transformed...
             % Amount of amorphous material dissolved at each timestep will
             % just be the original vf - new total vf. 
             
             vf_c_track = [vf_c_track vf_cryst];
             if firstit == 1
                vf_c_change = 0;
             else
                vf_c_change = vf_c_track(end-1) - vf_c_track(end);
             end
             
             if firstit == 1
                vf_a_diss = vf_init - vf_total;
             else
                vf_a_diss =  vf_totalout(end-1) - vf_totalout(end);
             end
             
%              vf_a_track = [vf_a_track vf_amorph];
%              if firstit == 1
%                 vf_a_diss = 0;
%              else
%                 vf_a_diss = vf_a_track(end) - vf_a_track(end-1);
%              end
             
             vf_c_rat = vf_c_change/(vf_c_change + vf_a_diss);
             TF_c = isnan(vf_c_rat);
             if TF_c == 1
                 vf_c_rat = 0;
             end
             vf_a_rat = vf_a_diss/(vf_c_change + vf_a_diss);
             TF_a = isnan(vf_a_rat);
             if TF_a == 1
                 vf_a_rat = 0;
             end
             %May have to change amorphous section - the change in vf
             %doesn't represent to amount of dissolved material, as there
             %is contribution from new added amoprhous material from c-t-a
             %transition. 
             %Find the change in xbinst between iterations, as this is the
             %amount of solute released
             
             %NNED A NEW XBINSTOT WHICH JUST TRACKS THE LOSS OF SOLUTE FROM
             %LARGE SPPS, EXCLUDING CLUSTERS
             if radflag == 1
                 if vf_total+vf_clust == 0
                     xbinst_spp = xb;
                 else
                     vf_crat = vf_cryst/(vf_cryst+vf_amorph);
                     vf_arat = vf_amorph/(vf_cryst+vf_amorph);
                     
                     xc_avg = (xc*vf_crat)+(xc_a*vf_arat);
                     xbinst_spp = xb - ((xc_avg - xa) * (vf_total));%???+vf_clust));
                 end
                 xbinst_spptot = [xbinst_spptot xbinst_spp];
             end
            
             if length(xbinst_spptot) <= 1
                 xb_change = xbinst_spptot(end) - xbinst_spptot(end);%on first iteration set it to be no change between volume fractions - can change this to carry over the end of specific arrays from the non irradiation run
             else
                 xb_change = xbinst_spptot(end) - xbinst_spptot(end-1); %change in crystalline vf by subtracting the vf of previous iteration from vf of current iteration            
                 %xb_change = abs(xb_change);
             end
             
             
             %This tracks solute lose via amoprhization and dissolution but
             %doesn't account for solute taken back up by cluster formation
             % Need to also consider the solute concentration profile of
             % amorphous zone. As an spp is dissolving it can be linear
             % from 40 - 10 at.%, so 10 at. % Fe is lost but as the core
             % diminishes the conc profile levels out.
%              if t > tau_sl
                if radflag == 1
             cryst_sol_loss = vf_c_rat*xb_change;
             amorph_sol_loss = vf_a_rat*xb_change;
             amorph_Cr_loss = (0.26/xc_a)*amorph_sol_loss; %See init script about Fe/Cr concs - this might have to change if running zry-2
             amorph_Fe_loss = (0.10/xc_a)*amorph_sol_loss; %Leave Fe as 0.25 as it is avergae between 0.4 (core) and 0.1 (edge). Need to change? As Fe released will be Fe at edge.?
             
             %The cumsum of these arrays gives the total matrix
             %concentration. To get the total matrix concentration I have
             %to take the final xbinst value determined from the pre-irradiation case and add that, although for that case I do not know the ratio of Fe/Cr. 
             xbout_a_Cr = [xbout_a_Cr amorph_Cr_loss]; %These arrays are the solute released at each iteration, whilst xbinst_tot is the total matrix solute concentration at that time
             xbout_a_Fe = [xbout_a_Fe amorph_Fe_loss];
             xbout_c_Fe = [xbout_c_Fe cryst_sol_loss]; %The sum of these three solutes and xb_init should equate to xbinst_tot.
%              else
%              cryst_sol_loss = 1*xb_change; %All solute loss when t < tau is from amorph-to-cryst transform
%              amorph_sol_loss = 0*xb_change;
%              amorph_Cr_loss = (0.26/0.51)*amorph_sol_loss; %these two don't matter as there is no amorphous dissolution
%              amorph_Fe_loss = (0.25/0.51)*amorph_sol_loss; 
%              
%              xbout_a_Cr = [xbout_a_Cr amorph_Cr_loss]; 
%              xbout_a_Fe = [xbout_a_Fe amorph_Fe_loss];
%              xbout_c_Fe = [xbout_c_Fe cryst_sol_loss];
%              
%              end
%                if FeSumAmorph_FirstIt == 0 
                   if any(r_cryst ~= r_cryst_old)
                       [FeRel_Am,FeRel_Both,CrRel,AmorphFeTrack,xc_Fec_Track,TotalCrTrack,TotalFeTrack] = FeAmorphRelease(r,n,r_cryst,n_cryst,r_old,n_old,r_cryst_old,n_cryst_old,phi,h,AmorphFeTrack,xc_Fec_Track,TotalCrTrack,TotalFeTrack,r_init,n_init,FeConc,CrConc,NiConc,zirc2flag);
                   else
                       FeRel_Am = 0;
                       FeRel_Both = 0;
                       CrRel = 0;
                   end
                    
                   if MultiStepFlag ~= 1
                   if length(FeSumAmorph) > 1
                       FeSumAmorph = [FeSumAmorph FeRel_Am+FeSumAmorph(end)];
                       FeSumTotal = [FeSumTotal FeRel_Both+FeSumTotal(end)];
                       CrSumTotal = [CrSumTotal CrRel+CrSumTotal(end)];
                   else
                       FeSumAmorph = [FeSumAmorph FeRel_Am];
                       FeSumTotal = [FeSumTotal FeRel_Both];
                       CrSumTotal = [CrSumTotal CrRel];
                   end
                   else
                       FeSumAmorph = [FeSumAmorph FeRel_Am+FeSumAmorph(end)];
                       FeSumTotal = [FeSumTotal FeRel_Both+FeSumTotal(end)];
                       CrSumTotal = [CrSumTotal CrRel+CrSumTotal(end)];
                   end
%                else 
%                    
%                    [FeRel_Am,FeRel_Both,CrRel,AmorphFeTrack,xc_Fec_Track,TotalCrTrack,TotalFeTrack] = FeAmorphRelease(r,n,r_cryst,n_cryst,r_old,n_old,r_cryst_old,n_cryst_old,phi,h,AmorphFeTrack,xc_Fec_Track,TotalCrTrack,TotalFeTrack,r_init,n_init,FeConc,CrConc,NiConc);
%                    FeSumAmorph = [FeSumAmorph FeRel_Am+FeSumAmorph(end)];
%                    FeSumTotal = [FeSumTotal FeRel_Both+FeSumTotal(end)];
%                    CrSumTotal = [CrSumTotal CrRel+CrSumTotal(end)];
%                    
%                end
        





if zirc2flag == 1
    if radflag == 1
        if vf_FeNi + vf_clustFeNi == 0
            xbinst_sppFeNi = xb_FeNi;
        else
            xbinst_sppFeNi = xb_FeNi - ((xc_FeNi - xa_FeNi) * (vf_FeNi)); %inst matrix concentration of FeNi SPPs (not clusters), used to track increase in solute in matrix per iteration to determine FeNi cluster formation
        end
    
    xbinst_spptotFeNi = [xbinst_spptotFeNi xbinst_sppFeNi];

    if length(xbinst_spptotFeNi) <= 1
        xb_changeFeNi = xbinst_spptotFeNi(end) - xbinst_spptotFeNi(end);%on first iteration set it to be no change between volume fractions - can change this to carry over the end of specific arrays from the non irradiation run
    else
        xb_changeFeNi = xbinst_spptotFeNi(end) - xbinst_spptotFeNi(end-1); 
    end
    
    FeNi_sol_loss = xb_changeFeNi;
    
    FeStoic = 0.9/1.9; %From Jan2021ModelUpdates pres - Fe/Ni ratio is 0.9
    NiStoic = 1/1.9; %For do Fe/Ni loss equal to the stoichiometric SPP conc.

    xbchange_FeNi_Fe = FeNi_sol_loss.*FeStoic;
    xbchange_FeNi_Ni = FeNi_sol_loss.*NiStoic;

    xboutFeNi_Fe = [xboutFeNi_Fe xbchange_FeNi_Fe];
    xboutFeNi_Ni = [xboutFeNi_Ni xbchange_FeNi_Ni];
    end
end
                end
             
             if radflag == 1
                 %New function to keep track of increase in clusters and their
                 %stoichiometry each iteration
                 [Fe2Cr_vf,Fe2Cr_rat] = ClusterTrackFeCr(newpart,bin,r_clust,xbout_a_Cr,xbout_a_Fe,xbout_c_Fe,Fe2Cr_vf,Fe2Cr_rat);
                 if zirc2flag == 1

                     %FeNi clusters have Fe(5.8) and Ni (3), indicating
                     %that Ni may be retained in the matrix to a greater
                     %extent. From solute released by SPPs (Ni slightly
                     %more than Fe) it may be possible to estiamte how much
                     %of each element stays in the matrix.

                     [Fe2Ni_vf,Fe2Ni_rat] = ClusterTrackFeNi(newpart_FeNi,bin_FeNi,r_clustFeNi,xboutFeNi_Fe,xboutFeNi_Ni,Fe2Ni_vf,Fe2Ni_rat);
                 end
             end
             %Output vectors for the clusters forming under irradiation
             if radflag == 1
                rbar_clust = ((sum(r_clust.*n_clust))./sum(n_clust)).*1e9; %Fill in output vectors including solute release ratios of clusters...
                rbar_clustout = [rbar_clustout rbar_clust];
                vf_clustout = [vf_clustout vf_clust];
                %nucrate is the normal nucrate above, as all new particles
                %are assigned to the cluster array under irradiation
                npart_clust = sum(n_clust);
                npart_clustout = [npart_clustout npart_clust];
                EqRadout = [EqRadout EqRad]; 
                ModalRadout = [ModalRadout ModalRad];
                CrDiffProfout = [CrDiffProfout;CrDiffProf];
                
                if zirc2flag == 1
                    %List cluster outputs of FeNi here
                end

             end

             
             %Need to add some code to distribute the starting xbinst
             %between the solutes to make sure graph makes complete sense -
             %this is just the excess solute in the matrix i.e. solubility
             %limit
             
             if firstit == 1
                xbsum = amorph_Cr_loss + amorph_Fe_loss + cryst_sol_loss + xb_init;
                xb_tot_check = [xb_tot_check xbsum];
             else
                xbsum = amorph_Cr_loss + amorph_Fe_loss + cryst_sol_loss;
                xb_tot_check = [xb_tot_check xbsum];
             end
         end
         % Calculation of a lattice parameter based on Vegard's law
         % 
         %ainst = a + ((xbinst./xb) .* (a_init - a));
         % Not edited this to account for amorphization case yet
         ainst = a + (((xbinst-xa)./(xb-xa)) .* (a_init - a));
         aout = [aout ainst * 1e10];
         solsuc = solsuc + 1;
         %bin disappears when rc hits zero - problems with gr during
         %irradiation
         %Set up an output vector to track dissolution rates
         if radflag == 1
             %Track mode, 1/2 mode and 2*mode
             [dsr1,dsr2,dsr3] = dissrate_track(r,n,dr,h);
             dsr1out = [dsr1out dsr1];
             dsr2out = [dsr2out dsr2];
             dsr3out = [dsr3out dsr3];
         else
             dsr1out = [];
             dsr2out = [];
             dsr3out = [];
         end
             
         grt = dr(bin)/h;
         grout = [grout grt];
         
         %Output vectors for only Fe-Ni SPPs 
         if zirc2flag == 1
         vfout_FeNi = [vfout_FeNi vf_FeNi];
         rbarout_FeNi = [rbarout_FeNi rbar_nm_FeNi];
         nrout_FeNi = [nrout_FeNi nr3_FeNi];
         npartout_FeNi = [npartout_FeNi npart_FeNi];
         rcout_FeNi = [rcout_FeNi rc_FeNi*1e9];
         
         
         
         xbinst_temp = xb - ((xc - xa) * vf2);
         xbinst_temp_FeNi = xb_FeNi - ((xc_FeNi - xa_FeNi) * vf2_FeNi);
         %disp(['xa ' num2str(xa) ' xbinst_temp ' num2str(xbinst_temp)])
%          xbinst_temp_tot = xbinst_temp + xbinst_temp_FeNi;
%          xbinst_temp_Fe = 0.24*xbinst_temp_tot;
%          xbinst_temp_tot = xbinst_temp_tot*0.76 + xbinst_temp_Fe/2; %this will be Fe+Cr+Ni matrix solute conc., therefore not approraite for nucleation/growth equations - need to just do all Fe+Cr and all Fe+Ni for seperate systems.  
%          
         if xbinst_temp < xa
            xbcheck_Zirc2 = 1;
         elseif xbinst_temp_FeNi < xa_FeNi
            xbcheck_Zirc2 = 1;
         else 
            xbcheck_Zirc2 = 0;
         end
       
%          if xbinst_temp_tot < xa
%              xbcheck_Zirc2 = 1;
%          else
%              xbcheck_Zirc2 = 0;
%          end
%          
         
         
         
         xbinst_temp_end = xb - ((xc - xa) * vf2);
         xbinst_temp_FeNi_end = xb_FeNi - ((xc_FeNi - xa) * vf2_FeNi);


         % 10/01/2023
         % From solute remaining in each system, assume Fe/Cr/Ni ratios are
         % same
%          xbinst_tempFeCr_Cr = xbinst_temp_end/(FeCrRat+1);
%          xbinst_tempFeCr_Fe  = xbinst_temp_end-xbinst_tempFeCr_Cr;
% 
%          xbinst_tempFeNi_Ni = xbinst_temp_FeNi_end/(FeNiRat+1);
%          xbinst_tempFeNi_Fe = xbinst_temp_FeNi_end-xbinst_tempFeNi_Ni;
% 
% %          xbout_Zirc2_FeCr = [xbout_Zirc2_FeCr xbinst_temp_end]; %track xbouts for each individual system
% %          xbout_Zirc2_FeNi = [xbout_Zirc2_FeNi xbinst_temp_FeNi_end];
% 
%          %Calc solute lost to SPPs in each system
%          SolSPPsFeCr = vf2.*xc;
%          SolSPPsFeNi = vf2_FeNi.*xc_FeNi;
%          %Solute remaining in each system
%          SolSystemFeCr = xb-SolSPPsFeCr;
%          SolSystemFeNi = xb_FeNi-SolSPPsFeNi;
%          %Solte available for pptn
%          SolAvFeCr = SolSystemFeCr-xa;
%          SolAvFeNi = SolSystemFeNi-xa;
% 
%          xbinst = SolAvFeCr;
%          xbinst_FeNi = SolAvFeNi;


         
         xbinst_endtemp_tot = xbinst_temp_end + xbinst_temp_FeNi_end; %Add the Cr, Ni and Fe remaining in system
%          xbinst_endtemp_Fe = 0.24*xbinst_endtemp_tot;
%          xbinst_endtemp_tot = xbinst_endtemp_tot*0.76 + xbinst_endtemp_Fe/2; 
%         
         
         xbout_Zirc2 = [xbout_Zirc2 xbinst_endtemp_tot]; %Okay to leave this as total Fe+Cr+Ni until irradiation, then can seperate to view seperate solutes.
         xbout_Zirc2_FeCr = [xbout_Zirc2_FeCr xbinst_temp_end]; %Okay to leave this as total Fe+Cr+Ni until irradiation, then can seperate to view seperate solutes.
         xbout_Zirc2_FeNi = [xbout_Zirc2_FeNi xbinst_temp_FeNi_end]; %Okay to leave this as total Fe+Cr+Ni until irradiation, then can seperate to view seperate solutes.
         end
         %Output vectors for useful combined info - matrix conc. etc.
     else
         solfail = solfail + 1;
    end 

    % Update temperature for next step
    %
    if isempty(tkprof) == 0
    if flag_me
        flag_me = 0;
        if stage<size(tkprof,1)
            stage=stage+1;
        else
            t = ttotal;
        end
        %stage = stage+1;
        tfinal=sum(tkprof(1:stage,3));
        steptime = 0;
        tk = tkprof(stage,1);
%         disp (['Heating stage ' num2str(stage)])
%         disp (['Temperature degC ' num2str(tk - 273)])
        h = hmin;
        firstit = 0;
    end
    if tkprof(stage,3)>0
        tk = ((steptime/tkprof(stage,3))*(tkprof(stage,2)-tkprof(stage,1)))+tkprof(stage,1);
    else
        tk = tkprof(stage-1,2);
    end
    end


     %
     if zirc2flag == 0
         deltarad_FeNi = 0;
     end
     if deltarad ~= 0.0 || deltarad_a ~= 0.0 || deltarad_FeNi ~= 0.0
         h1 = min(hmax, 0.9 * h * (taurad/deltarad)^pow);
     else
         h1 = hmax;
     end
     if zirc2flag == 1
     if deltarad_FeNi ~= 0.0 
         h1_FeNi = min(hmax, 0.9 * h * (taurad/deltarad_FeNi)^pow);
     else
         h1_FeNi = hmax;
     end
     end
     %
     if deltanum ~= 0.0 || deltanum_FeNi ~= 0.0
         h2 = min(hmax, 0.9 * h * (taunum/deltanum)^pow);
     else
         h2 = hmax;
     end 
     if zirc2flag == 1
     if deltanum_FeNi ~= 0.0
         h2_FeNi = min(hmax, 0.9 * h * (taunum/deltanum_FeNi)^pow);
     else
         h2_FeNi = hmax;
     end 
     end
     %
     if xbcheck == 1
         h3 = h./1.1;
     else
         h3 = hmax;
     end

     if FickFlag == 1
         h3 = h./1.1;
     else
         h3 = hmax;
     end

%      if xbinst < 5*xa
%          h3 = h./1.1;
%      else
%          h3 = hmax;
%      end


     if zirc2flag == 1
     if xbcheck_Zirc2 == 1
         h3_FeNi = h./1.1;
         h3_FeNi = hmax;
     else
         h3_FeNi = hmax;
     end
     end
     %
     % Step size for next step is smaller of step sizes
     % calculated for growth and nucleation
     % and limited by not exceeding mnum particles in each step
     % But if in first few iterations, make sure h doesn't get too big
     % h is not allowed to increase by more than 10% between steps
     %
     if firstit>100
      if zirc2flag == 1
      hprov = min([h1 h2 h3 hnuc h1_FeNi h2_FeNi h3_FeNi hnuc_FeNi]);
      else
      hprov = min([h1 h2 h3 hnuc]);
      end
      %disp(num2str([h1 h2 h3]))
      %if hprov == h1, disp(['limited by deltarad']); end;
      %if hprov == h2, disp(['limited by deltanum']); end;
      %if hprov == h3, disp(['limited by xbinst change']); end;
      h = max([hmin hprov]);
     else
      if zirc2flag == 1
      hprov = min([h1 h2 h3 hnuc h1_FeNi h2_FeNi h3_FeNi hnuc_FeNi]);
      h = min([hprov hmaxinit]);
      else
      hprov = min([h1 h2 h3 hnuc]);
      h = min([hprov hmaxinit]);
      end
     end
     if (h>1.1*h_old), h=1.1*h_old; end
     %
     % Check if xbinst--> xa reduce stepsize
     %
     %if xa > 0.99.*xbinst
     %    h = hmin;
     %    firstit = 0;
     %end
     h_old = h;
     % Need to save below for calculations of solute release.
     if radflag == 1
         r_total_old = r_total;
         rb_total_old = rb_total;
     end
     r_old = r;
     rb_old = rb;
     n_old = n;
     r_cryst_old = r_cryst;
     n_cryst_old = n_cryst;
     if hcheck_FeAmorph == 1
         h = h*0.1;
     end

    % Target mode to reach a modal diameter and then break the loop
    if TargetMode == 1 && zirc2flag == 0
        CurModalDiameter = ModalDiameterDetermine(r,n);
        if CurModalDiameter*1e9 > TargetModeDiameter
            break
        end
    end

%     %% catches to investigate things 10/10/24
% if radflag == 1
%     if rbar_totout(end) < 105
%         if rbar_totout(end) > rbar_totout(end-1)
%             a=5;
%             %disp('xbinst appraoching xa, leading to positive growth rates')
%         end
%     end
% end

end

 disp([num2str(solfail+solsuc) ' Iterations: ' num2str(solsuc) ' Successful ' num2str(solfail) ' Unsuccessful'])

 if radflag == 0
    [r_ln,n_ln] = lognrm_adjust(r,n,pgpout,rbarout,vfout);
    if zirc2flag == 1
        [r_lnFeNi,n_lnFeNi] = lognrm_adjustFeNi(r_FeNi,n_FeNi,pgpout,rbarout_FeNi,vfout_FeNi);
    else
        r_lnFeNi = []; n_lnFeNi = [];
    end
 end
%     r_ln = [];
%     n_ln = [];
%     r_lnFeNi = [];
%     n_lnFeNi = [];



end