function [xp,xa]=equilibriumzirc(tk)
% function [xnb]=equilibriumsc(tk)
% Calculates equilibrium solubility in zircaloy2 at temperature (tk)
% from Massih et al, J. Nuc. Mater. 322, 2003, 138-151
% 
xat = 1091.27 * exp(-18515.73/(8.3145 * tk));
xa = xat/1e6;
xp = 2/3;
return