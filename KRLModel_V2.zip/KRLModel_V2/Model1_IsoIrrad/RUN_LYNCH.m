%clear all
%% Air quenched
%Get a starting diameter to match as quenched (212 nm)
%[r,rb,n,tkprof,xb,xc,sfen,nsites,vmol,a,a_init]=zr_amorph_init_noniso([350 TEMP 30/3600; TEMP TEMP TIME],n,r,rb);
[r,rb,n,r_a,rb_a,n_a,xb,xc,xc_a,sfen,nsites,vmol,a,a_init,r_FeNi,rb_FeNi,n_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,zirc2flag]=zr_amorph_init_noniso_NEW([1050 10 30/3600],0);
[r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout,vf_aout,vf_totout,xbinst_tot,ramout,vfout_FeNi,rbarout_FeNi,nrout_FeNi,npartout_FeNi,r_FeNi,n_FeNi,rcout_FeNi,ram_diss,xbout_a_Cr,xbout_a_Fe,xbout_c_Fe,r_final,r_a_shell,xb_tot_check,amorph_diss_out,rbar_totout,xbout_Zirc2]= ... 
    zr_amorph_kin_noniso_NEW(r,n,zirc2flag,rb,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi,tkprof,xb,xc,xc_a,xb_FeNi,xc_FeNi,sfen,sfen_FeNi,nsites,vmol,vmol_FeNi,a,a_init,0);
plot((r.*2).*(10^9),n.*(10^-18))
xlim([0 400])

%% Water quenched
% %Get a starting diameter of 2 hours@700 of 112.5
% [r,rb,n,tkprof,xb,xc,sfen,nsites,vmol,a,a_init]=zr_amorph_init_noniso([700 700 4]);
% [r,n,tout,tkout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout]= ... 
%     zr_amorph_kin_noniso(r,rb,n,tkprof,xb,xc,sfen,nsites,vmol,a,a_init,0);
% plot((r.*2).*(10^9),n.*(10^-18))
% xlim([0 400])