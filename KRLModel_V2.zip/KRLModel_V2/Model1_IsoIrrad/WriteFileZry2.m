function WriteFileZry2(Outputs,Alloy,Time_in,Temperature_in,FeConc_in,CrConc_in,NiConc_in,FeCrRatio_in,FeNiRatio_in,IterCount,tcprof,OFN)


Nsteps = IterCount-1;

% convert tcprof to printable data. Format of [iso,ramp,iso,ramp];
NStages = size(tcprof,1); %Number of stages in tcprof
% NTimes = NStages/3;
Time_in = [];
Temperature_in_init = [];
Temperature_in_end = [];
for kj = 1:1:NStages
    Time_in = [Time_in;tcprof(kj,3)];
    Temperature_in_init = [Temperature_in_init;tcprof(kj,1)];
    Temperature_in_end = [Temperature_in_end;tcprof(kj,2)];
end


%% Write input parameters into a csv file
Stage = (1:1:NStages)';
Time_hours = (Time_in);
Temp_C_Start = (Temperature_in_init);
Temp_C_End = (Temperature_in_end);
Flux_n_cm2_s = (zeros(1,length(Time_in)))';
AlloyTab = zeros(1,length(Time_in))+Alloy';
Zircaloy = AlloyTab';
FeConc_atfrac = (zeros(1,length(Time_in))+FeConc_in)'; 
CrConc_atfrac = (zeros(1,length(Time_in))+CrConc_in)'; 
NiConc_atfrac = (zeros(1,length(Time_in))+NiConc_in)'; 
FeCrRatio = (zeros(1,length(Time_in))+FeCrRatio_in)';
FeNiRatio = (zeros(1,length(Time_in))+FeNiRatio_in)';


T = table(Stage,Zircaloy,Time_hours,Temp_C_Start,Temp_C_End,Flux_n_cm2_s,FeConc_atfrac,CrConc_atfrac,NiConc_atfrac,FeCrRatio,FeNiRatio);


FileNameSimCon = (['../Outputs/' OFN '_SimulatedConditions.csv']);
writetable(T,FileNameSimCon);

%% Write plotting stuff to an excel file with seperation by sheets per stage

FileNameExcel = (['../Outputs/' OFN '_AllOutputs.xlsx']);

for j = 1:Nsteps
    if length(Outputs(j).Radius) < length(Outputs(j).Time)
        Time_secs = Outputs(j).Time';

        MatrixSoluteConc_FeCr_atfrac = Outputs(j).SolConc';
        TotNumberDensitywTime_FeCr_perum3 = Outputs(j).NumDenwTime';
        MeanRadius_FeCr_nm = Outputs(j).MeanRad';
        VolumeFraction_FeCr = Outputs(j).VolFrac';

        MatrixSoluteConc_FeNi_atfrac = Outputs(j).SolConcFeNi';
        TotNumberDensitywTime_FeNi_perum3 = Outputs(j).NumDenwTimeFeNi';
        MeanRadius_FeNi_nm = Outputs(j).MeanRadFeNi';
        VolumeFraction_FeNi = Outputs(j).VolFracFeNi';        

        DumNaN = zeros(1,length(Time_secs)-length(Outputs(1).Radius));
        DumNaN(DumNaN == 0) = NaN;

        Radius_og = Outputs(j).Radius'.*1e9;
        Radius_FeCr_nm = [Radius_og;DumNaN'];
        NumDen_og = Outputs(j).NumDen'.*1e-18;
        NumberDensity_FeCr_perum3 = [NumDen_og;DumNaN'];

        Radius_FeCr_SOG_nm = [Outputs(j).Radius_ln'.*1e9;DumNaN'];
        NumberDensity_FeCr_SOG_perum3 = [Outputs(j).NumDen_ln'.*1e-18;DumNaN'];

         Radius_ogFeNi = Outputs(j).RadiusFeNi'.*1e9;
        Radius_FeNi_nm = [Radius_ogFeNi;DumNaN'];
        NumDen_ogFeNi = Outputs(j).NumDenFeNi'.*1e-18;
        NumberDensity_FeNi_perum3 = [NumDen_ogFeNi;DumNaN'];

        
        Radius_FeNi_SOG_nm = [Outputs(j).Radius_lnFeNi'.*1e9;DumNaN'];
        NumberDensity_FeNi_SOG_perum3 = [Outputs(j).NumDen_lnFeNi'.*1e-18;DumNaN'];

        TabExcelOutputs = table(Time_secs,MatrixSoluteConc_FeCr_atfrac,VolumeFraction_FeCr,MeanRadius_FeCr_nm,TotNumberDensitywTime_FeCr_perum3,Radius_FeCr_nm,NumberDensity_FeCr_perum3,Radius_FeCr_SOG_nm,NumberDensity_FeCr_SOG_perum3,MatrixSoluteConc_FeNi_atfrac,VolumeFraction_FeNi,MeanRadius_FeNi_nm,TotNumberDensitywTime_FeNi_perum3,Radius_FeNi_nm,NumberDensity_FeNi_perum3,Radius_FeNi_SOG_nm,NumberDensity_FeNi_SOG_perum3);
        writetable(TabExcelOutputs,FileNameExcel,'Sheet',j);

    else
        DumNaN = zeros(1,length(Outputs(1).Radius)-length(Outputs(j).Time));
        DumNaN(DumNaN == 0) = NaN;

        Radius_FeCr_nm = Outputs(j).Radius'.*1e9;
        NumberDensity_FeCr_perum3 = Outputs(j).NumDen'.*1e-18;
        Radius_FeCr_SOG_nm = Outputs(j).Radius_ln'.*1e9;
        NumberDensity_FeCr_SOG_perum3 = Outputs(j).NumDen_ln'.*1e-18;

        Radius_FeNi_nm =  Outputs(j).RadiusFeNi'.*1e9;
        NumberDensity_FeNi_perum3 = Outputs(j).NumDenFeNi'.*1e-18;
        Radius_FeNi_SOG_nm = Outputs(j).Radius_lnFeNi'.*1e9;
        NumberDensity_FeNi_SOG_perum3 = Outputs(j).NumDen_lnFeNi'.*1e-18;

        Time_secs_og = Outputs(j).Time';
        Time_secs = [Time_secs_og;DumNaN'];

        MatrixSoluteConc_FeCr_atfrac_og = Outputs(j).SolConc';
        MatrixSoluteConc_FeCr_atfrac = [MatrixSoluteConc_FeCr_atfrac_og;DumNaN'];

        TotNumberDensitywTime_perum3_og = Outputs(j).NumDenwTime';
        TotNumberDensitywTime_FeCr_perum3 = [TotNumberDensitywTime_perum3_og;DumNaN'];

        MeanRadius_nm_og = Outputs(j).MeanRad';
        MeanRadius_FeCr_nm = [MeanRadius_nm_og;DumNaN'];

        VolumeFraction_og = Outputs(j).VolFrac';
        VolumeFraction_FeCr = [VolumeFraction_og;DumNaN'];

        MatrixSoluteConc_FeNi_atfrac_og = Outputs(j).SolConcFeNi';
        MatrixSoluteConc_FeNi_atfrac = [MatrixSoluteConc_FeNi_atfrac_og;DumNaN'];

        TotNumberDensitywTime_FeNi_perum3_og = Outputs(j).NumDenwTimeFeNi';
        TotNumberDensitywTime_FeNi_perum3 = [TotNumberDensitywTime_FeNi_perum3_og;DumNaN'];

        MeanRadius_FeNi_nm_og = Outputs(j).MeanRadFeNi';
        MeanRadius_FeNi_nm = [MeanRadius_FeNi_nm_og;DumNaN'];

        VolumeFraction_FeNi_og = Outputs(j).VolFracFeNi';
        VolumeFraction_FeNi = [VolumeFraction_FeNi_og;DumNaN'];


        TabExcelOutputs = table(Time_secs,MatrixSoluteConc_FeCr_atfrac,VolumeFraction_FeCr,MeanRadius_FeCr_nm,TotNumberDensitywTime_FeCr_perum3,Radius_FeCr_nm,NumberDensity_FeCr_perum3,Radius_FeCr_SOG_nm,NumberDensity_FeCr_SOG_perum3,MatrixSoluteConc_FeNi_atfrac,VolumeFraction_FeNi,MeanRadius_FeNi_nm,TotNumberDensitywTime_FeNi_perum3,Radius_FeNi_nm,NumberDensity_FeNi_perum3,Radius_FeNi_SOG_nm,NumberDensity_FeNi_SOG_perum3);
        writetable(TabExcelOutputs,FileNameExcel,'Sheet',j);

    end
end


%% Dump the entire output history into one big csv file (only for variables that change with time)
% solute concentration is dumped as one entire list over all stages, r and
% n arrays only printed at begining and end.
FileNameCSVTime = (['../Outputs/' OFN '_TimeOutputs.csv']);


TimeTotStr = [];
SolConcStr = [];
NumDenStr= [];
MeanRadStr = [];
VolFracStr= [];
SolConcStr_FeNi = [];
NumDenStr_FeNi= [];
MeanRadStr_FeNi = [];
VolFracStr_FeNi= [];


for k = 1:Nsteps
    TimeTotStr = [TimeTotStr;Outputs(k).Time'];
    SolConcStr = [SolConcStr; Outputs(k).SolConc'];
    NumDenStr= [NumDenStr; Outputs(k).NumDenwTime'];
    MeanRadStr = [MeanRadStr; Outputs(k).MeanRad'];
    VolFracStr= [VolFracStr; Outputs(k).VolFrac'];
    SolConcStr_FeNi = [SolConcStr_FeNi;Outputs(k).SolConcFeNi'];
    NumDenStr_FeNi= [NumDenStr_FeNi;Outputs(k).NumDenwTimeFeNi'];
    MeanRadStr_FeNi = [MeanRadStr_FeNi;Outputs(k).MeanRadFeNi'];
    VolFracStr_FeNi= [VolFracStr_FeNi;Outputs(k).VolFracFeNi'];
end
TotTimeCSV = [TimeTotStr,SolConcStr,NumDenStr,MeanRadStr,VolFracStr,SolConcStr_FeNi,NumDenStr_FeNi,MeanRadStr_FeNi,VolFracStr_FeNi];

writematrix(TotTimeCSV,FileNameCSVTime,'Delimiter',',');
%% Dump final PSD to csv file, Most recent Radius and numden should be saved from foor loop above for xlsx write-out.
FileNameCSVPSD = (['../Outputs/' OFN '_PSDOutputs.csv']);
PSDCSV = [Radius_FeCr_nm,NumberDensity_FeCr_perum3,Radius_FeCr_SOG_nm,NumberDensity_FeCr_SOG_perum3,Radius_FeNi_nm,NumberDensity_FeNi_perum3,Radius_FeNi_SOG_nm,NumberDensity_FeNi_SOG_perum3];

writematrix(PSDCSV,FileNameCSVPSD,'Delimiter',',');





end