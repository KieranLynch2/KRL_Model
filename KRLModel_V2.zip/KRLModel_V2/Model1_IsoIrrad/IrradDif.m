function [d,m_IrradDif,k_IrradDif,m_IrradDif2,k_IrradDif2,m_IrradDif3,k_IrradDif3] = IrradDif(tk,VacSuper,firstit,m_IrradDif,k_IrradDif,m_IrradDif2,k_IrradDif2,m_IrradDif3,k_IrradDif3,d_final_dpa,phi,t)

%KL 04/04/2024 - VacSuper is just taken as 10^7 but then adjusted by a
%reduction by one order of magnitude further, see ZITNI paper
VacSuper = 7;


if firstit < 2 %just to spped things up - don't have to calculate it every time!
% VanInt_Line_x = [1181,1068,968,877,793,717];
% VanInt_Line_y = [1940,5955,17669,54239,166495,493999];

% Adjustment 13/11/24
VanInt_Line_x = [1000,900,800,700];
VanInt_Line_y = [1.2e4,3.56e4,1.48e5,9e5];


Const = polyfit(log(VanInt_Line_x),log(VanInt_Line_y), 1);
m_IrradDif = Const(1);
k_IrradDif = Const(2);


%% Determination of interstitial based mechanisms
Int_Mech_x = [1191,981,809]; %This is for a eq vacancy concentration - each x10 increase in vac leads to x10 decrease in diffusion, in this regime.
Int_Mech_y = [1e-11,1e-12,1e-13];

Const_2 = polyfit(log(Int_Mech_x),log(Int_Mech_y), 1);
m_IrradDif2 = Const_2(1);
k_IrradDif2 = Const_2(2);

%% Determination of vacancy based mechanism
Vac_Mech_x = [1147,1071,1003,937,876]; %This is for a 1e6 vacancy concentration - each x10 increase in vac leads to x10 decrease in diffusion, in this regime.
Vac_Mech_y = [1e-12,1e-13,1e-14,1e-15,1e-16];

Const_3 = polyfit(log(Vac_Mech_x),log(Vac_Mech_y), 1);
m_IrradDif3 = Const_3(1);
k_IrradDif3 = Const_3(2);


end

VacTransTK = tk.^m_IrradDif.*exp(k_IrradDif); % for tk, find if vac super sat is above or below transition line
if 10^VacSuper <= VacTransTK %Interstitial determined diffusion
    d = (tk.^m_IrradDif2.*exp(k_IrradDif2))./10^VacSuper; % Decrease by an order of mag for each order of mag increase in vacancies
elseif 10^VacSuper > VacTransTK %Vacancy determined diffusion
    VacSuperDiff = 6-VacSuper;
    d = (tk.^m_IrradDif3.*exp(k_IrradDif3))./10^VacSuperDiff;
end


dstart = (tk.^m_IrradDif2.*exp(k_IrradDif2)); %pure insterstitial mechanism at the start
dend = d;

d_X = [0 d_final_dpa];
d_Y = [dstart dend];
doserate = phi./(5e20);
dose = doserate.*t;

if dose < d_final_dpa
    dtemp = interp1(d_X,d_Y,dose);
else
    dtemp = dend;
end

d = dtemp*0.1; % Using constant vacanacy supersaturation of 7, but a further reduction by an order of magnitude was needed - see ASTM paper.

end
% doserate = phi./(5e20);
% 
% dose = doserate.*t;
% 
% if firstit == 0
%     [D_a,D_b] = DexpFit(d_init,d_final);
% end
% 
% if dose < 1
%     d = D_a.*exp(D_b.*dose);
% else
%     d = d_final;
% end
% 
% end


% tout = [];
% dout = [];
% tfinal = 60000000;
% d_init = 1e-20;
% phi = 0.6e14;
% for t = 1:10000:tfinal
% 
% d_final = 5e-25;
% 
% % tfrac = t/tfinal;
% % 
% % d_diff = d_init-d_final;
% % 
% % d_dec = d_diff.*tfrac;
% % 
% % d = d_init - d_dec;
% 
% 
% %% I probably need to slow down D at a constant rate, up tunil ~1 dpa, after
% %which it should plateu at a given value
% % If i can get this to work in a logarithmic way then i might be able to
% % find a combination of D and nsite values which work for smaples 2 & 3 of
% % Bajaj.
% % Might have to come up with exp relationship 
% 
% 
% k0 = phi./(5e20); %Conversion from flux to dpa/s
% 
% t1dpa = 1/k0;
% 
% if t < t1dpa  
%     
%     tfrac = t/t1dpa;
%     
%     d_spread = logspace(d_final,d_init,10);
%     d_spread2 = logspace(-26,-21,10);
%     
%     d = exp((log(d_init)+log(d_final)).*tfrac);
%     
% %     tfrac = t/t1dpa;
% %     d_diff = d_init-d_final;
% %     d_dec = d_diff.*tfrac;
% %     d = d_init - d_dec;
% else
%     d = d_final;
% end
% 
% tout = [tout t];
% dout = [dout d];
% end
% loglog(tout,dout)
% 
% 
% % end