function FickFlag = FickCheck(post,pre)

% rrows = sz(post,1);
cols = length(post);

xbPerChange = [];
for j = 1:1:cols
    change = (post(j)-pre(j));
    percent_i = abs(change./pre(j)).*100;
    xbPerChange = [xbPerChange percent_i];
end

%If any xbPerChange is inf, then make it zero.

if any(xbPerChange > 2)
    FickFlag = 1;
elseif any(post<0)
    FickFlag = 1;
else
    FickFlag = 0;
end

end