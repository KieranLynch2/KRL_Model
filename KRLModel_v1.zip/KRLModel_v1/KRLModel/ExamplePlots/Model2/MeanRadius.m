%% User Inputs
OutputFileName = 'Zirc4QuenchTest.mat'; %Zirc2TestNo, Zirc4TestNo, Zirc4Test
Stage = 1;
GraphTitle = '';
xmax = 200; % set xscale limit

%% Code - don't change. Copy to new script to change.

load (['..\..\Outputs\' OutputFileName])
MeanRadius_nm = sum(Outputs(Stage).MeanRad,2);
Time_secs = Outputs(Stage).Time';
semilogx(Time_secs,MeanRadius_nm,'LineWidth',2)
xlabel('Time / s')
ylabel('Mean radius / nm')
title([GraphTitle])
