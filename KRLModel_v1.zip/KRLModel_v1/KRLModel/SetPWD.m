%% Author: Kieran Lynch
% Date: 13/06/23
% Contact: kieran.lynch@manchester.ac.uk

function UserPWD = SetPWD

UserPWD = 'C:\Users\mcli4kl3\Dropbox (The University of Manchester)\Kieran Lynch\Model_progression\MATLAB_code\Finals\Code\KRLModel';

end