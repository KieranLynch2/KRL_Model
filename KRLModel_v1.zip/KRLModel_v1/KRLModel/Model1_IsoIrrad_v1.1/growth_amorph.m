function [gr,gr_a,r,rb,n_a,EqRad] = growth_amorph(r,r_a,rb,rb_a,rc_cryst,rc_amorph,ram,sfen,d,xbinst,xa,xc,xc_a,tk,vmol,n,n_a,radflag,tfinal,ram_diss,ram_total,t,tau_sl,vf,zirc2flag,vmax,phi,xb,n_clust,xc_clust,vf_crat,vf_arat,vf_clustrat)
% function [gr] = growth(r,sfen,d,xbinst,xc,xa,tk)
% Calculates growth rate of spherical Al3Zr dispersoids
%
% Inputs
% r         Particle radius (m) n.b. this script works with the bin edges
%           rather than the bin averages.
% sfen      Interfacial energy (J/m^2)
% d         Diffusion coefficient (m^2/s)
% xbinst    Average Zr concentration in matrix
% xc        Concentration of Zr in dispersoids
% xa        Concentration of Zr in matrix at interface
% tk        Temperature (K)
% Output
% gr        Growth rate (ms^-1)
% gr        Growth rate of the amorphous dummy SPPs
% r         Average particle radius (adjusted due to ram)
% rb         Particle radius bin edges (adjusted due to ram)
%
vfmax = vmax;
gas = 8.31459;
k = 1.3806488e-23;
h = 6.626e-34;
delta = 3.2e-10; % width of interface (assume approx <a> Zr)
na = 6.022045e23;
vat = vmol./na;
%cn = find(r>0);
%cy = find(r<=0);
%Without irradiation growth rates are determined using default method

if radflag == 0 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
c_cryst = find(rb>ram);
c_amorph = find(rb<=ram);
x = xa.*(exp(((2 .* sfen .* vmol)./(gas .* tk)).*(1./rb)));
xr(c_cryst) = xa .* ((xbinst./xa).^((rc_cryst)./rb(c_cryst)));
xr(c_amorph) = xa .* ((xbinst./xa).^((rc_amorph)./rb(c_amorph)));
ind=find(xr>xc);

gr = ((xbinst - xr)./(xc - xr)) .* (d./rb);
grOG = ((xbinst - x)./(xc - x)) .* (d./rb);

% % % playing with new form of NHM

% k0 = 1e-7;
% 
% q = 50; % Mixing rate - take this as 50 for now, can be determined more accurately with rpa calculations
% phi = k0; % Dose rate (dpa/s)
% lam = 6e-10; % Average displacement distance - take as 5 nm for now, again atomistic sims can help here
% xa = exp((-5.4e3./tk)-3.3).*1e0; 
% rg = 8.314;
% 
% delta = (q.*phi.*(lam.^2))./(d.*xa);
% R_cap = (2.*sfen.*vmol)./(rg.*tk);  
% R_i_cap = ((4.*R_cap)-(5.*lam.*delta))./(4.*(1+delta));
% % Ci = xa.*(1+delta);
% Ci = xa;
% ModGT = Ci.*(1+(R_i_cap./rb));
% 
% gr = ((xbinst - ModGT)./(xc - ModGT)) .* (d./rb);

% % %



% k2=100000;
% grKinit = k2.*vmol.*((xbinst-xr).^2);
% rcbin = find(rb<rc_cryst);
% grKneg = grKinit(rcbin).*-1;
% pos = find(rb>rc_cryst);
% grKpos = grKinit(pos).*1;
% 
% grK = [grKneg grKpos];

% gr = grK;

% xr(c_cryst) = xa*exp(((2*sfen*vat)./(tk*k))*(1./rb)); %From Robson, 2001 
% gr = ((xbinst - xr)./(xc - xr)) .* (d./rb);

rx = isreal(xr);
rgr = isreal(gr);
if rx==0 | rgr==0
    disp(['Imaginary parts in xr and/or gr'])
end
freq = (k .* tk)./h;
gstar_a = 15930 * k;
vmax_a =  abs(delta .* freq .* exp(-gstar_a/(k * tk)));
growlim_a = find(gr(c_amorph) > vmax_a);
dislim_a = find(gr(c_amorph) < -vmax_a);
gr(growlim_a) = vmax_a;
gr(dislim_a) = -vmax_a;
gstar_c = 15930 * k;
vmax_c =  abs(delta .* freq .* exp(-gstar_c/(k * tk)));
growlim_c = find(gr(c_cryst) > vmax_c);
dislim_c = find(gr(c_cryst) < -vmax_c);
gr(growlim_c) = vmax_c;
gr(dislim_c) = -vmax_c;
gr(ind) = -vmax_c; 
%Fill in arbitrarily the amorphous arrays
len = length(gr);
gr_a(1:len) = 0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

EqRad = 0; %Temp to stop script failing.
else
    
    c_cryst = find(rb>0);
    %Growth rate calculations below use bin edges
    %xr_c = xa .* ((xbinst./xa).^((rc_cryst)./rb));
    xr_c = xa .* ((xbinst./xa).^((rc_cryst)./rb(c_cryst))); %These two lines of code are the same essentially
    
    %Going to try gibbs thomson for growth rate clacs instead as when using
    %this method it seems that the largest SPPs have +ve growth (which is
    %set to zero) and the small ones are dissolving very quickly, which
    %leads to an unrealistic distribution/mechanism of SPP distribution
    %dissolution
    %xr_c = xa.*exp(((2 * sfen * vmol)/(gas * tk)).*(1./rb));
    
    
    xr_a = xa .* ((xbinst./xa).^((rc_amorph)./rb_a)); %what is xr?
    %
    gr = ((xbinst - xr_c)./(xc - xr_c)) .* (d./rb);
    gr_a = ((xbinst - xr_a)./(xc_a - xr_a)) .* (d./rb_a);
    %
    crx = isreal(xr_c);
    arx = isreal(xr_a);
    crgr = isreal(gr);
    argr = isreal(gr_a);
    if crx==0 || crgr==0 || arx==0 || argr==0
        disp(['Imaginary parts in xr and/or gr'])
    end
    %
    freq = (k .* tk)./h;
    %
    %Need ind statement for both crystalline and amorphous arrays, this
    %addresses the issue of the NaN entries in the array
%     ind_a=find(xr_a>xc_a);
     ind_c=find(xr_c>xc);
    %
    gstar_a = 15930 * k;
    vmax_a =  abs(delta .* freq .* exp(-gstar_a/(k * tk)));
    growlim_a = find(gr(c_cryst) > vmax_a);
    dislim_a = find(gr(c_cryst) < -vmax_a);
    gr(growlim_a) = vmax_a;
    gr(dislim_a) = -vmax_a;
%     growlim_a = find(gr_a > 0);
%     dislim_a = find(gr_a < 0);
%     gr_a(growlim_a) = 0;
%     gr_a(dislim_a) = -vmax_a; %currently set so that there is not growth of amorphous particles, and dissolution is set to a max value
    lengr_a = length(gr_a);
    lengr = length(gr);
    
    %Calculation of dissolution rate based on Griffths work
    amorph_diss_rate = ram_diss/tfinal;
    %During irradiation the Fe-Cr crystalline cores do not undergo
    %dissolution, just amorphization. The amorphous rims are dissolved
    %according to diss_rate.
    %The crystalline cores are dissolved at a rate according to cryst_diss
    cryst_diss = (ram_total*1e-9)/tfinal; %m/s
    
     %gr_a(1:lengr_a) = -diss_rate; %In m/s? %set to zero for now instead of -vmax_a; this is effective dissolution of amorphous dummy SPPs
    gr_a(1:lengr_a) = -3e-16;%-amorph_diss_rate; %Leave amorphization dissolution as zero for now and calculated using amorph_diss function, using a linear equation to subtract from the r_a array as performing two dissolution rate calcs would disrupts and misalign the number densities    
  
    %gr(1:lengr) = -amorph_diss_rate; %INSTEAD OF USING RAM_TOTAL FOR THIS I SHOULD USE THE RAM CALCULATED ITERATIVELY, OR ALTERNATIVELY HAVE TO USE RAM_TOTAL FOR AMORPHIS_DISS FUNCTION!

    gr(ind_c) = -vmax_a;
    
    
    %below are conditions being played with to understand the dissolution
    %of amorphous zone process
    if t <= tau_sl
        gr(1:lengr) = 0;
    end
    
    pstgr = find(gr>0);
    gr(pstgr) = 0;
    
    if t > tau_sl %uncomment this if manual incubation time to dissolution is needed
        %Function which uses rate determined emperically from Bajaj data
        [drdt] = AmorphDissRate(tk,phi);
%         drdt = 0;
        
        %Function which uses the NHM model
%         n(541) = 0;
%         [drdt,EqRad] = NHM(rb,d,xb,xc_a,vat,n,phi,n_clust,xc_clust,xc,vf_crat,vf_arat,vf_clustrat,xbinst,vmol,sfen,tk,xa);
       

%         drdt = ((xbinst - xa)./(xc - xa)) .* ((d)./rb); 

%         drdt = (3.*d.*xbinst)./(4.*pi.*rb.*xc);

%         drdt = NHMDiss(rb,phi,tk);
        EqRad = 0;

    else
        
%         x = xa.*(exp(((2 .* sfen .* vmol)./(gas .* tk)).*(1./rb)));
% 
%         drdt = ((xbinst - x)./(xc - x)) .* (d./rb);
        EqRad = 0;
%         drdt=0;
% drdt = (3.*d.*xbinst)./(4.*pi.*rb.*xc);
        drdt = 0;
    end

%         drdt = -2e-15;

% % % THIS IS ALL MODIFIED GT WORK

% k0 = phi./(5e20);
% 
% q = 50; % Mixing rate - take this as 50 for now, can be determined more accurately with rpa calculations
% lam = 1e-9; % Average displacement distance - take as 5 nm for now, again atomistic sims can help here
% xa = exp((-5.4e3./tk)-3.3).*1e0; 
% rg = 8.314;
% 
% delta = (q.*k0.*(lam.^2))./(d.*xa);
% R_cap = (2.*sfen.*vmol)./(rg.*tk);  
% R_i_cap = ((4.*R_cap)-(5.*lam.*delta))./(4.*(1+delta));
% % Ci = xa.*(1+delta);
% Ci = xa.*10;
% ModGT = Ci.*(1+(R_i_cap./rb));
% % ModGT = Ci.*exp((R_i_cap./rb));
% % xbinst = 4.92e-6;
% 
% drdt = ((xbinst - ModGT)./(xc - ModGT)) .* (d./rb);

% % %

        gr(1:lengr) = drdt; %REMOVE THIS -1 WHEN FIGURED OUT WHAT TO DO WITH R/RB/N
%     else
%         EqRad = 0;
%     end
end

%Code to limit the growth of Fe-Cr SPPs when Zirc2flsag is active so that
%the system cannot exceed the maximum theoretical voluem fraction
% if zirc2flag == 1
%     if vf.*1.1 > vfmax
%         %Smallest SPPs are first to dissolve as they have negative growth
%         %rates, going to then implement dissolution in the smaller bin
%         %which has SPPs in
%         search=find(n>0);
%         searchmin = min(search);
%         gr_positive = find(gr>0);
%         gr(gr_positive) = 0; %makes all positive growth rates equal to zero so that in this system SPPs can only dissolve, thus increasing vf in matrix and allowing other system to grow if needed
%         gr(searchmin) = -vmax_c;
%     end
% end
% disp(['Capillary radius irrad = ' num2str(R_i_cap), ' d = ' num2str(d)])

return