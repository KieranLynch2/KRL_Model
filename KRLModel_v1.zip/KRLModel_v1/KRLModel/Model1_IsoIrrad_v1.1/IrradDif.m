function [d,D_a,D_b] = IrradDif(d_init,d_final,t,phi,D_a,D_b,firstit)


doserate = phi./(5e20);

dose = doserate.*t;

if firstit == 0
    [D_a,D_b] = DexpFit(d_init,d_final);
end

if dose < 1
    d = D_a.*exp(D_b.*dose);
else
    d = d_final;
end

end


% tout = [];
% dout = [];
% tfinal = 60000000;
% d_init = 1e-20;
% phi = 0.6e14;
% for t = 1:10000:tfinal
% 
% d_final = 5e-25;
% 
% % tfrac = t/tfinal;
% % 
% % d_diff = d_init-d_final;
% % 
% % d_dec = d_diff.*tfrac;
% % 
% % d = d_init - d_dec;
% 
% 
% %% I probably need to slow down D at a constant rate, up tunil ~1 dpa, after
% %which it should plateu at a given value
% % If i can get this to work in a logarithmic way then i might be able to
% % find a combination of D and nsite values which work for smaples 2 & 3 of
% % Bajaj.
% % Might have to come up with exp relationship 
% 
% 
% k0 = phi./(5e20); %Conversion from flux to dpa/s
% 
% t1dpa = 1/k0;
% 
% if t < t1dpa  
%     
%     tfrac = t/t1dpa;
%     
%     d_spread = logspace(d_final,d_init,10);
%     d_spread2 = logspace(-26,-21,10);
%     
%     d = exp((log(d_init)+log(d_final)).*tfrac);
%     
% %     tfrac = t/t1dpa;
% %     d_diff = d_init-d_final;
% %     d_dec = d_diff.*tfrac;
% %     d = d_init - d_dec;
% else
%     d = d_final;
% end
% 
% tout = [tout t];
% dout = [dout d];
% end
% loglog(tout,dout)
% 
% 
% % end