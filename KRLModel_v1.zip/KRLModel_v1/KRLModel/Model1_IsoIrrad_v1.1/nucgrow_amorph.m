function [nr,gr,gr_a,EqRad,N_a,N_b] = nucgrow_amorph(vf,vf_a,ram,r,r_a,rb,rb_a,d,t,nsites,sfen,tk,xa,xb,xc,xc_a,tau,vmol,a,n,n_a,radflag,tfinal,ram_diss,ram_total,tau_sl,vf_total,zirc2flag,vmax,phi,n_clust,vf_clust,vf_amorph,xc_clust,N_a,N_b,firstit,c_loop)
%
% Function follows same syntax as Joe's original script. In the
% zr_amorph_kin script the function calls rb and rb_a, but in this script
% it changes it to r and r_a - which act as the bin edges for the
% growth_amorph script. EDIT: As i need to change the bin averages and the
% edges i need to deviate from this syntax and bring in both the edges and
% averages through this function.
%
% function [nr,gr] = nucgrow(vf,rb,d,nsites,sfen,tk,xa,xb,xc)
% Inputs
% vf        Current volume fraction of dispersoids
% r         Mean size of size classes (m)
% d         Diffusion coefficient (m^2s^-1)
% nsites    Number density of nucleation sites (/m^-3)
% sfen      Interfacial energy for nucleation/growth (J/m^-2)
% tk        Temperature  (K)
% xa        Equilibrium concentration of Zr in matrix at planar interface
% xb        Current average zirconium concentration in matrix
% xc        Zirconium concentration in dispersoids
% Outputs
% nr        Nucleation rate of dispersoids (m^-3s^-1)
% gr        Growth rate of each size class (ms^-1)
%
%
% update mean matrix concentration
%
if radflag == 0
    xbinst = xb - ((xc - xa) * vf);
            vf_crat = [];
        vf_arat = [];
        vf_clustrat = [];
else
    vf_tot = vf_total;
    vf_cryst = vf;
    if vf_total+vf_clust == 0
        xbinst = xb;
    else
        vf_crat = vf_cryst/(vf_cryst+vf_amorph+vf_clust);
        vf_arat = vf_amorph/(vf_cryst+vf_amorph+vf_clust);
        vf_clustrat = vf_clust/(vf_cryst+vf_amorph+vf_clust);
        
        xc_avg = (xc*vf_crat)+(xc_a*vf_arat)+(xc_clust*vf_clustrat);
        xbinst = xb - ((xc_avg - xa) * (vf_total+vf_clust));
    end
    
    % vf_tot = vf_total; %vf == vf_cryst when radflag == 1, vf_a is amorphous vf
    % if vf_tot == 0
    %     xbinst = xb;
    % else
    % vf_crat = vf/(vf+vf_a);
    % vf_arat = vf_a/(vf+vf_a);
    % xc_avg = (xc*vf_crat)+(xc_a*vf_arat);
    % xbinst = xb - ((xc_avg - xa) * vf_tot);
    % end
end
if xbinst < 0, xbinst = 0; end

%
% calculate critical radius, growth and nucleation rates
%
% xbinst is recalculated in critradco: Do not pass
    rc_cryst = critrad_cryst(sfen,xa,xb,xc,xc_a,vf,vf_a,tk,vmol,radflag,vf_total,vf,vf_clust,vf_amorph,xc_clust);
    rc_amorph = critrad_amorph(sfen,xa,xb,xc,vf,tk,vmol);
    [nr,N_a,N_b] = nucrate_amorph(rc_cryst,sfen,nsites,xbinst,xb,d,t,tk,tau,vmol,a,radflag,tfinal,phi,N_a,N_b,firstit,c_loop);
    [gr,gr_a,r,rb,n_a,EqRad] = growth_amorph(r,r_a,rb,rb_a,rc_cryst,rc_amorph,ram,sfen,d,xbinst,xa,xc,xc_a,tk,vmol,n,n_a,radflag,tfinal,ram_diss,ram_total,t,tau_sl,vf,zirc2flag,vmax,phi,xb,n_clust,xc_clust,vf_crat,vf_arat,vf_clustrat);
 %   if rc_cryst > max(r)
 %       disp(['stop'])
end
