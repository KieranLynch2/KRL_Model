function OutputStatement = ScriptToRunIsoIrrad(Alloy,SetConc,FeConc,CrConc,NiConc,radflag,TargetMode,TargetModeDiameter,Taylor,Motta,PreFile,Time,Temperature,Flux,tcprof,OFN,PSDSnap,PSDStage)

% OutputStatement = ScriptToRunIsoIrrad(Alloy,SetConc,FeConc,CrConc,NiConc,radflag,TargetMode,TargetModeDiameter,Taylor,Motta,PreFile,Time,Temperature,Flux,tcprof,OFN)

% This is the master script for isothermal heat treatments and irradiation
% For quenching and subsequent annealing, please use the quenching script
% and transfer the files to here for irradiation exposure.
% clear all
%% User options
% Zircaloy-4 or Zircaloy-2
% Isothermal annealing in the asbence of irradiation with user defined inputs
% Isothermal annealing in the absence of irradiation with a target modal diameter set
% Irradiation (With the cavaet that no irradiation calibration/modelling of Zr2(Fe,Ni) evolution has been performed).

%% Choose your alloy, 1 is on, 0 is off.
% Alloy = 4;
if Alloy == 4
    Zircaloy4 = 1;
    Zircaloy2 = 0; %Note: irradiation for this alloy not well calibrated
elseif Alloy == 2
    Zircaloy4 = 0;
    Zircaloy2 = 1; %Note: irradiation for this alloy not well calibrated
end

if Zircaloy4 == 1
    zirc2flag = 0;
elseif Zircaloy2 == 1
    zirc2flag = 1;
end

%% Choose your alloy composition -> Need to lock this down when loading in an input file!! (Will this be read in atuomatically after this statement and overwrite??

% SetConc = 1;
if SetConc == 1 %When SetConc ==1 the alloy composition is nominal values
if Zircaloy4 == 1
    FeConc = 0.0033;
    CrConc = 0.0018;
    NiConc = 0;
    FeCrRatio = FeConc/CrConc;
    FeNiRatio = [];
end
if Zircaloy2 == 1
FeConc = 0.002;%0.0033; %0.002
CrConc = 0.0018;%0.0018; %0.0018
NiConc = 0.0008;%0; %0.0008
%For Zircaloy2
FeCrRatio = 0.71;
FeNiRatio = 0.9;
end

elseif SetConc == 0
    if Zircaloy2 == 1
        FeCrRatio = 0.71; % Same ratios in both cases
        FeNiRatio = 0.9;
    else
        FeCrRatio = 2;
        FeNiRatio = 0.9; %This is a dummy - not used in simulations
    end
end


%% Irradiation active? Uncomment which option you would like
% radflag = 1; % Radiation active
% radflag = 0; % Radiation not active

%% Zirc2 under irradiation not ready yet
if radflag == 1 && Zircaloy2 == 1
    error('Zircaloy-2 under irradiation is not well calibrated for. Therefore this option is not currently recommended. Enter ScriptToRun.m file and remove this line if desired.')
end

%% Do you want to aim for a target modal diameter (no irradiation)
% TargetMode = 1; %aim for target
% TargetModeDiameter = 20; %Enter a target modal diameter in nm for FeCr type in Zircaloy-4

% TargetMode = 0; %do not aim for target

if TargetMode == 0
    TargetModeDiameter = [];
end

if TargetMode == 1
    tcprof = [700,700,100000];
end

if Zircaloy2 == 1 && TargetMode == 1
    error('Target mode not available in Zircaloy-2')
end
if radflag == 1 && TargetMode == 1
    error('Target mode not available under irradiation')
end

%% Annealing in the absence of irradiation inputs - put as an array if required
if radflag == 0
%     PreFile = []; %Type in .mat file containing distribution before further annealing if required
    PreFileLoc = (['../FilesToLoad/' PreFile '.mat']);
    if exist(PreFileLoc) ~= 0 %Only loads in the PreFile if it is specified, e.g. from quench and anneal output.
    load(PreFileLoc,"CrConc","FeConc","NiConc","r","r_FeNi","r_ln","r_lnFeNi","n","n_ln","n_FeNi","n_lnFeNi","rb")
    end

%     tcprof = [700 700 10/3600; 600 600 10/3600];
    Time = [];
    Temperature = [];
    Flux = [];

    Taylor = [];
    Motta = [];
elseif radflag == 1 %% Irradiation options below here
%     PreFile = 'Garz1989_290C.mat'; %Type in .mat file containing distribution before irradiation
        PreFileLoc = (['../FilesToLoad/' PreFile '.mat']);
    if exist(PreFileLoc) == 0 %Only loads in the PreFile if it is specified, e.g. from quench and anneal output.
        error('Irradiation needs an input file')
    end
    load(PreFileLoc,"CrConc","FeConc","NiConc","r","r_FeNi","r_ln","r_lnFeNi","n","n_ln","n_FeNi","n_lnFeNi","rb")
%     Time = [1258*24]; %In hours
%     Temperature = [290]; % In degrees C
%     Flux = [0.92e14]; %neutron flux in n/cm2/s

    tcprof = [];

    % Pick amorphization model, 1 = active, 0 = not active
%     Taylor = 1;
%     Motta = 0;
    if Taylor == 1 %This is required - make sure in GUI script this is correctly accounted for
        Motta = 0;
    end
    if Motta == 1
        Taylor = 0;
    end
end



%% Get input r,n,rb arrays depending if they exist or not
if Zircaloy4 == 1
    if radflag == 0 %For annealing runs, don't want to take n_ln as inputs before more annealing. Only at last step before irradiation should n_ln be used.
        if exist('n','var') == 1
            r_in = r;n_in = n;rb_in = rb;r_FeNi_in = [];n_FeNi_in = [];rb_FeNi_in = [];
        else
            r_in = [];n_in = [];rb_in = [];r_FeNi_in = [];n_FeNi_in = [];rb_FeNi_in = [];
        end
    elseif radflag == 1 %Taking r_ln,n_ln arrays for input for irradiation
        if exist('n_ln','var') == 1
            r_in = r_ln;n_in = n_ln;rb_in = rb;r_FeNi_in = [];n_FeNi_in = [];rb_FeNi_in = [];
            if isempty(r_ln)
                error('Input distribution does not exist, check second order growth post-processing function has been applied')
            end
            n_in = SOGLimit(n_in,r_in);
        else
            error('Input distribution does not exist, check second order growth post-processing function has been applied')
        end
    end
elseif Zircaloy2 == 1
    if radflag == 0 %For annealing runs, don't want to take n_ln as inputs before more annealing. Only at last step before irradiation should n_ln be used.
        if exist('n','var') == 1
            r_in = r; n_in = n;rb_in = rb;r_FeNi_in = r_FeNi;n_FeNi_in = n_FeNi;rb_FeNi_in = rb; %No rb_FeNi?
        else
            r_in = [];n_in = [];rb_in = [];r_FeNi_in = [];n_FeNi_in = [];rb_FeNi_in = [];
        end
    elseif radflag == 1 %Taking r_ln,n_ln arrays for input for irradiation
        if exist('n_ln','var') == 1
            r_in = r_ln;n_in = n_ln;rb_in = rb;r_FeNi_in = r_lnFeNi;n_FeNi_in = n_lnFeNi;rb_FeNi_in = rb_FeNi;
            % Set upper limit of 3.6 mode after second order function - user choice
            n_in = SOGLimit(n_in,r_in);
        else
            error('Input distribution does not exist, check second order growth post-processing function has been applied')
        end
    end
end
   


%% Loop through inputs and kinetics 
if radflag == 0
if length(Time) ~= length(Temperature)
    disp('length of time and temperature arrays do not match!')
end
elseif radflag == 1
    if (length(Time) ~= length(Temperature)) || (length(Time) ~= length(Flux)) % Need to fix flux input!!
    error('length of time, temperature and flux arrays do not match!')
    end
end

if radflag == 1
    NSteps = length(Time);
elseif radflag == 0
    NSteps = size(tcprof,1); %Need to go into kin.m script and end the runs after each stage, but then re-enter using original cycle behaviour.
end

IterCount = 1;
TimeTotal = 0; %For irradiations mainly, so starts at zero as all inputs should be pre-irradiation. Would need to change if loading a pre-irradiated input. - Could automate this with a checking of ram 

ramTotal = 0; %Might need to make this irrad only!
FeAmorphDissTotal = 0;
CrTotal = 0;
FeAmorphTotal = 0;             
r_cryst_in = [];
n_cryst_in = [];
AmorphIncFlag = 0;
DissIncFlag = 0;
AmorphIncTimeDone = [];
DissIncTimeDone = [];
Outputs = struct;
FirstStepNotIncFlag = 0;

if radflag == 1
    r_init = r_in;
    n_init = n_in;
else
    r_init = [];
    n_init = [];
end

if NSteps > 1
    MultiStepFlag = 1;
else 
    MultiStepFlag = 0;
end

while IterCount <= NSteps
    if radflag == 1
        [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,xa_FeNi,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,FeCrRat,FeNiRat,a_FeNi,tkprof,radflag]=zr_amorph_init(Temperature(IterCount),Time(IterCount),Flux(IterCount),radflag,zirc2flag,r_in,n_in,rb_in,r_FeNi_in,rb_FeNi_in,n_FeNi_in,Motta,Taylor,TimeTotal,ramTotal,FeAmorphDissTotal,CrTotal,FeAmorphTotal,FeConc,CrConc,NiConc,FeCrRatio,FeNiRatio,tcprof);
    else
        tcprof_in = tcprof(IterCount,:);
        [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,xa_FeNi,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,FeCrRat,FeNiRat,a_FeNi,tkprof,radflag]=zr_amorph_init(Temperature,Time,Flux,radflag,zirc2flag,r_in,n_in,rb_in,r_FeNi_in,rb_FeNi_in,n_FeNi_in,Motta,Taylor,TimeTotal,ramTotal,FeAmorphDissTotal,CrTotal,FeAmorphTotal,FeConc,CrConc,NiConc,FeCrRatio,FeNiRatio,tcprof_in);
    end

        [r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout,vf_aout,vf_totout,xbinst_tot,ramout,vfout_FeNi,rbarout_FeNi,nrout_FeNi,npartout_FeNi,r_FeNi,n_FeNi,rcout_FeNi,ram_diss,xbout_a_Cr,xbout_a_Fe,xbout_c_Fe,r_a_shell,xb_tot_check,amorph_diss_out,rbar_totout,xbout_Zirc2,vf_totalout,r_total,r_cryst,n_cryst,vf_amorphout,vf_crystout,xa_store,r_ln,n_ln,dsr1out,dsr2out,dsr3out,r_lnFeNi,n_lnFeNi,Fe2Cr_vf,Fe2Cr_rat,rb_clust,r_clust,n_clust,npart_clustout,vf_clustout,rbar_clustout,EqRadout,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,xbout_Zirc2_FeCr,xbout_Zirc2_FeNi,FeSumAmorph,FeSumTotal,CrSumTotal,tauamorph,tau_sl]= ... 
        zr_amorph_kin(r,n,zirc2flag,rb,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi,tk,tfinal,d,d_FeNi,xa,xb,xc,xc_a,xb_FeNi,xc_FeNi,sfen,sfen_FeNi,nsites,vmol,vmol_FeNi,a,a_init,vmax,vmax_FeNi,xc_clust,phi,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,FeCrRat,FeNiRat,xa_FeNi,a_FeNi,Motta,Taylor,TimeTotal,ramTotal,FeAmorphDissTotal,CrTotal,FeAmorphTotal,r_cryst_in,n_cryst_in,MultiStepFlag,AmorphIncFlag,DissIncFlag,AmorphIncTimeDone,DissIncTimeDone,FeConc,CrConc,NiConc,TargetMode,TargetModeDiameter,tkprof,radflag);
    
        r_in = r; n_in = n; rb_in = rb; r_FeNi_in = r_FeNi; n_FeNi_in = n_FeNi; rb_FeNi_in = rb_FeNi;
        
        if radflag == 1
             TimeTotal = tout(end); %Carry the time through the loops
             ramTotal = sum(ramout); %Might need to make this irrad only!
             FeAmorphDissTotal = FeSumTotal(end);
             CrTotal = CrSumTotal(end);
             FeAmorphTotal = FeSumAmorph(end);
             r_cryst_in = r_cryst;
             n_cryst_in = n_cryst;
            %Take incubation time to amrophization and dissolution from first irradiation regime
            if IterCount == 1
                DoseToAmorphFirst = tauamorph;
                IncToDissFirst = tau_sl;
            end
            
            if NSteps > 1
            if TimeTotal < tauamorph
                error(['Warning! Amorphization incubation period not exceeded in stage ' num2str(IterCount) '. Please re-use parameters which exceed incubation period in first stage.'])
                AmorphIncTimeDone = tauamorph-TimeTotal;
                FirstStepNotIncFlag = 1;
            else
                AmorphIncTimeDone =[];
            end

            if TimeTotal < tau_sl
                error(['Warning! Dissolution incubation period not exceeded in stage ' num2str(IterCount) '. Please re-use parameters which exceed incubation period in first stage.'])
                DissIncTimeDone = tau_sl-TimeTotal;
                FirstStepNotIncFlag = 1;
            else 
                DissIncTimeDone = [];
            end
            end

            %Save all outputs from every stage for writing to csv file.
            Outputs(IterCount).Time = tout;
            Outputs(IterCount).MeanRad = rbar_totout;
            Outputs(IterCount).Npart = npartout;
            Outputs(IterCount).FeAmorph = FeSumAmorph;
            Outputs(IterCount).FeTotal = FeSumTotal;
            Outputs(IterCount).Cr = CrSumTotal;
            Outputs(IterCount).Ram = ramout;
            Outputs(IterCount).Radius = r;
            Outputs(IterCount).NumDen = n;
            Outputs(IterCount).Radius_Init = r_init;
            Outputs(IterCount).NumDen_Init = n_init;

            %If at any point the incubation time for amorphization and
            %dissolution are passed, the following irradiation steps will
            %continue amorphizing/dissolving regardless if the new inc time
            %is less
            if TimeTotal > tauamorph
                AmorphIncFlag = 1;
            end
            if TimeTotal > tau_sl
                DissIncFlag = 1;
            end


        elseif radflag == 0
             TimeTotal = tout(end); %Carry the time through the loops
             ramTotal = 0; %Might need to make this irrad only!
             FeAmorphDissTotal = [];
             CrTotal = [];
             FeAmorphTotal = [];
             Outputs(IterCount).Time = tout;
             Outputs(IterCount).SolConc = xbout;
             Outputs(IterCount).NumDenwTime = npartout;
             Outputs(IterCount).MeanRad = rbarout;
             Outputs(IterCount).VolFrac = vfout;
            Outputs(IterCount).Radius = r;
            Outputs(IterCount).NumDen = n;
            Outputs(IterCount).Radius_ln = r_ln;
            Outputs(IterCount).NumDen_ln = n_ln;
        end

        if radflag == 0 && Zircaloy2 == 1
             Outputs(IterCount).Time = tout;
             Outputs(IterCount).SolConc = xbout_Zirc2_FeCr;
             Outputs(IterCount).NumDenwTime = npartout;
             Outputs(IterCount).MeanRad = rbarout;
             Outputs(IterCount).SolConcFeNi = xbout_Zirc2_FeNi;
             Outputs(IterCount).NumDenwTimeFeNi = npartout_FeNi;
             Outputs(IterCount).MeanRadFeNi = rbarout_FeNi;
             Outputs(IterCount).VolFrac = vfout;
             Outputs(IterCount).VolFracFeNi = vfout_FeNi;
             Outputs(IterCount).Radius = r;
            Outputs(IterCount).NumDen = n;
            Outputs(IterCount).RadiusFeNi = r_FeNi;
            Outputs(IterCount).NumDenFeNi = n_FeNi;
            Outputs(IterCount).Radius_ln = r_ln;
            Outputs(IterCount).NumDen_ln = n_ln;
            Outputs(IterCount).Radius_lnFeNi = r_lnFeNi;
            Outputs(IterCount).NumDen_lnFeNi = n_lnFeNi;
        end 

        if PSDSnap == 1
           PSDGraphPlot(PSDStage,Outputs,IterCount,NSteps,Alloy,radflag,r_init,n_init,r_cryst,n_cryst)
        end

        IterCount = IterCount+1;
end

if radflag == 1
    disp(['Radius of amorphization = ' num2str(sum(ramout).*1e9) ' nm '])
    disp(['Incubation time to amorphization = ' num2str(DoseToAmorphFirst./86400) ' days (Calculated from the first step in irradiation regime)'])
    disp(['Incubation time to dissolution = ' num2str(IncToDissFirst./86400) ' days (Calculated from the first step in irradiation regime)'])
    if FirstStepNotIncFlag == 1
        disp('Warning! The first irradiation step did not exceed either amorphization or the dissolution incubation periods. The model is not suited to this irradiation regime. Please use alternative parameters.')
    end
end

 % Choose an output file name
% OFN = 'TESTRUNS';
OFN_matlab = (['../Outputs/' OFN '.mat']); % Choose an output filename 
save([OFN_matlab])


%% Write out to text files to give the simulated conditions
% DataWriteOut - three options: Zirc4 pre irrad, Zirc2 pre irrad, Zirc4 post irrad
% Need output structures and r,n,r_cryst,n_cryst,r_init,n_init... r_ln,n_ln for anealing
if radflag == 0
    if Zircaloy2 == 1
        WriteFileZry2(Outputs,Alloy,Time,Temperature,FeConc,CrConc,NiConc,FeCrRatio,FeNiRatio,IterCount,tcprof,OFN)
    elseif Zircaloy4 == 1
        WriteFileZry4NoIrrad(Outputs,r,n,r_ln,n_ln,Alloy,Time,Temperature,FeConc,CrConc,NiConc,FeCrRatio,FeNiRatio,IterCount,tcprof,OFN)
    end
elseif radflag == 1
    WriteFileZry4Irrad(Outputs,r,n,r_cryst,n_cryst,DoseToAmorphFirst,IncToDissFirst,Alloy,Time,Temperature,Flux,FeConc,CrConc,NiConc,FeCrRatio,FeNiRatio,IterCount,Motta,Taylor,OFN)
end

OutputStatement = (['Simulation complete. Please check Outputs folder.']);

end

%% Plots

% Plot of PSD before and after irradiation
% 
% plot((r_init.*2).*(10^9),n_init.*(10^-18),'-','LineWidth',2)
% hold on
% xlim([0 1400])
% r_cryst(1) = 0;
% r_cryst_zero = find(r_cryst <= 0);
% n_cryst(r_cryst_zero) = 0;
% r_cryst_nonzero = find(r_cryst > 0);
% r_cryst_plot = r_cryst(r_cryst_nonzero);
% n_cryst_plot = n_cryst(r_cryst_nonzero);
% plot((r_cryst_plot.*2).*(10^9),n_cryst_plot.*(10^-18),'-','LineWidth',2)
% plot((r_total.*2).*(10^9),n.*(10^-18),'-','LineWidth',2)
% legend('Initial SPP size distribution','Crystalline cores','Final SPP size distribution');
% xlabel('SPP diameter / nm')
% ylabel('Number density in each size class / \mum^{-3}')



% Plots of chemical changes with irradiation

% plot(tout,FeSumTotal)
% hold on
% plot(tout,CrSumTotal)
% hold on
% plot(tout,FeSumAmorph)






%% Below is misc files, but may be useful for plotting

% % % % % %% Script running for Zircaloy-4 Irradiation
% % % % %Use estimates of Bajaj data, going to introduce a parameter in PERT
% % % % %function to limit the max value in distribution to 3.6*Dmode, in
% % % % %accordance with Gros.
% % % % % 
% % load 'Bajaj_dbar240NEW.mat' %N.B. This Bajaj 240dbar uses the mean with volume fraction, rather than the arithmetic mean, whereas i'm now moving towards an arithmetic mean as this is more likely the case in experimental, I would say
% % %  semilogx(tout,rcout_c)
% % r = r_ln;
% % n = n_ln;
% % % 
% % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb]=zr_amorph_init(332,120*24,1.5e14,0,r,n,rb,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb);%,r_a,rb_a,n_a); 
% % 
% % 
% % %Need these below just while loading up the Taylor ram eq. 10 only once per
% % %sample:
% % ram_total_end_r = []; 
% % ram_total_end_rb = []; 
% % time_amorph = []; 
% % time_amorphrb = [];
% 
% % 
% % 
% % % load Valizadeh.mat
% % 
% % % plot((r.*2).*(10^9),n.*(10^-18),'LineWidth',2)
% % % xlim([0 80])
% % 
% % ram_total_end_r = []; 
% % ram_total_end_rb = []; 
% % time_amorph = []; 
% % time_amorphrb = [];
% % 
% % 
% % % r = r_ln; %Make the adjusted lognormal arrays equal to r and n
% % % n = n_ln; %Made a mistake, this is now in m^-3
% % % d = r.*2;
% % % Based off of Gros paper the largest diameter is 3.6 Dmode, and 2.6Dmode is
% % % 95.5% of SPPs
% % % Therefore delete all those number denisities above that value
% % % maximum = max(n);
% % % mode_n = find(n==maximum);
% % % 
% % % Dmax = (d(mode_n)).*3.6;
% % % a=d;%dummy data
% % % y=Dmax;
% % % [val,idx]=min(abs(a-y));
% % % minVal=a(idx); %idx here gives index of D array which closest matches Dmax
% % % 
% % % delete all entries in n larger than Dmax
% % % n(idx:end) = 0;
% % % rbar1 = (sum(r.*n))./sum(n);
% % % rbar2 = (vfout(end)./((4/3) * pi * sum(n)))^(1./3);
% % % 
% % 
% % 
% % 
% % % r_init = r;
% % % n_init = n;
% % % 
% % % load '750C38hours_PERT.mat'
% % % dc_edge = 0:bin_width:((mode_d*1e9)*f)+(bin_width/2);
% % % n = num_den*1e18;
% % % n(end) = 0;
% % % r = (dc./2)*1e-9;
% % % rb = (dc_edge./2)*1e-9;
% % % r_a = r;
% % % rb_a = rb;
% % % n_a = zeros(1,length(n));
% % % 
% % % r_init = r;
% % % rb_init = rb;
% % % n_init = n;
% % 
% % % Below is for Bajaj specimen 2 and times are inc time (Adiss) + post inc time
% % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag]=zr_amorph_init(270,(9.7222e+03+9.1667e+03)+18000,0,r,n,rb);%,r_a,rb_a,n_a); 
% % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag]=zr_amorph_init(270,(8000),0,r,n,rb);
% % %
% % %Bajaj sample 1
% % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag]=zr_amorph_init(270,402*24,0,r,n,rb);%,r_a,rb_a,n_a);
% % load 'BajajSample2Eq10.mat'
% % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb]=zr_amorph_init(270,402*24,0.4e14,0,r,n,rb,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb);%,r_a,rb_a,n_a); 
% 
% 
% % % %sample 2 
% load 'BajajSample2Eq10.mat'
% % % d = r.*2;
% % % maximum = max(n);
% % % mode_n = find(n==maximum);
% % % 
% % % Dmax = (d(mode_n)).*3.6;
% % % a=d;%dummy data
% % % y=Dmax;
% % % [val,idx]=min(abs(a-y));
% % % minVal=a(idx); %idx here gives index of D array which closest matches Dmax
% % % 
% % % % delete all entries in n larger than Dmax
% % % n(idx:end) = 0;
% 
% 
% r_init = r;
% n_init = n;
% % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,xa_FeNi,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,FeCrRat,FeNiRat,a_FeNi,radflag]=zr_amorph_init(270,787*24*2,0.4e14,1,0,r,n,rb,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb);%,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi)
% 
% % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,xa_FeNi,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,FeCrRat,FeNiRat,a_FeNi,radflag]=zr_amorph_init(280,8166,0.68e14,1,0,r,n,rb,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb);%,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi)
% % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,xa_FeNi,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,FeCrRat,FeNiRat,a_FeNi,radflag]=zr_amorph_init(250,74166.6,0.079e14,1,0,r,n,rb,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb);%,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi)
% [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,xa_FeNi,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,FeCrRat,FeNiRat,a_FeNi,radflag]=zr_amorph_init(250,8166*2,6.88e14,1,0,r,n,rb,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb);%,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi)
% 
% % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb]=zr_amorph_init(270,787*24*2,0.4e14,0,r,n,rb,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb);%,r_a,rb_a,n_a); 
% 
% %Note 28/3 probably best to just quote a total Fe conc in matrix, as not
% %sure on calculations to separate dissolution from amorphization
% 
% [r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout,vf_aout,vf_totout,xbinst_tot,ramout,vfout_FeNi,rbarout_FeNi,nrout_FeNi,npartout_FeNi,r_FeNi,n_FeNi,rcout_FeNi,ram_diss,xbout_a_Cr,xbout_a_Fe,xbout_c_Fe,r_a_shell,xb_tot_check,amorph_diss_out,rbar_totout,xbout_Zirc2,vf_totalout,r_total,r_cryst,n_cryst,vf_amorphout,vf_crystout,xa_store,r_ln,n_ln,dsr1out,dsr2out,dsr3out,r_lnFeNi,n_lnFeNi,Fe2Cr_vf,Fe2Cr_rat,rb_clust,r_clust,n_clust,npart_clustout,vf_clustout,rbar_clustout,EqRadout,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,xbout_Zirc2_FeCr,xbout_Zirc2_FeNi,FeSumAmorph,FeSumTotal,CrSumTotal]= ... 
%     zr_amorph_kin(r,n,zirc2flag,rb,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi,tk,tfinal,d,d_FeNi,xa,xb,xc,xc_a,xb_FeNi,xc_FeNi,sfen,sfen_FeNi,nsites,vmol,vmol_FeNi,a,a_init,vmax,vmax_FeNi,xc_clust,phi,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,FeCrRat,FeNiRat,xa_FeNi,a_FeNi,radflag);
% 
% % plot(tout,FeSumTotal)
% hold on
% % plot(tout,CrSumTotal)
% plot(tout,FeSumAmorph)
% 
% 
% plot((r_init.*2).*(10^9),n_init.*(10^-18),'-','LineWidth',2)
% hold on
% xlim([0 400])
% r_cryst(1) = 0;
% r_cryst_zero = find(r_cryst <= 0);
% n_cryst(r_cryst_zero) = 0;
% r_cryst_nonzero = find(r_cryst > 0);
% r_cryst_plot = r_cryst(r_cryst_nonzero);
% n_cryst_plot = n_cryst(r_cryst_nonzero);
% plot((r_cryst_plot.*2).*(10^9),n_cryst_plot.*(10^-18),'-','LineWidth',2)
% plot((r_total.*2).*(10^9),n.*(10^-18),'-','LineWidth',2)
% % plot((r_FeNi.*2).*(10^9),n_FeNi.*(10^-18),'LineWidth',2)
% % plot((r_FeNi_init.*2).*(10^9),n_FeNi_init.*(10^-18),'LineWidth',2)
% legend('Initial SPP size distribution','Crystalline cores','Final SPP size distribution');%,'Fe-Ni Final','Fe-Ni Initial')
% xlabel('SPP diameter / nm')
% ylabel('Number density in each size class / \mum^{-3}')
% 
% 
% 
% % %sample 3
% % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag]=zr_amorph_init(270,267*24,0,r,n,rb);%,r_a,rb_a,n_a); 
% % load 'BajajSample3Eq10.mat'
% % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb]=zr_amorph_init(270,267*24,1.2e14,0,r,n,rb,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb);%,r_a,rb_a,n_a); 
% % %sample 4
% % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag]=zr_amorph_init(310,395*24,0,r,n,rb);%,r_a,rb_a,n_a); 
% % load 'BajajSample4Eq10.mat'
% % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb]=zr_amorph_init(310,395*24,0.6e14,0,r,n,rb,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb);%,r_a,rb_a,n_a); 
% % % %sample 5
% % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag]=zr_amorph_init(310,144*24,0,r,n,rb);%,r_a,rb_a,n_a); 
% % load 'BajajSample5Eq10.mat'
% % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb]=zr_amorph_init(310,144*24,1.3e14,0,r,n,rb,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb);%,r_a,rb_a,n_a); 
% % % %sample 6 
% % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag]=zr_amorph_init(310,382*24,0,r,n,rb);%,r_a,rb_a,n_a); 
% % load 'BajajSample6Eq10.mat'
% % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb]=zr_amorph_init(310,382*24,1.2e14,0,r,n,rb,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb);%,r_a,rb_a,n_a); 
% % % %sample 7 
% % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag]=zr_amorph_init(332,120*24,0,r,n,rb);%,r_a,rb_a,n_a); 
% % load 'BajajSample7Eq10.mat'
% % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb]=zr_amorph_init(332,220*24,1.5e14,0,r,n,rb,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb);%,r_a,rb_a,n_a); 
% % %sample 8 
% % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag]=zr_amorph_init(332,469*24,0,r,n,rb);%,r_a,rb_a,n_a); 
% % load 'BajajSample8Eq10.mat'
% % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb]=zr_amorph_init(332,469*24,1.2e14,0,r,n,rb,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb);%,r_a,rb_a,n_a); 
% % %sample 9
% % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag]=zr_amorph_init(270,461*24,0,r,n,rb);%,r_a,rb_a,n_a); 
% % load 'BajajSample9Eq10.mat'
% % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb]=zr_amorph_init(270,461*24,1.1e14,0,r,n,rb,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb);%,r_a,rb_a,n_a); 
% % 
% % %Valizadeh runs
% % %Valizadeh sample
% % % 5 Cycle sample
% % %Need to run this as Zirc-2 as xb (and maybe other parameters) are
% % %different!
% % % load Valizadeh.mat
% % % 
% % load Valizadeh5Cycle_305C.mat %This has Taylor eq.10 stored, without irradiation run, these ram values are technically for 305C!
% % 
% % % plot((r.*2).*(10^9),n.*(10^-18),'LineWidth',2)
% % hold on
% % plot((r_ln.*2).*(10^9),n_ln.*(10^-18),'LineWidth',2)
% % % plot((r_FeNi.*2).*(10^9),n_FeNi.*(10^-18),'LineWidth',2)
% % hold on
% % plot((r_lnFeNi.*2).*(10^9),n_lnFeNi.*(10^-18),'LineWidth',2)
% % xlabel('SPP diameter / nm')
% % ylabel('Number density in each size class / \mum^{-3}')
% % xlim([0 120])
% % legend('Fe-Cr','Fe-Ni')%,'Fe-Cr','Fe-Ni','Fe-Ni')
% % 
% 
% % tk = 320+273;
% % tfinal = 312.5*24*60*60;
% % phi = 6e14;
% % [ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb] = Taylor_eq10_tfinal(tk,tfinal,phi,r,rb);
% % 
% % 
% % r = r_ln; %Make the adjusted lognormal arrays equal to r and n
% % n = n_ln; %Made a mistake, this is now in m^-3
% % r_init = r;
% % n_init = n;
% % % 
% % r_FeNi_init = r_lnFeNi;
% % n_FeNi_init = n_lnFeNi;
% % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb]=zr_amorph_init(320,365*24*9,0.68e14,1,r,n,rb,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb);%,r_a,rb_a,n_a); 
% % % % % % 6 cycle
% % % % % 7 cycle
% % % % % 9 cycle
% % % 
% % % 
% % % %Gilbon et al. high temperature observations
% % % % load Gilbon.mat
% % % % r = r_ln; %Make the adjusted lognormal arrays equal to r and n
% % % % n = n_ln; %Made a mistake, this is now in m^-3
% % % % Run Taylor eq.10 outside of the script first, then save file. For now
% % % % this prevents accidentally runnning the irradiation case with wrong ram
% % % % arrays.
% % % % tk = 400+273;
% % % % tfinal = 258*24*60*60;
% % % % phi = 0.54e14;
% % % % phi = 1.3e14;
% % % % [ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb] = Taylor_eq10_tfinal(tk,tfinal,phi,r,rb);
% % % %       
% % % % load Gilbon5dpa.mat
% % % % r_init = r;
% % % % n_init = n;
% % % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb]=zr_amorph_init(400,258*24,0.54e14,0,r,n,rb,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb);%,r_a,rb_a,n_a); 
% % % 
% % % load Gilbon13dpa.mat
% % % r_init = r;
% % % n_init = n;
% % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb]=zr_amorph_init(400,258*24,1.3e14,0,r,n,rb,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb);%,r_a,rb_a,n_a); 
% % % 
% % % % ID 35
% % % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag]=zr_amorph_init(358,(106*24),0,r,n,rb);%,r_a,rb_a,n_a); 
% % % 
% % % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag]=zr_amorph_init(270,17800,0,r,n,rb);%,r_a,rb_a,n_a); 
% % % % [r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout,vf_aout,vf_totout,xbinst_tot,ramout,vfout_FeNi,rbarout_FeNi,nrout_FeNi,npartout_FeNi,r_FeNi,n_FeNi,rcout_FeNi,ram_diss,xbout_a_Cr,xbout_a_Fe,xbout_c_Fe,r_a_shell,xb_tot_check,amorph_diss_out,rbar_totout,xbout_Zirc2,vf_totalout,r_total,r_cryst,n_cryst,vf_amorphout,vf_crystout,xa_store,r_ln,n_ln,dsr1out,dsr2out,dsr3out]= ... 
% % % %   zr_amorph_kin(r,n,zirc2flag,rb,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi,tk,tfinal,d,d_FeNi,xa,xb,xc,xc_a,xb_FeNi,xc_FeNi,sfen,sfen_FeNi,nsites,vmol,vmol_FeNi,a,a_init,1);
% % % 
% % % % r_lnFeNi = [];
% % % % n_lnFeNi = [];
% % % 
% % % 
% % 
% % %Tagtstrom material C
% % % load Tagtstrom_MaterialC.mat
% % % r = r_ln; %Make the adjusted lognormal arrays equal to r and n
% % % n = n_ln; %Made a mistake, this is now in m^-3
% % % r_FeNi = r_lnFeNi;
% % % n_FeNi = n_lnFeNi;
% % % % Run Taylor eq.10 outside of the script first, then save file. For now
% % % % this prevents accidentally runnning the irradiation case with wrong ram
% % % % arrays.
% % % tk = 280+273;
% % % tfinal = 352*24*60*60*4; %in seconds
% % % phi = 0.66e14;
% % % % phi = 1.3e14;
% % % [ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb] = Taylor_eq10_tfinal(tk,tfinal,phi,r,rb);
% % %      
% % % load Tagtstrom_MatC3Cycle.mat
% % % r = r_ln; %Make the adjusted lognormal arrays equal to r and n
% % % n = n_ln; %Made a mistake, this is now in m^-3
% % % r_init = r;
% % % n_init = n;
% % % r_FeNi_init = r_lnFeNi;
% % % n_FeNi_init = n_lnFeNi;
% % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb]=zr_amorph_init(280,352*24*3,0.55e14,1,r,n,rb,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb);%,r_a,rb_a,n_a); 
% % 
% % % load Tagtstrom_MatC4Cycle.mat
% % % r = r_ln; %Make the adjusted lognormal arrays equal to r and n
% % % n = n_ln; %Made a mistake, this is now in m^-3
% % % r_init = r;
% % % n_init = n;
% % % r_FeNi_init = r_lnFeNi;
% % % n_FeNi_init = n_lnFeNi;
% % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb]=zr_amorph_init(280,352*24*4,0.55e14,1,r,n,rb,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb);%,r_a,rb_a,n_a); 
% % 
% % 
% % %Garzarolli_1989LowT
% % % load Garz1989_290C.mat
% % % r = r_ln; %Make the adjusted lognormal arrays equal to r and n
% % % n = n_ln; %Made a mistake, this is now in m^-3
% % % tk = 290+273;
% % % tfinal = 1e22/0.92e14; %in seconds
% % % phi = 0.92e14; %determined from the experimental methods, where the authoer states irradiation cycles
% % % [ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb] = Taylor_eq10_tfinal(tk,tfinal,phi,r,rb);
% % 
% % % load Garz1989_290C_Eq10.mat
% % % % %Due to the size od this distribution, the final SPP sizes went
% % % % %unreasonably large. Remove any n values < 1 (per m3) --> this is just a modelling
% % % % %artefact from the log-normal fit.
% % % n(n<1)=0;
% % % r_init = r;
% % % n_init = n;
% % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb]=zr_amorph_init(290,1258*24,0.92e14,0,r,n,rb,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb);%,r_a,rb_a,n_a); 
% % % % %Change back to 290 C!
% % 
% % %Garzarolli_1989HighT
% % % load 
% % % r = r_ln; %Make the adjusted lognormal arrays equal to r and n
% % % n = n_ln; %Made a mistake, this is now in m^-3
% % % tk = 290+273;
% % % tfinal = 1e22/0.92e14; %in seconds
% % % phi = 0.92e14; %determined from the experimental methods, where the authoer states irradiation cycles
% % % [ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb] = Taylor_eq10_tfinal(tk,tfinal,phi,r,rb);
% % 
% % % load 
% % % %Due to the size od this distribution, the final SPP sizes went
% % % %unreasonably large. Remove any n values < 1 (per m3) --> this is just a modelling
% % % %artefact from the log-normal fit.
% % % n(n<1)=0;
% % % r_init = r;
% % % n_init = n;
% % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb]=zr_amorph_init(290,1258*24,0.92e14,0,r,n,rb,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb);%,r_a,rb_a,n_a); 
% % 
% % 
% % % load Garz_1996_dmode150nm.mat
% % % r = r_ln; %Make the adjusted lognormal arrays equal to r and n
% % % n = n_ln; %Made a mistake, this is now in m^-3
% % % plot((r_ln.*2).*(10^9),n_ln.*(10^-18),'LineWidth',2)
% % 
% % % tk = 350+273;
% % % tfinal = 1543*24*60*60; %in seconds
% % % phi = 0.975e14; %determined from the experimental methods, where the authoer states irradiation cycles
% % % [ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb] = Taylor_eq10_tfinal(tk,tfinal,phi,r,rb);
% % 
% % % load Garz_1996_A3.mat
% % % r = r_ln; %Make the adjusted lognormal arrays equal to r and n
% % % n = n_ln; %Made a mistake, this is now in m^-3
% % % r_init = r;
% % % n_init = n;
% % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb]=zr_amorph_init(350,1543*24,0.975e14,0,r,n,rb,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb);%,r_a,rb_a,n_a); 
% % 
% % % load Garz_1996_A2.mat
% % % r = r_ln; %Make the adjusted lognormal arrays equal to r and n
% % % n = n_ln; %Made a mistake, this is now in m^-3
% % % r_init = r;
% % % n_init = n;
% % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb]=zr_amorph_init(325,1543*24,0.9e14,0,r,n,rb,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb);%,r_a,rb_a,n_a); 
% % % % 
% % % load Garz_1996_A1mat.mat
% % % r = r_ln; %Make the adjusted lognormal arrays equal to r and n
% % % n = n_ln; %Made a mistake, this is now in m^-3
% % % r_init = r;
% % % n_init = n;
% % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb]=zr_amorph_init(300,1543*24,0.368e14,0,r,n,rb,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb);%,r_a,rb_a,n_a); 
% % 
% % 
% % 
% % 
% % %Temporary scripts for Jacobs scenarios 13/9/2022
% % tk = 275+273;
% % phi = 0.3e14;
% % flu = 1.6e22;
% % tfinal = flu./phi;
% % [ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb] = Taylor_eq10_tfinal(tk,tfinal,phi,r,rb);
% % 
% % 
% % [r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout,vf_aout,vf_totout,xbinst_tot,ramout,vfout_FeNi,rbarout_FeNi,nrout_FeNi,npartout_FeNi,r_FeNi,n_FeNi,rcout_FeNi,ram_diss,xbout_a_Cr,xbout_a_Fe,xbout_c_Fe,r_a_shell,xb_tot_check,amorph_diss_out,rbar_totout,xbout_Zirc2,vf_totalout,r_total,r_cryst,n_cryst,vf_amorphout,vf_crystout,xa_store,r_ln,n_ln,dsr1out,dsr2out,dsr3out,r_lnFeNi,n_lnFeNi,Fe2Cr_vf,Fe2Cr_rat,rb_clust,r_clust,n_clust,npart_clustout,vf_clustout,rbar_clustout,EqRadout,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb]= ... 
% %     zr_amorph_kin(r,n,zirc2flag,rb,r_a,rb_a,n_a,r_lnFeNi,rb_FeNi,n_lnFeNi,tk,tfinal,d,d_FeNi,xa,xb,xc,xc_a,xb_FeNi,xc_FeNi,sfen,sfen_FeNi,nsites,vmol,vmol_FeNi,a,a_init,vmax,vmax_FeNi,xc_clust,phi,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,1);
% % 
% % 
% % 
% % % semilogy(tout./86400,dsr3out,'LineWidth',2)
% % % hold on
% % % xlabel('Time / days')
% % % ylabel('Dissolution rate / m^{2} s^{-2}')
% % % set(gca,'FontSize',18)
% % 
% % % subplot(1,2,1)
% % plot((r_init.*2).*(10^9),n_init.*(10^-18),'-','LineWidth',2)
% % % plot((r_stnd.*2).*(10^9),n_stnd.*(10^-18),'LineWidth',2)
% % hold on
% % % plot((r_ln.*2).*(10^9),n_ln.*(10^-18),'LineWidth',2)
% % hold on
% % xlim([0 200])
% % r_cryst(1) = 0;
% % r_cryst_zero = find(r_cryst <= 0);
% % n_cryst(r_cryst_zero) = 0;
% % r_cryst_nonzero = find(r_cryst > 0);
% % r_cryst_plot = r_cryst(r_cryst_nonzero);
% % n_cryst_plot = n_cryst(r_cryst_nonzero);
% % plot((r_cryst_plot.*2).*(10^9),n_cryst_plot.*(10^-18),'-','LineWidth',2)
% % plot((r_total.*2).*(10^9),n.*(10^-18),'-','LineWidth',2)
% % plot((r_FeNi.*2).*(10^9),n_FeNi.*(10^-18),'LineWidth',2)
% % plot((r_FeNi_init.*2).*(10^9),n_FeNi_init.*(10^-18),'LineWidth',2)
% % legend('Initial SPP size distribution','Crystalline cores','Final SPP size distribution','Fe-Ni Final','Fe-Ni Initial')
% % xlabel('SPP diameter / nm')
% % ylabel('Number density in each size class / \mum^{-3}')
% % %set(gca,'YScale','log')
% % 
% % set(gca,'FontSize',18)
% % subplot(1,2,2)
% % plot(tout./3600,rbar_totout.*2,'LineWidth',2)
% % xlabel('Time / hours')
% % ylabel('Mean SPP diameter / nm')
% % set(gca,'FontSize',18)
% % 
% % % plot(tout./86400,xbinst_tot,'LineWidth',2)
% % % hold on
% % % plot(tout./86400,xa_store,'LineWidth',2)
% % % legend('Matrix solute concentration','Solubility limit')
% % % xlabel('Time / days')
% % % ylabel('Solute concentration / at. frac.')
% % % set(gca,'FontSize',18)
% % % % xlim([300 800])
% % % 
% % % 
% % % 
% % % 
% % % % subplot(1,4,3)
% % % % plot(tout,xa_store)
% % % % ylabel('xa')
% % % % 
% % % % subplot(1,3,3)
% % % % plot(tout./86400,dsr1out,'LineWidth',2)
% % % % hold on
% % % % plot(tout./86400,dsr2out,'LineWidth',2)
% % % % plot(tout./86400,dsr3out,'LineWidth',2)
% % % % % plot(tout,grout)
% % % % legend('100 nm','200 nm','400 nm')
% % % % xlabel('Time / days')
% % % % ylabel('Dissolution rate / ms^{-1}')
% % % % set(gca,'FontSize',18)
% % % 
% % % 
% % Fe_c_sol = cumsum(xbout_c_Fe);
% % Fe_a_sol = cumsum(xbout_a_Fe);
% % Cr_a_sol = cumsum(xbout_a_Cr);
% % check = Fe_c_sol+Fe_a_sol+Cr_a_sol;
% % % total_sol = cumsum(xb_tot_check);
% % % xbinstout = cumsum(xbinst_tot);
% % plot(tout./86400,Fe_c_sol.*1e6,'LineWidth',2)
% % hold on
% % plot(tout./86400,Fe_a_sol.*1e6,'LineWidth',2)
% % plot(tout./86400,Cr_a_sol.*1e6,'LineWidth',2)
% % 
% % %Solute in clusters = vf.*xc
% % Clust_sol = vf_clustout.*xc_clust;
% % plot(tout./86400,Clust_sol.*1e6,'LineWidth',2)
% % % plot(tout./86400,total_sol.*1e6,'LineWidth',2) %This shows a discepncy
% % % between solute released and final matrix conc, but that is just related
% % % to the solute concentration in the matrix at the start of simulations
% % plot(tout./86400,xbinst_tot.*1e6,'LineWidth',2) %This is the total solute concentration in the matrix, so accounts for solute being used by cluster formation
% % legend('Fe released during crystalline-to-amorphous transformation','Fe released during precipitate dissolution','Cr released during precipitate dissolution','Solute contained within clusters','Matrix solute concentration','Location','northwest')
% % xlabel('Time / days')
% % ylabel('Solute concentration / appm')
% % set(gca,'FontSize',18)
% % % 
% % plot(tout./86400,vf_totalout,'LineWidth',2)
% % hold on
% % plot(tout./86400,vf_crystout,'LineWidth',2)
% % plot(tout./86400,vf_amorphout,'LineWidth',2)
% % plot(tout./86400,vf_clustout,'LineWidth',2)
% % xlabel('Time/ days')
% % ylabel('Volume fraction')
% % legend('Total SPP','Crystalline cores','Amorphous material','Clusters')
% % 
% % set(gca,'FontSize',18)
% % 
% % 
% % 
% % plot(tout./86400,dsr1out,'LineWidth',2)
% % 
% % %Cluster plotting
% % subplot(2,2,1)
% % plot((r_clust.*2).*(10^9),n_clust.*(10^-18),'LineWidth',2)
% % xlim([0 5])
% % xlabel('Cluster diameter / nm')
% % ylabel({'Number density in each'; 'size class / \mum^{-3}'})
% % set(gca,'FontSize',18)
% % 
% % subplot(2,2,2)
% % semilogy(tout./86400,npart_clustout,'LineWidth',2)
% % xlabel('Time / days')
% % ylabel({'Number density of'; 'clusters / m^{-3}'})
% % set(gca,'FontSize',18)
% % subplot(2,2,3)
% % semilogy(tout./86400,EqRadout.*1e9,'LineWidth',2)
% % xlabel('Time / days')
% % ylabel('Equilibrium radius / nm')
% % set(gca,'FontSize',18)
% % subplot(2,2,4)
% % semilogy(tout./86400,nrout,'LineWidth',2)
% % xlabel('Time / days')
% % ylabel({'Nucleation rate /'; 'clusters m^{-3} s^{-1}'})
% % set(gca,'FontSize',18)
% % 
% % 
% % semilogy(tout./86400,rbar_clustout,'LineWidth',2)
% % xlabel('Time / days')
% % ylabel({'Mean radius / nm'})
% % set(gca,'FontSize',18)
% % %Plot the elemental ratios of clusters, this can also then be used to
% % %determine final estimation of the composition of Fe + Cr in solution
% % 
% % % plot(cumsum(Fe2Cr_vf),Fe2Cr_rat)
% % 
% % % plot(tout./8600,(cumsum(Fe2Cr_vf)).*xc_clust.*1e6,'LineWidth',2)
% % % xlabel('Time / days')
% % % ylabel('Total concentration of Fe+Cr in clusters / appm')
% % % set(gca,'FontSize',18)
% %% Script for Zircaloy-2 irradiation
% % load 'ValizadehNew.mat'
% % %Fe-Cr
% % r = r_ln; %Make the adjusted lognormal arrays equal to r and n
% % n = n_ln; %Made a mistake, this is now in m^-3
% % d = r.*2;
% % 
% % r_init = r;
% % rb_init = rb;
% % n_init = n;
% % 
% % %Fe-Ni
% % 
% % r_FeNi = r_lnFeNi; %Make the adjusted lognormal arrays equal to r and n
% % n_FeNi = n_lnFeNi; %Made a mistake, this is now in m^-3
% % 
% % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag]=zr_amorph_init(290,365*5*24,1,r,n,rb,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi);
% % [r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout,vf_aout,vf_totout,xbinst_tot,ramout,vfout_FeNi,rbarout_FeNi,nrout_FeNi,npartout_FeNi,r_FeNi,n_FeNi,rcout_FeNi,ram_diss,xbout_a_Cr,xbout_a_Fe,xbout_c_Fe,r_a_shell,xb_tot_check,amorph_diss_out,rbar_totout,xbout_Zirc2,vf_totalout,r_total,r_cryst,n_cryst,vf_amorphout,vf_crystout,xa_store,r_ln,n_ln,dsr1out,dsr2out,dsr3out,r_lnFeNi,n_lnFeNi]= ... 
% %     zr_amorph_kin(r,n,zirc2flag,rb,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi,tk,tfinal,d,d_FeNi,xa,xb,xc,xc_a,xb_FeNi,xc_FeNi,sfen,sfen_FeNi,nsites,vmol,vmol_FeNi,a,a_init,vmax,vmax_FeNi,1);
% % 
% % 
% % plot((r_init.*2).*(10^9),n_init.*(10^-18),'LineWidth',2)
% % hold on
% % xlim([0 250])
% % r_cryst(1) = 0;
% % r_cryst_zero = find(r_cryst <= 0);
% % n_cryst(r_cryst_zero) = 0;
% % r_cryst_nonzero = find(r_cryst > 0);
% % r_cryst_plot = r_cryst(r_cryst_nonzero);
% % n_cryst_plot = n_cryst(r_cryst_nonzero);
% % plot((r_cryst_plot.*2).*(10^9),n_cryst_plot.*(10^-18),'LineWidth',2)
% % plot((r_total.*2).*(10^9),n.*(10^-18),'LineWidth',2)
% % plot((r_FeNi.*2).*(10^9),n_FeNi.*(10^-18),'LineWidth',2)
% % legend('Initial SPP size distribution','Crystalline cores','Final SPP size distribution','Fe-Ni SPPs')
% % xlabel('SPP diameter / nm')
% % ylabel('Number density in each size class / \mum^{-3}')
% 
% 
% % % r_a = r;
% % % rb_a = rb;
% % % n_a = zeros(1,length(n));
% % 
% %  load '750c12hours.mat'
% %  
% % r_init = r;
% % n_init = n;
% % rb_init = rb;
% % % %If loading from PERT the size of the r and n arrays change, so need to
% % % %change size of amorphous shells
% % % %Need narrower bins as critical radius and newsize are in the same bin,
% % % %because after PERT the bins are evenly spread out rather than
% % % %logarithmacly. May be able to just turn that error off KWN because no
% % % %nucleation during irradiation.
% % % %At the moment (07/06/2021) loading a PERT SPP size distribution into this
% % % %scipt produces odd results. However, using a standard KWN produced SPP
% % % %distribution works well. However(!) PERT will be needed to capture the
% % % %largest SPPs which are often missed when running low CAP pre-irradiation
% % % %conditions
% % % 
% % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag]=zr_amorph_init(310,24*365*2,0,r,n,rb); 
% % [r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout,vf_aout,vf_totout,xbinst_tot,ramout,vfout_FeNi,rbarout_FeNi,nrout_FeNi,npartout_FeNi,r_FeNi,n_FeNi,rcout_FeNi,ram_diss,xbout_a_Cr,xbout_a_Fe,xbout_c_Fe,r_a_shell,xb_tot_check,amorph_diss_out,rbar_totout,xbout_Zirc2,vf_totalout,r_total,r_cryst,n_cryst,vf_amorphout,vf_crystout]= ... 
% %   zr_amorph_kin(r,n,zirc2flag,rb,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi,tk,tfinal,d,d_FeNi,xa,xb,xc,xc_a,xb_FeNi,xc_FeNi,sfen,sfen_FeNi,nsites,vmol,vmol_FeNi,a,a_init,1);
% % 
% % % 
% % % plot((r_init.*2).*(10^9),n_init.*(10^-18),'LineWidth',2)
% % % hold on
% % % xlim([0 250])
% % % r_cryst(1) = 0;
% % % r_cryst_zero = find(r_cryst <= 0);
% % % n_cryst(r_cryst_zero) = 0;
% % % r_cryst_nonzero = find(r_cryst > 0);
% % % r_cryst_plot = r_cryst(r_cryst_nonzero);
% % % n_cryst_plot = n_cryst(r_cryst_nonzero);
% % % plot((r_cryst_plot.*2).*(10^9),n_cryst_plot.*(10^-18),'LineWidth',2)
% % % plot((r_total.*2).*(10^9),n.*(10^-18),'LineWidth',2)
% % % legend('Initial SPP size distribution','Crystalline cores','Final SPP size distribution')
% % % xlabel('SPP diameter / nm')
% % % ylabel('Number density in each size class / \mum^{-3}')
% % % Fe_c_sol = cumsum(xbout_c_Fe);
% % % Fe_a_sol = cumsum(xbout_a_Fe);
% % % Cr_a_sol = cumsum(xbout_a_Cr);
% % % total_sol = cumsum(xb_tot_check);
% % % plot(tout./86400,Fe_c_sol.*1e6,'LineWidth',2)
% % % hold on
% % % plot(tout./86400,Fe_a_sol.*1e6,'LineWidth',2)
% % % plot(tout./86400,Cr_a_sol.*1e6,'LineWidth',2)
% % % plot(tout./86400,total_sol.*1e6,'LineWidth',2)
% % % legend('Fe released during crystalline-to-amorphous transformation','Fe released during amorphization dissolution','Cr released during amorphization dissolution','Total matrix solute concentration','Location','northwest')
% % % xlabel('Time / days')
% % % ylabel('Matrix solute concentration / appm')
% % % 
% % plot(tout./86400,vf_totalout,'LineWidth',2)
% % hold on
% % plot(tout./86400,vf_crystout,'LineWidth',2)
% % plot(tout./86400,vf_amorphout,'LineWidth',2)
% % xlabel('Time/ days')
% % ylabel('Volume fraction')
% % legend('Total SPP','Crystalline cores','Amorphous material')
% % 
% % set(gca,'FontSize',18)
% %% Script running for Zircaloy-2 non-irradiation
% 
% % % load 'Bajaj_dbar240.mat'
% % % 
% % % r = r_ln; %Make the adjusted lognormal arrays equal to r and n
% % % n = n_ln; %Made a mistake, this is now in m^-3
% % % d = r.*2;
% % % 
% % % load Gros_Start_120nm.mat
% % % 
% % % load Shah_Zirc2Init.mat
% % % 
% % % ram_total_end_r = []; 
% % % ram_total_end_rb = []; 
% % % time_amorph = []; 
% % % time_amorphrb = [];
% % % 
% % % radflag = 0;
% % % 
% % % 
% % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,xa_FeNi,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,FeCrRat,FeNiRat]=zr_amorph_init(300,1,0,radflag,1,r,n,rb);%,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi)
% % % 
% % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,xa_FeNi,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,FeCrRat,FeNiRat]=zr_amorph_init(700,2,0,radflag,1,r,n,rb,[],[],[],[],[],[],[],r_FeNi,rb_FeNi,n_FeNi);%,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi)
% % % 
% % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,xa_FeNi,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,FeCrRat,FeNiRat,a_FeNi]=zr_amorph_init(600,20,0,radflag,1,r,n,rb,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi);
% % % 
% % % [r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout,vf_aout,vf_totout,xbinst_tot,ramout,vfout_FeNi,rbarout_FeNi,nrout_FeNi,npartout_FeNi,r_FeNi,n_FeNi,rcout_FeNi,ram_diss,xbout_a_Cr,xbout_a_Fe,xbout_c_Fe,r_a_shell,xb_tot_check,amorph_diss_out,rbar_totout,xbout_Zirc2,vf_totalout,r_total,r_cryst,n_cryst,vf_amorphout,vf_crystout,xa_store,r_ln,n_ln,dsr1out,dsr2out,dsr3out,r_lnFeNi,n_lnFeNi,Fe2Cr_vf,Fe2Cr_rat,rb_clust,r_clust,n_clust,npart_clustout,vf_clustout,rbar_clustout,EqRadout,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,xbout_Zirc2_FeCr,xbout_Zirc2_FeNi]= ... 
% % %     zr_amorph_kin(r,n,zirc2flag,rb,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi,tk,tfinal,d,d_FeNi,xa,xb,xc,xc_a,xb_FeNi,xc_FeNi,sfen,sfen_FeNi,nsites,vmol,vmol_FeNi,a,a_init,vmax,vmax_FeNi,xc_clust,phi,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,FeCrRat,FeNiRat,xa_FeNi,a_FeNi,0);
% % % 
% % % 
% % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag]=zr_amorph_init(600,0.745,1);%,r,n,rb); 
% % % [r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout,vf_aout,vf_totout,xbinst_tot,ramout,vfout_FeNi,rbarout_FeNi,nrout_FeNi,npartout_FeNi,r_FeNi,n_FeNi,rcout_FeNi,ram_diss,xbout_a_Cr,xbout_a_Fe,xbout_c_Fe,r_a_shell,xb_tot_check,amorph_diss_out,rbar_totout,xbout_Zirc2,vf_totalout,r_total,r_cryst,n_cryst,vf_amorphout,vf_crystout,xa_store,r_ln,n_ln,dsr1out,dsr2out,dsr3out,r_lnFeNi,n_lnFeNi]= ... 
% % %     zr_amorph_kin(r,n,zirc2flag,rb,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi,tk,tfinal,d,d_FeNi,xa,xb,xc,xc_a,xb_FeNi,xc_FeNi,sfen,sfen_FeNi,nsites,vmol,vmol_FeNi,a,a_init,vmax,vmax_FeNi,0);
% % % 
% % % [r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout,vf_aout,vf_totout,xbinst_tot,ramout,vfout_FeNi,rbarout_FeNi,nrout_FeNi,npartout_FeNi,r_FeNi,n_FeNi,rcout_FeNi,ram_diss,xbout_a_Cr,xbout_a_Fe,xbout_c_Fe,r_a_shell,xb_tot_check,amorph_diss_out,rbar_totout,xbout_Zirc2,vf_totalout,r_total,r_cryst,n_cryst,vf_amorphout,vf_crystout,xa_store,r_ln,n_ln,dsr1out,dsr2out,dsr3out,r_lnFeNi,n_lnFeNi]= ... 
% % %     zr_amorph_kin(r,n,zirc2flag,rb,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi,tk,tfinal,d,d_FeNi,xa,xb,xc,xc_a,xb_FeNi,xc_FeNi,sfen,sfen_FeNi,nsites,vmol,vmol_FeNi,a,a_init,vmax,vmax_FeNi,0);
% % % 
% % % ram_total_end_r = []; 
% % % ram_total_end_rb = []; 
% % % time_amorph = []; 
% % % time_amorphrb = [];
% % % 
% % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb]=zr_amorph_init(600,0.01,0,1);%,~,~,~,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb);%,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi);
% % % 
% % % [r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout,vf_aout,vf_totout,xbinst_tot,ramout,vfout_FeNi,rbarout_FeNi,nrout_FeNi,npartout_FeNi,r_FeNi,n_FeNi,rcout_FeNi,ram_diss,xbout_a_Cr,xbout_a_Fe,xbout_c_Fe,r_a_shell,xb_tot_check,amorph_diss_out,rbar_totout,xbout_Zirc2,vf_totalout,r_total,r_cryst,n_cryst,vf_amorphout,vf_crystout,xa_store,r_ln,n_ln,dsr1out,dsr2out,dsr3out,r_lnFeNi,n_lnFeNi,Fe2Cr_vf,Fe2Cr_rat,rb_clust,r_clust,n_clust,npart_clustout,vf_clustout,rbar_clustout,EqRadout,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb]= ... 
% % %     zr_amorph_kin(r,n,zirc2flag,rb,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi,tk,tfinal,d,d_FeNi,xa,xb,xc,xc_a,xb_FeNi,xc_FeNi,sfen,sfen_FeNi,nsites,vmol,vmol_FeNi,a,a_init,vmax,vmax_FeNi,xc_clust,phi,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,0);
% % % 
% % % 
% % % semilogy(tout./86400,xbout,'LineWidth',2)
% % % xa_line = xa.*ones(length(xbout),1);
% % % hold on
% % % semilogy(tout./86400,xa_line,'LineWidth',2);
% % % xlabel('Time / days')
% % % ylabel('Concentration / at. frac.')
% % % legend('Matrix concentration','Solubility limit')
% % % set(gca,'FontSize',18)
% % % title(['310 ' char(176) 'C'])
% % % 
% % % 
% % % subplot(1,4,1)
% plot((r.*2).*(10^9),n.*(10^-18),'LineWidth',2)
% hold on
% % % % hold on
% % % % plot((r_ln.*2).*(10^9),n_ln.*(10^-18),'LineWidth',2)
% plot((r_FeNi.*2).*(10^9),n_FeNi.*(10^-18),'LineWidth',2)
% hold on
% % plot((r_lnFeNi.*2).*(10^9),n_lnFeNi.*(10^-18),'LineWidth',2)
% xlabel('SPP diameter / nm')
% ylabel('Number density in each size class / \mum^{-3}')
% xlim([0 120])
% legend('Fe-Cr','Fe-Ni')%,'Fe-Cr','Fe-Ni','Fe-Ni')
% set(gca,'FontSize',18)
% % % hold on
% % % plot((r_FeNi.*2).*(10^9),n_FeNi,'LineWidth',2)
% % % xlim([0 200])
% % % subplot(1,4,2)
% % % semilogx(tout,rbarout.*2)
% % % hold on
% % % semilogx(tout,rbarout_FeNi.*2)
% % % subplot(1,4,3)
% % % semilogx(tout,xbout_Zirc2_FeCr,'LineWidth',2)
% % % hold on
% % % semilogx(tout,xbout_Zirc2_FeNi,'LineWidth',2)
% % % yline(xa,'LineWidth',2)
% % % yline(xa_FeNi,'LineWidth',2)
% % % subplot(1,4,4)
% % % semilogx(tout,vfout)
% % % hold on
% % % semilogx(tout,vfout_FeNi)
% % % legend('Fe-Cr','Fe-Ni')
% % % vmax = (xb - xa)/(xc - xa);
% % % vmax_FeNi = (xb_FeNi - xa)/(xc_FeNi - xa);
% % % yline(vmax)
% % % yline(vmax_FeNi)
% 
% %% Script running for Zircaloy-4 non-irradiation
% 
% % % [r,rb,n,tkprof,xb,xc,sfen,nsites,vmol,a,a_init]=zr_amorph_init_noniso([1050 10 2/3600]);  %%%% Need to fix the non-iso script as theres been loads of
% % % % changes to the iso one
% % % [r,n,tout,tkout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout]= ... 
% % %     zr_amorph_kin_noniso(r,rb,tkprof,xb,xc,sfen,nsites,vmol,a,a_init,0);
% % % 
% % % 
% % 
% % % % load 'YaoRough.mat'
% % % load 'Bajaj_dbar240.mat'
% % 
% % % load Gros_Start_120nm.mat
% % 
% % r = r_ln; %Make the adjusted lognormal arrays equal to r and n
% % n = n_ln; %Made a mistake, this is now in m^-3
% % dbar = ((sum(r.*n))/sum(n))*2;
% % 
% % radflag = 0;
% % 
% % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag]=zr_amorph_init(480,200,0);%,r,n,rb);
% % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi]=zr_amorph_init(700,2,0,0,r,n,rb);%,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi)
% % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust]=zr_amorph_init(700,50,0,0)%,r,n,rb);%,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi)
% % % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb]=zr_amorph_init(600,0.4,0,0);%,r,n,rb);%,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi)
% % 
% % 
% % 
% % % [r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout,vf_aout,vf_totout,xbinst_tot,ramout,vfout_FeNi,rbarout_FeNi,nrout_FeNi,npartout_FeNi,r_FeNi,n_FeNi,rcout_FeNi,ram_diss,xbout_a_Cr,xbout_a_Fe,xbout_c_Fe,r_a_shell,xb_tot_check,amorph_diss_out,rbar_totout,xbout_Zirc2,vf_totalout,r_total,r_cryst,n_cryst,vf_amorphout,vf_crystout,xa_store,r_ln,n_ln,dsr1out,dsr2out,dsr3out]= ... 
% % %     zr_amorph_kin(r,n,zirc2flag,rb,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi,tk,tfinal,d,d_FeNi,xa,xb,xc,xc_a,xb_FeNi,xc_FeNi,sfen,sfen_FeNi,nsites,vmol,vmol_FeNi,a,a_init,vmax,vmax_FeNi,0);
% % 
% % % [r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout,vf_aout,vf_totout,xbinst_tot,ramout,vfout_FeNi,rbarout_FeNi,nrout_FeNi,npartout_FeNi,r_FeNi,n_FeNi,rcout_FeNi,ram_diss,xbout_a_Cr,xbout_a_Fe,xbout_c_Fe,r_a_shell,xb_tot_check,amorph_diss_out,rbar_totout,xbout_Zirc2,vf_totalout,r_total,r_cryst,n_cryst,vf_amorphout,vf_crystout,xa_store,r_ln,n_ln,dsr1out,dsr2out,dsr3out,r_lnFeNi,n_lnFeNi]= ... 
% % %     zr_amorph_kin(r,n,zirc2flag,rb,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi,tk,tfinal,d,d_FeNi,xa,xb,xc,xc_a,xb_FeNi,xc_FeNi,sfen,sfen_FeNi,nsites,vmol,vmol_FeNi,a,a_init,vmax,vmax_FeNi,phi,0);
% % 
% % % [r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout,vf_aout,vf_totout,xbinst_tot,ramout,vfout_FeNi,rbarout_FeNi,nrout_FeNi,npartout_FeNi,r_FeNi,n_FeNi,rcout_FeNi,ram_diss,xbout_a_Cr,xbout_a_Fe,xbout_c_Fe,r_a_shell,xb_tot_check,amorph_diss_out,rbar_totout,xbout_Zirc2,vf_totalout,r_total,r_cryst,n_cryst,vf_amorphout,vf_crystout,xa_store,r_ln,n_ln,dsr1out,dsr2out,dsr3out,r_lnFeNi,n_lnFeNi,Fe2Cr_vf,Fe2Cr_rat,rb_clust,r_clust,n_clust,npart_clustout,vf_clustout,rbar_clustout,EqRadout,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb]= ... 
% % %     zr_amorph_kin(r,n,zirc2flag,rb,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi,tk,tfinal,d,d_FeNi,xa,xb,xc,xc_a,xb_FeNi,xc_FeNi,sfen,sfen_FeNi,nsites,vmol,vmol_FeNi,a,a_init,vmax,vmax_FeNi,xc_clust,phi,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,0);
% % 
% % [r,rb,n,r_a,rb_a,n_a,tk,d,tfinal,xb,xc,xc_a,xa,sfen,nsites,vmol,vmax,a,a_init,r_FeNi,rb_FeNi,n_FeNi,d_FeNi,xb_FeNi,xc_FeNi,sfen_FeNi,vmol_FeNi,vmax_FeNi,zirc2flag,phi,xc_clust,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,FeCrRat,FeNiRat]=zr_amorph_init(600,0.4,0,radflag,0);%,r,n,rb,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi)
% % [r,n,tout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout,vf_aout,vf_totout,xbinst_tot,ramout,vfout_FeNi,rbarout_FeNi,nrout_FeNi,npartout_FeNi,r_FeNi,n_FeNi,rcout_FeNi,ram_diss,xbout_a_Cr,xbout_a_Fe,xbout_c_Fe,r_a_shell,xb_tot_check,amorph_diss_out,rbar_totout,xbout_Zirc2,vf_totalout,r_total,r_cryst,n_cryst,vf_amorphout,vf_crystout,xa_store,r_ln,n_ln,dsr1out,dsr2out,dsr3out,r_lnFeNi,n_lnFeNi,Fe2Cr_vf,Fe2Cr_rat,rb_clust,r_clust,n_clust,npart_clustout,vf_clustout,rbar_clustout,EqRadout,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb]= ... 
% %     zr_amorph_kin(r,n,zirc2flag,rb,r_a,rb_a,n_a,r_FeNi,rb_FeNi,n_FeNi,tk,tfinal,d,d_FeNi,xa,xb,xc,xc_a,xb_FeNi,xc_FeNi,sfen,sfen_FeNi,nsites,vmol,vmol_FeNi,a,a_init,vmax,vmax_FeNi,xc_clust,phi,ram_total_end_r,ram_total_end_rb,time_amorph,time_amorphrb,FeCrRat,FeNiRat,0);
% % 
% % 
% % 
% % %do i after run where nucleation has been completed
% % 
% % % subplot(1,4,1)
% % rbar = ((sum(r_ln.*n_ln))/sum(n_ln))*1;
% % rbarFeNi = ((sum(r_lnFeNi.*n_lnFeNi))/sum(n_lnFeNi))*1;
% % 
% % plot((r.*2).*(10^9),n.*(10^-18),'LineWidth',2)
% % hold on
% % xlim([0 200])
% % % subplot(2,2,2)
% % % semilogx(tout,nrout)
% % % hold on
% % % subplot(2,2,3)
% % % semilogx(tout,grout);
% % % hold on
% % % subplot(2,2,4)
% % % semilogx(tout,rbarout);
% % % hold on
% % plot((r_ln.*2).*(10^9),n_ln.*(10^-18),'LineWidth',2)
% % xlim([0 300])
% % hold on
% % % plot((r_lnFeNi.*2).*(10^9),n_lnFeNi.*(10^-18),'LineWidth',2)
% % % xlim([0 1000])
% % subplot(1,4,2)
% % semilogx(tout,rbarout.*2)
% % hold on
% % % semilogx(tout,rbarout_FeNi.*2)
% % subplot(1,4,3)
% % % semilogx(tout,xbout_Zirc2)
% % subplot(1,4,4)
% % semilogx(tout,vfout)
% % hold on
% % vmax = (xb - xa)/(xc - xa);
% % yline(vmax)
% % % semilogx(tout,vfout_FeNi)
% % legend('Fe-Cr','Fe-Ni')
% 
% %% Quench rate calcs
% % 
% % %only have ABQ size distribution so far..
% % 
% % [r,rb,n,tkprof,xb,xc,sfen,nsites,vmol,a,a_init]=zr_amorph_init_noniso([877 10 240.9/3600]);
% % 
% % [r,n,tout,tkout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout]= ... 
% %     zr_amorph_kin_noniso(r,rb,tkprof,xb,xc,sfen,nsites,vmol,a,a_init,0);