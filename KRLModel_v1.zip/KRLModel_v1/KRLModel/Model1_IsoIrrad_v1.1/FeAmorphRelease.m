function [FeRel_Am,FeRel_Both,CrRel,AmorphFeTrack,xc_Fec_Track,TotalCrTrack,TotalFeTrack] = FeAmorphRelease(r,n,r_cryst,n_cryst,r_old,n_old,r_cryst_old,n_cryst_old,phi,h,AmorphFeTrack,xc_Fec_Track,TotalCrTrack,TotalFeTrack,r_init,n_init,FeConc,CrConc,NiConc,zirc2flag)

D = (3.48e-41.*phi.*1e4)-(2.61e-24); % Phi comes in n/cm2/s, convert to m
% D = (3.48e-39.*phi.*1e4)-(2.61e-24); % Phi comes in n/cm2/s, convert to m

% Have to loop over SPPs to determine ones which are partially and fully
% amorphous
% Hvae to track progress of Fully amorphous SPPs
if zirc2flag == 0
xc_Fec = 0.44; % Concentration of Fe in crystalline SPP --> 0.4 for Zry4, 0.3 for Zry2?
xc_Feca = 0.2; % Concentration of Fe at crysatlline/amorphous interface according to Robson, 2021
xc_Fea = 0.1; % Concentration of Fe at amorphous/matrix interface
xc_cr = 0.22; % Concentration of Cr in crystalline SPP and amorphous zone.
else
    xc_Fec = 0.33; % Concentration of Fe in crystalline SPP --> 0.4 for Zry4, 0.3 for Zry2?
xc_Feca = 0.2; % Concentration of Fe at crysatlline/amorphous interface according to Robson, 2021
xc_Fea = 0.1; % Concentration of Fe at amorphous/matrix interface
xc_cr = 0.33; % Concentration of Cr in crystalline SPP and amorphous zone.
end
% xc_Cr = xc-xc_c; %Cr conc stays the same
%Need another trackable array of xc_FecTrack, which follows the centre SPP
%conc, and is this reduces (or just do an average SPP Fe conc ?)s


%% Current Fe conc - This actually also includes the Fe lost from dissolution

PartA = find(r_cryst>0); %Partially amorphous SPPs
FullA = find(r_cryst<=0); % Fully amorphous SPPs
% For partially amorphous SPPs
deltaaz_P = r(PartA) - r_cryst(PartA);
CurFe_P = ((r(PartA).*xc_Fec) - ((0.5.*deltaaz_P).*(xc_Feca-xc_Fea))  - (deltaaz_P.*(xc_Fec-xc_Feca)))./r(PartA); %Use r to exclude effects of SPP dissolution here

% For fully amorphous SPPs
Time = (r(FullA).^2)./(6.*D);




if length(Time) > 0

% Update 28/3/23:
% Once an SPP is fully amorphous, the concentration of xc_c essentially
% becomes xc_Feca - have set it to 0.2 in preamble.


xc_Fec_rate = (xc_Fec_Track(FullA)-xc_Fea)./Time; % Determine a rate at which xc_Fec should change by to fit the linear decrease in solute according to time
xc_Fec_Track(FullA) = xc_Fec_Track(FullA) - (xc_Fec_rate.*h);    % Apply this rate to get current Fe conc for these SPPs

%Catch any cores which have completed Fe distribution and set their conc to xc_Fea
CoreCatch = find(xc_Fec_Track<xc_Fea);
xc_Fec_Track(CoreCatch) = xc_Fea;


deltaaz_F = r(FullA);
CurFe_F = ((r(FullA).*xc_Fec_Track(FullA)) - ((0.5.*deltaaz_F).*(xc_Fec_Track(FullA)-xc_Fea)))./r(FullA);

    CurFe = [CurFe_F CurFe_P];
else
    CurFe = [CurFe_P];
end

vf = 4/3 .* pi .* ((r.^3) .* n);

CurTotFe = sum(vf.*CurFe);

% AmorphFeTrack = [AmorphFeTrack CurTotFe];

% if length(AmorphFeTrack) > 1
%     FeRel = AmorphFeTrack(end-1) - AmorphFeTrack(end);
% else
%     FeRel = 0;
% end

% if FeRel < 0
%     aaaa=5;
% end

%% Dummy/imaginary Fe conc in SPPs if dissolution was zero
PartA_dum = find(r_cryst>0); %Partially amorphous SPPs
FullA_dum = find(r_cryst<=0); % Fully amorphous SPPs
% For partially amorphous SPPs
deltaaz_P_dum = r_init(PartA_dum) - r_cryst(PartA_dum);
% CurFe_P_dum = ((r_init(PartA_dum).*xc_Fec) - ((0.5.*deltaaz_P_dum).*(xc_Fec-xc_Fea)))./r_init(PartA_dum); %Use r to exclude effects of SPP dissolution here
CurFe_P_dum =      ((r(PartA_dum).*xc_Fec) - ((0.5.*deltaaz_P_dum).*(xc_Feca-xc_Fea))  - (deltaaz_P_dum.*(xc_Fec-xc_Feca)))./r(PartA_dum); %Use r to exclude effects of SPP dissolution here


if length(Time) > 0
%For fully amorphous SPPs - use the xc_Fec determined from the up-to-date steps
deltaaz_F_dum = r_init(FullA_dum);
CurFe_F_dum = ((r_init(FullA_dum).*xc_Fec_Track(FullA_dum)) - ((0.5.*deltaaz_F).*(xc_Fec_Track(FullA_dum)-xc_Fea)))./r_init(FullA_dum);
CurFe_dum = [CurFe_F_dum CurFe_P_dum];
else
    CurFe_dum = [CurFe_P_dum];
end
vf_dum = 4/3 .* pi .* ((r_init.^3) .* n_init); %Does n work here??????
CurTotFe_dum = sum(vf_dum.*CurFe_dum);
% Calculate difference between only amorphous (Dummy) and including
% dissolution

CurTotFe_DissOnly = CurTotFe - CurTotFe_dum;

AmorphFeTrack = [AmorphFeTrack CurTotFe_dum]; % Just Fe released from amorphization process
TotalFeTrack = [TotalFeTrack CurTotFe]; % Total Fe released including dissolution

if length(AmorphFeTrack) > 1
    FeRel_Am = AmorphFeTrack(end-1) - AmorphFeTrack(end);
else
    FeRel_Am = 0;
end

if length(TotalFeTrack) > 1
    FeRel_Both = TotalFeTrack(end-1) - TotalFeTrack(end);
else
    FeRel_Both = 0;
end

%% Current Cr conc
% xc_cr = 0.22;
vf_cr = 4/3 .* pi .* ((r.^3) .* n);

CurTotCr = sum(vf_cr.*xc_cr);

TotalCrTrack = [TotalCrTrack CurTotCr];

if length(TotalCrTrack) > 1
    CrRel = TotalCrTrack(end-1) - TotalCrTrack(end);
else
    CrRel = 0;
end


% Sanity check
if FeRel_Am < 0 || CrRel < 0 || FeRel_Both < 0
    aaaa=5;
end


end

%% Need to add in an effieicny catch for adaptive timestep.
% if length(Time) > 0
%     Temprate = (xc_Fec_Track(FullA)-xc_Fea)./Time;
%     timecheck = xc_Fec_Track(FullA) - (Temprate.*h);
% if any(timecheck<xc_Fea)
%     hcheck_FeAmorph = 1;
% else
%     hcheck_FeAmorph = 0;
% end
% else 
%     hcheck_FeAmorph = 0;
% end
% 
% end

%% Previous iteration Fe conc

% PartA_old = find(r_cryst_old>0); %Partially amorphous SPPs
% FullA_old = find(r_cryst_old<=0); % Fully amorphous SPPs
% % For partially amorphous SPPs
% deltaaz_P_old = r_old(PartA_old) - r_cryst(PartA_old);
% CurFe_P_old = ((r_old(PartA_old).*xc_Fec) - ((0.5.*deltaaz_P_old).*(xc_Fec-xc_Fea)))./r_old(PartA_old); %Use r_old to exclude effects of SPP dissolution here
% 
% % For fully amorphous SPPs
% Time_old = (r_old(FullA_old).^2)./(6.*D);
% xc_Fec_rate = (xc_Fec_Track-xc_Fea)./Time; % Determine a rate at which xc_Fec should change by to fit the linear decrease in solute according to time
% xc_Fec_Track = xc_Fec_Track - (xc_Fec_rate.*h_old);    % Apply this rate to get current Fe conc for these SPPs
% 
% deltaaz_F = r_old(FullA);
% CurFe_F = ((r_old(FullA).*xc_Fec_Track) - ((0.5.*deltaaz_P).*(xc_Fec_Track-xc_Fea)))./r_old(FullA);
% 
% CurFe = [CurFe_P CurFe_F];

% end



% r = 5;
% n = 10;
% r_cryst = 4.9999;
% 
% r_old = 5;
% r_cryst_old = 5;
% xc = 0.66;
% 
% xc_Fec = 0.4; % Concentration of Fe in crystalline SPP --> 0.4 for Zry4, 0.3 for Zry2?
% xc_Fea = 0.1; % Concentration of Fe at amorphous/matrix interface
% xc_Cr = xc-xc_c; %Cr conc stays the same
% 
% rc = r_cryst;
% ra = r;
% 
% m = (xc_a-xc_c)./(ra-rc);
% mTF = isinf(m);
% if mTF == 0
%     CurFe = 4.*pi.* (   ((xc_c./3).*rc.^3) + ((m./4).*(ra.^4)) + (((ra.^3)./3).*(xc_c-(m.*rc))) - ((m./4).*rc.^4) - (((rc.^3)./3).*(xc_c-(m.*rc)))    );
%     % Fe_cont = 4.*pi.*(((rho_c./3).*r_c.^3) + ((m./4).*r_a.^4) + ((r_a.^3./3).*(rho_c-(m*r_c))) - ((m./4).*(r_c.^4)) - ((r_c.^3./3).*(rho_c-(m*r_c))));
% 
% else
%     CurFe = xc_c;
% end
% 
% rc_old = r_cryst_old;
% ra_old = r_old;
% 
% m_old = (xc_a-xc_c)./(ra_old-rc_old);
% 
% mTFold = isinf(m_old);
% if mTFold == 0
%     OldFe = 4.*pi.* (   ((xc_c./3).*rc_old.^3) + ((m_old./4).*(ra_old.^4)) + (((ra_old.^3)./3).*(xc_c-(m_old.*rc_old))) - ((m_old./4).*rc_old.^4) - (((rc_old.^3)./3).*(xc_c-(m_old.*rc_old)))    );
% else
%     OldFe = CurFe; %i.e. no solute release
% end
% 
% % CurFe/OldFe gives the average atomic fraction of the SPPs considering the
% % change in solute concentration throughout.
% % Calculate the change in matrix concentration due to this process
% % As the number density of the arrays changes due to dissolution of SPPs,
% % the change in Fe conc from amorphization will use the same (current)
% % number density and just measure the release of Fe through the increased
% % ram. 
% % The change in number density is then kept as a seperate problem to be
% % dealt with in dissolution
% 
% TotCurFe = CurFe.*n;
% TotOldFe = OldFe.*n;
% 
% 
% % vf = 
% % xbinst = (xb - vf.*(xc-xa));
% 
% FeRel = OldFe - CurFe;
% 



% end