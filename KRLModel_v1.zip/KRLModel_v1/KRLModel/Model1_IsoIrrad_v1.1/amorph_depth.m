function [ram] = amorph_depth(h,phi)
%
% Motta et al model to predict depth of amorphous region
% in Zr(Cr,Fe)2 precipitates
%
% All parameters from Motta et al., J. Nuc. Mater. 195 (1995) pp. 277-285
phi_sigma = phi/5e20; %Convert from n/cm2/s to dpa/s
%
c0 = 0.44;
ca = 0.1;
dc = 0.03;
mu = 5e-9;
ram = (1/6) * mu * phi_sigma * h * ((((3/2)*(c0-ca))/dc)-1);
end

%Test up to 10 dpa but at a dose of 1e-5 and 1e-7
% t = 100000000 (1e-7), 1e6 (1e-5)%
%1e-7 ram = 1.17e-7, 1.7e-7

%Motta does use flux but as it is multiplied by time it is essentially a
%fluence and dos not follow with predictions of faster flux leading to
%higher damage on SPPs