function [r,n,rb,r_ln,n_ln,rbarout,vfout,tkout,tout,xbout,npartout,SolSplitout,xbchangeFickout,QR,NSegs,FeConc,CrConc] = ScriptToRun_Quench(tcprof,FeConc,CrConc,radflag,OFN,NSegs)


QR = (tcprof(1,1)-tcprof(1,2))/tcprof(1,3);

if isempty(FeConc) == 1 
FeConc = 0.0033; %in at. frac.
CrConc = 0.0018; 
end

%%%%%%%load 'QuenchTest' %For development

%% Do not edit below without permission!

%%%%%NSegs = 10; %This is 10 by default, simulations can be sped up by decreasing - see K.Lynch thesis for full description

time = (1050-25)./QR;

[r,rb,n,tkprof,xb,xc,sfen,nsites,vmol,a,a_init,sfengb,nsitesgb,Vgrain,Agb,GBWidth]=zr_amorph_init_noniso([1050 25 (time/3600)],FeConc,CrConc,NSegs);%ABQ, from Massih, 2003 the QR should be determined from 1050C to 750C, which is where the lamella thickness relationship is derived.


FickSwitch = 0; %This should be on 1, 0 is not intersegmental diffusion!

[r,n,tout,tkout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout,xaout,growthout,grtrck2,grtrck4,grtrck6,PFZout,r_ln,n_ln,xbinstTrack,hout,Distout,TotalSolDistEnd,dtEnd,dtTrack,firstit,xbinstTotTrackEnd,vfTrack,SolSplitout,xbchangeFickout,Avout]= ...
    zr_amorph_kin_noniso(r,rb,n,tkprof,xb,xc,sfen,sfengb,nsites,vmol,a,a_init,Vgrain,Agb,GBWidth,FickSwitch,0);


for j = 1:1:NSegs
    r_now = r(j,:);
    n_now = n(j,:);
    rbaroutHori = rbarout';
    rbarout_now = rbaroutHori(j,:);
    vfoutHori = vfout';
    vfout_now = vfoutHori(j,:);
  if radflag == 0
    [r_ln_temp,n_ln_temp] = lognrm_adjust_TEST(r_now,n_now,pgpout,rbarout_now,vfout_now);
  end
    r_ln(j,:) = r_ln_temp;
    n_ln(j,:) = n_ln_temp;
end


end