%% This is the master run file for quench and quench/annealing
function OutputStatement = ScriptToRun_Model2_QA(tcprof,Mode_QuenchAnneal,FeConc,CrConc,radflag,OFN,PSDSnap,PSDStage)


%Nstages
NSteps = size(tcprof,1);

Outputs = struct;

if Mode_QuenchAnneal == 1 && NSteps == 1
    error('No annealing steps. Change mode to Quench only.')
end

IterCount = 1;

NSegs = 4; %Keep at 10! Can go lower if speed is priority.

while IterCount <= NSteps
    tcprof_in = tcprof(IterCount,:);
    if IterCount == 1
        cd Quench\
        [r,n,rb,r_ln,n_ln,rbarout,vfout,tkout,tout,xbout,npartout,SolSplitout,xbchangeFickout,QR,NSegs,FeConc,CrConc] = ScriptToRun_Quench(tcprof_in,FeConc,CrConc,radflag,OFN,NSegs);
        cd ..\
    else
        % Only run subsequent annealing if quench and anneal mode is selected
        if Mode_QuenchAnneal == 1
            cd PostQAnneal\
            [r,n,rb,r_ln,n_ln,rbarout,vfout,tkout,tout,xbout,npartout,xbchangeFickout] = ScriptToRun_PostQuenchAnneal(tcprof_in,r_in,rb_in,n_in,xbout,SolSplitout,xbchangeFickout,TimeTotal,QR,NSegs,FeConc,CrConc);
            cd ..\
        end
    end

    r_in = r; n_in = n; rb_in = rb; 
    
    %Outputs Struct
             TimeTotal = tout(end); %Carry the time through the loops
             Outputs(IterCount).Time = tout;
             Outputs(IterCount).SolConc = xbout;
             Outputs(IterCount).NumDenwTime = npartout;
             Outputs(IterCount).MeanRad = rbarout;
             Outputs(IterCount).VolFrac = vfout;
            Outputs(IterCount).Radius = r;
            Outputs(IterCount).NumDen = n;
            Outputs(IterCount).Radius_ln = r_ln;
            Outputs(IterCount).NumDen_ln = n_ln;

        if PSDSnap == 1
           PSDGraphPlot(PSDStage,Outputs,IterCount)
        end

    IterCount = IterCount + 1;
end

%Write output files
Alloy = 4;
FeCrRatio = FeConc/CrConc;
WriteFileZry4QA(Outputs,r,n,r_ln,n_ln,Alloy,FeConc,CrConc,FeCrRatio,tcprof,OFN,NSegs);

% Save r and n now as one PSD so it can be used as an irradiation input.
rSegments = r;
nSegments = n;
r = r(1,:);
n = sum(n);

OFN_matlab = (['../Outputs/' OFN '.mat']); % Choose an output filename 
save([OFN_matlab])

OutputStatement = (['Simulation complete. Please check Outputs folder.']);


end