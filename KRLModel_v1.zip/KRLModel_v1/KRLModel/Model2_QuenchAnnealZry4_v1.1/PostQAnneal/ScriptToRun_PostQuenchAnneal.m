function [r,n,rb,r_ln,n_ln,rbarout,vfout,tkout,tout,xbout,npartout,xbchangeFickout] = ScriptToRun_PostQuenchAnneal(tcprof,r,rb,n,xbout,SolSplitout,xbchangeFickout,TimeTotal,QR,NSegs,FeConc,CrConc)


r_in = r(1,:);
n_in = n;
rb_in = rb(1,:);
xbinst = xbout(end,:);
SolSplit = SolSplitout(end,:);
xbinit = xbout(1,:);

[r,rb,n,tkprof,xb,xc,sfen,nsites,vmol,a,a_init,sfengb,nsitesgb,Vgrain,Agb,GBWidth,xbinst,SolSplit,xbinit,xbchangeFickout]=zr_amorph_init_noniso(tcprof,r_in,rb_in,n_in,xbinst,SolSplit,xbinit,QR,xbchangeFickout,NSegs,FeConc,CrConc);

[r,n,tout,tkout,vfout,rbarout,npartout,npartcritout,nrcritout,nrout,rcout_c,rcout_a,amorphout,xbout,grout,aout,fsout,M,ndump,capout,pgpout,socapout,xaout,growthout,grtrck2,grtrck4,grtrck6,PFZout,r_ln,n_ln,xbinstTrack,hout,Distout,TotalSolDistEnd,dtEnd,dtTrack,firstit,xbinstTotTrackEnd,vfTrack,SolSplitout,xbchangeFickout,Avout,TotModeOut,ArithMeanOut]= ...
    zr_amorph_kin_noniso(r,rb,n,tkprof,xb,xc,sfen,sfengb,nsites,vmol,a,a_init,Vgrain,Agb,GBWidth,xbinst,SolSplit,xbinit,xbchangeFickout,TimeTotal,0);


radflag = 0;
for j = 1:1:NSegs
    r_now = r(j,:);
    n_now = n(j,:);
    rbaroutHori = rbarout';
    rbarout_now = rbaroutHori(j,:);
    vfoutHori = vfout';
    vfout_now = vfoutHori(j,:);
  if radflag == 0
    [r_ln_temp,n_ln_temp] = lognrm_adjust_TEST(r_now,n_now,pgpout,rbarout_now,vfout_now);
  end
    r_ln(j,:) = r_ln_temp;
    n_ln(j,:) = n_ln_temp;
end

end