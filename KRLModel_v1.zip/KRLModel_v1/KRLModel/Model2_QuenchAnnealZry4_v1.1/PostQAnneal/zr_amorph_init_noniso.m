function[r,rb,n,tkprof,xb,xc,sfen,nsites,vmol,a,a_init,sfengb,nsitesgb,Vgrain,Agb,GBWidth,xbinst,SolSplit,xbinit,xbchangeFickout]=zr_amorph_init_noniso(tcprof,r,rb,n,xbinst,SolSplit,xbinit,QR,xbchangeFickout,NSegs,FeConc,CrConc)
%
%
% Initializes parameters for zirconium precipitation model
%
% Need to comment out lines below depending on which alloy is being used
%
% Inputs:
% tcprof    Temperature profile: Each line should be [start_temp/C end_temp/C time/h]
%
% Outputs:
% r         Size bins (mean sizes) (m)
% rb        Size bins (edge sizes) (m)
% tk        Temperature  (K)
% tfinal    Time to calculate for (s)
% xb        Initial concentration of solute (atoms/m^3)
% nsites    Number of nucleation sites  (m^-3)
% sfen      Interfacial energy of precipitate (Jm^-2)
% vmol		Molar volume of precipitate (m^-3/mol)
% vmax		Maximum volume fraction of precipitate
% a			Lattice parameter at end of precipitation (m)
% a_init	Lattice parameter at start of precipitation (m)
%
%
%
% Temperature profile for multistage/non-isothermal heat treatments
% Format [start temp, end temp, time]
%
tkprof(:,1)=tcprof(:,1) + 273;
tkprof(:,2)=tcprof(:,2) + 273;
tkprof(:,3)=tcprof(:,3).*3600;
% nad - adjusts number of nucleation sites as a fraction of number of sites
% for homogeneous nucleation
% nad =1e-9 for Zirc-4 to fit Gros and Wadier data
%nad = 1e-9;
%
%User inputs specifically for quench
%could try and determine relationships to automatically derive this.
% GBWidth = 6.11e-6.*0.5;%1.63e-6.*0.5; %This is the width of the alpha-Zr grains, but should actually be a half-width as it is from grain centre to grain boundary
% GBWidth = 3.67e-6.*0.5;

% Addition to determine GBWidth based on QR
QRMas = QR; %Dummy to avoid complex nuumbers
c0 = 135.246;
L0 = 0.1; %um
Lmas = sqrt((L0.^2) + c0 * (QRMas^-1));
GBWidth = Lmas.*0.5.*1e-6;

Vgrain = 51*1e-18; %Average grain volume (um3)
Agb = 7.43*1e-6*Vgrain; %Average area of grain bounadry per unit volume



% From Massih paper (for Zirc-4)
%
vmol = 9e-6;
ram = 92.906;
a_init = 0.32388e-9; %inital Zr parameter --> for Vergards law calcs
% finds equilibrium solubility (Massih paper data)
xc = 0.66;
%
%
% a Lattice parameter for Zr at end of ppt
a = 0.32425e-9; %Change to average of Fe-Cr and Fe-Ni lattice parameters, as a is the parameter of the *product* phase.
% xb = effective composition Fe + Cr ZIRC-4
xb = FeConc + CrConc;
%
% sfen is interfacial energy for precipitate phase. This is a fitting
% parameter. Massih value = 0.25
%
sfen  = 0.22;
sfengb = 0.22;
% sfen = 0.22;
% sfengb = 0.2;%0.15;
% nad = 1e-9; % This gives good fit to Gros and Wadier sizes (sfen = 0.25)
% nad = 3e-8;
% nadgb = 1e-5;% This gives good fit to Massih et al. sizes (sfen = 0.25) 
%only use nad for trying to create good code as it will reduce nucleation
%rate and speeed up simulations


% Every lattice site in Zr potential nuc. site (Nsites = 4.30e28)
% nsitesM = 4.3e28.*nad; %removed xb as just going to use a nad and then adjust according the the reduction in solute in each segment



a_nsites =    9.2e+19;
b_nsites =    1.27;

nsitesM = a_nsites.*(QR.^b_nsites);

aSv = 3.*1e4;
bSv = 0.7;
Sv = aSv.*QR.^bSv;
VolGB = 0.9e-9*Sv;
ZrAt = 4.3e28;
HetSites = VolGB.*ZrAt;
nsitesgb = HetSites;
% nsitesgb = 5.86e24;

% Set the number of matrix and GB sites equal to all atoms, and gb atoms,
% then in the nucrate script it is adjusted by number of avail

%Determining number of nucleation sites for hetero nuc
% ABQgbVol = 0.154; %this is area of gb per unit volume (um2/um3)
% OBQgbVol = 1.43;
% GBvol = OBQgbVol * 10e-4; %From avg gb width, Plowman 2020 (gb vol in um3 per 1 um3 of material)
% atomsum = 4.3e8 * GBvol;
% atomsm = atomsum*1e18;
% 
% 
% nsitesgb = atomsm.*xb; %number of sites avalaible based on gb area/atoms and mupltiplied by total solute conc.
% %
%Alternative method, from Xiong etal 2018 and Theory of transformations in
%metals and alloys chap 10 JW christian, 2002.

nsitesgb_temp = ((10e-10)*(4.3e28))/(GBWidth); %GB size == 6.11 and 1.63 um resepctively for ABQ and OBQ

% nsitesgb = nsitesgb_temp * nadgb; %Continous nucleation - have to make
% sure nuc_rate doesn't exceed nsites_gb as that physically doesn't make
% sense
% nsitesgb = nsitesgb_temp; %site saturate nucleation

%Try adjusting sfen to increase grain boundary nucleation, as in robson et
%al. could explaing issue with gstar het approach

% nsitesgb = 4.3e28 * nad;%gb sites per um3 of grain boundary, coordiantion number is very similar

% nsitesgb = nsitesM;
% Set up size bins

% scale goes from .1A to um
scale = 1e-11;  
 % steps is number of bins per decade
  steps = 30; %changed from 60
% mindec is lowest log10(radius) in nM
  mindec = 0;
% ndec is number of decades to cover
  ndec = 9;
% number of bin edges
  nb = ndec*steps+1;
  if exist('n','var')==0;
      % get bin edges
    rb = logspace(mindec,mindec+ndec,nb);
    % rb = logspace(mindec,mindec+ndec,nb);
    % get bin centers in the geometric sense
    % r = 10.^(0.5*log10(rb(1:nb-1))+0.5*log10(rb(2:nb)));
    r = 10.^(0.5*log10(rb(1:nb-1))+0.5*log10(rb(2:nb)));
    % scale to M
    % linear size binning
    %scale = 1.5e-7;
    %% Below for predictions for Aaronson paper
    %rb = linspace(0,1,5000);
    %rb = linspace(0,3200,1601);
    %r = ((rb(1:end-1)+rb(2:end))./2);
    rb = (rb*scale);
    r = (r*scale);
    len = length(r);
    n(1:len) = 0;
  end
  Nsegments = NSegs;
r = repmat(r,Nsegments,1); %change integer number in middle to desired number of segments
% n = repmat(n,Nsegments,1);
rb = repmat(rb,Nsegments,1);

%distribution of number of sites
rsz = size(r);
rrows = rsz(1);
nsites = zeros(1,rrows);
nsites(1:end-1) = nsitesM;
nsites(end)=nsitesgb;
end